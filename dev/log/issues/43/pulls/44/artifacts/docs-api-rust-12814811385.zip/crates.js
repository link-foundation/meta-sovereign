window.ALL_CRATES = ["meta_sovereign_core","meta_sovereign_rs","meta_sovereign_server","meta_sovereign_wasm"];
//{"start":21,"fragment_lengths":[21,20,24,22]}