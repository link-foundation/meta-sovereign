(function() {
    const implementors = Object.fromEntries([["meta_sovereign_core",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.99.1/core/cmp/trait.Eq.html\" title=\"trait core::cmp::Eq\">Eq</a> for <a class=\"struct\" href=\"meta_sovereign_core/struct.Link.html\" title=\"struct meta_sovereign_core::Link\">Link</a>",0],["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.99.1/core/cmp/trait.Eq.html\" title=\"trait core::cmp::Eq\">Eq</a> for <a class=\"struct\" href=\"meta_sovereign_core/struct.LinoNode.html\" title=\"struct meta_sovereign_core::LinoNode\">LinoNode</a>",0]]],["meta_sovereign_server",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.99.1/core/cmp/trait.Eq.html\" title=\"trait core::cmp::Eq\">Eq</a> for <a class=\"enum\" href=\"meta_sovereign_server/http/enum.LogFormat.html\" title=\"enum meta_sovereign_server::http::LogFormat\">LogFormat</a>",0]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":59,"fragment_lengths":[545,306]}