(function() {
    const implementors = Object.fromEntries([["meta_sovereign_server",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.99.1/core/marker/trait.Copy.html\" title=\"trait core::marker::Copy\">Copy</a> for <a class=\"enum\" href=\"meta_sovereign_server/http/enum.LogFormat.html\" title=\"enum meta_sovereign_server::http::LogFormat\">LogFormat</a>",0],["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.99.1/core/marker/trait.Copy.html\" title=\"trait core::marker::Copy\">Copy</a> for <a class=\"struct\" href=\"meta_sovereign_server/routes/struct.MetricsCtx.html\" title=\"struct meta_sovereign_server::routes::MetricsCtx\">MetricsCtx</a>",0]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":59,"fragment_lengths":[620]}