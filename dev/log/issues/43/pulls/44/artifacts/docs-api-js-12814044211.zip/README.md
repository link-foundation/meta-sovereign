# meta-sovereign API reference

Generated from JSDoc-style module headers and `export` statements.
Re-run with `npm run docs:api`.

## `js/src/automation/automations.js`

Automations (issue #31, PR #34): user-configurable rules of the form
"trigger → audience → conditions → action", after the triggers of
https://github.com/konard/vk-bot (`{ name, condition, action }` run on
new messages or on a schedule) and the daily caps, de-duplication
ledger and confirm-before-send habits of
https://github.com/konard/hh-job-application-automation.

An automation is stored as an `automation:<id>` link:

  triggers    [{ kind: 'manual' }]               run on demand (selected
                                                 people, an audience)
              [{ kind: 'chat-menu' }]            offered in every chat's menu
              [{ kind: 'schedule', every: '1d' }]
              [{ kind: 'incoming', pattern, flags }]
  audience    a people.js audience spec or its text form; defaults to
              everyone we have a personal chat with
  conditions  { silentDays, mutual, personal, lastFrom, networks,
                cooldownDays }
  action      { kind: 'send-template', templates: { informal, formal,
                neutral? }, form: 'auto' | 'informal' | 'formal' }
  mode        'safe' — every message is a draft the user confirms in the
              chat; 'auto' — sent with typing and human-like pauses
  pacing      { minDelayMs, maxDelayMs, typing, charsPerMinute,
                maxTypingMs, dailyCap }
  limit       most messages per run

Re-engaging dormant contacts (the original ask of issue #31) is just the
`reengage-dormant` preset. Everything here is pure over a list of links;
sending lives in `./runner.js`.

**Exports**

- `ADDRESS_CHOICES`
- `AUTOMATION_MODES`
- `AUTOMATION_PREFIX`
- `AUTOPILOT_PREFIX`
- `DEFAULT_COOLDOWN_DAYS`
- `DEFAULT_PACING`
- `DRAFT_PREFIX`
- `EDIT_PREFIX`
- `RUN_PREFIX`
- `STATE_PREFIX`
- `TRIGGER_KINDS`
- `automationKey`
- `automationPresets`
- `draftFor`
- `draftId`
- `editAfterSend`
- `editId`
- `hasTrigger`
- `incomingTrigger`
- `normalizeAutomation`
- `parseDuration`
- `planAutomation`
- `redraftWithForm`
- `runRecordId`
- `templateFromText`
- `withEdit`

## `js/src/automation/autopilot.js`

Autopilot (R-Y87): an automation goes through every chat it fits by
itself — the user's edited text included (R-Y86) — one chat at a time,
as a person would: typing, send, a pause of the automation's pacing,
the next one, and no more than its daily cap.

Its state is the `automation-autopilot:<automation>` link, streamed to
the app: which chat it is on (`current`), what it did (`sent`,
`failed`), how many are left and when it goes on (`nextAt`). With
`monitor` on, the app opens each chat as the autopilot comes to it, so
the user watches it work; turning the monitor off leaves it working.

A chat that cannot be written to is passed over; one the network
cannot reach now (no connection, signed out) pauses the autopilot with
the reason. It stays on across a restart of the server until the user
stops it or no chat is left.

**Exports**

- `afterFailure`
- `autopilotId`
- `createAutopilot`

## `js/src/automation/drafts.js`

Safe-mode drafts (see `./runner.js`), without timers or Node modules so
the browser can hold drafts while no server is up: load an automation
(a saved link or a preset), queue drafts, and settle them — send after
confirmation, switch "ты"/"вы", mark as sent by hand, or skip.

**Exports**

- `ConfirmationRequiredError`
- `draftOperations`
- `listAutomations`
- `loadAutomation`
- `queueDrafts`
- `runRecord`

## `js/src/automation/index.js`

Automation graph (R-C3, R-C4).

A graph is a set of nodes and directed edges. Node kinds:
  - `pattern`   — fires when its regex matches an incoming message.
  - `reply`     — picks a variation from a `ReplyVariationGroup`.
  - `branch`    — conditional split based on previous outputs.
  - `wait`      — pauses until the partner sends another message.
  - `send`      — outputs a message via the chosen `MessageSource`.

`runGraph` evaluates the graph for a given inbound message and
returns the planned outbound messages. In `auto` mode they are sent
directly; in `semi` mode they are returned as suggestions for the
Operator UI to confirm.

**Exports**

- `addEdge`
- `addNode`
- `createGraph`
- `runGraph`

## `js/src/automation/next-chat.js`

The next chat an automation fits (R-Y86). What the user sent — their
edit of the automation's text, kept as `automation-edit:<automation>`
with names turned back into `{name}`/`{first}` — is what the next chat
gets, until they send its own text again or reset it. The autopilot
(R-Y87) goes through the chats one `next` at a time.

**Exports**

- `nextChatOperations`

## `js/src/automation/outbox.js`

The durable outbox and the one guarded send function (R-Z3).

Every automated send (automations, the autopilot, greetings, re-engage
sessions, broadcast and outreach) goes through `guardedSend`:

  1. refuse a chat on the opt-out list (nothing is written, nothing sent);
  2. refuse a key already `sending`, `sent` or `unknown` (a double click,
     a rerun, a restart): never send twice;
  3. write `outbox:<key>` as `{ status: 'sending' }` BEFORE the send; if
     that write fails nothing is sent;
  4. send with the key as the draft's `clientId` (Telegram turns it into
     the message's `random_id`, so even a lost answer cannot duplicate);
  5. write `sent`; a failing store write after a successful send is only
     logged and never becomes `failed` (the record stays `sending`, which
     a restart turns into `unknown`, and nothing resends either);
     `failed` for a definite refusal, `unknown` for a timeout or reset.

After a crash `recoverOutbox` turns every `sending` record into
`unknown`. An `unknown` send is NEVER retried by itself: the page lists
it and the user decides (`resolveOutbox`: it arrived, or it did not).

**Exports**

- `DAY_MS`
- `MAX_CONSECUTIVE_FAILURES`
- `OUTBOX_PREFIX`
- `OUTBOX_STATUSES`
- `batchStopReason`
- `guardedSend`
- `hashText`
- `isAmbiguous`
- `isRateLimit`
- `listOutbox`
- `outboxId`
- `outboxKey`
- `recentSends`
- `recoverOutbox`
- `resolveOutbox`
- `transientStore`

## `js/src/automation/paced-send.js`

Paced automatic sends (R-Z3): one draft after another with the
automation's pauses, up to its daily cap (the ledger and the outbox
count together), stopping the whole batch on a rate limit, a send in
doubt, or too many failures in a row.

**Exports**

- `createPacedSender`

## `js/src/automation/record-outcome.js`

After a guarded send (R-Z3): the chat history and the run ledger. The
outbox already holds the truth, so a store that fails here never turns
a send that went out into a failure (and nothing is resent).

**Exports**

- `recordOutcome`

## `js/src/automation/runner.js`

Running automations (see `./automations.js`): drafts, confirmed sends,
paced automatic sends with a typing status, and the scheduler that
fires `schedule` and `incoming` triggers.

Safe mode never sends on its own: a run writes one
`automation-draft:<automation>:<source>:<chat>` link per person, the
chat screen shows it pre-filled, and the user sends, edits, switches
"ты"/"вы", marks it as sent by hand, or skips it. Auto mode sends
through `send(draft)` (the adapter, falling back to the official web
UI) like a person would, after vk-bot's outgoing queue: show "typing…"
for as long as the text takes to type, send, then wait a random pause
before the next one, and stop at the daily cap.

Every outcome is an `automation-run:<automation>:<source>:<chat>` link,
which is the cooldown ledger; sent messages are also stored as
ordinary `msg:` links so the chat and the reply graph see them.

**Exports**

- `ConfirmationRequiredError`
- `createAutomationRunner`
- `createAutomationScheduler`
- `stillConfirmed`
- `typingDurationMs`

## `js/src/automation/safety.js`

Send safety settings shared by every automated send (R-Z3): quiet
hours, the opt-out list (chats and people never to message) and the
reasons a chat cannot be written to at all (blocked us, we left it,
a deleted account, a bot, a channel).

One `automation-settings:global` link holds them; the page edits it
(`GET`/`PUT /api/automations/settings`). Pure and free of Node modules
so the browser can plan with it too.

**Exports**

- `DEFAULT_QUIET_HOURS`
- `SETTINGS_ID`
- `loadSettings`
- `normalizeSettings`
- `optOutEntry`
- `quietMsLeft`
- `saveSettings`
- `unreachableReason`

## `js/src/broadcast/index.js`

Broadcast (R-B4) and profile/resume sync (R-D5, R-D6).

Outbound posting wraps each network's adapter; the function below
accepts a list of target networks and posts the same message via
each adapter's `live.post()` method. Adapters that do not yet
implement `post` raise — surfacing the gap clearly rather than
silently dropping.

**Exports**

- `broadcast`
- `planOutreach`
- `runOutreach`
- `syncProfile`
- `syncResume`

## `js/src/cli/automation-commands.js`

Automations from the terminal (issue #31 / PR #34) — the same engine
as the server and the chat menu (`../automation/runner.js`):

- `automations` / `automations list` — saved automations and presets.
- `automations plan <id>` — who would get what, and why the rest are
  left out. Nothing is written.
- `automations run <id>` — safe mode queues one draft per person; auto
  mode shows the planned messages and sends exactly those (typing,
  pacing, daily cap) after a y on the terminal, or with `--yes`
  (`--confirm=true`) in scripts.
- `automations review` — safe (debug) mode: one pending draft at a
  time; each is sent only after the user answers `y`, and can be
  edited, switched to the other "ты"/"вы" form, marked as sent by
  hand, or skipped.
- `automations drafts | history | save <file.json> | delete <id>`.

`--chat=vk:101,telegram:5` narrows a plan or run to chosen chats (what
the chat menu does); with `--test` the conditions are ignored there.

**Exports**

- `AUTOMATION_HELP`
- `createAutomationCommands`

## `js/src/cli/browser-open.js`

**Exports**

- `maybeOpenHostedApp`

## `js/src/cli/confirm.js`

**Exports**

- `confirmCli`

## `js/src/cli/contact-commands.js`

**Exports**

- `CONTACTS_HELP`
- `createContactCommands`

## `js/src/cli/cv-commands.js`

CV subcommands (issue #29, R-V17).

The terminal gets the same surface as the HTTP API: the catalogue
and the dry-run plans answer without a browser, `cv-read`/`cv-sync`
drive one through the facade, and `cv-telemetry` replays what a run
recorded so a failed live run is debuggable after the fact.

The command map is built by a factory so the CLI entry point injects
its own `openStore` (and the tests inject a fake commander) without
this module importing the entry point back.

**Exports**

- `CV_HELP`
- `createCvCommands`
- `parseList`
- `parsePlatforms`
- `parseVars`

## `js/src/cli/greetings-commands.js`

Greeting subcommands (issue #35).

The terminal gets the same surface as `/api/greetings/*`: browse the
built-in or live sticker catalogue, save which stickers and phrases
to greet with, preview a plan and send it. Sending pauses between
messages the way konard/vk-bot does (30 s by default) so a batch of
greetings does not look like a burst of spam.

The command map is built by a factory so the CLI entry point injects
its own `openStore`, and the tests inject fake source adapters.

**Exports**

- `DEFAULT_SEND_DELAY_MS`
- `GREETINGS_HELP`
- `createGreetingCommands`
- `parseStickerList`
- `planOptions`

## `js/src/cli/index.js`

meta-sovereign CLI (R-F2).

Subcommands cover the full feature surface so every capability the
server exposes is also reachable from the terminal: import/export,
backup/restore, serve, sources, audience, facts, search, broadcast,
sync (listen/connect), patterns (infer/list), graphs (run/list),
replies (list), profile/resume, cv (platforms/plan/read/diff/sync/
telemetry over browser-commander), automations (plan/run/review drafts),
greetings (stickers/select/plan/send).

Returns an exit code instead of calling `process.exit`, keeping the
entry point unit-testable.

**Exports**

- `runCli`

## `js/src/cli/lino-args.js`

Tiny `lino-arguments`-compatible parser (R-F2).

Accepts both `--key value` and `--key=value`. Boolean flags are
single tokens like `--auto`. Positional arguments are returned in
`_`. This is a stand-in for the real `lino-arguments` package; it
satisfies the prototype's CLI without taking a dep before the npm
package is published.

**Exports**

- `parseArgs`

## `js/src/cli/migrate-commands.js`

`meta-sovereign migrate` (R-Z17): bring a store folder to the data
schema this build writes, or say what that would do.

  migrate --store=<dir>             migrate now (takes the store lock)
  migrate --store=<dir> --dry-run   count what would change; writes nothing
  migrate --store=<dir> --status    the store's schema version and history

A store is migrated by every command that opens it for writing and by
`serve`; this command is for doing it on purpose, or looking first.

**Exports**

- `MIGRATE_HELP`
- `SCHEMA_ERROR_CODES`
- `createMigrateCommands`
- `migrationNotice`

## `js/src/cli/rolling-serve.js`

**Exports**

- `startRollingCliServer`
- `upgradeRunningServer`

## `js/src/cli/trust-commands.js`

`meta-sovereign trust` (R-Y64).

Safari lets the hosted app reach the local server only over https,
with a certificate it trusts. `serve` makes that certificate for
localhost and 127.0.0.1 only (../server/local-tls.js); this command
asks macOS to trust it for TLS, once. macOS shows its own password
prompt, so nothing is trusted without the person's consent. On other
systems it prints where the certificate is and how to trust it.

The runner is injected so the tests never touch a real keychain.

**Exports**

- `TRUST_HELP`
- `certificateIsTrusted`
- `createTrustCommands`
- `setupLocalCertificate`
- `trustCommandFor`
- `waitForLocalCertificate`

## `js/src/crm/address-form.js`

Address-form detection (issue #31, R-X3..R-X5).

Russian — like Chinese, Hindi and most European languages — has two
ways to say "you": the familiar "ты" and the polite "вы". A message
that reopens an old conversation has to keep whichever one the two
people used, so the planner reads the dialog and counts markers of
each form.

Markers are word-level regexes, grouped by language. Each one is a
whole word (Unicode-aware boundaries, because `\b` only knows ASCII
letters), so "вы" never fires inside "выход" and "ты" never fires
inside "работы". The marker table is data, so callers can add their
own rules — including `pattern:*` links from the Patterns screen
labelled `address:informal` or `address:formal`.

Deliberately left out: Russian 2nd-person-plural verb endings
(`-ете`/`-ите`), because the same endings close dozens of nouns in
the prepositional case ("в интернете", "на сайте"). Only a curated
list of polite verbs is counted. The singular endings `-ешь`/`-ишь`
have no such collisions and are counted as a morphological rule.

**Exports**

- `ADDRESS_FORMS`
- `addressRulesFromPatterns`
- `defaultAddressRules`
- `definedOnly`
- `detectAddressForm`
- `scoreAddressForm`

## `js/src/crm/audience.js`

Audience expression DSL (R-D2).

A small set-algebra over store links so callers can describe a
target audience as text — used by the server (`/api/audience`),
the CLI (`audience` subcommand) and the outreach flow.

Grammar:
  expr   := or
  or     := and ("OR" and)*
  and    := primary ("AND" primary)*
  primary := "NOT" primary | "(" expr ")" | atom
  atom   := <dim>:<value>
  dim    := network | chat | sender | fact | kind | body | since | before | me

Examples:
  network:telegram AND NOT chat:42
  (network:telegram OR network:vk) AND fact:speaks_russian
  body:hello AND since:2024-01-01
  kind:msg AND me  (every message I sent)

**Exports**

- `evalAudience`
- `parseAudience`

## `js/src/crm/index.js`

CRM module (R-D1..R-D4).

- `aggregateContact(store, contactId)` collects every link
  referencing the contact into a single view.
- Set-algebra over saved queries: `intersect`, `union`, `difference`.
- `localSearch` runs a Dice-similarity scan over messages, contacts,
  chats, communities — the simplest implementation that satisfies
  "configurable parameters" without taking a search-index dep yet.

**Exports**

- `aggregateContact`
- `difference`
- `intersect`
- `localSearch`
- `union`

## `js/src/crm/people.js`

People directory, cross references and audience specs (issue #31,
PR #34).

PR #34 asks for automation "triggered manually on selected users
(which should be searchable, and cross referenced)" and for audiences
merged from friends, chats, communities and lists — e.g. the
intersection of several lists, so exactly the right people are
targeted.

- `buildPeople` folds messages, `person:` links, `member:` links and
  saved `list:` links into one entry per `<source>:<user>`.
- `crossReference` suggests (never merges) the same human on several
  networks by name or handle; confirmed matches live in `sameAs`.
- `searchPeople` ranks exact > prefix > substring matches.
- Audience specs are JSON (`{ kind: 'intersect', of: [...] }`) with a
  compact text form (`friends:vk & chat:vk:2000000001 - list:blocked`)
  so an audience can be typed, saved and shown alike.

Everything is pure over a list of links, like `./reengage.js`, so the
CLI, the server and the offline SPA share one implementation.

**Exports**

- `AUDIENCE_KINDS`
- `AUDIENCE_PREFIX`
- `LIST_PREFIX`
- `audienceLink`
- `buildPeople`
- `crossReference`
- `formatAudienceSpec`
- `listLink`
- `parseAudienceSpec`
- `peopleIndex`
- `personKey`
- `resolveAudience`
- `searchPeople`
- `splitPersonKey`
- `stubPerson`
- `toAudienceSpec`

## `js/src/crm/person-learn.js`

What a conversation tells about the person on the other side
(R-Y50 .. R-Y53), learned from the stored history only:

  - the questions asked and their answers (either side asking);
  - how the two address each other, "ты" or "вы": an agreement
    ("на ты?" — "давай") wins over the form simply used;
  - their occupation, position and workplace, from what they said
    about themselves or answered when asked;
  - their accounts elsewhere (LinkedIn, GitHub, …), from links they
    sent themselves.

Pure: messages in (`{ id, sender, body, timestamp }`, ours with
sender `me`), facts out. Nothing here reads the network; whether a
GitHub account links back is ./github-check.js.

**Exports**

- `QUESTION_INTENTS`
- `addressFormOf`
- `groupQuestions`
- `intentOf`
- `isQuestion`
- `learnAccounts`
- `learnAddress`
- `learnConversation`
- `learnPerson`
- `learnWork`
- `questionAnswers`
- `sameQuestion`

## `js/src/crm/reengage.js`

Re-engage dormant personal contacts (issue #31, R-X1..R-X9).

The flow is: find every 1:1 conversation that has been silent for at
least `days` (90 by default), work out whether the two people used
"ты" or "вы" (see `./address-form.js`), render the matching template
and hand the drafts to a session that, by default, sends exactly one
message per explicit confirmation.

Everything here is pure over a list of links, so the CLI, the server
and the SPA (fully offline) share one implementation. Sending is the
only side effect and it is injected.

Every decision is written back to the store as a
`reengage:<source>:<chat>` link (`sent`, `skipped` or `failed`), so a
contact who was just messaged — or deliberately skipped — is not
offered again until the cooldown has passed.

**Exports**

- `DAY_MS`
- `DEFAULT_DORMANT_DAYS`
- `REENGAGE_MODES`
- `REENGAGE_PREFIX`
- `SafeModeError`
- `buildReengageRecord`
- `createAdapterSender`
- `createReengageSession`
- `defaultReengageTemplates`
- `detectSelfIds`
- `findDormantContacts`
- `firstName`
- `groupByChat`
- `isPersonalChatType`
- `normalizeReengageMode`
- `personalPartner`
- `planReengagement`
- `prefillLinkFor`
- `reengageRecordId`
- `renderReengageText`
- `templateFor`
- `withAddressForm`

## `js/src/crm/words.js`

Words and the gaps between them, read by a tiny parsing expression
grammar — the temporary way to compare questions (R-Y57) until
link-assistant/formal-ai can tell two of the same meaning apart from
two that only look alike (link-assistant/formal-ai#1330):

  text   ← (word / number / gap)*
  word   ← letter (letter / mark / inner)*
  inner  ← [-'’] &letter            "кто-то", "don't" stay one word
  number ← digit+ ([.,:] digit+)*   "2.5", "10:30"
  gap    ← (!letter !digit .)+      spaces, punctuation, emoji

Every rule is an anchored (sticky) pattern tried in order, as a PEG
tries its choices, so the text is read once, left to right, and every
character belongs to exactly one token.

**Exports**

- `foldWord`
- `overlap`
- `sameWords`
- `stemOf`
- `stemsOf`
- `tokensOf`
- `wordsOf`

## `js/src/cv/browser.js`

Browser session factory for CV plans (R-V14).

`browser-commander` and `playwright` are optional dependencies: the
model, the diff, the plans and the telemetry all work without a
browser, and only an actual read/write run needs one. This module is
the single place that knows how to obtain a commander, so the CLI,
the server and the tests share one story — including the story we
tell when the packages are missing.

Every dependency is injectable, which is what lets the unit tests
exercise the failure paths (missing package, launch failure, close
failure) without downloading a Chromium.

**Exports**

- `BROWSER_PACKAGES`
- `BrowserUnavailableError`
- `browserAvailability`
- `defaultProfileDir`
- `launchWithCommander`
- `openBrowserSession`
- `withBrowserSession`

## `js/src/cv/diff.js`

CV comparison: field-level diffs between two snapshots and a
cross-platform agreement matrix (R-V2).

Both operations are built on one flattening pass that turns a CV
into stable `path → value` pairs. Repeated records are keyed by
their identity fields rather than by array position, so inserting a
job at the top of an experience list does not report every later
entry as changed.

**Exports**

- `applyFlatChanges`
- `compareCvs`
- `cvFromFlat`
- `cvsEqual`
- `diffCv`
- `flattenCv`
- `formatChange`
- `formatDiff`
- `reconcileCvs`

## `js/src/cv/index.js`

CV synchronisation facade (R-V15).

Everything below composes the four layers that live next to it:
the canonical model, the keyed diff, the declarative platform plans
and the plan runner. Callers — CLI, server, SPA, tests — only ever
touch this module, so "read one", "read all", "compare" and "push
the reconciled values back" behave identically everywhere.

Nothing here needs a browser unless a live run is requested: a
commander can be injected, which is how the whole flow is tested.

**Exports**

- `BROWSER_PACKAGES`
- `BrowserUnavailableError`
- `CV_TELEMETRY_PREFIX`
- `browserAvailability`
- `compareAllCvs`
- `createCvRunner`
- `cvPlatformCatalogue`
- `defaultProfileDir`
- `describeCvPlatform`
- `diffAllCvs`
- `dryRunPlan`
- `getCvPlatform`
- `listCvPlatforms`
- `loadCvTelemetry`
- `loadStoredCvs`
- `openBrowserSession`
- `readAllCvs`
- `readCvFrom`
- `summarizeCvRuns`
- `syncCvAcross`
- `updateCvOn`
- `validateCvPlatforms`
- `withBrowserSession`

## `js/src/cv/model.js`

Canonical CV model and its Links Notation projection (R-V1).

Every platform adapter reads into — and writes out of — this single
shape, so a LinkedIn CV and a TopCV CV can be diffed field by field
without any platform-specific knowledge leaking into the comparison
code. The notation projection reuses the repository's indented
links-notation reader/writer, which makes a CV just another link
tree inside the store.

**Exports**

- `BOOLEAN_FIELDS`
- `CV_SECTIONS`
- `LIST_SECTIONS`
- `MAP_SECTIONS`
- `RECORD_KEY_FIELDS`
- `RECORD_SECTIONS`
- `cvFieldCount`
- `cvFromLink`
- `cvFromLino`
- `cvLinkId`
- `cvToLink`
- `cvToLino`
- `cvToLinoNodes`
- `emptyCv`
- `isCvPath`
- `normalizeCv`
- `recordKey`

## `js/src/cv/platforms/define.js`

Platform descriptor factory (R-V3).

A descriptor bundles everything the runner, the CLI and the SPA need
to know about one job board: where its CV lives, how a session is
established, what we have actually observed on the public internet,
and the ordered plans for reading and updating. Derived fields
(supported paths, confidence tally) are computed here so callers
never recompute them inconsistently.

**Exports**

- `definePlatform`
- `updateGroup`
- `validatePlatform`

## `js/src/cv/platforms/habr-career.js`

Habr Career (career.habr.com) CV plan — R-V5.

Career renders the whole profile into a single server-side state
blob (`script[type="application/json"][data-ssr-state="true"]`), so
reading is a JSON mapping rather than selector archaeology. The DOM
selectors below are kept as a documented fallback and were observed
on a public profile on 2026-09-16.

Editing is owner-only: every resume section of the state carries an
`edit` field that is `null` for guests and holds the section's edit
URL for the owner, so the update plan discovers edit targets at
runtime instead of hard-coding paths we could not verify.

**Exports**

- `habrCareerCvPlatform`
- `habrEditTargets`
- `habrStateToCv`

## `js/src/cv/platforms/hh.js`

hh.ru CV plan — R-V6.

hh publishes a large OpenAPI specification, but it contains no
applicant-side resume mutation: `/resumes/{resume_id}` is read-only
(`operationId: get-resume`) and the applicant's own list is only
referenced as `resumes_url` → `https://api.hh.ru/resumes/mine`.
Everything that changes a resume happens in the web UI, which is why
this platform is driven through browser-commander.

hh markup is annotated with `data-qa` attributes — the same
convention browser-commander itself prefers when it has to synthesise
a unique selector — so the plan targets those rather than class
names, and every selector is reported through telemetry until an
authenticated run confirms it.

**Exports**

- `hhCvPlatform`

## `js/src/cv/platforms/index.js`

Registry of CV platforms (R-V12).

The issue names LinkedIn, hh.ru, Habr Career, Naukri, VietnamWorks
and TopCV; SuperJob joins them because the server already advertises
it as a resume sync target. Every consumer — CLI, HTTP routes, SPA —
reads the catalogue from here so a new platform is registered once.

**Exports**

- `cvPlatformCatalogue`
- `cvPlatforms`
- `describeCvPlatform`
- `getCvPlatform`
- `habrCareerCvPlatform`
- `hhCvPlatform`
- `linkedinCvPlatform`
- `listCvPlatforms`
- `naukriCvPlatform`
- `superjobCvPlatform`
- `topcvCvPlatform`
- `validateCvPlatforms`
- `validatePlatform`
- `vietnamworksCvPlatform`

## `js/src/cv/platforms/linkedin.js`

LinkedIn CV plan — R-V7.

LinkedIn has no public profile-editing API: the Profile API is
gated behind partner programs, so the supported route for keeping a
profile current is the member's own browser session. `/in/me/`
resolves to the signed-in member's profile, which lets the plan work
without knowing the vanity URL, and redirects to `/uas/login` when
the session is gone — the plan's authentication check.

**Exports**

- `linkedinCvPlatform`

## `js/src/cv/platforms/naukri.js`

Naukri.com CV plan — R-V8.

Naukri keeps the applicant profile behind `/mnjuser/profile` and
bounces anonymous visitors to `/nlogin/login` with the original path
in the `URL` query parameter — a redirect we confirmed ourselves and
that the plan uses as its session check. Naukri's public APIs cover
job search only, so profile edits go through the UI.

**Exports**

- `naukriCvPlatform`

## `js/src/cv/platforms/parse.js`

Text normalisation shared by the platform mappers (R-V4).

Job boards render the same facts in wildly different shapes: Habr
Career ships rich HTML inside a JSON blob and Russian month names,
VietnamWorks and TopCV use Vietnamese ones, LinkedIn uses English.
Normalising here — rather than in each descriptor — is what makes a
cross-platform diff meaningful instead of a wall of formatting
noise.

**Exports**

- `PRESENT_MARKERS`
- `clean`
- `isPresent`
- `parseDuration`
- `parseLanguage`
- `parseMonth`
- `stripHtml`
- `uniqueList`

## `js/src/cv/platforms/steps.js`

Step vocabulary shared by every CV platform plan (R-V3).

A plan is plain data: an ordered list of steps that the runner
interprets against a browser-commander instance. Keeping the plans
declarative means they can be inspected, printed, diffed and tested
without a browser, which is what lets us ship complete drafts for
platforms whose authenticated markup we have not seen yet.

**Exports**

- `CONFIDENCE_LEVELS`
- `STEP_ACTIONS`
- `click`
- `draftSteps`
- `extractJson`
- `fill`
- `goto`
- `press`
- `read`
- `readAttribute`
- `readList`
- `readRecords`
- `requireUrl`
- `screenshot`
- `snapshot`
- `validateSteps`
- `waitFor`

## `js/src/cv/platforms/superjob.js`

SuperJob CV plan — R-V11.

SuperJob is already a message source in this repository and is one of
the resume sync targets the server announces, so its CV plan lives
here for parity even though the issue lists it only implicitly. The
resume area answers 200 without authentication, which makes it the
cheapest platform to smoke-test the runner against.

**Exports**

- `superjobCvPlatform`

## `js/src/cv/platforms/topcv.js`

TopCV CV plan — R-V10.

TopCV rejects plain HTTP clients outright: every path we probed —
including the home page — answered 403 to curl with a desktop user
agent. That is itself the finding that justifies browser automation
here; the URLs below are recorded as candidates and the first
authenticated run confirms them through telemetry.

**Exports**

- `topcvCvPlatform`

## `js/src/cv/platforms/vietnamworks.js`

VietnamWorks CV plan — R-V9.

VietnamWorks is a Next.js application: `/my-profile` answers 200 even
for guests, but its `__NEXT_DATA__` payload carries only
`{params, userIP}` — the profile itself is fetched client-side after
authentication. The plan therefore extracts `__NEXT_DATA__` when the
page ships one (so an authenticated run captures whatever the server
does embed) and otherwise reads the rendered DOM.

Class names are hashed CSS modules (`ProfileStrength_header__JzLOw`)
and styled-components (`sc-2eb60299-0`), which change on every build,
so selectors anchor on the stable module prefix via `[class*="…"]`
and on the `data-tab` attributes the app ships.

**Exports**

- `vietnamworksCvPlatform`
- `vietnamworksNextDataToCv`

## `js/src/cv/runner.js`

Plan runner (R-V14).

Interprets a platform's declarative steps against a browser-commander
instance. The runner knows nothing about any particular job board:
everything site-specific lives in the descriptors, so adding a
platform never means touching this file, and a plan can be replayed
against a fake commander in tests without a browser.

Every step goes through telemetry, including the ones that miss, so
the first authenticated run against a platform whose selectors are
still drafts produces a log that says exactly which selector to fix.

**Exports**

- `assignPath`
- `createCvRunner`
- `dryRunPlan`
- `hasUnresolved`
- `mergeCv`
- `resolveTemplate`
- `selectorCandidates`
- `valueAtPath`

## `js/src/cv/telemetry.js`

CV automation telemetry (R-V13).

The issue asks for full observability *before* we have authenticated
access: "as soon as we start testing we will be able to get all logs,
recordings of markup change and so on, so it will be easy to debug
and fix everything". So every run records, per step: what it tried,
which selector matched (and which fallback did, if the first missed),
how long it took, what it read or wrote, and a fingerprint of the
markup it saw. Fingerprints are diffed against the previous run, so a
silent layout change on hh.ru or LinkedIn surfaces as a
`markup.changed` event instead of an empty CV.

Personal data is redacted by default: telemetry is meant to be
attachable to a bug report.

**Exports**

- `TELEMETRY_EVENTS`
- `baselineFromReport`
- `combineSinks`
- `createJsonlSink`
- `createMemorySink`
- `createStoreSink`
- `createTelemetryRun`
- `diffFingerprint`
- `fileSafeSegment`
- `fingerprintMarkup`
- `redactText`
- `runIdFor`

## `js/src/facts/index.js`

Fact extraction (R-C5).

Given a list of `Pattern`s, scan a chat's messages for
`question → answer` pairs: a message that matches a question
pattern, immediately followed by a partner reply, becomes a fact
attributed to that partner. Output is grouped by participant so it
works in group chats.

**Exports**

- `extractFacts`

## `js/src/greetings/catalog.js`

Greeting catalogue (issue #35): what each network can send to open
a dialog, and which stickers we offer out of the box.

No artwork lives in this repository. Every sticker is referenced by
its network id plus a direct preview link served by the network
itself, so the UI can show it and the adapter can send it. Packs we
cannot enumerate in advance are listed live through the network's
API (`listGreetingStickers` in `./index.js`).

**Exports**

- `builtInGreetingStickers`
- `facebookGreetingStickers`
- `greetingNetworks`
- `greetingTexts`
- `telegramDefaultGreetings`
- `telegramGreetingSets`
- `vkGreetingStickers`
- `vkIncomingGreetingStickerIds`
- `vkStickerPreview`

## `js/src/greetings/detect.js`

Greeting detection (issue #35).

A greeting is a message that carries nothing but a "hi": `Привет!`,
`hello there`, `你好`, `नमस्ते`, `xin chào`, a waving-hand emoji, or a
sticker from the greeting catalogue. The Russian pattern is ported
verbatim from konard/vk-bot `triggers/greeting.js` (public domain),
where it has been answering real VK dialogs; the other languages
follow the same shape — the whole message must be greeting words,
optional addressees ("тебе", "everyone") and punctuation, so
"hi, can you review my PR?" is a question, not a greeting.

**Exports**

- `detectGreetingLanguage`
- `greetingEmoji`
- `greetingPatterns`
- `isGreetingMessage`
- `isGreetingText`

## `js/src/greetings/index.js`

Greetings (issue #35): open dialogs with a "hi" or a greeting sticker.

Starting a conversation is the slow, repetitive part of outreach, so
this module does it in bulk the way konard/vk-bot does on VK:

  - `planGreetings({links, mode: 'initiate'})` picks chats we have
    never written to — and, after them, chats that went quiet longest
    ago — and assigns each a greeting sticker or text;
  - `planGreetings({links, mode: 'reply'})` picks chats whose last
    message is an unanswered greeting ("Привет!", "hi", 👋, a
    greeting sticker) and answers in kind;
  - `runGreetings(plan, {store})` sends through each network's
    `live.post` (stickers where the network has them, text
    otherwise) and records `greeting:<network>:<chat>` so the same
    chat is not greeted twice.

The planner is pure and deterministic given `random`, so the UI can
preview exactly what a queue run will send.

**Exports**

- `DEFAULT_DELAY_MS`
- `GREETING_LIMITS`
- `MIN_DELAY_MS`
- `isRateLimit`
- `listLiveGreetingStickers`
- `loadGreetingCredentials`
- `previewGreetings`
- `runGreetings`

## `js/src/greetings/plan.js`

Greetings planning (issue #35): the browser-safe half of the
subsystem. Catalogue, detection, selection and the pure planner live
here; sending (`runGreetings`) and live listing live in `./index.js`,
which needs the network adapters.

The SPA imports this module, not `./index.js`: the adapters include
code the page's Content Security Policy forbids (`new Function`), so
pulling them into the bundle stops the whole app from starting.

**Exports**

- `GREETING_SELECTION_ID`
- `defaultGreetingSelection`
- `greetingCatalogue`
- `greetingLinkId`
- `knownGreetingStickerIds`
- `loadGreetingSelection`
- `normalizeGreetingSelection`
- `planFromStore`
- `planGreetings`
- `saveGreetingSelection`
- `summarizeChats`

## `js/src/handlers/index.js`

Data-driven handler runtime.

Implements the architecture described in
https://habr.com/ru/companies/deepfoundation/articles/656879 :
components do not call each other directly, they read and write
to the central links store; reactions are handlers registered
against link create/update/delete events.

Two correctness properties matter:

1. **At-most-once across replication.** When a handler reacts to
   a link, it stamps that link with `handledBy[handlerId] = ts`.
   On the next put coming back through sync the bus checks the
   stamp and skips already-handled handlers, so two peers cannot
   both send the same broadcast or both fire the same automation
   graph just because the link round-trips.

2. **Causality.** Handlers may write further links back into the
   store; the bus is reentrant and serialises events per link id
   so a handler that writes a follow-up link sees the original
   update before its own write echoes back.

The bus is intentionally transport-agnostic: it just wraps a
`UniversalLinksAccess`. Whoever owns the store (server, browser,
Electron renderer) can attach the same handler set; the
`handledBy` stamp prevents duplicate work after the next sync.

**Exports**

- `automationHandler`
- `broadcastHandler`
- `createHandlerBus`
- `outreachHandler`
- `profileSyncHandler`
- `resumeSyncHandler`
- `sourcePullHandler`

## `js/src/index.js`

meta-sovereign — Personal Meta Profile Sovereign system.

Public entry point. The library is organised by subsystem; each
sub-export is also published as its own NPM-importable path so
downstream apps can depend on just the slice they need (R-F1).

**Exports**

- `runCli`
- `startServer`

## `js/src/marketplaces/catalogue.js`

**Exports**

- `MARKETPLACES`
- `marketplaceProfileId`
- `marketplaceProfileUrl`

## `js/src/marketplaces/profile-page.js`

**Exports**

- `captureProfilePage`

## `js/src/marketplaces/sessions.js`

**Exports**

- `cleanMarketplaceProfile`
- `createMarketplaceSessions`

## `js/src/patterns/index.js`

Patterns module (R-C1).

Two primitives:
  - `inferRegex(examples)` produces a regex that matches every
    example by tokenising on whitespace and replacing varying tokens
    with `\S+`. This is a simple but real example-driven generaliser
    — enough to demo the workflow; deeper synthesis (REGAE,
    SplitRegex) is a follow-up.
  - `simplifyRegex(regex)` collapses `(\S+\s+){2}\S+` style
    repetitions into `(\S+\s+){n}` form for readability.

`Pattern` itself is a small data class so it can be persisted as a
link in the unified database.

**Exports**

- `compilePeg`
- `createPattern`
- `inferRegex`
- `inferRegexLcs`
- `lcs`
- `matchAll`
- `simplifyRegex`

## `js/src/patterns/safe-regex.js`

Running a stored or user-written pattern without freezing the server
(R-Z1, ReDoS). A catastrophic pattern such as `(a+)+$` takes longer than
the age of the universe on a long line, and a regex runs on the main
thread, where it would stop the scheduler and every account too.

  - a pattern is at most MAX_PATTERN_LENGTH characters;
  - the text it is tried on is cut to MAX_INPUT_LENGTH characters;
  - the match runs under a time budget (`node:vm` stops a script that
    runs too long, the regex engine included). Where `node:vm` does not
    exist (a browser) only the two caps apply.

A match that runs out of time is "no match", never a hang.

The time budget costs a watchdog per call (~50 microseconds), and
patterns run in loops over thousands of messages, so only a pattern with
a shape that can blow up pays it: a quantified group that holds a
quantifier or an alternation (`(a+)+`, `(a|b)*`), two or more
unbounded `.*`, or a back-reference. The rest run directly.

**Exports**

- `MAX_INPUT_LENGTH`
- `MAX_PATTERN_LENGTH`
- `REGEX_BUDGET_MS`
- `safeRegExp`
- `safeRegExpOrNull`
- `safeTest`

## `js/src/replies/index.js`

Reply variation groups (R-C2).

A `ReplyVariationGroup` is a labelled set of strings that all
answer the same prompt. `findCandidates(history, prompt)` returns
outgoing user messages whose Sørensen-Dice similarity to `prompt`
exceeds `threshold` — a tiny, dependency-free fuzzy ranker.

**Exports**

- `createReplyGroup`
- `dice`
- `findCandidates`
- `pickVariation`

## `js/src/replies/reply-cache.js`

The browser's own copy of the reply index (R-Y70): suggestions while
typing come from memory, in the same task as the keystroke, never
from a round trip.

The copy is links, as everything else in the associative stack: the
server's `/api/suggest/model` gives the index as `reply-link`,
`sent-link`, `word-link`, `spelling-link`, `chat-link` and
`last-link` rows (./reply-graph.js `modelLinks`), pruned to what a
suggestion can use, with a version. The copy is kept in the browser's
links storage (IndexedDB, or doublets-web when present) as
`{ links }` with a `reply-model` link for the version, so a reload
suggests at once, before the server answers. After that only the
messages the server learned since that version come down (`since`),
and are learned here the same way the server learned them; the whole
model only when the server rebuilt its index or this copy is too far
behind. The live stream says when to ask (`nudge`).

**Exports**

- `createReplyCache`
- `mergeSuggestions`

## `js/src/replies/reply-graph.js`

Message-to-message reply graph and two-stage autocomplete (issue #31).

The graph is learned from history: every time the owner answers a
partner's message, the pair (their message → our reply) becomes one
reply link, counted. It is learnable from an archive import, from a
live pull and in real time (`observe(message)` as messages arrive).

Autocomplete then works in three stages, fastest-to-type first:

  1. Whole-message replies. The last message in the chat is looked up
     in the graph; every reply we ever sent to the same message is
     offered once (deduplicated), sorted by how often we used it.
     What the user has typed so far narrows the list by prefix.
     Before anything is typed only the typical replies show — used
     more than once and a good share of all our answers to it — so a
     message like "ok", answered a hundred different ways, offers
     none. Nothing is offered when there is nothing to answer, or no
     reply we know for it.
  2. Whole messages. While the user types, every message they sent
     before that starts with what is typed, most used first.
  3. Word by word. After those, the next word (or the rest of the
     current word) is predicted from the words of the conversations —
     ours counted three times, the people we talk with once (in chats
     we wrote in; broadcast channels left out) — a trigram → bigram →
     unigram back-off.

The index is plain data (`toLinks`/`fromLinks` round-trip it through
the links store), and its lookups are hash-map reads, so suggesting is
O(replies for that message) however long the history is. The
`link-cli` backend in `./reply-store-clink.js` mirrors the same links
into a doublets database for the CLI and the server.

**Exports**

- `DEFAULT_REPLY_WINDOW_MS`
- `buildReplyIndex`
- `createReplyIndex`
- `extractReplyPairs`
- `lastIncomingIn`
- `normalizeMessage`
- `tokenizeWords`

## `js/src/replies/reply-service.js`

The reply service: message-to-message autocomplete over a links store
(issue #31).

It learns the reply graph from the store's history the first time it
is asked, then keeps learning in real time from every message the
store receives (imports, live adapters, our own sends). Suggestions
come in three stages — every reply we used before for the message
waiting for an answer (deduplicated, most used first), then whole
messages we sent that start with what is typed, then word-by-word
completion from the conversations' words.

Keystrokes are answered by the in-memory index. When a link-cli
(`clink`) reply store is given it is loaded with the same graph and
kept up to date as the persisted, queryable mirror; its status is
reported but never blocks a suggestion (see reply-store-clink.js).

A browser answers keystrokes itself (./reply-cache.js): `model()`
gives it the index as links, pruned to what a suggestion can use, and
a version; `model({ since })` then gives only the messages learned
since, in order, for the client to learn the same way — or the whole
model again when it is too far behind or the index was rebuilt.

**Exports**

- `createReplyService`

## `js/src/replies/reply-store-clink.js`

The message-to-message reply graph kept in a link-cli (`clink`)
doublets database, for fast whole-message autocomplete (issue #31).

Network shape (all values are named points, shared by every link that
mentions them; names come from `clinkName`):

  q = (ms:prompt P)          P = the normalized incoming message
  e = (q R)                  R = the normalized reply — one edge per
                                 distinct (prompt, reply) pair
  (e ms:n:<count>)           how many times we answered P with R
  (e <original text>)        the reply as we typed it
  (e ms:t:<iso>)             when we last used it

A prompt is wrapped in `q` so a reply equal to its prompt ("привет" →
"Привет!") is still its own edge. Suggesting is one join query
`($q: ms:prompt P) ($e: $q $r) ($a: $e $v)`; learning updates the
count link in place. The whole graph is (re)loaded at once through
the binary links notation archive (`clink --import-binary`).

link-cli 1.0.0 (Rust) and 4.0.0 (.NET) scan every link per lookup, so
a query costs tens to hundreds of milliseconds as the graph grows
(experiments/clink-query-scaling.mjs). The reply service therefore
answers keystrokes from the in-memory index and keeps this store as
the persisted, queryable mirror.

**Exports**

- `createClinkReplyStore`
- `replyNetwork`

## `js/src/server/account-scope.js`

**Exports**

- `accountScope`

## `js/src/server/aggregate.js`

Contact aggregation helper shared by every route that needs to roll
messages up into per-contact views (R-D1).

The owner ("me") is not their own contact. A contact carries the
name its latest message gave (`senderName`), and the list starts with
whoever was heard from last, like a messenger's contact list.

With `{ people: true }` (the Contacts screen) the `person:` links a
connected account brings — the Telegram address book, chat partners —
join the list too, even before any message, each with `open`: the
chat to write to them in.

**Exports**

- `aggregateContacts`

## `js/src/server/audience-sync.js`

Audience membership sync (R-X13; wired by R-Z7).

An audience such as `friends:vk & chat:vk:2000000001` only finds people
when their `member:` links are in the store. This reads, through each
network's official API and the user's own token, the friends, chat members
and community members that the saved audiences and the automations name,
and stores them (`syncMembership`). It only reads; nothing is sent.

  POST /api/audience/sync { source? }  -> { ok, sources: [{ source, ok,
       groups, members, error? }] }  now, for one network or every one
       the audiences name

It also runs by itself once a day (`MS_AUDIENCE_SYNC_HOURS`, 0 = off,
default 24) while the server is up. A network without a token, or one
that cannot list a kind of group (Telegram's Bot API has no friends and
lists only a chat's administrators), reports that and the rest goes on.

**Exports**

- `audienceGroups`
- `audienceSyncFor`
- `handleAudienceSyncRoute`
- `syncAudiences`

## `js/src/server/background-jobs.js`

The jobs that run by themselves while the server is up, started once the
port is really ours (R-Z7; a second `serve` on a busy port must not run
them on the same store):

  automatic backup          ./backup-job.js          daily, keep 7 (R-A4)
  audience membership sync  ./audience-sync.js       daily (R-X13)
  24-hour cache purge       here                     hourly (R-S12, R-T12)

`backgroundJobs(...)` returns the part of the context holding `stopJobs`.

**Exports**

- `backgroundJobs`
- `purgeSoftCaches`

## `js/src/server/backup-job.js`

The automatic backup, started once the port is ours (R-A4, R-Z7).

ON by default (R-Z16): a streaming backup every 24 hours, the newest 3
kept. `MS_BACKUP_INTERVAL_HOURS` (or the `backups.intervalHours` option)
sets the interval in hours, `0` turns it off; `MS_BACKUP_KEEP` (or
`backups.keep`) sets how many archives are kept (default 3, `0` keeps
all). A value that is not a number >= 0 is ignored for the default and
logged once.
The archive is encrypted, and holds the secrets, only when the server has
a passphrase (`MS_SECRET_PASSPHRASE`); otherwise it leaves them out.
The first run is one interval after start, never at start. A nearly full
disk skips the run (R-Z14) and the log says so.

**Exports**

- `DEFAULT_INTERVAL_HOURS`
- `DEFAULT_KEEP`
- `backupJobFor`
- `backupSettings`

## `js/src/server/chat-index.js`

The chats in the store, so the page never needs every message
(R-Y29). The store keeps every message ever loaded — whole histories
once the background download has run — and the page asks for:

  heads()            the newest message of each chat (the chat list);
  page(key, before)  a page of one chat, older than message `before`
                     (the chat the user reads, as they scroll back);
                     or newer than message `after`, or around a time
                     `at` (a jump to a date, R-Y106), or around
                     message `around` (a jump to a message, R-Y107).
                     A key `<chat key>#topic:<id>` pages one forum
                     topic's messages alone (R-Y122).

The index holds a few numbers per message (id, time, network id), kept
current through the store's change feed. Its own feed marks a message
that arrives older than its chat's newest one as `quiet`: history read
in the background or ahead of the user, which the live event stream
leaves out (the page asks for it by page when it needs it).

**Exports**

- `createChatIndex`

## `js/src/server/confirmations.js`

Explicit confirmation for every write to a third-party service.

Reading (pulling messages, contacts, exports) happens as needed, but
nothing is sent, posted, published or changed on another service
unless the user confirmed that exact action. Each such route works in
two requests:

  1. without `confirmToken` it does nothing and answers
     `428 Precondition Required` with a preview of what would happen
     and a single-use token bound to exactly that request body;
  2. the app shows the preview, asks the user, and repeats the request
     with `confirmToken`. A token works once, for that body only, and
     expires after five minutes.

Store writes (sync, `PUT /links`) never trigger a send by themselves.

**Exports**

- `CONFIRM_TTL_MS`
- `confirmed`
- `createConfirmations`
- `offerConfirmation`
- `withoutToken`

## `js/src/server/cors.js`

Cross-origin access to the local server (issue #37).

The hosted web app (GitHub Pages) and the mobile WebViews run on
origins other than the server's own `http://127.0.0.1:<port>`, so a
browser only lets them read `/api/status` — and upgrade from the
restricted offline mode to the full app — when the server answers
with CORS headers for their origin. The server keeps listening on
loopback only; this module decides *which web pages* may use it.

Policy:
  - requests without an `Origin` header (curl, the CLI, Node) and
    same-origin requests (the SPA the server serves itself, the
    Electron window) are untouched;
  - origins on the allow-list get `Access-Control-Allow-Origin`
    echoed back, plus a preflight answer that also opts in to
    Chrome's Private Network Access check;
  - every other origin gets no CORS headers and a 403 on every method,
    so a random website cannot
    post `text/plain` bodies (which skip preflight) to the store.

The allow-list defaults only to the official GitHub Pages origin.
Same-origin localhost is checked separately. Other embedders explicitly
configure their WebView origin. The list can be replaced with the
`MS_ALLOW_ORIGINS` environment variable or `serve --allow-origin=`
(comma/space separated; `none` disables cross-origin access).

**Exports**

- `DEFAULT_ALLOWED_ORIGINS`
- `classifyOrigin`
- `corsContext`
- `handleCors`
- `hostAllowed`
- `parseAllowedOrigins`

## `js/src/server/email-attachments.js`

Mail attachments kept next to the store (R-Z5).

The bytes of an attachment are saved under their SHA-256 in
`<store>/media/email/`, so the same file is kept once, and a link names
it by that hash (`attachment.file`). A name from the outside is never
a path: only a 64-digit hash is accepted, and the resolved path must
stay inside the directory. A file above the cap is not kept.

**Exports**

- `MAX_ATTACHMENT_BYTES`
- `createAttachmentStore`

## `js/src/server/github-service.js`

GitHub as a full inbox, server side (R-Z11).

Which repositories to pull and how often is a saved setting
(`settings:github`); where each pull stopped is a cursor link
(`cursor:github:<owner/repo>`) written only after the pulled links were
stored (R-Z14), so a failed write repeats the same window. A repository
that fails does not stop the others; a rate limit stops the run and says
when to come back. Notifications are fetched into `notification:github:*`
links and marked read only by an explicit call.

There is no timer here: `pullJob()` is the job the shared pull runner
(../sources/pull-runner.js, R-Z8) registers as `github`, so "Fetch now" and
the schedule are the runner's. The schedule is off until the user picks
repositories and an interval.

**Exports**

- `DEFAULT_SETTINGS`
- `checkSettings`
- `createGithubService`
- `githubLive`
- `readGithubToken`

## `js/src/server/handlers-bootstrap.js`

Wires the built-in DDD handlers (live source pulls, automation
graphs) onto a server-side store: storing a command link runs it.
Only reads and local planning are wired this way. Writes to other
services (broadcast, profile/CV sync, outreach) are deliberately not:
a stored or synced link must never send anything; they run from
their routes after an explicit confirmation (./confirmations.js).

Kept separate from `index.js` so the server module stays small and
easy to read.

**Exports**

- `registerDefaultHandlers`

## `js/src/server/hosted-ui.js`

Which web page is the app's face (R-Y58, R-Y59).

By default it is the hosted one on GitHub Pages: a static bundle that
finds this server (./../web/discover.js) and becomes the full app
through it, so the server does not have to host a web site. The copy
the server serves itself is an opt-in fallback for offline use:
`serve --local-ui=true` or `MS_LOCAL_UI=on`. By default `/` sends the
browser to the hosted app. Safari uses the local HTTPS API after the
server's certificate is trusted; it does not need the local UI.

The hosted app finds the server by itself, on our port (8787) and the
few others it looks at (DEFAULT_PORTS in ../web/discover.js); no
address is put in its link. On any other port `serve` says so.

`serve --ui-url=` (or `MS_UI_URL`) names another hosted copy, a
fork's Pages for example; its origin is allowed to use the server.

Safari refuses the hosted page's requests to http://127.0.0.1 but
still shows it images from there, so the server answers one small
picture (BEACON_PATH) whose size says "here I am" and whether its own
copy is on; the hosted page offers certificate setup and links the
optional local copy only when enabled (../web/discover.js).
With cross-origin use off (`--allow-origin=none`) there is no picture.

With HTTPS on (./local-tls.js, R-Y64) Safari can use the server at
https://127.0.0.1 once it trusts the server's certificate; the picture
says HTTPS is on, and `/trust` is the page Safari is shown to trust it.

**Exports**

- `HOSTED_UI_URL`
- `foundOnPort`
- `hostedUiUrl`
- `localUiEnabled`
- `redirectToHosted`
- `serveBeacon`
- `serveTrust`
- `withHostedOrigin`

## `js/src/server/index.js`

Local web server (R-F4) + universal links HTTP surface (R-F8) + UI (R-F1).

Endpoints (full list lives in `routes-derived.js` and `routes-mutating.js`):
  GET  /                         -> GitHub Pages redirect (SPA with localUi=true)
  GET  /app.js, /app.min.js, /app.css -> optional SPA assets (localUi=true)
  GET  /links, /links/:id        -> read links
  PUT  /links                    -> upsert
  DEL  /links/:id                -> delete
  GET  /sources                  -> list message-source adapters
  GET  /api/contacts             -> contacts derived from messages
  GET  /api/status               -> service identity + store stats + verify diff count
  GET  /api/autocomplete?q=&me=  -> outgoing-history-driven completions
  GET  /api/suggest?source=&chat=&typed= -> reply-graph autocomplete
  GET  /api/audience?q=          -> set-algebra over store filters
  GET  /api/facts                -> question-answer pairs per partner
  GET  /api/search?q=            -> dice-similarity search
  GET  /api/patterns             -> persisted patterns
  PUT  /api/patterns             -> upsert pattern link
  POST /api/patterns/infer       -> { examples, mode } -> { regex, flags }
  GET  /api/graphs               -> persisted automation graphs
  PUT  /api/graphs               -> upsert graph
  POST /api/graphs/run           -> { id, message, mode } -> plan
  GET  /api/replies              -> persisted reply variation groups
  PUT  /api/replies              -> upsert reply variation group
  GET  /api/profile              -> read profile (R-D5)
  PUT  /api/profile              -> upsert + plan cross-network sync
  GET  /api/resume               -> read resume (R-D6)
  PUT  /api/resume               -> upsert + plan cross-network sync
  POST /api/broadcast            -> queue post for outbound networks
  POST /api/outreach             -> { query, text, networks, mode } -> plan
  /api/automations/*, POST /api/send, /api/typing -> routes-automations.js
  /api/message/* (edit, delete, react, read, forward) -> routes-messages.js
  /api/passcode/* -> the local passcode and its lock gate (routes-passcode.js)
  POST /api/client-log           -> the page's errors, in the log (routes-client-log.js)
  /api/people, /api/audiences, /api/lists -> routes-people.js
  GET  /api/people/learned?key=  -> what a conversation tells (routes-learned.js)
  GET  /api/greetings/*          -> greeting stickers/texts (routes-greetings.js)
  POST /api/email/pull           -> local-server email API/protocol proxy
  POST /api/email/send           -> local-server email send proxy
  GET  /api/email/attachment     -> a mail attachment from the media folder (routes-email.js)
  GET  /api/media/<network>/<sha256>[.ext] -> imported archive media (routes-media.js, R-Z15)
  POST /api/archive/upload?source=&name= -> import an export file (routes-archive-upload.js)
  GET  /api/backups              -> list archives (gated on archiveDir)
  POST /api/backups              -> { passphrase?, keep? } -> { file }
  POST /api/backups/restore      -> { file, passphrase? } -> { restored }
  GET  /api/auto-import          -> browser auto-import status + jobs
  POST /api/auto-import          -> { provider } -> job (see routes-auto-import.js)

Implemented with Node's built-in `http` module to keep the dependency
footprint at zero. The Docker images in `docker/` simply run
`node js/bin/meta-sovereign serve`.

**Exports**

- `CSP`
- `startServer`

## `js/src/server/listen-error.js`

**Exports**

- `listenFailure`

## `js/src/server/live-subset.js`

Keep a small derived set current without rescanning the entire archive.

**Exports**

- `createLiveSubset`

## `js/src/server/local-certificate-check.js`

**Exports**

- `matchesLocalCertificate`

## `js/src/server/local-key.js`

**Exports**

- `certificateFingerprint`
- `createDeviceKeyProtector`
- `deviceKeyFailure`
- `isDeviceKey`
- `unlockLocalKey`

## `js/src/server/local-tls.js`

HTTPS on the server's own port, for Safari (R-Y64).

Safari keeps an https page — the hosted app — from http://127.0.0.1
and http://localhost alike, but lets it reach https://127.0.0.1 with
a certificate it trusts. So the server makes one certificate of its
own, for localhost, 127.0.0.1 and ::1 only (it is no authority and
cannot stand for any other site), keeps it in `<store>/tls/`, and
answers TLS on the same port as plain HTTP: the first byte of each
connection tells them apart. The person trusts the certificate once
(`meta-sovereign trust`, or Safari's "visit this website" on
https://127.0.0.1:8787/trust), and the hosted app then finds the
server at https://127.0.0.1:8787 by itself (../web/discover.js).

The certificate is written by hand in DER with node:crypto, so no
package and no openssl is needed.

**Exports**

- `canShareTlsPort`
- `listenHttpAndHttps`
- `listenLocal`
- `loadLocalTls`
- `localTlsPaths`
- `makeLocalCertificate`

## `js/src/server/log.js`

Structured logging for the server (ROADMAP §7).

Two factories share one line format — one JSON object per line:

  {"ts":"2024-01-01T00:00:00.000Z","level":"info","event":"http",
   "method":"GET","path":"/links","status":200,"duration_ms":3}

  jsonLog()          opt-in stdout logger (set MS_LOG_FORMAT=json). Default
                     server mode keeps stdout silent so unit tests stay
                     clean; tests can pass their own `write` to capture.
  createServerLog()  the running app's verbose logger: every entry is
                     appended to a file inside the app's data folder AND
                     echoed to stdout, so each run leaves a full trace on
                     disk that makes root-causing any issue easy. This is
                     on by default for `meta-sovereign serve`.

**Exports**

- `createSafeWriter`
- `createServerLog`
- `installCrashLogging`
- `jsonLog`

## `js/src/server/metrics.js`

Prometheus exposition for the local server (ROADMAP §7).

Returned in the OpenMetrics text format so any standard scraper
(Prometheus, OpenTelemetry collector, vector.dev) can consume it
with no extra parsing. Metrics are intentionally minimal: link
counts by prefix, store size, sync peer counts, signaling rooms.

  GET /metrics

Always served — but only useful for headless deployments. The SPA
itself does not scrape itself; this is for the `npm run docker:*`
runs inside larger fleets.

**Exports**

- `collectMetrics`
- `handleMetrics`

## `js/src/server/native-helper.js`

**Exports**

- `compileSwiftHelper`

## `js/src/server/passcode.js`

**Exports**

- `AUTO_LOCK_MINUTES`
- `PASSCODE_FILE`
- `PASSCODE_MAX`
- `clearPasscode`
- `createPasscodeLock`
- `delayAfter`
- `hashPasscode`
- `verifyPasscode`

## `js/src/server/redact.js`

Secrets never reach a log line or a stored error (R-Z2).

`redact(text)` blanks what looks like a credential: Telegram Bot API
tokens (they sit in the URL path, `/bot<id>:<secret>/`), `Authorization`
/ `Cookie` header values, `Bearer` / `Basic` credentials, query or JSON
fields such as `access_token`, `session` or `password`, and very long
base64 runs (a Telegram string session). It is applied to every log line
by the logger and to the error messages the automation ledger stores.
The result keeps its shape, so a line still reads: `bot<redacted>`.

**Exports**

- `redact`
- `safeMessage`

## `js/src/server/request-gate.js`

**Exports**

- `createRequestGate`

## `js/src/server/rolling-control.js`

**Exports**

- `controlAddress`
- `createServerControl`
- `requestServerControl`

## `js/src/server/rolling-host.js`

**Exports**

- `startRollingServer`

## `js/src/server/rolling-release.js`

**Exports**

- `PACKAGE_ROOT`
- `rollingDirectory`
- `stageServerRelease`
- `verifyRelease`

## `js/src/server/rolling-supervisor.js`

**Exports**

- `RollingSupervisor`

## `js/src/server/rolling-worker.js`

**Exports**

- `createRollingWorker`

## `js/src/server/routes-archive-upload.js`

Archive uploads (R-Z23):
  POST /api/archive/upload?source=<network>&name=<file name>
       (application/octet-stream body: the file's bytes)
    -> { ok, imported, files: [{ name, imported, error? }], media?, chat? }

The page's import box sends an export it was given (a Facebook, X,
LinkedIn or WhatsApp .zip, a Telegram result.json, ...) here. The bytes
are streamed to a private temp folder in the store (never held in
memory, never base64, no fixed size cap) and read by the same importer
as auto-import (../sources/auto-import/files.js: a zip is opened in
place, media copied to `<store>/media/<network>/`); a WhatsApp export
keeps its own importer (../sources/whatsapp-file.js), which copies the
attachments its chat names. The temp file is removed afterwards, and
leftovers of a crash are swept on the next upload.

Not JSON, so not isTrustedMutation's check: its own, as for the Telegram
upload — the bytes' type is not one a form on another site can send
without asking first (CORS), and another site's page is refused. A disk
without room for the file twice over (the file and what it becomes)
is refused before anything is written (507).

**Exports**

- `ARCHIVE_UPLOAD_ROUTE`
- `UPLOAD_TIMEOUT_MS`
- `handleArchiveUpload`
- `uploadName`

## `js/src/server/routes-auto-import.js`

Browser auto-import routes (JS server only — see SERVER-PARITY.md).

  GET  /api/auto-import                   -> { available, reason, providers, jobs }
  POST /api/auto-import        {provider} -> job (opens the browser)
  GET  /api/auto-import/jobs/:id          -> job
  POST /api/auto-import/jobs/:id/capture  -> job (reads the open chat)
  POST /api/auto-import/jobs/:id/stop     -> job (closes the browser)

Sign-ins from the user's own browsers (./sign-ins.js):
  POST /api/auto-import/browsers/scan     -> { browsers, fullDiskAccess }
  POST /api/auto-import/browsers/import   {sources:[{browser,profile}]}
                                          -> { services, errors }
  POST /api/auto-import/browsers/full-disk-access
                                          -> opens System Settings (macOS)
Scanning reads only host names; importing reads cookie values and keeps
them in an owner-only file until the service's import window opens. Both
are POST so they share the same-app check below.

These routes start processes on the user's machine, so mutating calls
must come from the app: a JSON content type (cross-origin pages need a
CORS preflight, see ./cors.js) and an Origin that is absent, the
server's own, or on the CORS allow-list.

**Exports**

- `handleAutoImportRoutes`
- `isTrustedMutation`

## `js/src/server/routes-automations.js`

Automations API (issue #31 / PR #34) — see `../automation/`.

Endpoints:
  GET    /api/automations            → { automations } saved + presets
  GET    /api/automations/presets    → { presets }
  PUT    /api/automations            { automation } → saved automation
  DELETE /api/automations/:id
  POST   /api/automations/plan       { automation, targets?, limit? }
                                     → who it would message and why not
  POST   /api/automations/run        { automation, targets?, confirm?,
                                       trigger?, test?, limit? }
         Safe mode queues drafts; auto mode sends paced and needs
         `confirm: true` for manual and chat-menu runs. `test: true`
         with targets ignores the conditions (the chat menu's "test").
  GET    /api/automations/drafts?source=&chat=&automation=
  POST   /api/automations/drafts/send { id, confirm: true, text?, form? }
  POST   /api/automations/drafts/form { id, form }
  POST   /api/automations/drafts/mark { id }  (sent by hand)
  POST   /api/automations/drafts/skip { id }
  GET    /api/automations/history?automation=
  POST   /api/automations/next { automation, exclude?, queue? }
         → the next chat it fits, its draft written with `queue` (R-Y86)
  POST   /api/automations/edit/reset { automation } → its own text again
  GET    /api/automations/autopilot → { autopilots } (R-Y87)
  POST   /api/automations/autopilot { automation, on?, monitor? }
         `on: true` is confirmed (how many chats, how paced) first
  GET    /api/automations/outbox?status= → { outbox } every automated send
         (sending, sent, failed, unknown), newest first (R-Z3)
  POST   /api/automations/outbox/resolve { id, decision: 'sent'|'failed' }
         the user's decision about an `unknown` send; never retried by itself
  GET    /api/automations/settings → quiet hours, timezone, opt-out list
  PUT    /api/automations/settings { quietHours?, timezone?, optOut? }
  POST   /api/send   { source, chat, text, contact? } → the chat composer;
                     API first, the official web UI when it fails
  POST   /api/typing { source, chat, cancel? } → show our typing status
                     (`cancel`: stop showing it)
  GET    /api/typing?source=&chat=   → who is typing now

`automation` is an id (saved or preset) or a whole definition, so the
chat menu can test an edited automation before saving it.

**Exports**

- `handleAutomationRoutes`

## `js/src/server/routes-backup.js`

Backup HTTP surface (R-A4 + ROADMAP §4 backup→restore round-trip).

Endpoints (gated on `archiveDir` being configured at startup so a
read-only browser-bound deployment cannot accidentally write to disk):

  GET    /api/backups            -> list available archives
  POST   /api/backups            -> create one now (optional passphrase)
  POST   /api/backups/restore    -> { file, passphrase? } -> restored count

The list endpoint returns the on-disk filenames sorted oldest-first
so the UI can show them as a timeline. The full path stays server-
side; the UI only sees basenames it must echo back to the restore
endpoint, and we re-resolve under `archiveDir` to prevent traversal.

**Exports**

- `handleBackupRoutes`

## `js/src/server/routes-chat.js`

The chat screen's reads, from the store (see ./chat-index.js):
  GET /api/chat/heads                         -> the newest message of
                                                 every chat
  GET /api/chat/messages?key=&before=&limit=  -> { messages, more, newer }
                                                 a page of one chat, oldest
                                                 first, older than message
                                                 `before` (or newer than
                                                 `after`, or around the
                                                 ISO time `at`: R-Y106)
Other links reach the page through `GET /links?except=msg:`.

**Exports**

- `handleChatRoutes`

## `js/src/server/routes-client-log.js`

POST /api/client-log — what went wrong in the page, in the server's log
file, next to what the server did: a script error, a promise nobody
caught, a request that failed, an image that would not load.

  body: { level, event, error?, stack?, view?, …numbers and flags }

Only the shape of a problem is kept, never what the user reads: the
fields are an allow-list, strings are cut short, only numbers and
flags pass besides them. A page floods nothing — sixty entries a
minute at most — and other sites' pages may not write (an Origin
outside the allow-list is refused).

**Exports**

- `clientEntry`
- `createClientLogRoute`

## `js/src/server/routes-contacts-import.js`

**Exports**

- `handleContactsImport`

## `js/src/server/routes-cv.js`

CV synchronisation API (R-V16).

Thin HTTP skin over `js/src/cv`: the catalogue and the dry-run plans
need no browser at all, while `read`/`sync` open one through the
facade. Tests inject `ctx.cvCommander` (or `ctx.cvSessionFactory`)
so the whole surface is verifiable without downloading Chromium.

Endpoints:
  GET  /api/cv/platforms            catalogue of supported platforms
  GET  /api/cv/plan?platform=…      declarative plan + evidence
  GET  /api/cv/stored               snapshots the store already holds
  POST /api/cv/read                 live read of one or more platforms
  POST /api/cv/compare              cross-platform matrix + diffs
  POST /api/cv/sync                 reconcile and (optionally) push,
                                    narrowed by `paths`/`groups`
  GET  /api/cv/telemetry            recorded run events

**Exports**

- `handleCvRoutes`

## `js/src/server/routes-deleted.js`

The deleted messages of a chat: kept, never lost, and the user's to
bring back or to remove (R-K1, R-K2, R-K4; wired to a page by R-Z7).
These are local actions only: nothing is sent to any network.

  GET  /api/chat/deleted?key=<chat key>   -> { messages }  the chat's
                                             tombstoned messages, oldest
                                             first (at most 500)
  POST /api/chat/deleted/recover { ids }  -> { ok, recovered }  the
                                             messages show in the chat
                                             again
  POST /api/chat/deleted/purge { ids, confirm: true }
                                          -> { ok, purged }  erased from
                                             this device for good

Only a message that is already deleted can be recovered or purged; a live
one is never touched, whatever ids a request names.

**Exports**

- `handleDeletedRoutes`

## `js/src/server/routes-derived.js`

Read-only API routes that derive views from the unified store
(contacts, status, autocomplete, audience, facts).

Every endpoint returns plain JSON so the SPA can render without
extra parsing logic — the store remains the single source of truth.

**Exports**

- `handleDerivedRoutes`

## `js/src/server/routes-email.js`

Email routes (issue #3; R-Z5).

Its routes:
  POST /api/email/pull   { protocol?, limit?, offset?, … } -> { imported,
                         rawCount, nextOffset, skipped? }; the saved
                         connection (token, host, login, password) is
                         used unless the body names another server;
                         once every 15 s at most (429 `rate-limited`)
  POST /api/email/send   { message: { to, subject, text, … } } -> after
                         the user's confirmation (./confirmations.js)
  GET  /api/email/attachment?id=&n=|cid=&inline=1
                         -> an attachment's bytes, from the media folder
                         (fetched from the provider the first time when
                         it was not kept); only the app's pages may ask;
                         saved as a download, except a picture shown in a
                         mail (`inline=1`, never an SVG)

A failure answers `{ ok: false, error, code }`; nothing is reported as
done that was not. Another server named in the body never receives the
password or token saved for the first one.

**Exports**

- `emailConfig`
- `emailFailure`
- `handleEmailGets`
- `handleEmailPull`
- `pullEmail`
- `sendEmail`

## `js/src/server/routes-events.js`

GET /api/events — a Server-Sent Events stream of link changes, so the
chat shows a new message, a read receipt or typing the moment the
server learns about it (instead of on the next poll).

  event: link    data: { type: 'put', link }  |  { type: 'delete', id }
  event: ready   once, when the stream is open
  : ping         a comment every 25 s keeps proxies from closing it

A page that stops reading (a sleeping tab, a dead connection) is cut
off once `MAX_BUFFERED` bytes wait for it, instead of the server
holding every change for it until it runs out of memory: the page
reconnects and catches up (./web/chat-live.js `refresh`).

Only what the chat shows is streamed — messages, read markers, typing,
people, chat history marks and the Telegram sync status — never
`secret:` links, and no history read ahead of the user. Other
sites' pages may not listen (an Origin outside the allow-list is
refused).

**Exports**

- `EVENT_PREFIXES`
- `MAX_BUFFERED`
- `handleEventRoutes`
- `isStreamedId`

## `js/src/server/routes-github.js`

The GitHub inbox routes (R-Z11), all under /api/github/:

  GET  repos                  the user's repositories, `selected` marked
  GET  settings               { repos, intervalMinutes, notifications,
                                discussions }
  POST settings               the same, saved
  GET  notifications          the stored notification inbox
  POST notifications/read     { threadId } | { all: true } -- the only
                              thing that marks anything read on GitHub

"Fetch now" and the schedule are the shared pull runner's: POST /api/pull
{source: "github"} (./routes-pull.js). Pull, clone and post-comment stay in
./routes-mutating.js. Answers are
`{ ok, ... }` or the uniform `{ ok: false, error, code }`.

**Exports**

- `handleGithubRoutes`

## `js/src/server/routes-greetings.js`

Greetings API (issue #35).

Thin HTTP skin over `js/src/greetings`: the catalogue and the plan
preview need no network access; listing stickers live and sending a
queued plan go through the source adapters with the credentials the
store holds as `secret:*` links. Tests inject `ctx.greetingSources`
(and `ctx.greetingSleep`) so nothing reaches a real network.

Endpoints:
  GET  /api/greetings/catalogue     networks, built-in stickers, sets
  GET  /api/greetings/selection     stickers/texts the user picked
  PUT  /api/greetings/selection     save the pick
  POST /api/greetings/stickers      list greeting stickers live
  POST /api/greetings/plan          { mode, networks, limit, run,
                                      delayMs?, dailyCap?, maxPerRun? }
                                    -> plan (+ results when queued);
                                    `run: 'dry'` lists exactly who would
                                    get what, sending nothing (R-Z3)
  GET  /api/greetings/file?id=…     Telegram thumbnail proxy (the
                                    download URL embeds the bot token)

**Exports**

- `handleGreetingRoutes`

## `js/src/server/routes-learned.js`

What a personal conversation tells about the other person
(R-Y50 .. R-Y54), learned from the stored history:

  GET /api/people/learned?key=<source>:<chat>
  → { key, personal, complete, messages, address, work, accounts,
      asked, questions }

Read from the store only (../crm/person-learn.js), never from the
network. A Telegram chat whose history is not stored to its first
message yet is asked for first by the background download, and the
answer says `complete: false` until it is. The result is kept until
the chat gains or loses a message. GitHub accounts the person sent are
checked once a week (../sources/github-check.js). Only counts are
logged, never what was said.

**Exports**

- `createLearnedRoute`

## `js/src/server/routes-marketplaces.js`

**Exports**

- `handleMarketplaceRoutes`

## `js/src/server/routes-media.js`

Imported archive media (R-Z15):
  GET /api/media/<network>/<sha256>[.<ext>]
serves a file that an archive import (R-Z10 Facebook/Messenger,
Instagram, X, LinkedIn; R-Z15 WhatsApp) copied to
`<store>/media/<network>/<sha256><ext>`. The path is built only from
validated parts (a fixed network list, 64 hex digits, a fixed extension
list), so nothing outside that folder can be named. Pictures, audio and
video are shown inline; everything else, svg and html included, is
offered as a download with a sandboxing CSP. Audio and video answer
`Range`. The file is streamed, never read whole.

**Exports**

- `MEDIA_EXTENSIONS`
- `MEDIA_NETWORKS`
- `handleMediaGets`
- `parseMediaPath`

## `js/src/server/routes-messages.js`

What the user does to messages of any network (R-Y38): the network's
API first, its own web app second (../sources/message-actions.js).

  GET  /api/message/supports?source=  -> { source, actions: { edit:
                                         { api, browser }, … } }
  POST /api/message/edit    { ids: [id], text, caption?, noWebpage?,
                             invertMedia?, previewUrl?, previewSize? }
  POST /api/message/delete  { ids, revoke? }    (revoke: for everyone)
  POST /api/message/react   { ids: [id], emoji }   ('' takes ours back)
  POST /api/message/read    { source, chat, ids? } the chat read up to
                                                    the newest of ids
  POST /api/message/forward { ids, toChat }
       -> { ok, via: 'api' | 'browser', … }

Messages are named by their link ids (`msg:<source>:…`), all in one
chat; the server finds them in the store. What the network now says is
written back at once (the new text, the deletion, our reaction, the
read mark), so Chat shows it before the next sync. Only the app's own
pages may ask (a JSON body from an allowed origin).

**Exports**

- `externalIdOf`
- `handleMessageRoutes`

## `js/src/server/routes-mutating.js`

Mutating API routes: links CRUD, pattern persistence + inference,
graphs persistence + run, replies CRUD, profile + resume sync.

Each endpoint returns plain JSON. The store is the single source of
truth; nothing is held in server-side memory.

**Exports**

- `handleMutatingRoutes`
- `linkProblem`

## `js/src/server/routes-passcode.js`

**Exports**

- `gateLocked`
- `handlePasscodeRoutes`

## `js/src/server/routes-people.js`

People and audience API (issue #31, PR #34).

Search the people directory, review cross-network matches, keep
hand-picked lists and saved audiences, and resolve an audience to the
people an automation would be triggered for.

Endpoints:
  GET    /api/people?q=&limit=&self=   search the directory
  GET    /api/people/xref              same-person suggestions
  GET    /api/audiences                saved `audience:` links
  PUT    /api/audiences                { id?, name, spec | text }
  DELETE /api/audiences/<id>
  POST   /api/audiences/resolve        { spec | text, self?, limit? }
                                       → { count, people }
  GET    /api/lists                    saved `list:` links
  PUT    /api/lists                    { id?, name, members }
  DELETE /api/lists/<id>

A spec that does not parse or resolve (unknown kind, missing saved
audience, a cycle) is answered with 400 `{ error }`.

**Exports**

- `handlePeopleRoutes`

## `js/src/server/routes-pull.js`

Inbox pulls for the networks that have no live connection of their own
(R-Z8): the Connections card's "Fetch now" button and the background
schedule behind it.

Its routes:
  POST /api/pull {source}   -> { ok, source, imported, lastOkAt }
                                or { ok: false, error, code } with `code` one of
                                unsupported | not-connected | rate-limited
                                (HTTP 429, at most one fetch per 15 s per
                                network, `retryAfterMs`) | the network's own code
  GET  /api/pull/status     -> { ok, sources: { <source>: { connected,
                                lastOkAt, lastError } } }

The same `createPullRunner` (../sources/pull-runner.js) serves every
network: add a job to `pullJobs` to give another network a button and a
schedule. VK also keeps a Long Poll running (../sources/vk-sync.js).

**Exports**

- `createPullServices`
- `handlePullRoutes`
- `pullContext`
- `pullJobs`

## `js/src/server/routes-suggest.js`

Message-to-message autocomplete API (issue #31).

Endpoints:
  GET /api/suggest?source=&chat=&last=&typed=&limit=
      → { stage: reply|word|none, suggestions, lastMessage, backend }
      Whole replies we used before for the chat's last incoming
      message (or `last`), most used first; word-by-word completion of
      `typed` from our own messages when none match.
  GET /api/suggest/stats → { prompts, replies, pairs, words, mirror }
  GET /api/suggest/model?since=&format=json|lino
      → { version, self, windowMs, links } — the reply index as links,
      for a browser to suggest from by itself — or, given the version
      it holds, { version, changes }: the messages learned since.
      `format=lino` gives the links as Links Notation records.

**Exports**

- `handleSuggestRoutes`

## `js/src/server/routes-telegram-account-data.js`

**Exports**

- `ACCOUNT_DATA_POSTS`

## `js/src/server/routes-telegram-account-extras.js`

**Exports**

- `ACCOUNT_EXTRAS_POSTS`

## `js/src/server/routes-telegram-accounts.js`

**Exports**

- `ACCOUNTS_GETS`
- `ACCOUNTS_POSTS`
- `resolveAccount`

## `js/src/server/routes-telegram-admin-extras.js`

**Exports**

- `ADMIN_EXTRAS_POSTS`
- `invalid`
- `route`

## `js/src/server/routes-telegram-admin.js`

**Exports**

- `ADMIN_POSTS`

## `js/src/server/routes-telegram-apps.js`

**Exports**

- `APPS_POSTS`

## `js/src/server/routes-telegram-boosts.js`

**Exports**

- `BOOSTS_POSTS`

## `js/src/server/routes-telegram-bot-login.js`

**Exports**

- `BOT_LOGIN_POSTS`

## `js/src/server/routes-telegram-business.js`

**Exports**

- `BUSINESS_POSTS`

## `js/src/server/routes-telegram-calls.js`

**Exports**

- `CALLS_POSTS`

## `js/src/server/routes-telegram-channel-dm.js`

**Exports**

- `CHANNEL_DM_POSTS`

## `js/src/server/routes-telegram-channel-manage.js`

**Exports**

- `CHANNEL_MANAGE_POSTS`

## `js/src/server/routes-telegram-chat-admins.js`

**Exports**

- `CHAT_ADMINS_POSTS`

## `js/src/server/routes-telegram-chat-reactions.js`

**Exports**

- `CHAT_REACTIONS_POSTS`

## `js/src/server/routes-telegram-chat-settings.js`

**Exports**

- `CHAT_SETTINGS_POSTS`

## `js/src/server/routes-telegram-chat-themes.js`

**Exports**

- `CHAT_THEME_POSTS`

## `js/src/server/routes-telegram-chatlists.js`

**Exports**

- `CHATLIST_POSTS`
- `chats`
- `id`
- `title?`

## `js/src/server/routes-telegram-checklist-stats.js`

**Exports**

- `CHECKLIST_STATS_POSTS`
- `validTasks`

## `js/src/server/routes-telegram-cloud-themes.js`

**Exports**

- `CLOUD_THEME_POSTS`

## `js/src/server/routes-telegram-common-chats.js`

**Exports**

- `COMMON_CHATS_POSTS`

## `js/src/server/routes-telegram-contact-extras.js`

**Exports**

- `CONTACT_EXTRAS_POSTS`

## `js/src/server/routes-telegram-contacts.js`

**Exports**

- `CONTACTS_POSTS`

## `js/src/server/routes-telegram-drafts-calendar.js`

**Exports**

- `DRAFTS_CALENDAR_POSTS`

## `js/src/server/routes-telegram-effects.js`

**Exports**

- `EFFECTS_POSTS`
- `validEffect`

## `js/src/server/routes-telegram-emoji-groups.js`

**Exports**

- `EMOJI_GROUPS_POSTS`

## `js/src/server/routes-telegram-emoji-status.js`

**Exports**

- `EMOJI_STATUS_POSTS`
- `validSet`
- `validUntil`

## `js/src/server/routes-telegram-ephemeral.js`

**Exports**

- `EPHEMERAL_GETS`
- `EPHEMERAL_POSTS`

## `js/src/server/routes-telegram-export.js`

**Exports**

- `EXPORT_POSTS`
- `bad`
- `plain`

## `js/src/server/routes-telegram-files.js`

The Telegram routes that answer bytes, not JSON (GET /api/telegram/…):
a message's picture, a sticker's, a custom emoji's, a place's map, a
file by range, a peer's photo; and the GETs the page reads as JSON — a
chat's info, its unread marks. See ./routes-telegram.js for the list.

Its routes:
  GET  /api/telegram/story?peer=&id= -> a story's picture or video (by
                      range), downloaded once
  GET  /api/telegram/media?chat=&id=&size=&part=
                                     -> a message's picture (s/m/x/y/w),
                                        downloaded once, then from disk
  GET  /api/telegram/custom-emoji?id=&full=1
                                     -> a custom emoji's picture, or
                                        (full) its animation or video
                                        (R-Y120)
  GET  /api/telegram/map?lat=&lon=&w=&h=&zoom=&scale=&hash=
                                     -> a place's map picture, kept a
                                        day; strict 400s (R-Y131)
  GET  /api/telegram/file?chat=&id=&rich=document:<id>&download=1
                                     -> a message's video, voice, audio,
                                        GIF or sticker (up to 64 MB), by
                                        byte range for players to seek;
                                        `rich`: a file of its rich message,
                                        `download=1`: saved under its name
                                        (R-Y224); a bad `rich` is a 400
  GET  /api/telegram/avatar?peer=&size=s|b&chat=&msg=
                                     -> a person's or chat's photo; 404
                                        when they have none
  GET  /api/telegram/chat-info?chat= -> { kind, title, members, online,
                                        username, about, photo, lastSeen? }

**Exports**

- `GETS`
- `answerFile`
- `byteRange`
- `dispositionOf`
- `fromApp`
- `sendBytes`

## `js/src/server/routes-telegram-folder-edit.js`

**Exports**

- `FOLDER_EDIT_POSTS`

## `js/src/server/routes-telegram-forum-view.js`

**Exports**

- `FORUM_VIEW_POSTS`

## `js/src/server/routes-telegram-games.js`

**Exports**

- `GAMES_POSTS`

## `js/src/server/routes-telegram-gift-send.js`

**Exports**

- `GIFT_SEND_POSTS`

## `js/src/server/routes-telegram-gifts-manage.js`

**Exports**

- `GIFTS_MANAGE_POSTS`

## `js/src/server/routes-telegram-group-extras.js`

**Exports**

- `GROUP_EXTRAS_POSTS`

## `js/src/server/routes-telegram-hashtags.js`

**Exports**

- `HASHTAG_POSTS`
- `TAG_SCOPES`
- `validTagSearch`

## `js/src/server/routes-telegram-inline.js`

**Exports**

- `INLINE_POSTS`

## `js/src/server/routes-telegram-instant-view.js`

**Exports**

- `INSTANT_VIEW_GETS`
- `INSTANT_VIEW_POSTS`

## `js/src/server/routes-telegram-invite-links.js`

**Exports**

- `INVITE_LINKS_POSTS`

## `js/src/server/routes-telegram-link-preview.js`

**Exports**

- `LINK_PREVIEW_POSTS`

## `js/src/server/routes-telegram-message-links.js`

**Exports**

- `MESSAGE_LINK_POSTS`

## `js/src/server/routes-telegram-notify-settings.js`

**Exports**

- `NOTIFY_SETTINGS_POSTS`

## `js/src/server/routes-telegram-paid.js`

**Exports**

- `PAID_POSTS`

## `js/src/server/routes-telegram-pinned-list.js`

**Exports**

- `PINNED_LIST_POSTS`

## `js/src/server/routes-telegram-pinned-order.js`

**Exports**

- `PINNED_ORDER_POSTS`

## `js/src/server/routes-telegram-privacy.js`

**Exports**

- `PRIVACY_POSTS`

## `js/src/server/routes-telegram-private-call.js`

**Exports**

- `PRIVATE_CALL_POSTS`

## `js/src/server/routes-telegram-profile-extras.js`

**Exports**

- `PROFILE_EXTRAS_POSTS`

## `js/src/server/routes-telegram-profile-stories.js`

**Exports**

- `PROFILE_STORIES_GETS`
- `PROFILE_STORIES_POSTS`

## `js/src/server/routes-telegram-proxy.js`

**Exports**

- `PROXY_POSTS`

## `js/src/server/routes-telegram-quick-replies.js`

**Exports**

- `QUICK_REPLY_POSTS`

## `js/src/server/routes-telegram-request-peer.js`

**Exports**

- `REQUEST_PEER_POSTS`

## `js/src/server/routes-telegram-ringtones.js`

**Exports**

- `RINGTONE_GETS`
- `RINGTONE_POSTS`

## `js/src/server/routes-telegram-round.js`

**Exports**

- `ROUND_POSTS`
- `validRound`

## `js/src/server/routes-telegram-saved-gifs.js`

**Exports**

- `SAVED_GIFS_POSTS`

## `js/src/server/routes-telegram-saved-tags.js`

**Exports**

- `SAVED_TAGS_POSTS`

## `js/src/server/routes-telegram-security-extras.js`

**Exports**

- `SECURITY_EXTRAS_POSTS`

## `js/src/server/routes-telegram-security.js`

**Exports**

- `SECURITY_POSTS`

## `js/src/server/routes-telegram-send-as.js`

**Exports**

- `SEND_AS_POSTS`

## `js/src/server/routes-telegram-share.js`

**Exports**

- `SHARE_POSTS`

## `js/src/server/routes-telegram-stars.js`

**Exports**

- `STARS_POSTS`

## `js/src/server/routes-telegram-stats.js`

**Exports**

- `STATS_POSTS`

## `js/src/server/routes-telegram-sticker-extras.js`

**Exports**

- `STICKER_EXTRAS_POSTS`

## `js/src/server/routes-telegram-sticker-settings.js`

**Exports**

- `STICKER_SETTINGS_POSTS`
- `validContact`

## `js/src/server/routes-telegram-storage.js`

**Exports**

- `STORAGE_POSTS`

## `js/src/server/routes-telegram-stories.js`

**Exports**

- `STORIES_POSTS`

## `js/src/server/routes-telegram-story-actions.js`

**Exports**

- `STORY_ACTION_POSTS`

## `js/src/server/routes-telegram-story-extras.js`

**Exports**

- `STORY_EXTRAS_POSTS`

## `js/src/server/routes-telegram-story-manage.js`

**Exports**

- `STORY_MANAGE_POSTS`

## `js/src/server/routes-telegram-story-post.js`

**Exports**

- `STORY_POST_POSTS`

## `js/src/server/routes-telegram-topic-admin.js`

**Exports**

- `TOPIC_ADMIN_POSTS`

## `js/src/server/routes-telegram-transcribe.js`

**Exports**

- `TRANSCRIBE_POSTS`

## `js/src/server/routes-telegram-translate-chat.js`

**Exports**

- `TRANSLATE_CHAT_POSTS`

## `js/src/server/routes-telegram-ttl.js`

**Exports**

- `TTL_POSTS`

## `js/src/server/routes-telegram-voice-chat.js`

**Exports**

- `VOICE_CHAT_POSTS`

## `js/src/server/routes-telegram-wallpapers.js`

**Exports**

- `WALLPAPER_GETS`
- `WALLPAPER_POSTS`

## `js/src/server/routes-telegram-web-apps.js`

**Exports**

- `WEB_APPS_POSTS`

## `js/src/server/routes-telegram-yextras.js`

**Exports**

- `YEXTRAS_POSTS`

## `js/src/server/routes-telegram.js`

The connected Telegram account (see ../sources/telegram-account.js).
  GET  /api/telegram/status          -> { connected, kind, account, at, … }
  POST /api/telegram/sync    {full?} -> the status after a sync
  POST /api/telegram/history {chat, before?, limit?, priority?}
                                     -> { written, cached, complete } the
                                        chat's newest messages, or the page
                                        before message `before`; the store
                                        answers what it already holds
                           {chat, after} -> { written, cached, newest } the
                                        page after message `after` (R-Y106)
  POST /api/telegram/history-at {chat, date}
                                     -> { ok, id, newest } the first message
                                        at or after `date` (unix seconds)
                                        and a page around it (R-Y106)
                      {chat, id} -> { ok, id, newest } message `id` and a
                                        page around it (a jump to a message
                                        far back, R-Y107)
  POST /api/telegram/dialogs {priority?}
                                     -> { written, complete } the next page
                                        of the chat list
  POST /api/telegram/read {chat, maxId}
                                     -> { ok } marks the chat read up to
                                        maxId on Telegram (forward only)
  POST /api/telegram/draft {chat, text}
                                     -> { ok } the chat's cloud draft
  POST /api/telegram/refresh {chat, ids, priority?}
                                     -> { written, deleted } those messages
                                        read again; gone ones marked deleted
  POST /api/telegram/forward {fromChat, ids, toChat, dropAuthor?,
                      dropMediaCaptions?}
                                     -> { ok, forwarded } (the two flags
                                        hide the sender's name and the
                                        captions, R-Y154)
  POST /api/telegram/delete {chat, ids, revoke?}
                                     -> { ok, deleted }
  POST /api/telegram/pin {chat, id, unpin?, oneSide?, silent?}
                                     -> { ok, pinned }
  POST /api/telegram/dialog {chat, action, for?}
                                     -> { ok } the chat list's menu:
                                        pin, unpin, mute (for seconds),
                                        unmute, archive, unarchive,
                                        read, unread (R-Y97)
  POST /api/telegram/search-peers {q}
                                     -> { ok, peers } people and chats by
                                        name or username (R-Y107)
  POST /api/telegram/search-global {q, cursor?}
                                     -> { ok, messages, count, more, cursor }
                                        messages in every chat (R-Y107)
  POST /api/telegram/search {chat, q, offsetId?}
                                     -> { ids, count, more } the chat's
                                        messages with `q`, newest first,
                                        stored (R-Y98)
  POST /api/telegram/history {chat, topic, before?, limit?}
                                     -> { written, complete } a forum
                                        topic's newest messages, or the
                                        page before `before` (R-Y122)
  POST /api/telegram/forum-topics {chat, fresh?}
                                     -> { ok, forum, topics } a forum
                                        group's topics (R-Y122)
  POST /api/telegram/comments {chat, post, before?, limit?}
                                     -> { ok, group, root, messages,
                                        complete } a channel post's
                                        comments or a message's thread,
                                        oldest first (R-Y126)
  POST /api/telegram/comments-read {chat, post, max}
                                     -> { ok } the comments up to max read
  POST /api/telegram/readers {chat, id}
                                     -> { ok, readers: [{ id, name, date }] }
                                        who read the user's own message
                                        in a small group (R-Y127)
  POST /api/telegram/translate {chat, ids, to}
                                     -> { ok, items: [{ id, text,
                                        entities }] } 1..20 messages
                                        translated to `to` (R-Y132)
  POST /api/telegram/bot-commands {chat}
                                     -> { ok, commands: [{ command,
                                        description, bot, botName,
                                        username }], menu: { kind, text?,
                                        url? } } a bot's or a group's
                                        bots' commands (R-Y135)
  POST /api/telegram/reactors {chat, id, emoji?, offset?}
                                     -> { ok, count, items, next } who
                                        reacted to a message, by page
                                        (R-Y127)
  POST /api/telegram/comment-send {chat, post, text, replyTo?, clientId?}
                                     -> { ok, chat } a comment sent to
                                        the discussion group
  POST /api/telegram/shared-counts {chat}
                                     -> { ok, counts } how many photos,
                                        videos, files… (R-Y111)
  POST /api/telegram/shared-media {chat, kind, offsetId?}
                                     -> { ok, messages, count, more,
                                        last } a kind's, newest first
  POST /api/telegram/upload?name=   (application/octet-stream body)
                                     -> { token, name, size } one file
                                        kept for send-files (R-Y99)
  POST /api/telegram/send-files {chat, tokens, caption?, asPhoto?,
                                 group?, replyTo?}
                                     -> { ok, ids } the files sent:
                                        photos, albums, files (R-Y99)
  POST /api/telegram/send-voice {chat, token, duration, waveform?,
                                 replyTo?}
                                     -> { ok, ids } a recorded voice
                                        as a voice message (R-Y108)
  POST /api/telegram/bot-callback {chat, id, data?, game?}
                                     -> { ok, message, alert, url } a
                                        bot's button pressed (R-Y110)
  POST /api/telegram/sticker-search {q, lang?}
                                     -> { ok, stickers, sets } stickers
                                        for an emoji or words (R-Y112)
  POST /api/telegram/sticker-save {id, action}
                                     -> { ok } fave, unfave, unrecent,
                                        saveGif or unsaveGif (R-Y115)
  POST /api/telegram/sticker-set-install {id, install}
                                     -> { ok, installed } a found set
                                        added, or one removed (R-Y116)
  POST /api/telegram/invite-check {hash}
                                     -> { ok, already, chat | invite }
                                        what an invite link leads to
                                        (R-Y123)
  POST /api/telegram/invite-join {hash}
                                     -> { ok, chat? } the user joined
                                        (or asked to), on their press
  POST /api/telegram/chat-contacts   -> { ok, contacts } the contacts to
                                        pick a new group's members from
                                        (R-Y129)
  POST /api/telegram/group-create {title, users}
                                     -> { ok, chat, title } a basic group
  POST /api/telegram/channel-create {title, about?}
                                     -> { ok, chat, title } a channel
  POST /api/telegram/chat-edit {chat, title?, about?, photo?}
                                     -> { ok } a chat's name, description
                                        and photo (an upload's token, or
                                        "remove") changed
  POST /api/telegram/profile         -> { ok, id, firstName, lastName,
                                        about, username, phone, hasPhoto,
                                        aboutMax } the user's own profile
                                        (R-Y136)
  POST /api/telegram/profile-save {firstName?, lastName?, about?}
                                     -> { ok } names (1..64, 0..64) and
                                        bio (0..140) changed
  POST /api/telegram/username-check {username}
                                     -> { ok, status: available | taken |
                                        invalid }
  POST /api/telegram/username-save {username}
                                     -> { ok } ("" removes it)
  POST /api/telegram/profile-photo {token} | {remove: true}
                                     -> { ok } an upload set as the photo,
                                        or the photo removed
  POST /api/telegram/invite-revoke {chat}
                                     -> { ok, link } a chat's primary
                                        invite link replaced
  POST /api/telegram/peer-block {chat, block} -> { ok, blocked }
  POST /api/telegram/peer-contact {chat, add, firstName?, lastName?,
                                   share?} -> { ok, contact }
  POST /api/telegram/peer-report {chat, option?, message?, ids?} -> { ok,
                 result: choose{title, options} | comment{optional,
                 option} | reported } (R-Y128)
  POST /api/telegram/peer-report-spam {chat} -> { ok }
  POST /api/telegram/peer-settings {chat} -> { ok, bar: { reportSpam,
                                     addContact, blockContact,
                                     shareContact, autoarchived,
                                     registered, country } } (R-Y137)
  POST /api/telegram/peer-hide-bar {chat} -> { ok }
  POST /api/telegram/peer-share-contact {chat} -> { ok }
  POST /api/telegram/members {chat, q?, offset?, limit?}
                                     -> { ok, total, members, canBan,
                                        canInvite } a group's members,
                                        recent or found by words (R-Y125)
  POST /api/telegram/member-remove {chat, user}
                                     -> { ok } a member removed from the
                                        group; they may come back
  POST /api/telegram/sticker-set-box {id, accessHash} | {shortName}
                                     -> { ok, set, items } the set a
                                        chat's sticker belongs to, for
                                        its box (R-Y124)
  POST /api/telegram/dice {emoticon}
                                     -> { ok, emoticon, items } a die's
                                        animations: items[n] rolls to n
                                        (R-Y130)
  POST /api/telegram/emoji-keywords {lang}
                                     -> { ok, lang, keywords } the words
                                        emoji are found by (R-Y117)
  POST /api/telegram/gif-search {q, offset?}
                                     -> { ok, gifs, next } GIFs found
                                        by Telegram's @gif bot
  POST /api/telegram/remove-chat {chat, action, revoke?}
                                     -> { ok, deleted } clear, delete
                                        or leave the chat (R-Y100)
Responses carry the account's public name and counts, never a secret.

Routes of the routes-telegram-*.js tables are documented in those files.

**Exports**

- `byteRange`
- `fromApp`
- `handleTelegramRoutes`

## `js/src/server/routes-vk.js`

VK scroll-back (R-Z20), a user action from the page:

  POST /api/vk/history {chat, before?, captchaSid?, captchaKey?}
    -> { ok, imported, complete }
       or { ok: false, error, code } with `code` one of bad-request |
       not-connected | rate-limited (HTTP 429) | captcha (HTTP 409, plus
       `captcha: { sid, img }` -- `img` only when it is on VK's own API
       host) | the network's own code.

`chat` is the VK peer id, `before` the VK id of the oldest message the
page holds. A captcha is shown to the user by the page, which repeats
this request once with `captchaSid` and `captchaKey`; the program never
solves one, and pulls in the background never ask (they back off and mark
the connection as needing attention: ../sources/pull-runner.js).

**Exports**

- `handleVkRoutes`
- `historyRequest`

## `js/src/server/routes-whatsapp.js`

WhatsApp routes (R-Z9).

  GET  /api/whatsapp/web             -> { ok, state, open, signedIn, signedInAt, terms }
  POST /api/whatsapp/web/sign-in     -> opens the visible WhatsApp Web window
  POST /api/whatsapp/web/close       -> closes it
  POST /api/whatsapp/archive {name, data(base64)}
                                     -> imports an "Export chat" .txt or .zip
                                        (a zip's photos/videos/files are kept in media/whatsapp, R-Z15)

The sign-in window is for the person to scan the QR code themselves
(see ../sources/whatsapp-web-signin.js); these routes never touch it.

**Exports**

- `WHATSAPP_TERMS`
- `handleWhatsAppRoutes`

## `js/src/server/runtime-lifecycle.js`

**Exports**

- `createRuntimeLifecycle`

## `js/src/server/secret-mask.js`

What the page may learn about a saved secret (R-Z1): that it exists, not
what it is. The server uses the raw value itself (it reads the store, not
HTTP), so a `GET /links?prefix=secret:` answer — which a page on another
site could read if it got past the origin rules — carries no token and no
Telegram session.

The browser-only mode (the hosted page without a server) keeps its own
secrets in the browser's own store and never asks the server for them.

**Exports**

- `maskSecret`
- `maskSecrets`

## `js/src/server/telegram-extras.js`

The extra Telegram accounts, each fully usable (R-Y202; learned, never
copied: Telegram Desktop switches its whole window to the account the
user picks). R-Y198 only listed them; here each signed-in extra account
N (2..5) runs its own service on its own store, so nothing of it can
mix with account 1:

  <store dir>/accounts/telegram-N/   its own link store (data.lino, ...)
  <store dir>/accounts/telegram-N/media/telegram   its downloaded pictures

The directory is made only when the account is signed in, and removed
(that one directory, nothing else) when it is logged out.

Credentials. The account's secrets stay where R-Y198 keeps them, in
account 1's store under `secret:telegram@N:*`. `createTelegramAccount`
reads `secret:telegram:*` from the store it is given, so that store is
wrapped (`borrowSecrets`): a read of `secret:telegram:user-session`,
`api-id` or `api-hash` is answered from account 1's `@N` key, the
bot token is never offered, and the connection proxy is account 1's.
No secret is copied into the account's own store, and nothing is ever
written to account 1's store from here (reads and a change
subscription only).

`createExtraRuntime` keeps one entry per running slot: its store, its
chat index (the chat list and history pages), its service, and the
sender the composer uses. `scopedContext` is the server context a
request for that account is answered with.

**Exports**

- `accountDir`
- `borrowSecrets`
- `createExtraRuntime`
- `scopedContext`
- `telegramChats`
- `unreadOfStore`

## `js/src/server/telegram-route-error.js`

**Exports**

- `telegramRouteError`

## `js/src/server/util.js`

Tiny request/response helpers shared by route modules. Keeping these
separate lets each route file stay focused and well below the
eslint complexity budget.

**Exports**

- `BodyError`
- `MAX_JSON_BODY`
- `bodyFailure`
- `fail`
- `json`
- `readBody`
- `text`

## `js/src/server/worker-client.js`

**Exports**

- `spawnWorker`
- `workerArgs`

## `js/src/server/worker-proxy.js`

**Exports**

- `createWorkerProxy`

## `js/src/server/worker-request.js`

**Exports**

- `relayWorkerRequest`

## `js/src/server/worker-target.js`

**Exports**

- `createWorkerTarget`

## `js/src/sources/archive/context.js`

What an archive importer gets besides the parsed file (R-Z10): the
other files of the same archive (to find a message's photo, video…),
a sink that copies them into `<store>/media/<network>/<sha256>.<ext>`
(owner-only, content-addressed so a second import writes nothing new),
and per-import counters so ids stay unique across `message_N.json`.

**Exports**

- `createArchiveContext`
- `isFatalWrite`

## `js/src/sources/archive/legacy.js`

Re-importing an archive that an older build imported (R-Z10).

Before R-Z10 a Facebook message was `msg:facebook:<ms>` and a LinkedIn
one `msg:linkedin:<conversation>-<date>`. A link built from an archive
row carries (under a symbol, so it is never stored) the old id it had
and what that old link must look like (sender, chat). The importer
skips a row whose old link is already in the store, under the old id or
under the id migration 0005 moved it to (`alias:<old id>`), so the
import does not double the history.

**Exports**

- `LEGACY`
- `alreadyImported`
- `withLegacy`

## `js/src/sources/archive/media-store.js`

Copies archive files into `<store>/media/<network>/<sha256><ext>`
(R-Z10): owner-only, content-addressed (a second import writes
nothing new), streamed through a hash so large videos never sit in
memory. Node only; the page never loads this.

**Exports**

- `mediaSaver`
- `saveMedia`

## `js/src/sources/archive/meta-thread.js`

Facebook / Messenger and Instagram "Download your information" threads
(R-Z10): `messages/inbox/<thread>/message_N.json` (and `.html`) turned
into message links.

Ids are `<thread folder>:<timestamp ms>:<sender digest>:<n>` where n
counts messages of the same sender in the same millisecond, so two
messages never collide and importing the same archive again lands on
the same ids (no duplicates). The thread id is the folder name.
Learned from Meta's documented export layout, never from real data.

**Exports**

- `htmlDateToMs`
- `metaHtmlToLinks`
- `metaJsonToLinks`
- `threadIdOf`

## `js/src/sources/archive/text.js`

Text repairs shared by the data-archive importers (R-Z10).

**Exports**

- `baseName`
- `decodeEntities`
- `extName`
- `findAll`
- `fixDeep`
- `fixMojibake`
- `hasClass`
- `isoOf`
- `linkedinDate`
- `parseHtml`
- `shortHash`
- `textOf`

## `js/src/sources/archive/x-dms.js`

X "Download an archive of your data" Direct Messages (R-Z10): the
`window.YTD.<name>.partN = [...]` scripts `direct-messages.js` (1:1)
and `direct-messages-group.js` (groups), `account.js` (who "me" is),
and the files in `direct_messages_media/` / `direct_messages_group_media/`.

**Exports**

- `xDmsToLinks`
- `xToArchive`
- `ytdPayload`

## `js/src/sources/archive/zip-file.js`

A ZIP reader that works on the file, not on a buffer (R-Z10): only the
central directory is read up front; every entry is then read from its
own byte range and inflated as a stream, so a multi-gigabyte data
export never sits in memory. ZIP64 (archives and entries over 4 GiB or
65535 entries) is supported. Node built-ins only.

**Exports**

- `MAX_TEXT_BYTES`
- `isZipFile`
- `openZipFile`

## `js/src/sources/auto-import/archive.js`

Minimal readers for the containers provider data exports arrive in:
ZIP (Google Takeout, X, Facebook, LinkedIn), gzip'd tar (GitHub
account export) and CSV (LinkedIn, Upwork). Node built-ins only, so
the auto-import path adds no runtime dependency besides
browser-commander itself.

**Exports**

- `archiveReaderFor`
- `parseCsv`
- `readTarGzEntries`
- `readZipEntries`

## `js/src/sources/auto-import/files.js`

Turn what the auto-import browser produced — downloaded export files
or the DOM of an open chat — into unified message links.

**Exports**

- `extractVisibleMessages`
- `importDownloadedFile`
- `scrapedRowsToLinks`

## `js/src/sources/auto-import/index.js`

Browser auto-import (Connections -> "Import with browser").
Node-only: the local JS server drives a real browser through
browser-commander. See ./manager.js for the job lifecycle.

**Exports**

- `FULL_DISK_ACCESS_URL`
- `archiveReaderFor`
- `autoImportRecipes`
- `browserName`
- `createAutoImportManager`
- `createSignIns`
- `createTelegramCreds`
- `defaultRoots`
- `describeRecipes`
- `extractVisibleMessages`
- `hostAppName`
- `importDownloadedFile`
- `launchWithBrowserCommander`
- `maskHint`
- `parseCsv`
- `parseEnv`
- `probeBrowserAutomation`
- `readTarGzEntries`
- `readZipEntries`
- `scrapedRowsToLinks`

## `js/src/sources/auto-import/manager.js`

Auto-import jobs: one browser session per provider, driven by
browser-commander.

Lifecycle: launching -> waiting (browser open, listening for
downloads) <-> importing -> done | failed | stopped. A job keeps
listening after each import because some services split an export
into several files; it ends when the user presses "Finish", closes
the browser window, or after `idleTimeoutMs` without activity.

Browser selection (env, all optional):
  MS_BROWSER_CDP_URL     attach to an already running Chrome
                         (http://host:9222 or ws://...), e.g. from a
                         Docker container or your everyday browser
  MS_BROWSER_CHANNEL     chrome | msedge | brave | chromium ...
  MS_BROWSER_EXECUTABLE  explicit browser binary
  MS_BROWSER_HEADLESS=1  headless (only useful with a signed-in profile)
  MS_BROWSER_VERBOSE=1   browser-commander debug logging

**Exports**

- `createAutoImportManager`
- `launchWithBrowserCommander`
- `probeBrowserAutomation`

## `js/src/sources/auto-import/recipes.js`

Browser auto-import recipes, one per provider in `sourceRegistry`.

Every recipe opens `url` in a real browser driven by
browser-commander. The user signs in there (the profile is kept per
provider, so it is a one-time step) and starts the service's own data
export; every file the browser downloads is captured, unpacked when
it is a ZIP / tar.gz, and each entry whose path matches `files` is
handed to the provider's `parseArchive`.

`toArchive(name, text)` adapts a raw export file to the shape the
adapter's `parseArchive` expects (CSV rows, X's `window.YTD = ...`
scripts). Without it JSON files are parsed and anything else is
passed through as text.

`domains` are the sites whose sign-in cookies the import window may
reuse from the user's own browsers (see ./sign-ins.js).

Services without a downloadable export in the browser (Telegram Web,
WhatsApp Web) also carry a `scrape` config: "Capture this page"
reads the messages of the chat currently open in the browser.

**Exports**

- `autoImportRecipes`
- `describeRecipes`

## `js/src/sources/auto-import/sign-ins.js`

Reuse the sign-ins the user already has in their own browsers.

"Import with browser" opens each service in a dedicated browser profile,
so the user would otherwise sign in to every service again. With
browser-commander this module can:

  scan()        list every installed browser profile (Chrome, Safari,
                Firefox, Edge, Brave, Arc, Yandex, …) and count, per
                service, the cookies it holds. Only host names are read,
                never cookie values.
  importFrom()  on the user's explicit request, read the cookies of the
                chosen profiles, keep only the services' own sites and
                save them privately (owner-only file) until the next
                import window for that service is opened.
  peek/consume  the import window seeds those cookies once, then the
                copy is deleted: the dedicated profile keeps the session.

Everything is read-only for the source browsers and stays on this
computer. Cookie values are never logged and never sent to the app;
the app only sees counts and browser names.

macOS protects Safari's data (and some other browsers' files) behind
Full Disk Access. access() reports whether this server process has it
and openFullDiskAccessSettings() opens the right System Settings pane.

**Exports**

- `FULL_DISK_ACCESS_URL`
- `browserName`
- `createSignIns`
- `hostAppName`
- `onDomains`

## `js/src/sources/auto-import/telegram-creds.js`

Find the Telegram sign-ins the user already has on this computer.

People who experiment with Telegram scatter their own credentials across
repositories: the same bot token in a dozen project `.env` files, a GramJS
user "string session" saved beside another (konard/telegram-bot writes it
to `.telegram_session`), an `api_id`/`api_hash`/phone trio in a third.
This module walks folders the user chooses and distils them down to the
few real accounts behind them, so the account can be connected here
without hunting for them again.

  scan({ roots })  read-only walk of the chosen folders. The same token or
                   session found in many files collapses to ONE entry
                   (every location kept for display). Each distinct
                   credential is checked LIVE — bot tokens via the Bot API
                   `getMe`, user sessions via MTProto — so only accounts
                   that still work are listed, and a user session resolves
                   to its real phone number. Entries are grouped by the
                   account they belong to and typed: a bot token, a login
                   by session, or a login by phone & password.
  use(id, {store}) connect the chosen credential — store it under the
                   `secret:telegram:*` keys the app already reads. A
                   phone & password credential has no stored session yet,
                   so `use` reports `needsLogin` and the caller starts the
                   interactive sign-in with `loginContext(id)`.

Everything stays on this computer: raw values live in an owner-only file
(0600) until the user connects one, and are never logged or returned to
the browser — callers see types, locations and masked hints only.

**Exports**

- `createTelegramCreds`
- `defaultRoots`
- `maskEnds`
- `maskHint`
- `parseEnv`

## `js/src/sources/browser-actions.js`

What a person does to a message in a network's web app — edit it,
delete it, react to it, forward it, read the chat — done the same way
through browser-commander (R-Y38). It is the fallback of
./message-actions.js when the network's API cannot do the action.

Each action finds the message in the open chat by its id (the
`messages.idAttribute` of ./web-uis.js), marks that element so later
selectors can address it, opens its menu — a right click
(`actions.menu: 'contextmenu'`) or a button inside the message shown
on hover — and clicks the menu items the table names. A step whose
selector matches nothing fails with a code naming the table field to
update, never silently.

**Exports**

- `TARGET_ATTRIBUTE`
- `createBrowserActions`
- `dispatchContextMenu`
- `extractChats`
- `markMessage`
- `scrollToNewest`
- `selectComposerText`

## `js/src/sources/browser-sender.js`

Send and receive messages through the official web UIs (issue #31,
PR #34).

The API adapters (`./vk.js`, `./telegram.js`, `./whatsapp.js`) are
the first choice, but they are not always usable: a VK community
token cannot write to a personal friend, a Telegram bot cannot open a
conversation, WhatsApp Cloud needs a business number, and any token
can expire. In every one of those cases the person can still send the
message by hand in vk.com, web.telegram.org or web.whatsapp.com — so
this module does exactly that, through browser-commander, in the
persistent profile where the user signed in once.

- `WEB_UIS` (./web-uis.js) is the declarative per-network table: chat
  URL, composer, send control, message list, chat list, message menu
  and logged-in markers.
- `createBrowserSender()` drives those pages: `send`, `setTyping`,
  `readRecent`, `readChats`, `editMessage`, `deleteMessages`, `react`,
  `forwardMessages`, `markRead` (./browser-actions.js) and `close`,
  with one lazily opened page per network.
- `createFallbackSender()` tries the API first and falls back to the
  browser when the API throws (or is not configured).
- `createDefaultSender()` wires the source adapters and the browser
  together for automations and the chat composer.

The browser session itself comes from `../cv/browser.js`, so the
optional-dependency story (`browser-commander` + `playwright`,
`BrowserUnavailableError`, persistent profiles) is shared with CV runs.

**Exports**

- `BrowserLoginRequiredError`
- `NO_FALLBACK_CODES`
- `SendFallbackError`
- `WEB_UIS`
- `WEB_USER_CONFIRMED_ONLY`
- `createBrowserSender`
- `createDefaultSender`
- `createFallbackSender`
- `extractMessages`
- `firstMatch`

## `js/src/sources/contacts-import.js`

**Exports**

- `applyContactsImport`
- `normalizeContact`
- `planContactsImport`

## `js/src/sources/cv-bridge.js`

Bridge between the message-source registry and the CV plans (R-E11).

Every job board in the registry also owns a declarative CV plan in
`js/src/cv/platforms`. Wiring them together here means a caller that
already holds a source adapter can read or update the resume behind
it without knowing whether the board offers an HTTP API (hh.ru,
SuperJob) or only a browser session (Naukri, VietnamWorks, TopCV).

The CV modules are imported lazily so that loading the registry —
which the CLI and the server do on every start — never pulls in the
browser stack. The specifier is held in a constant so bundlers can
not follow it either: `js/src/cv/index.js` reaches `playwright`,
`node:fs/promises` and `node:os`, none of which exist in a browser
bundle, and the SPA only ever talks to `/api/cv/*` anyway.

**Exports**

- `CvRuntimeUnavailableError`
- `cvPlatformIdOf`
- `cvPlatformOf`
- `readSourceCv`
- `withCvPlatform`
- `writeSourceCv`

## `js/src/sources/email-compose.js`

Writing an outgoing mail (R-Z5; RFC 5322, 2045 and 2047, learned,
never copied).

The message that goes out is plain ASCII on the wire: a non-ASCII
subject or display name is an encoded word, the body is 7bit when it
can be and base64 UTF-8 when not, and every header value has its line
breaks removed (a subject of `x\r\nBcc: evil@x` cannot add a header).
A blind copy is never written into the message: it is an envelope
recipient only (`envelopeRecipients`). `Date` and `Message-ID` are
always set, and a reply carries `In-Reply-To` and `References`.

**Exports**

- `buildRfc822`
- `checkedAddress`
- `composeMessage`
- `encodeWords`
- `envelopeRecipients`
- `headerText`
- `newMessageId`
- `rfc5322Date`

## `js/src/sources/email-html.js`

A mail's HTML as safe data (R-Z5; learned, never copied).

HTML from the outside is never rendered. It is read into a small tree
of plain data (text, a few formatting tags, tables, lists, links, and
inline pictures that name a part of the same mail by `cid`) and the
page draws that tree with React elements only (../web/chat-email-body.js).
Everything else is dropped on the way in: scripts, styles, forms,
frames, event handlers, inline CSS, remote pictures (they would tell
the sender that the mail was read) and links that are not http, https,
mailto or tel. The plain-text form of a mail is made from the same tree.

**Exports**

- `decodeEntities`
- `htmlToSafe`
- `htmlToText`
- `safeHref`

## `js/src/sources/email-live.js`

Email over the network (issue #3; R-Z5).

Gmail, Microsoft Graph and JMAP are plain HTTP and can run in the SPA
when CORS allows it. IMAP, POP3 and SMTP need a local server transport
(./email-node-transport.js registers itself here with
`setEmailTransportFactory`) because browsers cannot open mail sockets.

`emailSource.live` is what the rest of the app calls (Chat's composer,
automations, `/api/message/read`): it takes the saved connection's
options (token, host, login, password… see ./email-store.js), picks the
protocol they describe and does the action. A reply carries the
thread's ids (In-Reply-To, References, Gmail `threadId`, Graph's reply
call, JMAP `inReplyTo`). Pulls skip what is already stored or start
after what was seen (`options.sync`), so a pull is not a re-download.

**Exports**

- `EMAIL_PROTOCOLS`
- `createEmailLive`
- `emailLiveActions`
- `protocolFor`
- `setEmailTransportFactory`

## `js/src/sources/email-mime.js`

Reading a raw mail message (R-Z5; learned from RFC 2045, 2046, 2047,
2231 and 5322, never copied from a mail client).

A message arrives as bytes (IMAP, POP3, `.eml`, `.mbox`) or as text
the page already decoded. It is read as a "binary string" (one char
per byte) so every part can be decoded with its own charset: koi8-r,
windows-1251, iso-8859-x, gb2312 and so on through `TextDecoder`.
Boundaries keep their case, multiparts nest, encoded-word headers
(Q and B, any charset) decode, attachments keep name, size and type
(and their bytes go to the attachment sink, when the server set one),
and the HTML body becomes a safe tree (./email-html.js).

**Exports**

- `base64ToBytes`
- `baseSubject`
- `bytesToBase64`
- `cleanMessageId`
- `decodeCharset`
- `decodeHeaderValue`
- `decodeQuotedPrintable`
- `decodeQuotedPrintableBytes`
- `emptyBody`
- `finishBody`
- `firstHeader`
- `headerObject`
- `mergeAlternative`
- `mergeSequence`
- `messageBinary`
- `messageIds`
- `normalizeAddress`
- `parseAddressList`
- `parseHeaders`
- `parseStructured`
- `readBody`
- `readMessage`
- `setAttachmentSink`
- `splitMbox`
- `threadKey`
- `utf8Bytes`

## `js/src/sources/email-node-socket.js`

Sockets for the local mail transport (R-Z5).

A mail connection is one of three kinds, and never a silent downgrade:
  tls       implicit TLS from the first byte (IMAP 993, POP3 995, SMTP 465);
  starttls  plain greeting, then the server must accept STARTTLS (IMAP and
            SMTP 143/587/1143/1025, POP3 110) and the rest runs over TLS;
  none      no TLS at all, only when asked for by name, and credentials
            travel in clear only to this computer (loopback).
The server's certificate is always checked. A private CA is given as
`ca`; switching the check off is allowed for loopback only (Proton
Bridge's self-signed certificate) and only when asked for by name.

**Exports**

- `MailSocket`
- `connectSocket`
- `guardCleartext`
- `isLoopback`
- `securityOf`
- `tlsOptionsOf`

## `js/src/sources/email-node-transport.js`

Node local-server transport for raw mail protocols (R-Z5).

Browser code must not import this module. It exists for the local
server and CLI path where TCP/TLS sockets are available:

- IMAP and POP3 read mail, SMTP sends it. Implicit TLS, STARTTLS and
  (named, loopback only) plain are in ./email-node-socket.js; the
  certificate is always checked.
- A password logs in with LOGIN / AUTH PLAIN / AUTH LOGIN; an OAuth
  token (no password) with XOAUTH2.
- A pull is incremental: IMAP remembers UIDVALIDITY and the last UID,
  POP3 the UIDLs it has seen (`options.since` in, `state` out); a
  message above the size cap is skipped, not loaded into memory.
- IMAP can mark mail read and move it to the Trash folder.
- A send never writes the Bcc into the message (it is a RCPT only),
  and a failure after the message left is `send-unknown`, never retried.

**Exports**

- `createNodeEmailTransport`

## `js/src/sources/email-records.js`

Email records as message links (issue #3; R-Z5).

Mail arrives as raw RFC 822 text or bytes (IMAP, POP3, `.eml`,
`.mbox`, Gmail `format=raw`) or as the JSON of Gmail, Microsoft Graph
and JMAP. Each is read into one link shape (`buildEmailMessageLink`):
the plain text, a safe tree of the HTML (never HTML itself), the
attachments' name, size and type, and the ids that put a mail into
its conversation: Message-ID, In-Reply-To and References (see
./email-mime.js `threadKey`). The network side is ./email-live.js.

**Exports**

- `SOURCE`
- `buildEmailMessageLink`
- `normalizeEmailRecord`
- `normalizeGmailMessage`
- `normalizeGraphMessage`
- `normalizeJmapMessage`
- `parseAddressList`
- `parseEmailArchive`
- `parseRfc822Message`
- `utf8ToBase64Url`

## `js/src/sources/email-store.js`

What the email adapter needs from the store (R-Z5): the connection the
user saved on the Connections screen, what was already pulled, and the
thread a Chat message answers.

The Connections screen saves `secret:email:<name>` links (token, host,
username, password…). `emailOptionsFrom` turns them into the `live`
options of ./email-live.js, with three helpers the adapter calls:

  sync.get / sync.set   what a pull remembers (IMAP's UIDVALIDITY and
                        last UID, Graph's newest time), in `sync:email:*`
                        links, written after the mail is stored;
  sync.has(id)          whether a mail is stored (it is not fetched again);
  lookup.thread(chat)   who to answer, the ids and subject, from the
                        newest incoming mail of the chat;
  lookup.messages(chat) the chat's mails (to mark them read).

Values never leave the server and nothing here logs them.

**Exports**

- `EMAIL_SETTINGS`
- `emailConfigured`
- `emailOptionsFrom`
- `secretValue`

## `js/src/sources/email.js`

Email source adapter (issue #3; R-Z5).

The facade over three modules: ./email-mime.js reads raw messages,
./email-records.js turns mail (raw or a provider's JSON) into message
links, and ./email-live.js talks to the mail servers. Browser-capable
mail APIs (JMAP, Gmail, Microsoft Graph) are plain HTTP fetches and
can run directly in the SPA when CORS allows them; raw protocols
(IMAP, POP3, SMTP) need the local server's transport.

**Exports**

- `EMAIL_PROTOCOLS`
- `buildEmailMessageLink`
- `buildRfc822`
- `composeMessage`
- `createEmailLive`
- `emailSource`
- `normalizeEmailRecord`
- `parseAddressList`
- `parseEmailArchive`
- `parseRfc822Message`
- `protocolFor`
- `setAttachmentSink`
- `setEmailTransportFactory`

## `js/src/sources/facebook.js`

Facebook source adapter (R-E5).

Reads `messages/inbox/<thread>/message_*.json|html` files from Facebook's
and Instagram's download-your-data archives (R-Z10: mojibake repaired,
media copied, collision-free ids; see ./archive/meta-thread.js).
The live side targets Messenger Platform / Graph API page messaging:
pull page conversations, normalize webhook events, send text replies,
and update page profile metadata when credentials permit it.

**Exports**

- `createFacebookLive`
- `facebookConversationsToLinks`
- `facebookDeliveryFromWebhook`
- `facebookSource`
- `facebookWebhookToLinks`

## `js/src/sources/github-actions.js`

What the user does to a GitHub item: reply, edit, delete, react (R-Z11).

Every action names the object by the reference kept at pull time
(`link.externalId`, ./github-ref.js) -- never by parsing the link id --
so an issue comment, a review comment and an issue body each reach their
own endpoint. An item pulled before the reference existed is refused with
`no-external-id`; nothing is sent and the browser is not tried.

**Exports**

- `GITHUB_EMOJI_TO_REACTION`
- `deleteGithubComments`
- `editGithubComment`
- `postGithubComment`
- `reactGithubComment`

## `js/src/sources/github-check.js`

Whether a GitHub account someone sent us is theirs (R-Y53): its public
profile is read once — `GET api.github.com/users/<login>` and its
`social_accounts` — kept in the store as `github-check:<login>` and
read again only after a week. Each login is asked about once at a
time; a rate limit is waited out, never retried in a loop.

  confirmed — the profile links back to the person (their Telegram
              username in the profile's links, blog or bio);
  name      — the profile's name is the person's name;
  shared    — they sent it, nothing on it points back;
  missing   — no such account;
  unknown   — GitHub could not be asked (offline, rate limit).

Only public data of a login the person sent is read; no token is sent.

**Exports**

- `createGitHubCheck`
- `githubCheckId`
- `githubVerdict`

## `js/src/sources/github-http.js`

Reading from the GitHub API politely (R-Z11).

  - Every list follows the `Link: rel="next"` header until there is no
    next page; a visited-url guard and a very high safety cap stop a
    server that loops (no page counting).
  - `ETag` / `Last-Modified` come back so the caller can ask again with
    `If-None-Match` / `If-Modified-Since`; a `304` costs no rate limit.
  - `x-ratelimit-remaining` / `x-ratelimit-reset` and the secondary limit's
    `retry-after` are respected: a short wait is slept (and the request
    repeated, a read is safe to repeat), a long one is reported as a
    `rate-limited` error carrying `retryAfter` seconds. Never a crash and
    never a busy loop.

Only reads go through here; writes keep `requestJson` (./http.js), which
marks an ambiguous outcome and is never repeated.

**Exports**

- `createGithubHttp`
- `headerValue`
- `parseLinkHeader`

## `js/src/sources/github-inbox.js`

The parts of a GitHub inbox the issue endpoints do not give (R-Z11):

  - Notifications (`GET /notifications`, classic token): mentions, review
    requests, assignments with their `reason`. Polled with `since` and
    `If-Modified-Since` (a 304 is free) and never faster than the
    `X-Poll-Interval` GitHub asks for. Marking read is a separate,
    explicit call (`markThreadRead`, `markAllRead`); fetching never does it.
  - Discussions through GraphQL (the REST API has none), read and reply,
    where the token has access. Lists are walked by `pageInfo`.

**Exports**

- `fetchDiscussions`
- `fetchNotifications`
- `graphqlUrl`
- `markAllRead`
- `markThreadRead`
- `replyToDiscussion`

## `js/src/sources/github-ref.js`

The GitHub identity of a pulled item (R-Z11): which object on GitHub a
link is, so edit, delete, react and reply reach the right one.

`link.externalId = { network: 'github', kind, id, nodeId, owner, repo,
number, inReplyTo? }` where `id` is the numeric REST id, `nodeId` the
GraphQL node id, `number` the issue / pull request / discussion number.
Items stored before this field existed have none: an action on them
refuses with `no-external-id` rather than guessing from the link id.

**Exports**

- `attachRef`
- `requireRef`

## `js/src/sources/github-sync.js`

Pulling one repository, again and again cheaply (R-Z11).

A first pull (no `since`) walks everything. A later one passes the
`since` the last successful pull returned: issue comments, review
comments and issues are asked `?since=` sorted by update time, pull
requests (no `since` parameter exists) are walked newest-update first
and the walk stops at the first one older than the cursor, and reviews
are fetched only for the pull requests that changed. The first page of
each stream is asked with `If-None-Match` (the ETag the last pull
returned for that very url), so an idle repository costs a free `304` per stream.

The function never stores anything and never moves a cursor: the caller
saves `since` and `etags` after its store write succeeded (R-Z14), so a
failed write repeats the same window next time.

**Exports**

- `syncGithubRepo`

## `js/src/sources/github.js`

GitHub source adapter (R-R1..R-R8).

Two surfaces in one file:

  - `githubSource.parseArchive(input)` ingests `gh api`-style JSON
    dumps (an array of payloads) or the standard envelope
    `{ issues, comments, pulls, reviews, reviewComments, discussions }`
    and yields `msg:github:<external_id>` links via
    `buildMessageLink()` (R-R1, R-R2).

  - `createGithubLive({ token, owner, repo, fetchImpl, baseUrl })`
    wraps the REST API:
      - `pullMessages()` walks issues -> issue comments -> pulls ->
        PR review comments -> reviews (R-R3, R-R4).
      - `listRepos()` paginates `/user/repos` (R-R8).
      - `cloneRepo({ owner, repo, ref, store })` downloads the
        tarball, gunzips it, walks USTAR/PAX entries and writes one
        `repo:<owner>/<name>:file:<path>` link per file plus a
        `repo:<owner>/<name>` index link with metadata children
        (R-R6, R-R7).
      - `post(content, { issueNumber })` creates an issue / PR
        comment (R-R5).

Pagination follows the `Link: rel="next"` header. The adapter is
dependency-free; the tarball walker uses `node:zlib` and a small
USTAR reader local to this file so the SPA bundle is unaffected by
the clone path.

**Exports**

- `GITHUB_EMOJI_TO_REACTION`
- `createGithubLive`
- `githubPayloadsToLinks`
- `githubSource`
- `paginate`
- `readTarEntries`

## `js/src/sources/habr-career.js`

career.habr.com source adapter (R-E7).

The site has no public archive export. The adapter therefore models
a resume (`/resume`) as a single link and applications as messages
fed in via the live API once OAuth flow is wired up. For the
prototype it accepts a JSON object the caller has already scraped.
The live adapter is intentionally path-configurable because Habr
Career does not publish a stable public API contract.

**Exports**

- `createHabrCareerLive`
- `habrApplicationsToLinks`
- `habrCareerSource`

## `js/src/sources/hh.js`

hh.ru source adapter (R-E8).

Wraps the official hh.ru API (https://api.hh.ru) for resume
read/write and message threads on vacancy responses. Archive import
accepts pre-fetched JSON; the live adapter talks to negotiations and
resume endpoints with injectable fetch/baseUrl for tests.

**Exports**

- `createHhLive`
- `hhNegotiationsToLinks`
- `hhSource`

## `js/src/sources/http.js`

Small HTTP helpers shared by live source adapters.

The adapters keep endpoint defaults close to their networks, while
tests inject `fetchImpl` and `baseUrl` so no real credentials or
network access are required for verification.

**Exports**

- `DEFAULT_TIMEOUT_MS`
- `addSearch`
- `authHeaders`
- `codedError`
- `compact`
- `contentTarget`
- `contentText`
- `envValue`
- `idFromChat`
- `markSendOutcome`
- `requestJson`
- `resolveOption`
- `threadTarget`
- `timedRequest`
- `unsupportedError`

## `js/src/sources/index.js`

MessageSource adapter framework.

Each external network is wrapped in a `MessageSource` whose only
required method is `parseArchive(input)` — given an export file (or
a parsed object) it yields unified `Message` links.

The unified `Message` link shape:
  id        = `msg:<source>:<external_id>`
  tokens    = ['message', source, externalId]
  children  = ids of sender, chat, body, timestamp links

Adapters use the helpers below to keep their code small. Live
network APIs (token flows, OAuth, rate limits) belong inside each
adapter's `live*` methods; adapters expose browser-direct HTTP APIs
where the upstream service permits them and local-server fallback
hooks where browsers cannot speak the raw provider protocol.

**Exports**

- `BrowserOnlySourceError`
- `CvRuntimeUnavailableError`
- `MEMBER_GROUP_KINDS`
- `VK_TOKEN_SOURCES`
- `buildMessageLink`
- `classifyVkOAuthGate`
- `createJobBoardSource`
- `cvPlatformIdOf`
- `cvPlatformOf`
- `describeVkError`
- `getSource`
- `importInto`
- `inspectVkToken`
- `isTypingActive`
- `jobBoardArchiveToLinks`
- `listCvSources`
- `listSources`
- `liveOptionsFrom`
- `memberLink`
- `personLink`
- `probeVkOAuthGate`
- `pullBrowserInto`
- `pullLiveInto`
- `rankVkTokenSources`
- `readSourceCv`
- `setTypingFor`
- `sourceHandlerId`
- `sourceRegistry`
- `stampSourceLink`
- `syncMembership`
- `typingLink`
- `vkTypingFromUpdate`
- `withCvPlatform`
- `writeSourceCv`

## `js/src/sources/job-board.js`

Factory for browser-only job-board adapters (R-E11..R-E13).

Naukri, VietnamWorks and TopCV publish no candidate-facing message
or resume API: their recruiter inboxes and profile editors are only
reachable from an authenticated browser session. Rather than invent
endpoints we cannot verify, these adapters

  - parse the export/notification dumps the boards do hand out (or a
    scrape produced by the CV plans), and
  - route every live operation to the declarative CV plans in
    `js/src/cv`, which drive a real browser through browser-commander
    and record telemetry for each step.

One factory serves all three boards, so a fix to the archive parser
or to the browser fallback lands on every board at once.

**Exports**

- `BrowserOnlySourceError`
- `createJobBoardSource`
- `jobBoardArchiveToLinks`

## `js/src/sources/link.js`

Shared normalized Link builders for source adapters.

`chatType`, `chatName` and `senderName` are optional: adapters that
know them (Telegram exports carry `personal_chat`/`private_group`…)
pass them on, and links from adapters that do not stay unchanged.

`sticker` (issue #35) is only set when the message is a sticker, so
text messages keep their historical shape: `{id, pack}` with the
network's own sticker id and optional pack/set name, plus `emoji`
where the network reports one (Telegram).

The other optional fields (R-Y39) — `service`, `edited`, `deleted`,
`raw`, `outgoing`, `attachments`, `forwardedFrom`, `reactions`,
`delivery` — follow the same rule.

**Exports**

- `buildMessageLink`

## `js/src/sources/linkedin.js`

LinkedIn source adapter (R-E6).

Parses the CSVs in LinkedIn's data export — at minimum
`messages.csv` and `Profile.csv` — represented here as already-parsed
arrays of records (callers wrap the CSV reader of their choice).
The live side wraps LinkedIn's REST Posts API so profile/resume
updates can be exported as posts and API-side post imports can be
normalized back into unified links.

**Exports**

- `createLinkedInLive`
- `linkedinPostsToLinks`
- `linkedinSource`

## `js/src/sources/live-links.js`

Live presence and audience links (issue #31, PR #34).

Two requirements from PR #34 live here:

- Typing status in every messenger: when a person or our own
  automation is typing, a `typing` link records it (with a short TTL
  so stale indicators expire), and `setTypingFor` asks the adapter to
  show "typing..." upstream before a reply — the read -> typing ->
  reply pacing used by konard/vk-bot.
- Automation can target friends, chat members and community members:
  `syncMembership` pulls those audiences from each adapter's live
  listing methods and stores them as `member` + `person` links.

All links are plain objects with `id` and `tokens`, ready for the
link store's `put`.

**Exports**

- `MEMBER_GROUP_KINDS`
- `isTypingActive`
- `memberLink`
- `personLink`
- `setTypingFor`
- `syncMembership`
- `typingLink`

## `js/src/sources/message-actions.js`

Everything the user does to a message, the API first and the network's
own web app second (R-Y38).

Sending already worked this way (./browser-sender.js); this module does
the same for every other action: edit, delete, react, mark read,
forward. For each one:

1. the network adapter's `live` method (`editMessage`, `deleteMessages`,
   `react`, `markRead`, `forwardMessages`) with the saved connection's
   token, when the adapter has it;
2. otherwise — or when the API refuses (no token, no right, an action
   the API does not have) — the same action done in the web app by
   ./browser-actions.js, in the browser profile the user signed in to
   once.

An adapter marks an error `fallback: false` when the action may already
be done (a connected account), so it is never done twice; `safe-mode`
and `bad-draft` never reach the browser either.

**Exports**

- `MESSAGE_ACTIONS`
- `createMessageActions`

## `js/src/sources/naukri.js`

naukri.com source adapter (R-E11).

Naukri's recruiter conversations live behind `/mnjuser/messages` and
are mirrored to the candidate's email; there is no documented
candidate API, so the adapter parses the exported inbox dump and
delegates resume writes to the Naukri CV plan.

**Exports**

- `naukriSource`

## `js/src/sources/peopleperhour.js`

PeoplePerHour source adapter (R-T1..R-T16).

Two surfaces in one file:

  - `peoplePerHourSource.parseArchive(input)` ingests:
      * an array of REST nodes / payloads,
      * the GDPR-style envelope
        `{ projects, proposals, workstreams, rooms, messages,
           invoices, hourstreams }`,
      * raw CSV strings (PeoplePerHour "Reports -> Earnings"
        exports).
    Output: one `msg:peopleperhour:<external_id>` link per message,
    plus `project:peopleperhour:*`, `proposal:peopleperhour:*`,
    `workstream:peopleperhour:*`, `room:peopleperhour:*`,
    `invoice:peopleperhour:*`,
    `hourstream:peopleperhour:<workstream>:<weekStart>` sibling
    links.

  - `createPeoplePerHourLive({ token, fetchImpl, baseUrl,
                             endpointOverrides })` wraps the
    PeoplePerHour REST endpoint at
    `https://www.peopleperhour.com/api/v1` with
    `Authorization: Bearer <PAT>`:
      * `searchProjects({ query, sort, limit })` runs
        `GET /projects/search`.
      * `pullMessages({ stage, perspective, projectId, workstreamId,
                       roomId })` walks proposal / workstream rooms
        and their messages with cursor pagination.
      * `listWorkstreams({ perspective })` paginates the workstreams
        endpoint for the chosen perspective.
      * `post({ text }, { roomId, workstreamId })` issues
        `POST /workstreams/{id}/messages` (or
        `POST /proposals/{id}/messages`).

`softCacheRetention(store, { ttlMs, now })` purges live-pulled
PeoplePerHour links whose `cacheTtlMs` has expired (R-T12);
archive-only links are left alone because the user owns those
rows.

The adapter is dependency-free — same file works in Bun, Node,
Deno, and the browser.

Several PeoplePerHour REST paths are unverified publicly because
the developer portal is gated; defaults document the likely paths
and `endpointOverrides` lets callers patch any operation without
forking the adapter.

**Exports**

- `createPeoplePerHourLive`
- `peoplePerHourPayloadsToLinks`
- `peoplePerHourSource`
- `softCacheRetention`

## `js/src/sources/private-call-dh.js`

The Diffie-Hellman steps of a private call's key (R-Y196; learned from
Telegram's public description of end-to-end calls, never copied).
Everything here is pure: the random bytes come in as arguments, so the
tests fix them. The secret exponent and the key never leave the server;
the page only ever gets the emoji derived from the key.

The caller sends `g_a_hash = SHA256(g_a)` first (phone.requestCall), the
callee answers `g_b = g^b mod p` (phone.acceptCall), and the caller then
reveals `g_a` with the key fingerprint (phone.confirmCall). The callee
checks that `SHA256(g_a)` is the hash it was given. Both sides get
`key = g_b^a = g_a^b mod p` (256 bytes, big-endian) and its fingerprint,
the low 64 bits of SHA1(key) as a signed little-endian number.

**Exports**

- `KEY_BYTES`
- `bigOf`
- `bytesOf`
- `checkDhConfig`
- `exponentOf`
- `fingerprintOf`
- `hashOf`
- `isProbablePrime`
- `modPow`
- `publicInRange`
- `publicOf`
- `sharedKey`

## `js/src/sources/private-call-emoji.js`

The emoji a private call shows so the two people can compare keys
(R-Y196; behaviour learned from Telegram's clients, never copied).

The four emoji come from `SHA256(key || g_a)`: its four 8-byte groups,
each read as a big-endian number with the top bit cleared, modulo the
size of the emoji table.

The table (333 entries, in Telegram's order) is protocol data: both
ends must index the same list. It is taken from TDLib's
`get_emoji_fingerprint` (td/telegram/misc.cpp, Copyright Aliaksei
Levin, Arseny Smirnov; Boost Software License 1.0,
https://www.boost.org/LICENSE_1_0.txt), written here as code points;
`-` joins the code points of one entry (flags, keycaps).

**Exports**

- `EMOJI_COUNT`
- `EMOJI_TABLE`
- `EMOJI_TABLE_VERIFIED`
- `emojiIndices`
- `emojiOf`

## `js/src/sources/private-call-machine.js`

The state machine of one private (one-to-one) call (R-Y196; learned from
how Telegram's clients behave, never copied). It is driven by what the
page asks (start, accept, discard, rate) and by UpdatePhoneCall, and it
talks to Telegram only through the `api` it is handed, so the tests give
it a fake. The secret exponent and the key live in here and nowhere else:
`publish` only ever gets the page's view of the call.

Phases of the view:
  incoming    somebody calls us (Accept / Decline)
  waiting     we called; Telegram has not told the other side yet
  ringing     we called; the other side's phone rings
  connecting  keys are being exchanged
  active      the key is agreed and its fingerprint checked
  ended       over (`reason`: hangup, missed, busy, disconnect, failed,
              migrate; `needRating` when Telegram asks for a rating)

Media: only the call's key and its signalling are done here. A browser
cannot speak tgcalls' own encrypted transport, and the encrypted
signalling envelope of the WebRTC variant could not be settled with
confidence, so `media` stays false and the page says audio is not
available. Nothing is sent through phone.sendSignalingData.

**Exports**

- `DEFAULT_RING_MS`
- `DISCARD_REASONS`
- `LIBRARY_VERSIONS`
- `PROTOCOL`
- `createCallMachine`
- `phoneCallOf`
- `ringMsOf`

## `js/src/sources/pull-runner.js`

One small runner for "fetch now" and "fetch on a schedule" of a network's
inbox (R-Z8; the page's Fetch button and the background poller share it).

A job is `{ ready(), run(), intervalMs }`:
 - `ready()` is true when the network is connected (a saved token), so a
   network nobody connected is never polled;
 - `run()` pulls and stores, returning `{ imported, ... }`. It saves any
   cursor itself, and only AFTER the store write succeeded, so a failed
   write is read again next time instead of skipped.

`fetchNow(source)` is the button: at most one run per `minGapMs` (15 s) for
a network, background runs counted too, and one at a time. `start()` is
the schedule: each ready job runs every `intervalMs`, and after a failure
the wait doubles up to `maxBackoffMs`, so a dead token or a down network
is not hammered. Nothing starts before `start()`, which the server calls
only once it listens. Errors come back as `{ ok: false, error, code }`
with secrets masked; nothing here throws at a caller.

A job may also have `due()` (checked by the schedule only, so a network
whose user turned the schedule off can still be fetched by hand) and its
`intervalMs` is then just how often `due()` is asked.

A pull that VK stops with a captcha (code `captcha`) is marked
`needsAttention` in `lastError`: neither the schedule nor this runner
shows or solves it (R-Z20; the page asks only for the user's own actions).

`pull-state:<source>` keeps `lastOkAt` and a job's own cursor.

**Exports**

- `PULL_MIN_GAP_MS`
- `createPullRunner`
- `loadPullState`
- `savePullState`

## `js/src/sources/secret-chat-crypto.js`

The cryptography of secret chats (R-Y219; learned from Telegram's public
description, https://core.telegram.org/api/end-to-end, and the layer-73
schema credited in ./secret-chat-tl.js; never copied from a GPL client).
Groundwork only: nothing imports this module but the secret-chat session
and the tests, and no route or page uses it. Pure: the random bytes come
in as an argument, so the tests fix them.

Key exchange: the same Diffie-Hellman steps as a call's (./private-call-dh.js):
the requester sends g_a, the accepter answers g_b, both get
`key = g^(ab) mod p` (256 bytes) and its fingerprint (the low 64 bits of
SHA1(key)). Telegram's checks are in `checkParameters` and `publicInRange`.

Messages (MTProto 2.0): the payload is the serialised
DecryptedMessageLayer with its length (int32, little endian) in front and
12..1024 random bytes behind, so that the whole is a multiple of 16:

  msg_key_large = SHA256(key[88+x .. 88+x+32] + plaintext)
  msg_key       = msg_key_large[8 .. 24]
  sha256_a      = SHA256(msg_key + key[x .. x+36])
  sha256_b      = SHA256(key[40+x .. 40+x+36] + msg_key)
  aes_key       = a[0..8] + b[8..24] + a[24..32]
  aes_iv        = b[0..8] + a[8..24] + b[24..32]

with x = 0 for what the chat's originator sends and x = 8 for what the
other side sends. The packet is `key_fingerprint (8) + msg_key (16) +
AES-256-IGE(plaintext)`.

**Exports**

- `KEY_BYTES`
- `MAX_PADDING`
- `MIN_PADDING`
- `acceptExchange`
- `bigOf`
- `bytesOf`
- `checkParameters`
- `decryptPayload`
- `encryptPayload`
- `fingerprintOf`
- `finishExchange`
- `igeDecrypt`
- `igeEncrypt`
- `keyVisual`
- `messageKey`
- `packetKeys`
- `padPayload`
- `startExchange`
- `systemRandom`

## `js/src/sources/secret-chat-session.js`

One secret chat's cryptographic session: the key, the sequence numbers
and the log of what was sent (R-Y219; learned from
https://core.telegram.org/api/end-to-end/seq_no, never copied). Pure and
immutable: every step returns the next state, a plain JSON object the
server keeps in its secret store (the key is hex in it; it never leaves
the server).

Sequence numbers. The chat's originator numbers what it sends 1, 3, 5, ...
(`out_seq_no = 2 * sent + 1`) and the other side 0, 2, 4, ...
(`2 * sent`). Every layer carries `in_seq_no`, the `out_seq_no` the sender
expects next from the other side (`2 * received + the other's parity`),
which also tells the receiver what it may forget of its sent log. A
received message whose `out_seq_no` is below the expected one is a
duplicate (dropped); above it, a gap: it is dropped as well and a resend of
the range `expected .. out_seq_no` is asked for (the other side then sends
it again with the same numbers).

**Exports**

- `createSession`
- `expectedInSeq`
- `nextOutSeq`
- `open`
- `resendRange`
- `seal`
- `withTtl`

## `js/src/sources/secret-chat-tl.js`

TL serialisation of the secret-chat payloads (R-Y219; learned from
Telegram's public end-to-end schema, https://core.telegram.org/schema/end-to-end,
and from TDLib's secret_api.tl, Boost Software License 1.0; never copied
from a GPL client). Pure: bytes in, plain objects out.

The secret layer used is 73 (MTProto 2.0 only): the latest layer whose
constructors are written here, so every peer from layer 73 up reads them.
The schema is not part of layer-232.tl (it is a separate schema), so the
constructor ids below were each checked as the CRC32 of the schema line
(old style: `Vector long`, `bytes` written as `string`) in the tests.

Objects:
  layer    { randomBytes, layer, inSeqNo, outSeqNo, message }
  message  { type: 'message', randomId, ttl, text, entities, replyTo,
             viaBot, groupedId, media }
           { type: 'service', randomId, action }
           { type: 'unknown', id }
  action   { type: 'setTtl', ttl } | { type: 'read', randomIds } |
           { type: 'delete', randomIds } | { type: 'screenshot',
           randomIds } | { type: 'flush' } | { type: 'resend', start,
           end } | { type: 'notifyLayer', layer } | { type: 'typing',
           typing } | { type: 'requestKey', exchangeId, ga } |
           { type: 'acceptKey', exchangeId, gb, fingerprint } |
           { type: 'abortKey', exchangeId } | { type: 'commitKey',
           exchangeId, fingerprint } | { type: 'noop' } |
           { type: 'unknown', id }
Long values (random ids, exchange ids, fingerprints) are BigInt.

Media is not read: a message with media only says `media: true`.

**Exports**

- `CONSTRUCTORS`
- `SECRET_LAYER`
- `createReader`
- `createWriter`
- `decodeLayer`
- `decodeMessage`
- `encodeLayer`
- `encodeMessage`

## `js/src/sources/soft-cache.js`

The 24-hour cache rule of Upwork and PeoplePerHour (R-S12, R-T12): links
pulled live from their APIs are kept at most `ttlMs` (a day) and then
deleted for good; links the user imported from an export are theirs and
stay. `softCacheRetentionFor(source, defaultTtlMs)` gives each adapter its
`softCacheRetention(store, { ttlMs, now })` -> `{ purged }`. The server
runs both on a schedule (R-Z7, ../server/background-jobs.js).

**Exports**

- `softCacheRetentionFor`

## `js/src/sources/sticker.js`

Sticker payloads shared by adapters that can send them (issue #35).

Outgoing content may carry `sticker` as a bare id or as an object
`{id, url}`: `id` is the network's own identifier (VK `sticker_id`,
Telegram `file_id`, WhatsApp media id, Zalo `attachment_id`) and
`url` a public file link for networks that accept one (WhatsApp,
Telegram). Normalising here keeps every adapter's `post` small.

**Exports**

- `contentSticker`

## `js/src/sources/superjob.js`

superjob.ru source adapter (R-E9).

Accepts a pre-fetched JSON archive of resumes + vacancy responses
(the public API at api.superjob.ru returns this shape). The live side
wraps API reads/writes with token/app-id headers and injectable fetch
for testability.

**Exports**

- `createSuperjobLive`
- `superjobResponsesToLinks`
- `superjobSource`

## `js/src/sources/system-contacts.js`

**Exports**

- `readSystemContacts`

## `js/src/sources/telegram-account-data-paths.js`

Where "Export Telegram data" writes (R-Y212): a folder the server
chooses, `<base>/<name>`, or `<base>/<name> (1)`, `(2)`, … when it is
already there, so an earlier export is never mixed with a new one.

**Exports**

- `freeFolder`

## `js/src/sources/telegram-account-data-run.js`

The work of "Export Telegram data" (R-Y212; learned, never copied),
done inside a takeout session: the account's information, the contacts,
the chat list chosen by kind, and each chat's history written by the
per-chat export (R-Y186, ./telegram-export-run.js) into its own folder
`chats/chat_NN`. Every request goes out wrapped in invokeWithTakeout.
`r` is the run: `{ env, c, job, value, now, sleep, takeoutId }`; Cancel is
the job's `cancelling` state, looked at between steps.

**Exports**

- `KINDS`
- `delayOf`
- `listChats`
- `runDataExport`
- `takeoutClient`
- `takeoutFlags`

## `js/src/sources/telegram-account-data.js`

"Export Telegram data", as Telegram Desktop has it in Settings → Advanced
(R-Y212; learned, never copied): the account's information, contacts and
the chats of the kinds the user picks (personal chats, bot chats, private
groups, private channels, public groups and channels) with a date range
and "include media up to N MB", read through a takeout session
(account.initTakeoutSession, requests wrapped in invokeWithTakeout,
account.finishTakeoutSession). Each chat is written by the per-chat export
(R-Y186, HTML and/or JSON) into a folder the server chooses under the
store directory's `exports` (never one the page names):
- `dataExportDefaults()` — `{ ok, job }`, the running or last export;
- `dataExportStart({ info, contacts, kinds, media, sizeLimitMb, from?,
  to?, formats })` — opens the takeout session first; Telegram may refuse
  with `{ ok: false, code: 'takeout-delay', seconds }`
  (TAKEOUT_INIT_DELAY_X), then starts it in the background → `{ ok, job }`;
- `dataExportStatus()` / `dataExportCancel()` / `dataExportReveal()`.
Only reads go to Telegram; no message text is ever logged.

**Exports**

- `createAccountData`
- `parseDataExport`

## `js/src/sources/telegram-account-extras.js`

Four small account features, as Telegram Desktop has them (R-Y174;
learned, never copied):
- `archiveSettings()` — account.getGlobalPrivacySettings → `{ ok,
  settings: { archiveAndMute, keepUnmuted, keepFolders, hideReadMarks,
  requirePremium } }`;
- `setArchiveSettings({ ...those five booleans })` —
  account.setGlobalPrivacySettings with the settings read again and
  only these five changed, so the fields the page does not show (gifts
  button, paid messages price, disallowed gifts) are kept;
- `webSessions()` — account.getWebAuthorizations → `{ ok, sessions:
  [{ hash, domain, bot, browser, platform, ip, region, created,
  active }] }`; `webSessionReset({ hash })` —
  account.resetWebAuthorization; `webSessionsResetAll()` —
  account.resetWebAuthorizations;
- `savedPin({ peer, pinned })` — messages.toggleSavedDialogPin, a
  chat of Saved Messages pinned or unpinned;
- `savedReorder({ peers })` — messages.reorderPinnedSavedDialogs, the
  pinned chats of Saved Messages in a new order, the first on top
  (R-Y197; chats not named keep their pin: no `force`).
Telegram's errors become codes the page shows as text
(PREMIUM_ACCOUNT_REQUIRED → `premium-required`).

**Exports**

- `ARCHIVE_FIELDS`
- `MAX_PINNED`
- `createAccountExtras`
- `settingsOf`
- `webSessionOf`

## `js/src/sources/telegram-account-live.js`

Real-time Telegram for a connected user session.

While the GramJS client is connected, Telegram pushes updates over the
same MTProto connection: new and edited messages, deletions, "read"
receipts and typing. `createTelegramLive` registers one raw handler on
each client the account opens and writes what the update means to the
store, as the same links a sync would write — so a message that arrives
live and the next sync agree, and nothing shows twice:

  msg:telegram:<chat>:<id>   new / edited (`edited`) / deleted (`deleted`)
  read:telegram:<chat>       the chat's read and draft state:
                             `outboxMaxId`  the other side read our
                                            messages up to this id
                             `inboxMaxId`   we read theirs up to it
                             `unreadCount`  unread at `unreadTopId`
                                            (Telegram's count; newer
                                            ones are counted from links)
                             `unreadMentions`, `unreadReactions`
                                            (@ and ♥ not seen yet)
                             `draft`, `draftAt`  the cloud draft
  typing:telegram:<chat>:<user>
  requests:telegram:<chat>   the people waiting to join a group or
                             channel: `pending` and `recent` ({ id,
                             name }); the page's join requests bar
                             follows it (R-Y161)
  eph:telegram:<chat>:<id>   an ephemeral message, shown to this user only
                             (never part of the history, R-Y223)
  groupcall:telegram:<chat>  the chat's voice chat or live stream: `call`
                             (null once over) and `rev`, which grows
                             when its participants change (R-Y188)

Updates missed while the connection was down come through the same
handler from the catch-up (./telegram-catchup.js); the background poll
stays as the last safety net.

**Exports**

- `FOLDERS_LIVE_ID`
- `createTelegramLive`
- `dialogInfo`
- `readLink`
- `readLinkId`
- `requestsLinkId`

## `js/src/sources/telegram-account.js`

The connected Telegram account — what makes "Connect" actually work.

Connecting (the credential finder, the phone login or pasted keys) only
stores `secret:telegram:*` links. This service reads them and does the
work behind Chat and Contacts:
  - sync(): a user session (MTProto, GramJS) lists the dialogs, their
    recent messages and the address-book contacts; a bot token pulls
    `getUpdates`. Everything lands as ordinary `msg:telegram:*` and
    `person:telegram:*` links, so Chat and Contacts show it unchanged.
  - history(chat): more of one chat's messages, when it is opened.
  - post() / setTyping(): the chat composer sends through the same
    account — a user session as the user, a bot token as the bot.
  - markRead() / saveDraft(): reading a chat here marks it read on
    Telegram, and the composer's draft is the chat's cloud draft, as in
    Telegram's own apps (a user session only).
  - live updates (./telegram-account-live.js) and the catch-up after a
    gap or a reconnect (./telegram-catchup.js) keep a user session
    current; start() adds a light poll as the last safety net (only
    dialogs whose newest message changed are re-read).

A user session wins over a bot token when both are stored: a bot only
sees messages sent to it, a user account sees their real chats. Bots
are never polled in the background — `getUpdates` would take updates
away from the bot's own process — and sync only when the user asks.

Secret values never leave this module: results and logs carry counts,
chat ids and the account's public name only.

**Exports**

- `OFFLINE_AFTER_MS`
- `TELEGRAM_SYNC_ID`
- `createTelegramAccount`
- `createUserConnection`
- `pinnedRanks`
- `reachability`
- `reachabilityOf`
- `readTelegramCredentials`
- `telegramDialogLinks`
- `telegramPersonLinks`
- `watchUndecodable`

## `js/src/sources/telegram-accounts.js`

More than one Telegram account, as Telegram Desktop allows: up to 3,
up to 5 with Premium (R-Y198; learned, never copied).

Additions only. Account 1 is today's single account and keeps its keys
(`secret:telegram:*`, `msg:telegram:*`, ...) and its whole service
untouched: this module never writes under them. An extra account lives
in its own namespace:
  secret:telegram@2:user-session | api-id | api-hash   its session
  account:telegram@2                                   public name only
Nothing exists for a slot until the user adds the account.

What an extra account can do today (honest scope): be signed in (the
existing login flow, parameterized by `account`), be listed with its
name, show its chat list and unread count read live from Telegram
(nothing is written to the message store, so no `telegram@2` messages
mix with account 1's), and be logged out (auth.logOut, then only its `@2` keys go).
R-Y202 makes an extra account fully usable: each runs on its own store
(src/server/telegram-extras.js), so `msg:telegram:*` and the page's
`source: 'telegram'` stay as they are. The dialogs here remain the
preview of an account whose service is not running.

Session contents are never logged or returned.

**Exports**

- `MAX_ACCOUNTS`
- `MAX_ACCOUNTS_PREMIUM`
- `SECRET_NAMES`
- `accountSlot`
- `createAccountsActions`
- `createExtraAccounts`
- `dialogRow`
- `extraSlots`
- `limitFor`
- `namespaceOf`
- `nextFreeSlot`
- `profileId`
- `readSlotCredentials`
- `removeExtraAccount`
- `saveExtraAccount`
- `secretId`

## `js/src/sources/telegram-actions.js`

What the user does to messages in Chat, as Telegram's apps do it
(R-Y36): read some messages again, forward them, delete them, show
their pictures.

- `refreshMessages({ chat, ids })` reads the messages by id (one
  request, by the stored peer, through the queue): an edit since is
  stored, and a message Telegram no longer has is marked `deleted` —
  so a deletion made in another app shows here even when no update
  about it arrived.
- `forwardMessages({ fromChat, ids, toChat })` and `deleteMessages({
  chat, ids, revoke })` change Telegram only on the user's press in
  Chat; Telegram's answer goes through the live handler at once (the
  forwarded messages appear, the deleted ones go) and moves the update
  counters, so the catch-up does not ask for them again.
- `pinMessage({ chat, id, unpin, oneSide, silent })` pins or unpins
  one message (R-Y67); Telegram's answer moves the pinned bar.
- `media({ chat, id, size })` is ./telegram-media.js.
- polls and checklists (vote, stop, results, voters, tick) are
  ./telegram-polls.js (R-Y74).
- the chat list's menu (pin, mute, archive, mark read or unread) is
  ./telegram-dialogs.js (R-Y97); search in a chat is
  ./telegram-search.js (R-Y98); files and photos are sent by
  ./telegram-upload.js (R-Y99); clearing, deleting and leaving a chat
  is ./telegram-chat-removal.js (R-Y100); scheduled messages are
  ./telegram-scheduled.js (R-Y102), chat folders ./telegram-folders.js
  (R-Y103); translating messages is ./telegram-translate.js (R-Y132);
  message effects are ./telegram-effects.js (R-Y149); emoji statuses
  ./telegram-emoji-status.js (R-Y162); the translate bar and summaries
  ./telegram-translate-chat.js (R-Y213).

**Exports**

- `createActions`

## `js/src/sources/telegram-add-members.js`

Adding members to a group or channel, as Telegram Desktop does
(R-Y204; learned, never copied):
- `addCandidates({ chat })` — the people to pick from: contacts and the
  people written to most (contacts.getContacts, contacts.getTopPeers)
  → `{ ok, people: [{ id, name, username, contact }] }`;
- `addMembers({ chat, users })` — channels.inviteToChannel (a supergroup
  or channel) or messages.addChatUser (a basic group, one by one, fwd
  limit 100) → `{ ok, added: [id], missing: [{ id, name }], failed:
  [{ id, code }] }`; `missing` are those their privacy keeps from being
  added (layer 225's missing_invitees), to whom the page may offer the
  chat's invite link;
- `sendInviteLink({ chat, users })` — the chat's primary link sent as a
  message to each of them (messages.exportChatInvite, sendMessage), only
  when the user asked for it → `{ ok, sent: [id], failed: [id] }`.
Telegram's errors become codes the page shows as text.

**Exports**

- `CHAT`
- `CODES`
- `bad`
- `codeOf`
- `createAddMembersActions`
- `failure`
- `inputUserOf`
- `isChannel`
- `nameOf`
- `remember`
- `textOf`
- `validUsers`

## `js/src/sources/telegram-admin-manage.js`

A chat's administrators, the history new members see, and upgrading a
group, as Telegram Desktop does (R-Y204; learned, never copied):
- `chatAdmins({ chat })` — the administrators (channels.getParticipants
  with the admins filter, or a basic group's full chat) → `{ ok, admins:
  [{ id, name, username, role, rank, rights, promotedBy, promotedByName,
  canEdit, self }] }`; `rights` holds every ChatAdminRights flag;
- `setAdmin({ chat, user, rights?, rank?, dismiss?, broadcast? })` —
  channels.editAdmin with the rights of the chat's kind (no rights at all
  dismisses), or in a basic group messages.editChatAdmin (a basic group
  has no custom rights or titles: those need an upgrade) → `{ ok }`;
- `setHistoryHidden({ chat, hidden })` — what new members see
  (channels.togglePreHistoryHidden; a basic group must upgrade first);
- `upgradeGroup({ chat })` — messages.migrateChat → `{ ok, chat, title }`
  with the supergroup's id; the answer's updates go through the live
  handler, which carries the migration service messages.
Telegram's errors become codes the page shows as text.

**Exports**

- `adminRequest`
- `createAdminManage`

## `js/src/sources/telegram-admin-rights.js`

**Exports**

- `ADMIN_RIGHTS`
- `ALL_ADMIN_RIGHTS`
- `RANK_MAX`
- `anyRight`
- `grantable`
- `kindOfChat`
- `rightsFor`
- `shapeRights`
- `validRank`
- `validRights`

## `js/src/sources/telegram-admin.js`

A group's permissions, slow mode and recent actions, as Telegram
Desktop's admin screens (R-Y133; learned, never copied):
- `chatPermissions({ chat })` — what members may do, the slow mode and
  whether the user may change them → `{ ok, rights, slowMode, canEdit }`;
  `rights` are positive: `true` is allowed (Telegram's flags say what is
  forbidden);
- `setPermissions({ chat, rights })` — the rights changed
  (messages.editChatDefaultBannedRights); rights not named stay as they
  are;
- `setSlowMode({ chat, seconds })` — a supergroup's slow mode
  (channels.toggleSlowMode);
- `adminLog({ chat, maxId? })` — a supergroup's or channel's recent
  actions, newest first, a page at a time (channels.getAdminLog) →
  `{ ok, events: [{ id, date, user, userName, kind, text?, msgId? }],
  next }`; `msgId` is a deleted message's id (R-Y200).
Telegram's errors become codes the page shows as text.

**Exports**

- `RIGHT_KEYS`
- `SLOW_MODES`
- `createAdminActions`
- `rightsOf`

## `js/src/sources/telegram-apps.js`

The bot and mini-app extras of Telegram Desktop (R-Y194; learned,
never copied). All reads; the only send is the existing inline-result
send, asked for by the page on a click:
- `appsPopular({ offset?, limit? })` — the popular mini apps
  (bots.getPopularAppBots), a page at a time → `{ ok, apps: [{ chat,
  name, username, users, mainApp }], next }` (`users` the bot's monthly
  users when Telegram says, `next` the offset of the next page);
- `botSimilar({ chat })` — the bots Telegram recommends beside a bot
  (bots.getBotRecommendations; Telegram limits the list for accounts
  without Premium) → `{ ok, bots: [same shape] }`;
- `preparedMessage({ bot, id })` — the message a mini app prepared
  (messages.getPreparedInlineMessage) → `{ ok, queryId, id, preview:
  { type, title, description }, peerTypes, bot }`; it is then offered
  to the inline send, which sends it to one chat chosen by the click;
- `collectibleInfo({ kind, value })` — what Fragment knows of a
  collectible username or phone number (fragment.getCollectibleInfo) →
  `{ ok, date, price: { amount, currency }, crypto: { amount, currency },
  url }` (amounts in the currency's smallest units).
Answers are kept five minutes. Errors become codes.

**Exports**

- `DEFAULT_PAGE`
- `ID`
- `KINDS`
- `MAX_PAGE`
- `PEER_TYPES`
- `PHONE`
- `PREPARED_ID`
- `USERNAME`
- `botOf`
- `collectibleOk`
- `createApps`
- `peerTypesOf`
- `previewOf`

## `js/src/sources/telegram-avatars.js`

Profile photos of Telegram peers (users, groups, channels), cached on
disk and served from there: GET /api/telegram/avatar?peer=&size=s|b.

Each avatar is downloaded once and kept at
`<dir>/avatars/<peer>-<size>` with a `.type` file. A "no photo" result
is remembered for 24 h (a `.none` file), a failed download is tried
again after 5 minutes; a cached avatar older than
24 h is re-downloaded in the background while the cached one is served.

Downloads go through the account's queue at `list` priority with key
`avatar:<peer>:<size>` — after what the user scrolls to, never blocking
it (R-Y34). Secrets are never logged.

**Exports**

- `createAvatarReader`

## `js/src/sources/telegram-backfill.js`

The slow download of every chat's whole history (R-Y30), so the store
holds it for offline reading, analysis and learning replies — and
Telegram is never asked for it again.

  1. the whole chat list first (its pages after the first one);
  2. then private chats, a page at a time, taking turns (the chat read
     longest ago goes next), so short chats are done early and a long
     one does not hold the others back;
  3. then groups the same way;
  4. channels never: they are read on demand only (opened or shown).

One request every few seconds, at `background` priority, and none at
all while the user waits for something (anything queued at `prefetch`
or above) or Telegram asked to wait. Progress lives in the store: each
chat's `history:` link (./telegram-history.js) says how far back it is
stored, so a restart goes on where it stopped. It also waits while the
server's memory is nearly full (the store is held in memory): more
history then waits for room instead of stopping the server. A chat
Telegram cannot address (no access hash for its user, a channel now
private) is passed over for the rest of the run instead of holding
every other chat back.

**Exports**

- `BACKFILL_EVERY_MS`
- `BACKFILL_HEAP_SHARE`
- `BACKFILL_ORDER`
- `BACKFILL_PAGE`
- `backfillKind`
- `backfillProgress`
- `createBackfill`
- `heapNearlyFull`
- `nextBackfill`
- `unreachableChat`

## `js/src/sources/telegram-boosts.js`

Channel boosts, as Telegram Desktop has them (R-Y173; learned, never
copied): a channel or supergroup has a boost level that Premium users
raise by giving it one of their boost slots.
- `boostsStatus({ chat })` — premium.getBoostsStatus → `{ ok, level,
  boosts, giftBoosts, currentLevelBoosts, nextLevelBoosts (null at the
  top), url, mine }` (`mine`: the user already boosts it);
- `myBoosts({ chat })` — premium.getMyBoosts → `{ ok, premium, slots:
  [{ slot, chat (marked id or null), title, expires, cooldownUntil }] }`
  (dates are unix seconds, 0 when none); an account without Premium has
  no slots;
- `boostApply({ chat, slot })` — premium.applyBoost with that one slot,
  a WRITE made only on the user's click → `{ ok, slots }`;
- `boostersList({ chat, offset? })` — premium.getBoostsList, for admins,
  a page of 50 → `{ ok, count, boosters: [{ user, name, date, expires,
  multiplier, gift, giveaway }], next }`.
Telegram's errors become codes the page shows as text.

**Exports**

- `BOOSTERS_PAGE`
- `boostersOf`
- `createBoosts`
- `slotsOf`
- `statusOf`

## `js/src/sources/telegram-bot-commands.js`

A bot's commands, as Telegram Desktop lists them (R-Y135; learned,
never copied): `botCommands({ chat })` for a bot chat
(users.getFullUser → botInfo) or a group (messages.getFullChat /
channels.getFullChannel → botInfo[], one per bot) →
`{ ok, commands: [{ command, description, bot, botName, username }],
menu: { kind: 'commands'|'webapp'|'default', text?, url? } }`.
`menu` is the bot's menu button of a bot chat. Answers are kept for
ten minutes, per chat.

**Exports**

- `createBotCommands`

## `js/src/sources/telegram-bot-login.js`

A bot's login links and the attachment menu (R-Y201; learned from how
Telegram Desktop behaves, never copied):
- `botUrlAuth({ chat, id, buttonId })` or `botUrlAuth({ url })`
  (messages.requestUrlAuth: a login button under a message, or a plain
  link whose domain is a login domain) → `{ ok, status, url }` where
  status is 'default' or 'accepted' (open `url`; the link itself for
  'default'), or `{ ok, status: 'request', domain, bot,
  requestWriteAccess }` when the person must be asked first;
- `botUrlAccept({ chat, id, buttonId } | { url }, writeAllowed)`
  (messages.acceptUrlAuth) → `{ ok, url }`, called only after the
  person ticked "Log in" and pressed Open;
- `urlAuthDomains()` (help.getAppConfig, `url_auth_domains`) → `{ ok,
  domains }`: the hosts whose links ask for a login. (Not done: the
  `autologin_domains` token appending, which only adds a query token.)
- `attachMenuBots()` (messages.getAttachMenuBots), `attachMenuBot({ bot |
  username })` (messages.getAttachMenuBot) and `attachMenuToggle({ bot,
  enabled, writeAllowed })` (messages.toggleBotInAttachMenu).
Nothing here runs unless the page asks on a person's press.

**Exports**

- `MAX_URL`
- `attachBotOut`
- `authOut`
- `createBotLogin`
- `domainsOf`
- `webUrl`

## `js/src/sources/telegram-bots.js`

A bot's buttons under its message, as Telegram's apps press them
(R-Y110): a callback button asks the bot through
messages.getBotCallbackAnswer, and the bot answers with words to show
(a toast, or a box when it is an alert), a link to open, or nothing —
what it changes in the chat (most often the message itself, edited)
comes as an update like any other.

A button's data is bytes; the app and the store name it in base64
(R-Y28).

**Exports**

- `answerOf`
- `createBotActions`
- `gameAnswerOf`

## `js/src/sources/telegram-business-bots.js`

Chatbots of Telegram Business (R-Y180; learned from Telegram Desktop's
Settings → Telegram Business → Chatbots, never copied).

- `businessBot()` → `{ ok, bot: { id, username, name, canReply, rights,
  recipients } | null }` — the connected bot (account.getConnectedBots);
- `businessBotSet({ username, recipients, canReply })` — connect a bot by
  its username (contacts.resolveUsername), who it serves
  (`existingChats`, `newChats`, `contacts`, `nonContacts`) and whether it
  may reply; other rights and chosen users of the same bot are kept
  (account.updateConnectedBot), on Save only;
- `businessBotRemove()` — disconnect it (updateConnectedBot, deleted);
- `businessBotChat({ chat })` → `{ ok, bar }` — whether a bot manages
  this chat, its name, paused or not (messages.getPeerSettings);
- `businessBotPause({ chat, paused })` (account.toggleConnectedBotPaused)
  and `businessBotDisable({ chat })` (account.disablePeerConnectedBot).

**Exports**

- `KINDS`
- `barOf`
- `createBusinessBots`
- `validRecipients`

## `js/src/sources/telegram-business-links.js`

Business chat links (R-Y180; learned from Telegram Desktop's Settings →
Telegram Business → Chat links, never copied): a link t.me/m/<slug> that
opens a chat with the user and puts a ready text in the box.

- `businessLinks()` → `{ ok, links: [{ slug, link, message, title,
  views }] }` (account.getBusinessChatLinks);
- `businessLinkCreate({ message, title? })` → `{ ok, link }`
  (account.createBusinessChatLink), on Save only;
- `businessLinkEdit({ slug, message, title? })` → `{ ok, link }`
  (account.editBusinessChatLink);
- `businessLinkDelete({ slug })` (account.deleteBusinessChatLink);
- `businessLinkResolve({ slug })` → `{ ok, chat, name, text }` — whose
  link it is and the text for the box (account.resolveBusinessChatLink).
  Nothing is sent: the page only puts the text in the box.

**Exports**

- `SLUG`
- `TEXT_MAX`
- `TITLE_MAX`
- `createBusinessLinks`
- `linkOf`
- `validLinkBody`

## `js/src/sources/telegram-business-messages.js`

The greeting and the away message of Telegram Business, as Telegram
Desktop's Settings → Telegram Business has them (R-Y179; learned, never
copied). Each one sends a quick reply shortcut to chats automatically:
- `businessMessages()` — users.getFullUser of the user (UserFull.
  businessGreetingMessage / businessAwayMessage) and messages.
  getQuickReplies → `{ ok, greeting, away, shortcuts: [{ id, name }],
  people: [{ id, name }] }`; `greeting` is `null` (off) or `{ shortcutId,
  recipients, noActivityDays }`, `away` `null` or `{ shortcutId,
  recipients, offlineOnly, schedule: { kind: 'always' | 'outside' |
  'custom', start?, end? } }` (times in seconds); `recipients` is
  `{ existingChats, newChats, contacts, nonContacts, excludeSelected,
  users: [id] }`;
- `businessGreetingSave({ enabled, shortcutId, recipients,
  noActivityDays })` — account.updateBusinessGreetingMessage (off: no
  message);
- `businessAwaySave({ enabled, shortcutId, recipients, offlineOnly,
  schedule })` — account.updateBusinessAwayMessage.
Writes come only from the page's Save. Telegram's refusals (Premium
needed…) become codes.

**Exports**

- `DAYS`
- `SCHEDULES`
- `createBusinessMessages`
- `validRecipients`
- `validSchedule`

## `js/src/sources/telegram-business.js`

Telegram Business, the parts of a profile (R-Y180; learned from Telegram
Desktop's Settings → Telegram Business, never copied). Reads are free;
every write happens on an explicit Save in the page.

- `businessHours()` → `{ ok, hours: { timezone, weekly: [{ start, end }],
  openNow } | null, timezones: [{ id, name, offset }] }` — the user's
  opening hours (users.getFullUser) and Telegram's time zones
  (help.getTimezonesList); minutes count from Monday 00:00 in the zone;
- `businessHoursSet({ timezone, weekly })` — account.updateBusinessWorkHours
  (no weekly hours: cleared);
- `businessLocation()` / `businessLocationSet({ address, lat?, lon? })` —
  account.updateBusinessLocation (nothing given: cleared);
- `businessIntro()` / `businessIntroSet({ title, description, sticker? })`
  — account.updateBusinessIntro; `sticker` an id from
  `businessIntroStickers()` (messages.getStickers) or the intro's own,
  null removes it;
- `businessProfile({ chat })` → `{ ok, hours, location, intro }` of a
  person, as their profile and an empty chat with them show it;
- `foldersTagsSet({ enabled })` — messages.toggleDialogFilterTags (Premium).
Telegram's refusals become codes (Telegram Business needs Premium).

**Exports**

- `CODES`
- `WEEK`
- `ask`
- `bad`
- `createBusiness`
- `failure`
- `hoursOf`
- `locationOf`
- `text`
- `validWeekly`
- `validZone`

## `js/src/sources/telegram-calendar.js`

Which days of a chat hold messages, and how many, for the jump-to-date
calendar (R-Y207; learned, never copied): messages.getSearchResultsCalendar
answers the days (newest first) before `before`, so a month further back
is another request with an earlier `before` — offset paging.

`calendar({ chat, filter?, before? })` → `{ ok, days: [{ date, count,
minId, maxId }], first, total, inexact }`: `date` is unix seconds, `first`
the time (unix seconds) of the chat's first matching message, `before` a
unix time (0: now). `filter` is one of FILTERS (default `empty`: every
message; `photoVideo` for the shared media tab).

**Exports**

- `FILTERS`
- `createCalendar`
- `daysOf`

## `js/src/sources/telegram-calls.js`

The recent calls list, as Telegram Desktop's main menu → Calls shows it
(R-Y163; learned, never copied). The app places no calls; this is the
history only:
- `callsList({ missed?, offsetId? })` — the account's phone-call service
  messages across every chat (messages.search with no peer, no query
  and InputMessagesFilterPhoneCalls, `missed` for the Missed tab), newest
  first, a page at a time → `{ ok, calls, next }`; each call is `{ chat
  (the other person's user id), name, id, date (ms), out, video, missed
  (incoming and ended missed or busy), duration (seconds) }`; `next` is
  the id to ask again with, or null at the end. Group calls are not in
  this list.
Telegram's errors become codes the page shows as text.

**Exports**

- `CALLS_PAGE`
- `callOf`
- `createCalls`
- `validCallsRequest`

## `js/src/sources/telegram-catchup.js`

Catching up on Telegram updates that never arrived.

Telegram numbers the updates of an account (`pts`): each one says the
number after it and how many it adds (`ptsCount`). Telegram's own apps
(TDLib, Telegram Web A and K) keep the last number and ask
`updates.getDifference` for everything after it whenever
  - the connection comes back (after sleep, a network change),
  - an update skips numbers and the missing one does not show up
    within 0.7 s (TDLib's MAX_UNFILLED_GAP_TIME),
  - Telegram says there were too many (`updatesTooLong`),
  - the app starts again (the number is saved).
GramJS has the hook for this (`catchUp()`) but it is an empty TODO, so
without this module a message sent while the connection was down only
appeared on the next poll, and an edit or deletion not at all.

What the difference returns goes through the same handler as live
updates (`handle`), so it lands as the same links. Channels and
supergroups have their own numbers; a gap there (`updateChannelTooLong`)
goes to that channel's own catch-up (`channelTooLong`,
./telegram-channels.js), and a difference too long to fetch falls back
to re-reading the dialogs (`resync`). Applying an update twice is
harmless (links merge by id). Every request goes through `request`
(the account's paced queue).

See docs/CHAT-REFERENCES.md, "Live updates and catching up after a gap".

**Exports**

- `GAP_MS`
- `TELEGRAM_STATE_ID`
- `createPtsCounter`
- `createTelegramCatchUp`
- `entitiesOf`
- `markedId`
- `ptsStep`
- `rewindPts`
- `updatesOfResult`

## `js/src/sources/telegram-channel-dm-shape.js`

Channel direct messages and suggested posts, shaped for the page
(R-Y191; learned from Telegram Desktop and the official apps, never
copied). Pure helpers, no network:
- `monoforumInfo(entity, chats)` — what a channel's info carries about
  its linked monoforum (the chat where subscribers write to the admins);
- `priceOf(amount)` — a StarsAmount / StarsTonAmount as `{ currency,
  amount }`;
- `suggestedOf(post)` — a SuggestedPost as `{ status, price, at }`;
- `actionOf(action)` — the suggested-post service messages;
- `dmMessageOf(message, names)` — one message of a thread;
- `threadOf(dialog, byId, names)` — one subscriber's thread.

**Exports**

- `actionOf`
- `dmMessageOf`
- `monoforumInfo`
- `nameOfUser`
- `namesOf`
- `priceOf`
- `suggestedOf`
- `threadOf`

## `js/src/sources/telegram-channel-dm.js`

Channel direct messages and suggested posts, as Telegram Desktop and the
official apps have them (R-Y191; learned, never copied). A channel may
link a monoforum: a chat where each subscriber has a thread with the
channel's admins. Everything here is asked by the page, a write only on
its own click.

- `channelDmThreads({ chat })` — the admin's list of threads
  (messages.getSavedDialogs with `parent_peer` = the monoforum) →
  `{ ok, threads: [{ peer, name, unread, top, at, last, free }] }`;
- `channelDmHistory({ chat, peer?, before?, limit? })` — a thread's
  messages, oldest first: with `peer` (an admin) messages.getSavedHistory
  with `parent_peer` and `peer` = the subscriber; without (a subscriber)
  messages.getHistory of the monoforum → `{ ok, messages, complete }`;
- `channelDmSend({ chat, text, peer?, stars?, suggestedPost?, clientId? })`
  — messages.sendMessage into the monoforum: an admin's reply names the
  thread with `InputReplyToMonoForum`; `stars` is the price the sender
  accepts for one message (`allow_paid_stars`); `suggestedPost` = `{
  stars, scheduleDate? }` is a subscriber's suggestion of a post;
- `channelDmDecide({ chat, id, approve, scheduleDate?, comment? })` —
  messages.toggleSuggestedPostApproval: an admin accepts a suggested
  post, or rejects it with an optional comment.
Telegram's errors become codes the page shows as words.

**Exports**

- `createChannelDm`

## `js/src/sources/telegram-channel-manage.js`

Managing a channel or group, as Telegram Desktop's Edit has it (R-Y216;
learned, never copied):
- `channelUsernameCheck({ chat, username })` — channels.checkUsername
  → `{ ok, status: 'available' }`; USERNAME_INVALID, USERNAME_OCCUPIED
  and CHANNELS_ADMIN_PUBLIC_TOO_MUCH come back as codes;
- `channelUsernameSave({ chat, username })` — channels.updateUsername
  (an empty name makes the chat private);
- `publicChannels()` — channels.getAdminedPublicChannels → `{ ok,
  channels: [{ chat, title, username }] }`, for the limit's "Revoke link";
- `publicLinkRevoke({ chat })` — one of those channels made private;
- `usernamesDeactivate({ chat })` — channels.deactivateAllUsernames;
- `channelColorSave({ chat, forProfile, color?, emoji? })` —
  channels.updateColor (name colour or profile colour, with a background
  emoji); BOOSTS_REQUIRED comes back as `boosts`;
- `channelEmojiStatusSet({ chat, documentId|null, until? })` —
  channels.updateEmojiStatus;
- `inactiveChannels()` — channels.getInactiveChannels → `{ ok, channels:
  [{ chat, title, date, broadcast }] }`, for the "too many channels" case;
- `leaveChannels({ chats })` — channels.leaveChannel on the chosen ones,
  only those Telegram lists as inactive.
Deleting a chat is `removeChat` with the `destroy` action.
Telegram's errors become codes the page shows as text.

**Exports**

- `createChannelManage`

## `js/src/sources/telegram-channels.js`

Each channel's and supergroup's own catch-up (R-Y35).

Telegram numbers a channel's updates on their own (`pts`), apart from
the account's. When it has too many to push for one channel it sends
`updateChannelTooLong` instead, and an update that skips numbers means
some never came — in both cases a new message, an edit or a deletion
is missing. Telegram's apps then ask `updates.getChannelDifference`
for that channel from its last number (TDLib's get_channel_difference,
Telegram Web K's getChannelDifference); so does this module, instead
of re-reading the whole chat list, which brings neither edits nor
deletions and costs far more requests.

A channel's number lives in the store (`pts:telegram:<chat>`), from
the chat list (each dialog carries it) and then from every update, so
a restart goes on where it stopped. One channel is caught up at most
once a minute unless the user has it open, through the account's
queue; broadcast channels (not groups) only while the user reads them,
as their history is read on demand only (R-Y30).

**Exports**

- `CHANNEL_EVERY_MS`
- `channelStateId`
- `channelStep`
- `createChannelSync`

## `js/src/sources/telegram-chat-admins.js`

Adding members and managing administrators (R-Y204; learned, never
copied): the actions of telegram-add-members.js (`addCandidates`,
`addMembers`, `sendInviteLink`) and telegram-admin-manage.js
(`chatAdmins`, `setAdmin`, `setHistoryHidden`, `upgradeGroup`), sharing
the users they have seen (their access hashes).

**Exports**

- `createChatAdmins`

## `js/src/sources/telegram-chat-edit.js`

New groups and channels, and a chat's info edited, as Telegram Desktop
does (R-Y129; learned, never copied):
- `chatContacts()` — the user's contacts to pick members from
  (contacts.getContacts) → `{ ok, contacts: [{ id, name, username, phone, online,
  lastSeen? }] }` (R-Y189: `lastSeen` an ISO time, or recently/week/month);
- `createGroup({ title, users })` — a basic group of those contacts
  (messages.createChat) → `{ ok, chat, title }`;
- `createChannel({ title, about })` — a broadcast channel
  (channels.createChannel) → `{ ok, chat, title }`;
- `editChatInfo({ chat, title?, about?, photo? })` — the title, the
  description, and the photo: an upload's `token` (the page's upload,
  sent as the chat's photo) or `'remove'` → `{ ok }`.
The new peer is remembered and Telegram's answer goes through the live
handler. Telegram's errors become codes the page shows as text.

**Exports**

- `MAX_ABOUT`
- `MAX_MEMBERS`
- `MAX_TITLE`
- `createChatEdit`
- `uploadedFile`

## `js/src/sources/telegram-chat-info.js`

Chat metadata for the sidebar and header (R-Y36): member count, online
count, about text, username and whether the peer has a profile photo.
  GET /api/telegram/chat-info?chat=<id>
  → { chat, kind, title, members, online, username, about, photo,
      pinned (the newest pinned message's id), broadcast?, bot?,
      lastSeen?, commonChats? (a person: groups in common) }

Fetched through the account's queue at `view` priority and cached in
memory for 60 s (online counts change, so longer is wrong). The three
chat kinds each need their own Telegram call:
  - channel/supergroup (-100N): channels.GetFullChannel + GetOnlines
  - basic group (-N):           messages.GetFullChat  + GetOnlines
  - user (positive id):         users.GetFullUser
Secrets are never logged; only the error code on failure.

**Exports**

- `canBanIn`
- `canEditIn`
- `canInviteIn`
- `canPinIn`
- `canSetTtlIn`
- `createChatInfoReader`
- `moderationOf`
- `statusOf`
- `topicRightsIn`

## `js/src/sources/telegram-chat-reactions.js`

Which reactions a group or channel allows, as Telegram Desktop's
"Reactions" in Manage group / channel (R-Y160; learned, never copied):
- `availableReactions()` — the emoji reactions Telegram offers
  (messages.getAvailableReactions, the inactive ones left out), kept in
  memory for ten minutes → `{ ok, reactions: [{ emoji, title, premium }] }`;
- `chatReactionsSet({ chat, mode, reactions? })` — the chat's setting
  (messages.setChatAvailableReactions): `mode` is 'all', 'some' (with
  1 to 100 emoji of at most 16 characters) or 'none' → `{ ok }`.
`reactionsOf(full)` reads the setting off a ChatFull / ChannelFull
(for the chat info) and `canReactIn(entity)` says who may change it:
the chat's creator, or an admin with the right to change info.
Telegram's errors become codes the page shows as text.

**Exports**

- `MAX_EMOJI_LENGTH`
- `MAX_REACTIONS`
- `MODES`
- `canReactIn`
- `createChatReactions`
- `reactionsOf`
- `validEmojis`
- `validSetting`

## `js/src/sources/telegram-chat-removal.js`

Clearing, deleting and leaving a chat, as Telegram's apps do it
(R-Y100; Telegram Desktop's "Clear history", "Delete chat" and
"Leave", learned, never copied):

- `clear` — every message of the chat deleted, the chat kept:
  messages.deleteHistory with just_clear (a person or a basic group;
  `revoke` deletes them for the other side too), channels.deleteHistory
  for a supergroup (for the user only).
- `delete` — a personal chat's every message deleted and the chat
  gone from the list (`revoke`: for the other person too).
- `leave` — a basic group: the user leaves it (messages.deleteChatUser)
  and its history goes; a supergroup or channel:
  channels.leaveChannel.
- `destroy` — the owner deletes a group or channel for everyone
  (channels.deleteChannel, messages.deleteChat; R-Y216), no undo; the
  chat leaves the list like a left one.

Telegram deletes history a part at a time (`offset` says there is
more); it is asked again until done. The chat's stored messages are
then marked deleted, so the messages leave the screens at once; the
chat goes with them after `delete` and `leave`, but a cleared chat
stays in the list, empty, as Telegram keeps it: its read link holds
when it was cleared and its name and type, as the list is built from
messages. The update counters move with Telegram's answers.

**Exports**

- `REMOVAL_ACTIONS`
- `createChatRemoval`
- `removalAllowed`

## `js/src/sources/telegram-chat-settings.js`

A group's and a channel's settings in Manage group / channel (R-Y165;
learned, never copied), as Telegram Desktop has them:
- `chatSettingSet({ chat, setting, value })` — one switch, from a strict
  allow-list: `signatures` and `signatureProfiles`
  (channels.toggleSignatures), `joinToSend` (channels.toggleJoinToSend),
  `joinRequest` (channels.toggleJoinRequest), `hideMembers`
  (channels.toggleParticipantsHidden), `antiSpam` (channels.toggleAntiSpam)
  `autotranslation` (channels.toggleAutotranslation, the channel's owner,
  R-Y184) and `noForwards` (messages.toggleNoForwards; a group or a
  channel);
- `discussionGroups({ chat })` — the supergroups a channel may be linked
  to (channels.getGroupsForDiscussion) → `{ ok, groups: [{ id, title }] }`;
- `discussionSet({ chat, group })` — links the channel to a group, or
  unlinks it with `group: null` (channels.setDiscussionGroup).
`settingsInfo(entity, full, chats)` is what the chat's info carries so the
page knows the current values and which switches the user may use.
Telegram's errors become codes the page shows as words.

**Exports**

- `SETTING_KEYS`
- `createChatSettings`
- `quietFailureOf`
- `settingsInfo`
- `validSetting`

## `js/src/sources/telegram-chat-themes.js`

Chat themes, as Telegram Desktop's "Change colours" has them (R-Y170;
learned, never copied):
- `chatThemes({ fresh })` — the themes Telegram offers for chats
  (account.getChatThemes, asked again with the hash it gave so an
  unchanged list costs nothing) as `{ ok, themes: [{ emoticon, title,
  light, dark }] }`. `light` and `dark` are the colours of the theme's
  ThemeSettings for that mode (`{ base, accent, outgoing, messages }`,
  colour ints as Telegram has them, the page turns them into CSS), or
  null; a theme's wallpaper is left to the chat background code;
- `setChatTheme({ chat, emoticon })` — a theme of the list (emoticon ''
  for none) for a chat with a person (messages.setChatTheme), the one
  write. Only emoticons of the list are sent.
`themeOf(full)` is the emoticon of the theme a user's full info carries.

**Exports**

- `USER_CHAT`
- `createChatThemes`
- `settingsPage`
- `themeOf`
- `themePage`

## `js/src/sources/telegram-chat-url.js`

**Exports**

- `isTelegramWebUrl`
- `telegramChatUrl`

## `js/src/sources/telegram-chatlists.js`

Shared folders (chat lists), as Telegram Desktop has them (R-Y172;
learned, never copied): a folder whose chats others can add through a
`t.me/addlist/<slug>` link.

- `chatlistInvites({ id })` — chatlists.getExportedInvites: the folder's
  links, `{ slug, title, url, chats: [chat] }`, and the names of the chats;
- `chatlistExport({ id, title?, chats })` — chatlists.exportChatlistInvite
  with the chats chosen from the folder's groups and channels; the folder
  becomes a shared one (`folderId` says which);
- `chatlistInviteEdit({ id, slug, title?, chats? })` —
  chatlists.editExportedInvite; `chatlistInviteDelete({ id, slug })` —
  chatlists.deleteExportedInvite;
- `chatlistCheck({ slug })` — chatlists.checkChatlistInvite, only a look:
  `{ ok, already, folderId?, title, emoticon, chats: [{ chat, name, kind,
  joined }] }` (`joined`: the user is in it; for a folder the user has,
  the chats not yet in are the new ones);
- `chatlistJoin({ slug, chats })` — only on the user's press:
  chatlists.joinChatlistInvite for a new folder, chatlists.
  joinChatlistUpdates for one the user already has; only chats the link
  names can be chosen;
- `chatlistLeaveSuggestions({ id })` — chatlists.getLeaveChatlistSuggestions:
  the chats it would be good to leave as well;
  `chatlistLeave({ id, chats })` — chatlists.leaveChatlist.
New chats in a shared folder the user joined (R-Y211):
- `chatlistUpdates({ id })` — chatlists.getChatlistUpdates: `{ ok, chats:
  [{ chat, name, kind }] }`, the chats the folder's owner has added;
- `chatlistUpdatesJoin({ id, chats })` — only on the user's press:
  chatlists.joinChatlistUpdates with chats the last look named;
- `chatlistUpdatesHide({ id })` — chatlists.hideChatlistUpdates, the
  notice put away.
Telegram's errors become codes the page shows as words.

**Exports**

- `SLUG`
- `createChatlists`
- `slugOfUrl`
- `validChats`
- `validFolderId`
- `validLinkTitle`

## `js/src/sources/telegram-cloud-themes.js`

Cloud themes and the per-chat translation switch, as Telegram Desktop has
them (R-Y209; learned, never copied):
- `cloudThemes({ fresh })` — the themes of the account and Telegram's
  (account.getThemes in Desktop's 'tdesktop' format, asked again with the
  hash it gave) as `{ ok, themes: [cloudPage] }`;
- `cloudTheme({ slug })` — one theme by its t.me/addtheme slug
  (account.getTheme with InputThemeSlug) as `{ ok, theme }`;
- `installCloudTheme({ id, accessHash, slug, dark, reset })` — records the
  theme as the account's (account.installTheme), or with `reset` puts the
  default back; the page applies the colours on its own;
- `toggleTranslations({ chat, disabled })` — "Do not translate this chat"
  or the offer back (messages.togglePeerTranslations).
A theme's page form keeps the colours of its ThemeSettings only (the
`{ base, accent, outgoing, messages }` of chat themes, light and dark);
the .tdesktop-theme file is never parsed.

**Exports**

- `CHAT`
- `DIGITS`
- `SLUG`
- `cloudPage`
- `createCloudThemes`

## `js/src/sources/telegram-comments.js`

A channel post's comments, and a group message's thread of replies,
as Telegram's apps open them (R-Y126; learned, never copied):

- `comments({ chat, post, before, limit })` — `{ ok, group, root,
  unread, messages, complete }`: the discussion (messages.
  getDiscussionMessage: the group the comments are in and the post's
  copy there, `root`), then its replies by page, oldest first
  (messages.getReplies), the page before message `before` when given.
  The comments are given to the page, not stored: the discussion group
  is no chat of the user's list unless they joined it.
- `readComments({ chat, post, max })` — the comments up to `max` read
  (messages.readDiscussion on the post's copy in the group).
- `sendComment({ chat, post, text, replyTo, clientId })` — a comment
  sent to the discussion group, answering the post's copy (or the
  comment `replyTo`, with the copy as its thread's top).

**Exports**

- `createComments`

## `js/src/sources/telegram-common-chats.js`

Groups in common with a person (R-Y158; learned, never copied), as
Telegram Desktop lists them from a person's profile:
- `commonChats({ chat, maxId? })` — the groups and channels both the
  account and the person are in, a page at a time
  (messages.getCommonChats) → `{ ok, chats: [{ chat, title, kind,
  members }], next }`. `chat` is the marked id (-100N for a supergroup
  or channel, -N for a basic group), `kind` 'group' or 'channel',
  `members` the count when Telegram says it (else null); `next` is the
  `maxId` for the following page (the last chat's own id), or null.
Read-only. Telegram's errors become codes the page shows as text.

**Exports**

- `COMMON_PAGE`
- `createCommonChats`

## `js/src/sources/telegram-contact-extras.js`

What Telegram's official clients have on a contact besides the chat
(R-Y217; learned, never copied):
- `contactNote({ chat, note })` — a private note on a contact
  (contacts.updateContactNote; read back as `note` in the chat info);
- `contactToken()` — "Share my contact": a link and its expiry
  (contacts.exportContactToken) → `{ ok, url, expires }`;
  `contactTokenOpen({ token })` — opens such a link
  (contacts.importContactToken) → `{ ok, chat, name }`;
- `phoneResolve({ phone })` — t.me/+<digits> (contacts.resolvePhone) →
  `{ ok, found: false }` or `{ ok, found: true, chat, name }`;
- `contactPhoto({ chat, mode, token })` — a photo for a contact, `mode`
  `save` (only the user sees it), `suggest` (the contact is asked) or
  `reset` (the personal one removed): photos.uploadContactProfilePhoto
  with the page's upload;
- `birthdaySuggest({ chat, day, month, year? })` — users.suggestBirthday;
- `savedContacts()` — the count of imported contacts Telegram keeps
  (contacts.getSaved); `savedContactsReset()` — contacts.resetSaved;
- `blockFromReplies({ msgId, deleteMessage, deleteHistory, reportSpam })`
  — "Block user" on a message of the Replies chat
  (contacts.blockFromReplies).
Nothing is sent but on the user's explicit click. Telegram's errors
become codes the page shows as text.

**Exports**

- `MODES`
- `NOTE_MAX`
- `PHONE_DIGITS`
- `TOKEN`
- `USER`
- `createContactExtras`
- `noteOf`
- `validMsgId`

## `js/src/sources/telegram-contacts-edit.js`

Close friends and adding a contact by phone number, as Telegram
Desktop has them (R-Y169; learned, never copied):
- `closeFriends()` — the user's contacts with who is a close friend now
  (contacts.getContacts, User.close_friend) →
  `{ ok, contacts: [{ id, name, username, closeFriend }] }`;
- `closeFriendsSet({ ids })` — the list saved as it is
  (contacts.editCloseFriends); an empty list clears it;
- `contactImport({ phone, firstName, lastName })` — one contact added
  by number (contacts.importContacts with an InputPhoneContact) →
  `{ ok, found: false }` when the number is not on Telegram, else
  `{ ok, found: true, contact: { id, name, username }, chat }`.
Telegram's errors become codes the page shows as text.

**Exports**

- `MAX_IDS`
- `MAX_NAME`
- `PHONE`
- `USER_ID`
- `contactOf`
- `createContactsEdit`
- `idsOf`

## `js/src/sources/telegram-contacts.js`

The Contacts window's live statuses and the read time of one's own
message in a private chat, as Telegram Desktop shows them (R-Y189;
learned, never copied):
- `contactStatuses()` — every contact's last seen at once
  (contacts.getStatuses) → `{ ok, statuses: [{ id, online, lastSeen? }] }`,
  `lastSeen` an ISO time or recently / week / month (as chat info has it);
- `messageReadTime({ chat, id })` — when the person read the user's own
  message (messages.getOutboxReadDate) → `{ ok, read: true, date }`, `date`
  in ms. Telegram's refusals that still mean "read" answer
  `{ ok, read: true, date: null, code }`: `your-privacy` (the user hides
  their own read times), `peer-privacy` (the person hides theirs),
  `too-old` (older than 7 days); MESSAGE_NOT_READ_YET answers
  `{ ok, read: false }`. Other errors become codes.

**Exports**

- `createContactsActions`
- `readFailure`

## `js/src/sources/telegram-custom-emoji-search.js`

Custom emoji found by words, as Telegram Desktop's emoji status picker
and emoji panel search them for a Premium account (R-Y206; learned,
never copied):
- `customEmojiSearch({ q })` — the documents Telegram has for an emoji
  or a word (messages.searchCustomEmoji) → `{ ok, ids }`, decimal
  strings the page draws with the custom emoji pictures. Kept ten
  minutes by words.

**Exports**

- `MAX_QUERY`
- `createCustomEmojiSearch`
- `queryOf`

## `js/src/sources/telegram-custom-emoji.js`

Custom emoji in messages, as Telegram's apps draw them (R-Y120;
learned, never copied). A message's `MessageEntityCustomEmoji` names a
document by id; this asks Telegram for those documents
(messages.getCustomEmojiDocuments), ids asked close together in one
request (up to 200), each document kept by id, and gives the page:

- `customEmojiPicture({ id, full })` — the emoji's still picture: a
  webp sticker itself, else its thumbnail; `full` the animation (a
  .tgs, for the page's Lottie player) or the video (a webm), null for
  a still one. Each downloaded once into the app folder, with the
  sticker pictures' size limits.

The page may name any id the message carried; one Telegram does not
know is refused (null). An expired file reference asks again once.

**Exports**

- `createCustomEmoji`

## `js/src/sources/telegram-dialog-state.js`

**Exports**

- `createDialogState`

## `js/src/sources/telegram-dialogs.js`

What the chat list's menu does to a chat, as Telegram's apps do it
(R-Y97; Telegram Desktop's dialogs menu, learned, never copied):

- `pin` / `unpin` — messages.toggleDialogPin; Telegram refuses more
  pinned chats than the account may have (`PINNED_DIALOGS_TOO_MUCH`).
- `mute` (for `for` seconds, or for good) / `unmute` —
  account.updateNotifySettings on the chat.
- `archive` / `unarchive` — folders.editPeerFolders, folder 1 or 0.
- `unread` — messages.markDialogUnread: the chat's unread mark;
  `unmark` takes it off (the chat opened, as Desktop does).
- `read` — every message read (to the newest Telegram listed), the
  unread mark taken off.

Each change is then written as the update Telegram sends the other
devices about it, through the same live handler, so the list moves at
once and the next update about it changes nothing.

**Exports**

- `DIALOG_ACTIONS`
- `MUTE_FOREVER`
- `createDialogActions`
- `muteUntilOf`
- `peerOfChat`

## `js/src/sources/telegram-drafts.js`

Cloud drafts kept in step with the other devices, as Telegram Desktop
does (R-Y207; learned, never copied):
- `syncDrafts()` — messages.getAllDrafts, whose answer is a set of
  UpdateDraftMessage; each goes through the live handler's draft writer
  (the same one that follows a draft typed on the phone), and a stored
  draft Telegram no longer lists (cleared elsewhere) is emptied →
  `{ ok, drafts, cleared }`.
- `clearAllDrafts()` — messages.clearAllDrafts, then every stored draft
  is emptied → `{ ok, cleared }`.
The per-chat save (saveDraft in telegram-account.js) is untouched.

**Exports**

- `createDrafts`
- `draftsOf`

## `js/src/sources/telegram-effects.js`

Message effects, as Telegram Desktop and the mobile apps have them
(R-Y149; learned, never copied): a message in a private chat can be
sent with an effect (an emoji bursting over it when it arrives).
- `availableEffects()` — the effects Telegram offers
  (messages.getAvailableEffects, hash 0) → `{ ok, effects: [{ id,
  emoticon, premiumRequired? }], premium }`; ids are decimal strings,
  kept in memory for a few minutes. `premium` says whether the account
  has Premium (the page shows the Premium-only ones locked).
The animation documents are not fetched: the page plays the emoji.

**Exports**

- `EFFECT_ID`
- `createEffects`

## `js/src/sources/telegram-emoji-groups.js`

What the emoji panel needs to offer custom emoji and category tabs, as
Telegram Desktop's does (R-Y214; learned, never copied):
- `emojiPanelInfo({ status })` → `{ ok, premium, groups }`: whether the
  account has Premium (users.getUsers, who may insert custom emoji
  anywhere) and Telegram's emoji groups ("Love", "Joy"…;
  messages.getEmojiGroups, or getEmojiStatusGroups for the status
  picker), each `{ title, iconEmojiId, emoticons }` — the custom emoji
  that draws its tab and the standard emoji it filters the grid to.
  Kept ten minutes by kind; a failure of the groups leaves `[]`.

**Exports**

- `createEmojiGroups`
- `groupOf`

## `js/src/sources/telegram-emoji-keywords.js`

The words emoji are found by in the emoji panel's search and in the
":word" suggestions of the message box, in the page's language, as
Telegram's apps find them (R-Y117, R-Y206; learned, never copied):
Telegram's own list (messages.getEmojiKeywords), asked once a day per
language and kept in memory and in the app's store. A list kept in the
store is brought up to date by what changed since its version
(messages.getEmojiKeywordsDifference) instead of being asked whole.

- `emojiKeywords({ lang })` — `{ ok, lang, version, keywords }`,
  `keywords` `{ word: [emoji…] }`, the words in lower case.

**Exports**

- `applyDifference`
- `createEmojiKeywords`
- `keywordMap`

## `js/src/sources/telegram-emoji-status.js`

Emoji statuses, as Telegram Desktop and the mobile apps have them
(R-Y162; learned, never copied): a Premium account shows a custom emoji
after its name, for a while or until it changes it.
- `emojiStatuses()` → `{ ok, premium, current, defaults, recent }`:
  account.getDefaultEmojiStatuses and account.getRecentEmojiStatuses
  (hash 0); `current` is the account's own status, each status
  `{ id, until? }` with `id` the custom emoji's document id as a
  decimal string and `until` Unix seconds.
- `emojiStatusSet({ documentId|null, until? })` — account.updateEmojiStatus
  with EmojiStatus{documentId, until} or EmojiStatusEmpty (null removes
  it). Setting one is Premium-only: Telegram's refusal is the code
  `premium`.
- `statusOf(value)` is the status a user or channel entity carries (a
  collectible one by its emoji), `statusFields(entity, prefix)` its flat
  fields on a stored link, for the chat list and the messages.

**Exports**

- `DOCUMENT_ID`
- `MAX_UNTIL_SECONDS`
- `createEmojiStatus`
- `statusFields`
- `statusOf`

## `js/src/sources/telegram-ephemeral.js`

Ephemeral messages (layer 232; R-Y223; learned, never copied): a bot's
message shown to one user only (a group's welcome message, a bot's
private answer in a group). They are not part of the chat's history
and are never fetched: they arrive as updates only, so they are kept
in the store under their own id kind,

  eph:telegram:<chat>:<id>   `ephemeral: true`, the message shaped as a
                             normal `msg:` link (text, `raw` with its
                             entities, media and inline keyboard),
                             `deleted` once Telegram deleted it

so nothing that reads `msg:` links (repairs, history, counts, the chat
list) ever sees them. The page draws them in the chat by date.

- `ephemeralMessages({ chat })` — the chat's ephemeral messages kept;
- `ephemeralCallback({ chat, id, data })` — a press on an inline
  callback button of one (ephemeral.getCallbackAnswer), answered like
  a normal bot button (./telegram-bots.js). Only on a click.

Message text is never logged.

**Exports**

- `createEphemeral`
- `ephemeralLinkId`
- `ephemeralLinkOf`
- `ephemeralLive`

## `js/src/sources/telegram-export-html.js`

The HTML pages of an exported chat (R-Y186; Telegram Desktop's export
has `messages.html`, `messages2.html`, … with a small stylesheet; the
markup and the style here are our own): up to 1000 messages a page,
each page linking to the next, the media shown from relative links.
The pages are plain English, as the files are data for the user to
keep, not the app's screen.

**Exports**

- `EXPORT_CSS`
- `PER_PAGE`
- `createHtmlWriter`
- `esc`
- `messageHtml`
- `pageHtml`
- `pageName`
- `textHtml`

## `js/src/sources/telegram-export-media.js`

What an exported message carries besides its words (R-Y186; Telegram
Desktop's export, learned, never copied): which kind of file it is,
which of the export's folders it goes to, whether the user's choices
(kinds on or off, the size limit) let it be downloaded, and the JSON
fields that name the file or tell why there is none. Places, contacts
and polls need no file: they are written into the message itself.

**Exports**

- `FOLDER_OF`
- `NOTE_FAILED`
- `NOTE_OFF`
- `NOTE_TOO_LARGE`
- `OPTION_OF`
- `fileInfoOf`
- `inlineMediaOf`
- `mediaFields`
- `skipNote`
- `wantedName`

## `js/src/sources/telegram-export-output.js`

What an export writes to its folder (R-Y186): `result.json` as Telegram
Desktop's machine-readable export has it (`name`, `type`, `id`,
`messages[]`), written message by message so a cancelled export still
leaves a valid file, and/or the HTML pages (./telegram-export-html.js);
plus the chat's name, kind and id as the export's header says them.

**Exports**

- `chatMeta`
- `exportIdOf`
- `keyOfChat`
- `openOutput`

## `js/src/sources/telegram-export-paths.js`

Where an exported chat history goes and what its files are called
(R-Y186; Telegram Desktop's "Export chat history", learned, never
copied): the default folder `~/Downloads/Telegram Desktop/
ChatExport_<YYYY-MM-DD>`, the folder the user typed checked (absolute,
and never inside the app's own store directory), and file names made
safe and unique inside the export.

**Exports**

- `checkFolder`
- `createNamer`
- `dayEndMs`
- `dayOf`
- `dayStartMs`
- `defaultFolder`
- `freeDefaultFolder`
- `isDay`
- `localIso`
- `safeName`
- `stampOf`

## `js/src/sources/telegram-export-run.js`

One export running in the background (R-Y186): the chat's history read
page by page, oldest first (messages.getHistory, through the account's
queue at `prefetch` priority, waiting out "wait N seconds"), each message
written to the folder with its file downloaded as the user's choices
allow. `r` is the run: `{ env, c, job, now, sleep, publish, ... }`.
Cancel is a `cancelling` state the loops look at between steps; what was
written stays. No message text is ever logged.

**Exports**

- `asked`
- `execute`
- `failure`
- `newRun`
- `stopping`

## `js/src/sources/telegram-export-shape.js`

A Telegram message as one entry of the JSON export (R-Y186). The field
names are those of Telegram Desktop's documented machine-readable
export (`name`, `type`, `id`, `messages[]` with `id`, `type`, `date`,
`date_unixtime`, `from`, `from_id`, `text`, `text_entities`,
`reply_to_message_id`, …); the code is our own, working on the plain
message the store keeps (`rawMessage`, ./telegram-history.js).

**Exports**

- `actionFieldsOf`
- `entitiesOf`
- `messageOf`
- `segmentsOf`
- `senderOf`
- `serviceOf`
- `textFieldsOf`

## `js/src/sources/telegram-export.js`

"Export chat history", as Telegram Desktop has it in a chat's menu
(R-Y186; learned, never copied). The user picks what to include
(photos, videos, voice messages, round video messages, stickers, GIFs,
files), a size limit for videos and files, a date range, the format
(HTML, JSON or both) and a folder; the server then reads the chat's
whole history in the background and writes it there:
- `exportDefaults()` — `{ ok, folder, job }`: Desktop's default folder
  (`~/Downloads/Telegram Desktop/ChatExport_<YYYY-MM-DD>`) and the
  running or last export;
- `exportStart({ chat, chatName?, media, sizeLimitMb, from?, to?,
  formats, folder })` — checks everything first (`bad-request`,
  `relative-folder`, `inside-store`, `bad-folder`, `busy` when one is
  running; one export at a time), then starts it → `{ ok, job }`;
- `exportStatus()` — `{ ok, job }`, `job` null when none ran;
- `exportCancel()` — stops it (what was written stays) → `{ ok, job }`;
- `exportReveal()` — opens the finished export's folder in the file
  manager.
Only reads go to Telegram (./telegram-export-run.js): messages.getHistory
page by page and the files' downloads, through the account's queue. The
progress is an `export:telegram:<chat>` link (the events stream carries
it); no message text is ever logged.

**Exports**

- `DEFAULT_LIMIT_MB`
- `FORMATS`
- `MAX_LIMIT_MB`
- `MEDIA_KEYS`
- `active`
- `createHistoryExport`
- `exportRuntime`
- `opener`
- `parseExport`
- `revealOf`
- `validFormats`
- `validLimit`
- `validRange`

## `js/src/sources/telegram-fact-checks.js`

Fact checks under messages, as Telegram Desktop shows them (R-Y166;
learned, never copied): a message whose fact check Telegram marks
`need_check` carries only its hash; the text is asked for.
- `factChecks({ chat, ids })` — messages.getFactCheck for the messages
  (up to 100) → `{ ok, items: [{ id, country, text, entities }] }`, the
  entities by className as a stored message's; a message with none is
  left out. Answers are kept in memory by chat and id.
Errors become codes.

**Exports**

- `createFactChecks`
- `factOf`
- `validFactRequest`

## `js/src/sources/telegram-folder-edit.js`

Creating, editing, deleting and ordering chat folders, as Telegram
Desktop's Settings → Folders and the folder tab's menu do (R-Y164;
learned, never copied). The folder is the page's shape (see
./telegram-folders.js): `{ title, emoticon?, contacts, nonContacts,
groups, broadcasts, bots, excludeMuted, excludeRead, excludeArchived,
include, exclude, pinned }`, the lists being our chat ids.

- `folderSave({ id?, folder })` — messages.updateDialogFilter with a
  DialogFilter (layer 225: the title is a TextWithEntities; a shared
  folder, `chatlist: true`, is a DialogFilterChatlist with chats only,
  R-Y172). With no `id` the folder is new and takes the next free id (Telegram wants the
  client to choose it, 2 or more);
- `folderDelete({ id })` — the same method with no filter;
- `foldersReorder({ order })` — messages.updateDialogFiltersOrder; the
  ids of every folder in the new order (0 is "All chats");
- `foldersSuggested()` — messages.getSuggestedDialogFilters, as
  `{ folder, description }` for the recommended folders.
Telegram's errors (too many folders, too many chats, ...) become codes
the page shows as words.

**Exports**

- `CHATS_MAX`
- `COLORS`
- `TITLE_MAX`
- `createFolderEdit`
- `inputsOf`
- `validFolder`
- `validId`

## `js/src/sources/telegram-folders.js`

Chat folders, as Telegram's apps show them (R-Y103; Telegram Desktop's
folders above the chat list, learned, never copied).

`folderList({ fresh })` — messages.getDialogFilters, as plain data the
page applies to its chat list (./../web/chat-folders.js):

  { id, title, emoticon,
    contacts, nonContacts, groups, broadcasts, bots,   // who is in
    excludeMuted, excludeRead, excludeArchived,       // who is not
    include: [chat], exclude: [chat], pinned: [chat],  // by name
    chatlist?, hasMyInvites? }                        // a shared one

and `{ id: 0, all: true }` where "All chats" stands among them (a
Premium user may move it). Chats are our chat ids (Telegram's marked
ids: a user's id, -chat, -100channel). Kept for a minute: folders
change rarely, and only in Telegram's settings.

**Exports**

- `createFolders`
- `folderOf`
- `peerChat`

## `js/src/sources/telegram-format.js`

Text formatting as Telegram's apps send it (R-Y101; Telegram Desktop's
markdown and its formatting shortcuts, learned, never copied).

What is typed is sent as Telegram's entities, the markers removed:

  **bold**   __italic__   ~~strike~~   ||spoiler||   `code`
  <u>underline</u>   ```lang
  pre (a code block)```   [text](https://link)

As in Desktop, a marker counts only at a word's edge ("2**3**4" and
"snake__case__name" stay as typed), the formatted text cannot start or
end with a space, a lone `*` or `_` stays, and nothing is parsed inside
code; underline, which Telegram's markdown has no marker for (Desktop
makes it with Ctrl+U), is <u>…</u>. Offsets and lengths are UTF-16 units — what Telegram counts and
what JS strings index.

Pure: shared by the server (sending, editing) and the page (pending
messages, the composer's shortcuts, editing a formatted message).

**Exports**

- `CLASS_OF`
- `MARKERS`
- `apiEntities`
- `linkUrl`
- `parseFormatted`
- `rawEntities`
- `sliceFormatted`
- `toMarkdown`
- `wrapSelection`

## `js/src/sources/telegram-forum-view.js`

A forum group seen as its whole message list or as its topics, as
Telegram Desktop's ⋯ menu has it (R-Y171; learned, never copied):
- `forumView({ chat, asMessages })` — channels.toggleViewForumAsMessages
  with `enabled` = asMessages → `{ ok, asMessages }`. Called only on the
  user's click; the flag Telegram keeps comes back with the chat info
  (channelFull view_forum_as_messages).

**Exports**

- `createForumView`

## `js/src/sources/telegram-forum.js`

A forum group's topics, as Telegram's apps show them (R-Y122; Telegram
Desktop's forum, learned, never copied):

- `forumTopics({ chat })` — `{ ok, forum, topics }`: the topics
  (messages.getForumTopics), pinned first, each `{ id, title,
  iconColor, iconEmojiId, top, unread, readInboxMaxId, mentions,
  pinned, closed,
  hidden, at, last }`, `last` the topic's newest message (stored as
  any read one is). A group that is not a forum: `forum: false`. Kept
  for a little while, so the page can ask as often as it shows them.
- `topicHistory({ chat, topic, before, limit })` — `{ written,
  complete }`: a topic's newest messages, or the page before message
  `before` (messages.getReplies on the topic's first message), stored;
  the page reads them from the store by the topic's key.

**Exports**

- `createForum`
- `topicOf`

## `js/src/sources/telegram-games.js`

HTML5 bot games, as Telegram Desktop shows them (R-Y190; learned, never
copied): `gameHighScores({ chat, id })` — a game message's high scores
(messages.getGameHighScores, asked as the user themself) →
`{ ok, scores: [{ pos, user, name, score, me }] }`, best first. Playing
itself is a bot button's press (messages.getBotCallbackAnswer with
`game`, in ./telegram-bots.js). Posting a score (setGameScore) is for
bots only and is not offered.

**Exports**

- `createGames`
- `scoresOf`

## `js/src/sources/telegram-gif-save.js`

A GIF in a chat saved to the user's GIFs or taken from them, as Telegram
Desktop's message menu does (R-Y171; learned, never copied):
- `messageGifSave({ chat, message, unsave })` — `{ ok, id, saved }`:
  reads the message (its document comes with a fresh file reference),
  checks it is an animation, and asks messages.saveGif with its
  InputDocument (`unsave` true removes it). A FILE_REFERENCE_EXPIRED
  answer reads the message again once, as the file reader does. The
  panel's saved list (messages.getSavedGifs) is asked again after.
Telegram's errors become codes the page shows as text.

**Exports**

- `createGifSave`

## `js/src/sources/telegram-gift-send.js`

Sending a gift to a person, as Telegram Desktop's "Send a gift" does
(R-Y185; learned, never copied):
- `giftCatalogue({ fresh? })` — the gifts one can buy
  (payments.getStarGifts, asked with the hash of the last answer, so an
  unchanged catalogue is not sent again) → `{ ok, gifts: [{ id, stars,
  title, limited, soldOut, remains, total, premium, birthday, sticker }] }`;
  each `sticker` is the sticker panel's item (see telegram-stickers.js);
- `giftSend({ chat, gift, stars, text?, hideName? })` — the only thing
  that pays, on the confirmation's button alone: payments.checkCanSendGift
  first (the person may not take gifts), then payments.getPaymentForm
  with an InputInvoiceStarGift, then payments.sendStarsForm with that
  form's id — and only when the form's price is the `stars` the page
  showed (else `code: 'price'`, nothing is paid).
Telegram's errors become codes the page shows as text.

**Exports**

- `TEXT_MAX`
- `createGiftSend`
- `giftCard`

## `js/src/sources/telegram-gifts-manage.js`

Managing received gifts, unique (collectible) gifts and gift codes, as
Telegram Desktop does (R-Y193; learned, never copied). The list of a
person's gifts is `starGifts` (telegram-stars.js); this adds what is done
to one. A gift is named by `chat` and either `msgId` (a gift of a person,
InputSavedStarGiftUser) or `savedId` (a gift of a chat,
InputSavedStarGiftChat). Every write happens on its own click, behind the
page's confirmation:
- `giftConvert(ref)` — payments.convertStarGift → `{ ok }`;
- `giftUpgradePreview({ giftId })` — payments.getStarGiftUpgradePreview →
  `{ ok, models, patterns, backdrops, prices }` (what an upgrade may
  become; nothing is changed);
- `giftUpgrade({ ...ref, stars, keepDetails? })` — free (`stars` 0:
  payments.upgradeStarGift) or paid (a payment form with
  InputInvoiceStarGiftUpgrade, sent only when its price is the `stars`
  the page showed, else `code: 'price'`, nothing is paid);
- `giftTransfer({ ...ref, to, stars })` — the same for a unique gift
  given to the person `to` (payments.transferStarGift or an
  InputInvoiceStarGiftTransfer form);
- `giftPin({ chat, pins })` — payments.toggleStarGiftsPinnedToTop sets the
  pinned list (the app config's `stargifts_pinned_to_top_limit`, else 6;
  more is refused with `code: 'pin-limit'` and the `limit`);
- `giftUnique({ slug })` — payments.getUniqueStarGift → `{ ok, gift }`;
- `giftCodeCheck({ slug })` — payments.checkGiftCode → `{ ok, info }`;
- `giftCodeApply({ slug })` — payments.applyGiftCode (Premium, for the
  months the code holds).
Telegram's errors become codes the page shows as text.

**Exports**

- `PIN_LIMIT`
- `codeInfoOf`
- `createGiftsManage`
- `hexColor`
- `pinLimitOf`
- `rarityOf`
- `refOf`
- `validRef`

## `js/src/sources/telegram-giveaways.js`

Giveaways, as Telegram Desktop shows them (R-Y184; learned, never
copied). Read only: nothing here creates, joins or changes a giveaway.
- `giveawayInfo({ chat, id, channels?, winners? })` —
  payments.getGiveawayInfo of the giveaway message `id` in `chat` →
  `{ ok, ended: false, participating, preparing, startDate,
  joinedTooEarlyDate?, disallowedChat?, disallowedCountry? }` while it
  runs, or `{ ok, ended: true, winner, refunded, startDate, finishDate,
  winnersCount, activatedCount?, slug?, starsPrize? }` when it is over.
  `channels` and `winners` are ids from the card; their names come back
  as `channelNames` and `winnerNames` where we can read them (an id we
  cannot read stays out), at most MAX_NAMES each.
Telegram's errors become codes the page shows as text.

**Exports**

- `MAX_NAMES`
- `createGiveaways`
- `infoOf`
- `validIds`

## `js/src/sources/telegram-global.js`

Search across Telegram, as Telegram's apps search from the chat list's
box (R-Y107; learned, never copied): people and chats by name or
username — the user's own first, then public ones (contacts.search) —
and messages in every chat (messages.searchGlobal), newest first, a
page at a time. What is found is stored as any read message or chat
is: a found chat opens at once, a found message is there to show.

`searchPeers({ q })` → `{ ok, peers: [{ chat, name, username, kind,
members, mine }] }`;
`searchGlobal({ q, cursor? })` → `{ ok, messages, count, more, cursor }`
— `messages` the found ones as links, newest first; `cursor` asks for
the page after them;
`searchTag({ tag, scope, cursor? })` (R-Y182) — a hashtag or cashtag in
every chat (`scope: 'all'`, messages.searchGlobal) or in public posts
(`scope: 'public'`, channels.searchPosts), answered as searchGlobal.

**Exports**

- `GLOBAL_PAGE`
- `MAX_GLOBAL_QUERY`
- `PEERS_LIMIT`
- `TAG`
- `createGlobalSearch`
- `entitiesOf`
- `kindOf`
- `nameOf`
- `peerIdOf`
- `usernameOf`

## `js/src/sources/telegram-group-extras.js`

A supergroup's own sticker set and emoji pack, and the account's "New
contacts joined Telegram" notification, as Telegram Desktop has them
(R-Y211; learned, never copied):

- `groupStickerSet({ chat, shortName, emojis? })` — channels.setStickers
  with the set named by its short name (InputStickerSetShortName), or
  InputStickerSetEmpty with `shortName` null to remove it; `emojis`
  sets the group's emoji pack instead (channels.setEmojiStickers). The
  preview of a set before saving is the sticker box's
  (`stickerSetBox({ shortName })`, messages.getStickerSet);
- `contactSignUpGet()` — account.getContactSignUpNotification → `{ ok,
  on }` (the call answers whether notifications are silenced);
- `contactSignUpSet({ on })` — account.setContactSignUpNotification.
`groupStickersInfo(entity, full)` is what the chat info says about both.
Telegram's errors become codes the page shows as text.

**Exports**

- `CHANNEL`
- `SHORT_NAME`
- `createGroupExtras`
- `groupStickersInfo`
- `validGroupSet`

## `js/src/sources/telegram-history.js`

What of each Telegram chat is already in the store, so Telegram is
asked only for what is missing (R-Y24 .. R-Y28).

Every message ever loaded stays in the store (`data.lino` and
`data.bin`), with everything Telegram said about it (`raw`). A chat's
`history:telegram:<chat>` link records the stretch of it that is
stored without holes, from `newest` back to `oldest`, and `complete`
once that stretch reaches the chat's first message. Opening a chat
again, or scrolling back over what was read before, is then answered
from the store; Telegram is asked for older pages, for a chat never
opened, and — for channels, whose updates the account-wide catch-up
does not carry — for what came after `newest`.

Requests to Telegram go one at a time through `createFetchQueue`, the
most urgent first: the chat the user is looking at, then the chat
list, then chats visible in it, then the slow background download.

**Exports**

- `CHANNEL_FRESH_MS`
- `NO_PACE`
- `PACE`
- `PRIORITIES`
- `SLOW_FOR_MS`
- `STUCK_MS`
- `coverSlice`
- `createFetchQueue`
- `floodSeconds`
- `historyLink`
- `historyLinkId`
- `historyPlan`
- `isChannelChat`
- `isDisconnected`
- `methodOf`
- `rawMessage`

## `js/src/sources/telegram-inline-bots.js`

Inline bots in the message box, as Telegram Desktop's (R-Y138;
learned, never copied): `@gif cats` asks the bot @gif for answers.

- `inlineBot({ username })` — the bot behind a name
  (contacts.resolveUsername); only a bot with an inline placeholder
  counts → `{ ok, bot: { id, username, name, placeholder } }`, else
  code `not-inline` (a user, or a bot without inline mode) or `no-bot`;
- `inlineResults({ chat, username, query, offset })` — the bot's
  answers for the words, in this chat (messages.getInlineBotResults),
  a page at a time → `{ ok, bot, queryId, gallery, results: [{ id,
  type, title, description, doc }], next, switchPm, switchWebview }`.
  A result with a file (GIF, sticker, video) has `doc`, a panel item
  whose picture the sticker route serves; a photo or a result that
  only names a web address has none — the page never loads another
  site's address, and this server fetches none either;
- `inlineSend({ chat, queryId, id, replyTo, clientId, sendAs })` — one
  answer sent (messages.sendInlineBotResult, as the chat's picked "send
  as" identity when `sendAs` names one, R-Y147); only an answer this
  module gave in that chat; Telegram's reply goes through the live
  handler;
- `inlineStartBot({ username, startParam })` — the "switch to PM" button
  above the results (messages.startBot: bot, peer = the bot, randomId,
  startParam; R-Y147); only a start parameter that bot's answer offered.

Bots are kept ten minutes, answers as long as the bot says
(`cacheTime`, at most five minutes). Telegram's errors become codes.

**Exports**

- `MAX_OFFSET`
- `MAX_QUERY`
- `MAX_RESULT_ID`
- `NAME`
- `createInlineBots`
- `inputBot`
- `resolveBotUser`

## `js/src/sources/telegram-instant-view-shape.js`

Instant View pages as a safe JSON tree (R-Y205; learned, never copied):
Telegram's `Page` (blocks of `PageBlock`, text as `RichText`) becomes
plain objects the page draws with React elements only. Ids are strings,
every link is http, https or tg (or an anchor of the same page), and
what is unknown or too deep is dropped.

- `safeHref(url)` — the url if it may be linked, else null;
- `shapeText(rich, ctx)` — a RichText as inline nodes: `{ t: 'text', s }`,
  `{ t: 'b'|'i'|'u'|'s'|'code'|'sub'|'sup'|'mark', c }`, `{ t: 'a', href,
  c }`, `{ t: 'a', anchor, c }` (same page), `{ t: 'anchor', name, c }`,
  `{ t: 'img', id, w, h }`, and (R-Y225; learned, never copied) the
  rich-text kinds of Telegram's entities: `{ t: 'tag', s, c }` (hashtag,
  cashtag, bot command), `{ t: 'bankcard', s, c }`, `{ t: 'user', id,
  c }`, `{ t: 'date', date, ...flags, s, c }`, `{ t: 'emoji', id, s }`,
  `{ t: 'button', c, type, style }` and `{ t: 'math', s }`;
- `shapePage(page)` — `{ url, rtl, blocks, photos, documents }`, the
  last two the ids the page may ask the media route for.

**Exports**

- `richPlainText`
- `safeHref`
- `shapePage`
- `shapeRich`
- `shapeText`

## `js/src/sources/telegram-instant-view-whole.js`

The whole file of a document an Instant View page used: its video, audio
or file (R-Y224; learned, never copied). Read-only: downloaded through
the Telegram client (up to 64 MB), never from the page's own site; the
last two are kept so a player's range requests share one download.
  `createWholeFiles(env, context, files)(key)` -> `{ buffer, mimeType,
  name }`, `{ error: 'too-large', size }` or null; `key` is
  `document:<id>` of the `files` map the page remembered.

**Exports**

- `createWholeFiles`

## `js/src/sources/telegram-instant-view.js`

Instant View, as Telegram Desktop and the official clients offer it
(R-Y205; learned, never copied). Read-only:
- `instantView({ url, hash? })` — messages.getWebPage → `{ ok,
  available: true, siteName, title, page }` where `page` is the safe
  tree of ./telegram-instant-view-shape.js, or `{ ok, available: false
  }` when Telegram has no cached page for the link (the page offers
  "Open in browser"). A `t.me/iv?url=…` link names the page it wraps.
  Telegram's errors (WEBPAGE_NOT_FOUND, …) become codes;
- `instantViewFile({ kind, id })` — a picture the last pages used
  (`kind` 'photo' or 'document'), downloaded through the Telegram
  client with the media helpers (never from the page's own site) →
  `{ buffer, mimeType }` or null. Pages and pictures are kept in memory.
  With `full: true` a document comes whole (up to 64 MB) with its name,
  for a page's video, audio and files (R-Y224; learned, never copied);
  the last two are kept so a player's range requests share one download.

**Exports**

- `KINDS`
- `createInstantView`
- `targetOf`

## `js/src/sources/telegram-invite-links.js`

A group's or channel's invite links and join requests, as Telegram
Desktop's "Manage" screens have them (R-Y152; learned, never copied):
- `inviteLinks({ chat, revoked?, offsetDate?, offsetLink? })` — the
  user's own links (messages.getExportedChatInvites, adminId = self),
  or the revoked ones → `{ ok, primary, links, count, next }`;
- `inviteCreate({ chat, title?, expireDate?, usageLimit?, requestNeeded? })`
  — a new link (messages.exportChatInvite) → `{ ok, invite }`;
- `inviteEdit({ chat, link, revoked?, title?, expireDate?, usageLimit?,
  requestNeeded? })` — a link changed or revoked
  (messages.editExportedChatInvite) → `{ ok, invite, replacement? }`;
- `inviteDelete({ chat, link })` / `inviteDeleteRevoked({ chat })` — one
  revoked link, or all of them, deleted;
- `inviteImporters({ chat, link?, requested?, offset? })` — who joined
  through a link, or who asks to join (messages.getChatInviteImporters)
  → `{ ok, importers, count, next }`;
- `joinRequestHide({ chat, user, accessHash?, approved })` and
  `joinRequestsHideAll({ chat, approved, link? })` — requests approved
  or dismissed (messages.hideChatJoinRequest, hideAllChatJoinRequests).
Expire dates sent are unix seconds; dates read are milliseconds.
Telegram's errors become codes the page shows as text.

**Exports**

- `INVITE_LINK`
- `LIMIT_MAX`
- `TITLE_MAX`
- `createInviteLinks`
- `shapeInvite`
- `validLink`
- `validOffset`
- `validSettings`

## `js/src/sources/telegram-invite.js`

Chat invite links, as Telegram Desktop handles them (R-Y123; learned,
never copied):
- `checkChatInvite({ hash })` — what a link leads to
  (messages.checkChatInvite): `{ ok, already, chat }` when the user is in
  the chat (open it), else `{ ok, invite: { title, about, members,
  channel, broadcast, requestNeeded } }`;
- `joinChatInvite({ hash })` — only on the user's press of Join
  (messages.importChatInvite); the answer goes through the live handler,
  so the chat appears in the list;
- `revokeChatInvite({ chat })` — a chat's primary link replaced by a new
  one (messages.exportChatInvite with legacyRevokePermanent) →
  `{ ok, link }`.
Telegram's errors become codes the page shows as text.

**Exports**

- `INVITE_HASH`
- `createInvites`
- `markedId`

## `js/src/sources/telegram-jump.js`

A chat opened far back, as Telegram's apps open it on a date picked
in the calendar (R-Y106; learned, never copied): the first message on
or after that moment, with a page around it, read from Telegram and
stored; then the pages after it, one at a time, as the user scrolls
down toward the newest. Nothing between there and the newest is read
first.

What is read joins the chat's stored stretch (./telegram-history.js)
once it reaches it, so the rest comes from the store.

**Exports**

- `createHistoryJump`

## `js/src/sources/telegram-layer.js`

GramJS speaking Telegram's current API layer (R-Y76).

GramJS builds every TL class from one schema text (`telegram/tl/apiTl.js`)
and names its layer when it connects (`AllTLObjects.LAYER`). Its copy
is older than Telegram's, and Telegram sends a client what its layer
cannot describe — checklists, polls since their new constructor, newer
media — as `messageMediaUnsupported`, which no later read can repair.
So before GramJS loads, its schema module is given the layer Telegram
publishes (./telegram-api/layer-N.tl, made by
js/scripts/telegram-schema.mjs), and its LAYER set to match.

Anything going wrong here leaves GramJS as it was: older, but working.

**Exports**

- `LAYER`
- `SCHEMA_REV`
- `chatListClasses`
- `importTelegram`
- `installTelegramLayer`
- `peerDialogs`
- `quietOldButtons`
- `skipCommunities`
- `skipPeerlessDialogs`
- `withoutCommunities`

## `js/src/sources/telegram-left-channels.js`

The channels the user left, as Telegram Desktop shows them when the
channel limit is hit (R-Y200; learned, never copied):
- `leftChannels({ offset? })` — one page (channels.getLeftChannels, by
  how many were already read) → `{ ok, channels: [{ chat (-100…), title,
  username, members, broadcast }], next }`; `next` is the offset of the
  following page, or null at the end. Read only: nothing is joined here;
  the page's preview does that on the explicit Join.
Telegram's errors become codes the page shows as text.

**Exports**

- `createLeftChannels`
- `nextOffset`

## `js/src/sources/telegram-link-preview.js`

The link preview of the message box, as Telegram Desktop shows it
(R-Y145; learned, never copied):

- `linkPreview({ text, url })` — messages.getWebPagePreview with the
  text and its entities → `{ ok, state: 'ready', preview }` (`preview`:
  `{ url, displayUrl, siteName, title, description, photo, large }`,
  `photo` the id of a picture the route below serves, else null),
  `{ ok, state: 'pending' }` while Telegram is still fetching the page
  (the page asks again), or `{ ok, state: 'empty' }` (no preview).
  Ready and empty answers are kept for five minutes per link;
- `linkPreviewPhoto({ id })` — the picture of a page Telegram sent in
  a preview, downloaded through the Telegram client (never from the
  page's own site); only ids this module handed out are served.

`previewFields(body)` validates what a send carries about it:
`noWebpage`, `invertMedia`, and `previewUrl` with `previewSize`
('large' | 'small') → the draft's fields, or null when invalid.

**Exports**

- `PREVIEW_SIZES`
- `PREVIEW_URL`
- `createLinkPreview`
- `previewFields`

## `js/src/sources/telegram-map.js`

Map pictures for places (R-Y131), as Telegram Desktop draws them
(learned, never copied): a place in a chat shows a map image that
Telegram makes, asked with upload.getWebFile for an
InputWebFileGeoPointLocation.

- `mapImage({ lat, lon, accessHash?, w, h, zoom, scale })` — the image
  `{ ok, mime, bytes }`, read in 128 KiB chunks until the bytes run
  out. Kept in memory (about 64 pictures), so a place seen again is
  not asked again.

**Exports**

- `answerMap`
- `createMapActions`
- `mapQuery`

## `js/src/sources/telegram-media.js`

Pictures of Telegram messages, store first (R-Y36): a photo, a link
preview's photo, a file's thumbnail or a small picture sent as a file
(a sticker), for the chat to show inline as Telegram's apps do.

Where a picture is comes from the stored message (`raw.media`, R-Y28):
its id, access hash, file reference and data centre. So showing it is
one download, never a re-read of the message first; only when Telegram
says the file reference expired is the message read again (by its
stored peer, through the queue) and the download tried once more.

Each picture is downloaded once: it is kept in the app folder
(`<store>/media/telegram/<chat>/<id>-<size>`) and served from there.
Downloads go through the account's queue at `list` priority — after
what the user scrolls to, before anything read ahead (R-Y34). Videos,
voice notes and large files are never downloaded here.

**Exports**

- `RICH_DOCUMENT`
- `bigSize`
- `createFileReader`
- `createMediaReader`
- `docKind`
- `documentPicture`
- `fileLocation`
- `locationOf`
- `mediaOf`
- `nameOf`
- `pickSize`
- `pictureOf`
- `readCache`

## `js/src/sources/telegram-members.js`

A group's members, as Telegram Desktop lists them in the info column
(R-Y125; learned, never copied):
- `chatMembers({ chat, q, offset, limit })` — a supergroup's page
  (channels.getParticipants, the recent ones, or a search by `q`), a
  basic group's (messages.getFullChat) → `{ ok, total, members: [{ id,
  name, username, role, rank, self }], canBan, canInvite }`; `role` is
  creator, admin, member, restricted or banned;
- `removeMember({ chat, user })` — "Remove from group": the user banned
  and at once unbanned in a supergroup (so they may come back), a basic
  group's member deleted (messages.deleteChatUser).
Telegram's errors become codes the page shows as text.

**Exports**

- `createMembers`
- `inputPeerOf`

## `js/src/sources/telegram-message-links.js`

Links to messages, as Telegram Desktop has them (R-Y154; learned, never
copied):

- `messageLink({ chat, id, thread })` — "Copy link" of a message in a
  supergroup or channel (channels.exportMessageLink); `thread` asks for
  the link of a message inside a topic or a comment thread →
  `{ ok, link }`;
- `resolveLink({ username })` — the chat a t.me/username/123 link names
  (contacts.resolveUsername) → `{ ok, chat, name, username, kind }` with
  `chat` the marked id (-100…); a username of a person or a bot is code
  `not-chat`, an unknown one `no-chat`.
Telegram's errors become codes the page reads.

**Exports**

- `CHANNEL_CHAT`
- `LINK_USERNAME`
- `MAX_MESSAGE_ID`
- `createMessageLinks`
- `validMessageId`

## `js/src/sources/telegram-moderation.js`

Moderating a supergroup's members, as Telegram
Desktop's admin dialogs do (R-Y200; learned, never copied):
- `moderateUser({ chat, user, ids?, reportSpam?, ban?, deleteAll? })` —
  what the delete dialog's checkboxes ask: "Report spam" for the
  message ids (channels.reportSpam, first, while they still exist),
  "Ban user" (channels.editBanned, view messages off for good) and
  "Delete all from <name>" (channels.deleteParticipantHistory, asked
  again while Telegram's AffectedHistory says an `offset` is left) →
  `{ ok, deleted }`; supergroups only;
- `notSpam({ chat, msgId })` — "Not spam" for a message anti-spam
  deleted (channels.reportAntiSpamFalsePositive);
Telegram's errors become codes the page shows as text.

**Exports**

- `createModeration`
- `moderationBody`

## `js/src/sources/telegram-mtproto.js`

Telegram **user-account** auth over MTProto, the way konard/telegram-bot
does it: a GramJS `TelegramClient` built from an `api_id` / `api_hash`
and a `StringSession`, signed in with `client.start({ phoneNumber,
phoneCode, password })`, then `client.session.save()` is the reusable
session string (that project writes it to `.telegram_session`).

GramJS (the `telegram` package) is a heavy, optional dependency, loaded
lazily so the rest of the server never needs it. The client itself is
injected (`clientFactory`) so the login state machine is unit-tested
with a fake and the real GramJS lives only in `gramjsClientFactory`.

Two entry points:
  identify({apiId,apiHash,session})  connect with an existing session,
                                     read the account (getMe), disconnect.
  createLogin({apiId,apiHash,phone}) drive the interactive sign-in across
                                     HTTP requests: start → code → (2FA)
                                     password → a saved session string.
  createQrLogin({apiId,apiHash})     the same by QR code (R-Y203), see
                                     ./telegram-qr-login.js.

**Exports**

- `accountOf`
- `createTelegramMtproto`
- `gramjsClientFactory`

## `js/src/sources/telegram-notify-extras.js`

Reaction notifications, resetting the notification settings and
Telegram's own automatic-download preset (R-Y215; learned, never
copied):

- `reactionNotifyGet()` — account.getReactionsNotifySettings → `{ ok,
  messages, stories, previews, sound }`: who the account is told of
  reactions to its messages and stories from ('nobody', 'contacts' or
  'all'), whether the notification shows a preview and whether it has a
  sound;
- `reactionNotifySet({ messages?, stories?, previews?, sound? })` —
  account.setReactionsNotifySettings with the rest kept as it was (the
  poll votes setting, a chosen ringtone) → the same row;
- `notifyResetAll()` — account.resetNotifySettings: every notification
  setting back to Telegram's default;
- `autoDownloadPreset()` — account.getAutoDownloadSettings → `{ ok,
  medium: { disabled, photoMax, videoMax, fileMax } }` (bytes), the
  preset the page maps to its own settings.
Telegram's errors become codes the page shows as text.

**Exports**

- `FROM`
- `createNotifyExtras`
- `fromOf`
- `presetOf`
- `reactionRowOf`
- `validReactionChange`

## `js/src/sources/telegram-notify-settings.js`

Notification settings, as Telegram Desktop's Settings → Notifications
and a chat's "Notifications" have them (R-Y157; learned, never copied):

- `notifyOverview()` — the account's global settings for private chats,
  groups and channels (account.getNotifySettings with InputNotifyUsers,
  InputNotifyChats, InputNotifyBroadcasts) and the chats that differ
  (account.getNotifyExceptions, sounds not compared) → `{ ok, scopes:
  { users | chats | broadcasts: { on, previews, stories } }, exceptions:
  [{ chat, name, scope, state: 'muted' | 'unmuted' | 'custom',
  muteUntil, forever, previews }] }`;
- `notifyScopeSet({ scope, on, previews, stories })` — one change to a
  scope (account.updateNotifySettings; off is muted for good, on is
  muteUntil 0), the rest of its settings kept → `{ ok, scope, ...row }`;
- `notifyChat({ chat })` — one chat's own settings (getNotifySettings
  with InputNotifyPeer) → `{ ok, chat, exception, muteUntil, forever,
  previews, stories }`;
- `notifyChatSet({ chat, mute, previews, reset })` — a chat's own: `mute`
  'off', 'forever' or seconds; `previews` 'default', 'on' or 'off';
  `reset` sends empty settings so the chat follows the global ones.
A chat's sound (R-Y181): `notifyChat` answers `sound` — 'default', 'none'
or a saved ringtone's id — and `notifyChatSet({ sound })` sets it
(NotificationSoundDefault is no sound field, NotificationSoundNone,
NotificationSoundRingtone); exceptions carry it too.
Layer 225 has no per-chat flag for pinned messages or for mentions, so
neither is offered; stories are muted by `storiesMuted`.
Telegram's errors become codes the page shows as text.

**Exports**

- `SCOPES`
- `chatFields`
- `createNotifySettings`
- `exceptionOf`
- `rowOf`
- `soundText`
- `validChatChange`
- `validScopeChange`

## `js/src/sources/telegram-ownership.js`

Ownership of a chat, as Telegram Desktop's edit dialog has it (R-Y200;
learned, never copied):
- `convertToGigagroup({ chat, confirm })` — the supergroup becomes a
  broadcast group where only admins write (channels.convertToGigagroup);
  cannot be undone, so `confirm: true` is required;
- `transferOwnership({ chat, user, password })` — the chat handed to a
  member (messages.editChatCreator, layer 225's call for groups and
  channels) with the 2-Step Verification password checked by the
  `telegram` package's SRP helper (`computeCheck`). The password lives
  only in the request in memory: never logged, stored, put into an error
  or answered. PASSWORD_MISSING, PASSWORD_TOO_FRESH_* and
  SESSION_TOO_FRESH_* come back as codes (with `waitSeconds`).
Telegram's errors become codes the page shows as text.

**Exports**

- `PASSWORD_MAX`
- `createOwnership`

## `js/src/sources/telegram-pages.js`

Reading Telegram page by page, store first (R-Y24 .. R-Y26): one
chat's history (newest, then older pages as the user scrolls back) and
the chat list beyond its first page. What the store already holds is
never asked for again (./telegram-history.js says what that is); every
request goes through the account's queue at the caller's priority.

A chat is asked for by its stored input peer (./telegram-peers.js),
so reading it is one request; a channel the user reads is caught up
through its own difference (./telegram-channels.js), which also brings
its edits and deletions.

The helpers that turn GramJS objects into links live in
./telegram-account.js and come in through `tools`, so this module has
no import cycle with it.

**Exports**

- `createPageReader`
- `dialogsCursor`

## `js/src/sources/telegram-paid-messages.js`

Paid messages, as Telegram Desktop has them (R-Y184; learned, never
copied): a person or a group may charge Stars per message.
- `paidPrice({ chat })` — what one message costs the user in `chat`:
  a person's price from users.getRequirementsToContact, a supergroup's
  from its `send_paid_messages_stars` (channels.getChannels; an owner or
  admin writes free) → `{ ok, stars }` (0: free). Read only;
- `paidSettings()` — account.getGlobalPrivacySettings → `{ ok, stars }`,
  the price the user charges non-contacts (0: nobody is charged);
- `paidSettingsSave({ stars })` — account.setGlobalPrivacySettings with
  `noncontact_peers_paid_stars` = stars (0 removes it) and every other
  setting KEPT as read (a WRITE, on Save only), 0..PAID_STARS_MAX;
- `paidRevenue({ user })` — account.getPaidMessagesRevenue → `{ ok,
  stars }` earned from one person (read only);
- `paidException({ user, allow, refund })` — account.
  toggleNoPaidMessagesException: `allow` lets the person write for free
  (optionally refunding what they paid), otherwise they pay again (a
  WRITE, on a confirmation only);
- `paidPriceSave({ chat, stars })` — channels.updatePaidMessagesPrice for
  a group the user admins, 0 turns it off (a WRITE, on Save only).
Sending into such a chat is not here: a send carries the Stars the user
confirmed (`allowPaidStars`, telegram-send-as-client.js). Telegram's
errors become codes the page shows as text.

**Exports**

- `PAID_STARS_MAX`
- `createPaidMessages`
- `validPrice`

## `js/src/sources/telegram-peer-actions.js`

What Telegram Desktop offers on a person or a chat besides talking
(R-Y128; learned, never copied):
- `peerBlock({ chat, block })` — "Block user" / "Unblock user"
  (contacts.block, contacts.unblock);
- `peerContact({ chat, add, firstName, lastName, share })` — "Add to
  contacts" with the name typed (contacts.addContact; `share` lets them
  see our phone number) / "Delete contact" (contacts.deleteContacts);
- `peerReport({ chat, option, message, ids })` — "Report" as layer 225
  has it (messages.report on the whole chat, or — with `ids`, up to a
  hundred message ids of the chat, R-Y175 — on those messages): the first
  call, with no option, answers `{ result: 'choose', title, options:
  [{ text, option }] }`; a call with a chosen `option` (base64 of its
  bytes) answers `choose` again (a narrower list), `comment` (Telegram
  asks for words: `optional`, `option`) or `reported`; the comment comes
  back in `message`;
- `peerReportSpam({ chat })` — "Report spam" on a stranger's chat
  (messages.reportSpam).
The bar over a chat with a stranger (R-Y137):
- `peerSettings({ chat })` — what Telegram offers there
  (messages.getPeerSettings) → `{ ok, bar: { reportSpam, addContact,
  blockContact, shareContact, autoarchived, registered, country } }`;
- `peerHideBar({ chat })` — the bar's × (messages.hidePeerSettingsBar);
- `peerShareContact({ chat })` — "Share my phone number"
  (contacts.acceptContact).
Telegram's errors become codes the page shows as text.

**Exports**

- `bytesOf`
- `createPeerActions`
- `inputUserOf`
- `shapeReport`

## `js/src/sources/telegram-peers.js`

Where each Telegram chat is, kept in the store (R-Y34): the input peer
Telegram needs to be asked about a chat (its id and access hash), and
what kind of chat it is, as `peer:telegram:<chat>` links.

GramJS knows a chat only after it has seen it in an answer; after a
restart, asking for a chat by its bare id made it look the chat up
(`getEntity`) or list the dialogs again — a request more for every
chat read. With the peer stored, reading a chat is one request, and
the chat list is asked for only to read the chat list.

**Exports**

- `createPeers`
- `peerLinkId`
- `peerRecord`

## `js/src/sources/telegram-phone-change.js`

Change phone number, as Telegram Desktop's Settings → My Account has it
(R-Y212; learned, never copied):
- `phoneChangeSend({ phone })` — account.sendChangePhoneCode with the
  default CodeSettings → `{ ok, phoneCodeHash, length, timeout }`; the
  code goes to the new number;
- `phoneChangeConfirm({ phone, phoneCodeHash, code })` —
  account.changePhone → `{ ok, phone }`, the number the account has now.
Telegram's errors (PHONE_NUMBER_OCCUPIED, PHONE_CODE_INVALID, …) become
codes the page shows as text. The code is never logged or kept.

**Exports**

- `CODE`
- `PHONE`
- `createPhoneChange`

## `js/src/sources/telegram-pinned-list.js`

A chat's pinned messages as a list, and "Unpin all", as Telegram
Desktop has them (R-Y166; learned, never copied):
- `pinnedList({ chat, topMsgId?, offsetId? })` — the chat's pinned
  messages (messages.search with InputMessagesFilterPinned), newest
  first, a page at a time → `{ ok, messages, count, next }`: the messages
  as the history's links, `count` how many Telegram says are pinned,
  `next` the id to ask again with (null at the end). `topMsgId` is a
  forum topic's id.
- `unpinAll({ chat, topMsgId? })` — every pinned message (in the topic)
  unpinned (messages.unpinAllMessages, asked again while Telegram says
  there is more) → `{ ok }`.
Telegram's errors become codes the page shows as text.

**Exports**

- `PINNED_PAGE`
- `createPinnedList`
- `validPinnedRequest`

## `js/src/sources/telegram-pinned-order.js`

Reordering the pinned chats, as Telegram Desktop lets the user drag
them (R-Y159; learned, never copied):

- `reorderPinned({ folder, chats })` — messages.reorderPinnedDialogs
  with `force`, for the main list (folder 0) or the Archive (folder 1);
  `chats` are all the pinned chats of that folder, first on top. A
  chat Telegram has pinned there that the request leaves out is added
  at the end, so `force` never unpins one by accident. Telegram's
  answer is then written as the update the other devices get, through
  the live handler, so the list keeps that order (the pinned rank, not
  the date).
Telegram's errors become codes the page shows as text.

**Exports**

- `MAX_PINNED`
- `createPinnedOrder`
- `validOrder`

## `js/src/sources/telegram-polls.js`

Polls and checklists, as Telegram's own apps have them (R-Y74).

- `UpdateMessagePoll` (a vote anywhere, ours too; its effect is in
  ./telegram-updates.js) writes the poll's
  results into the stored message's `raw.media`. Results marked `min`
  carry counts only: what we chose and which answer is right are kept
  from what was stored.
- `vote` (messages.sendVote; no options retracts), `stop` (the poll's
  author closes it: messages.editMessage with the poll `closed`),
  `results` (messages.getPollResults, for a poll on screen: Telegram
  sends a poll's results only to who asks), `votes` (who voted for
  what in a public poll: messages.getPollVotes) and `toggleTodo`
  (messages.toggleTodoCompleted).

- `sendPoll` (a new poll, R-Y121: messages.sendMedia with InputMediaPoll; its
  answers as InputPollAnswer, a quiz's right one by its place;
  Telegram's answer goes to the live handler).

- `sendTodo` (a new checklist, R-Y195: the same send path with
  InputMediaTodo) and `appendTodo` (messages.appendTodoList).

An option is bytes; the app and the store name it in base64 (R-Y28).

**Exports**

- `TODO_LIMITS`
- `createPollActions`
- `mergePollResults`
- `pollWriter`

## `js/src/sources/telegram-privacy.js`

Privacy and security of the connected account, as Telegram Desktop's
Settings → Privacy and Security has it (R-Y139; learned, never copied):
- `privacyRules()` — account.getPrivacy for each key → `{ ok, keys:
  [{ key, choice, label, allow, disallow, options }] }`; `choice` is
  `everybody`, `contacts`, `nobody` or `other` (then `label` names it:
  `close-friends`, `premium` or `except-contacts`), `allow` and
  `disallow` count the exceptions (people and chats) and are only
  shown, never edited;
- `setPrivacy({ key, choice })` — account.setPrivacy with the base rule
  of the choice and the existing exceptions KEPT: the users come back
  with their access hashes in the answer to getPrivacy and go out as
  InputUser; the chats go out as the same ids; the bots rules stay. A
  key whose exceptions cannot all be converted is refused
  (`exceptions-unsupported`), never saved with fewer;
- `sessions()` — account.getAuthorizations → `{ ok, ttlDays, sessions }`;
  `terminateSession({ hash })` — account.resetAuthorization (never the
  current session); `terminateOthers()` — auth.resetAuthorizations;
- `blockedUsers({ offset, limit })` — contacts.getBlocked → `{ ok,
  count, items, next }`; `unblockUser({ id, accessHash })` —
  contacts.unblock.
- `defaultTtl()` — messages.getDefaultHistoryTTL → `{ ok, period }`
  (seconds, 0 off); `setDefaultTtl({ period })` —
  messages.setDefaultHistoryTTL, the timer new chats start with
  (R-Y151; the period is one of TTL_PERIODS).
Telegram's errors become codes the page shows as text.

**Exports**

- `CHOICES`
- `PAGE_MAX`
- `PRIVACY_KEYS`
- `choiceOf`
- `createPrivacy`
- `rulesFor`
- `sessionOf`

## `js/src/sources/telegram-private-call.js`

Private (one-to-one) voice calls, as Telegram's clients place and take
them (R-Y196; learned, never copied). Nothing rings, dials or asks for
the microphone by itself: every write below answers a click, except
answering Telegram's own updates (receivedCall, the DH steps).

The call's state machine and its Diffie-Hellman key stay on the server
(./private-call-machine.js, ./private-call-dh.js); the page reads the
view of the call from the link `phonecall:telegram` (streamed like the
other live links) and only ever sees the emoji of the key.

- `privateCallStart({ user, name? })` — "Call" in a private chat's
  header: phone.getCallConfig, messages.getDhConfig, phone.requestCall
  with g_a_hash → `{ ok, callId }`;
- `privateCallAccept({ id })` — Accept: phone.receivedCall already
  answered when it rang; now messages.getDhConfig and phone.acceptCall
  with g_b;
- `privateCallDiscard({ id, reason? })` — Decline / End / ring timeout:
  phone.discardCall with the duration and the reason (hangup, missed,
  busy, disconnect);
- `privateCallRate({ id, rating, comment? })` — phone.setCallRating
  after the call (1 to 5);
- `privateCallState()` — the call's view now or null;
- `phoneCalls.handle(client, effect)` (internal) — UpdatePhoneCall from
  the live handler drives the machine (the update's phoneCallRequested /
  phoneCallWaiting / phoneCallAccepted / phoneCall / phoneCallDiscarded);
  UpdatePhoneCallSignalingData is read and dropped.
Media is not done (see ./private-call-machine.js): the view says
`media: false`, and the PhoneConnectionWebrtc servers are only counted.
Telegram's errors become codes the page shows as text.

**Exports**

- `LINK_ID`
- `apiOf`
- `createPrivateCall`
- `validCallId`
- `validDiscard`
- `validRating`
- `validStart`

## `js/src/sources/telegram-profile-extras.js`

Profile extras, as Telegram Desktop has them (R-Y178; learned, never
copied): a birthday, a name colour and a profile colour (Premium), a
personal channel — the user's own, and other people's on their profiles.
- `profileExtras()` → `{ ok, premium, birthday, color, profileColor,
  personalChannel }` from users.getFullUser of the user; a colour is
  `{ color, emoji }` (the palette index and the background emoji's
  document id as a decimal string) or null, a birthday `{ day, month,
  year? }`, the personal channel `{ chat, title }`.
- `birthdaySave({ day, month, year? } | { remove: true })` —
  account.updateBirthday.
- `colors()` → `{ ok, name, profile }`: help.getPeerColors and
  help.getPeerProfileColors (kept by their hash for the session), each
  option `{ id, colors, dark? }` with `#rrggbb` strings.
- `colorSave({ forProfile, color?, emoji? })` — account.updateColor;
  neither colour nor emoji removes it. Premium only: the code `premium`.
- `personalChannels()` → `{ ok, channels }` — channels.getAdminedPublicChannels
  with `forPersonal`; `personalChannelSave({ chat } | { remove: true })` —
  account.updatePersonalChannel with one of those channels.
- `personalChannelCard({ chat })` → `{ ok, card: null | { chat, title,
  username, members, message } }` — a person's personal channel with its
  latest post (the one UserFull names), read-only.
- `birthdays()` → `{ ok, birthdays: [{ chat, name, day, month, year? }] }`
  — contacts.getBirthdays, the contacts whose birthday is today or soon.
Telegram's errors become codes the page shows as text.

**Exports**

- `BIRTHDAY_DAYS`
- `MAX_COLOR`
- `birthdayOf`
- `colorOf`
- `createProfileExtras`
- `daysUntil`
- `optionsOf`
- `validBirthday`

## `js/src/sources/telegram-profile-music.js`

Music on a profile, as Telegram Desktop shows it (R-Y185; learned, never
copied):
- `savedMusic({ chat, offset? })` — a person's saved songs
  (users.getSavedMusic, a page of 30) → `{ ok, count, mine, tracks: [{ id,
  title, performer, duration, size, name }], next }`; the documents are
  kept by id so a track can be played or removed;
- `musicFile({ id })` — a kept track's audio, downloaded once into the
  app folder (up to 64 MB), for the page's audio player (GET
  /api/telegram/music);
- `messageMusicSave({ chat, message, unsave? })` — a song from a chat's
  audio message added to the user's own profile music (account.saveMusic;
  a WRITE, on a click only); the message is read for a fresh file
  reference first and must be a song, not a voice note;
- `musicRemove({ id })` — one of one's own tracks taken off the profile
  (account.saveMusic with unsave; a WRITE, on a click only).
Telegram's errors become codes the page shows as text.

**Exports**

- `ID`
- `PAGE`
- `createProfileMusic`
- `isSong`
- `trackOf`

## `js/src/sources/telegram-profile-stories.js`

Stories on a profile, as Telegram Desktop shows them (R-Y185; learned,
never copied):
- `profileStories({ chat, album?, offset? })` — a person's or channel's
  pinned stories (stories.getPinnedStories, `offset` the id to go on
  from) or, with `album`, one album's (stories.getAlbumStories, `offset`
  a count); the first page of the pinned ones also names the albums
  (stories.getAlbums) → `{ ok, count, mine, me, stories: [{ …shapeStory,
  pinned, top }], albums: [{ id, title }], next }`;
- `storiesArchive({ offset? })` — one's own archive of expired stories
  (stories.getStoriesArchive), the same story rows;
- `storyPin({ chat, ids, pinned })` — stories shown on or taken off the
  profile (stories.togglePinned; a WRITE, on a click only);
- `storyPinTop({ chat, ids })` — the stories fixed at the top of the
  profile (stories.togglePinnedToTop, up to 3; `[]` clears; a WRITE, on a
  click only).
The pictures and videos are the story viewer's (`storyMedia`).
Telegram's errors become codes the page shows as text.

**Exports**

- `PAGE`
- `TOP_MAX`
- `albumOf`
- `createProfileStories`
- `rowsOf`

## `js/src/sources/telegram-profile.js`

The user's own Telegram profile, as Telegram Desktop's Settings → My
Account has it (R-Y136; learned, never copied):
- `myProfile()` — users.getFullUser of the user → `{ ok, id, firstName,
  lastName, about, username, phone, hasPhoto, aboutMax }` (the bio
  is 70 characters, 140 with Premium);
- `saveProfile({ firstName, lastName, about })` — account.updateProfile
  with only what is given;
- `checkUsername({ username })` → `{ ok, status }`, `status` being
  `available`, `taken` or `invalid` (account.checkUsername);
- `saveUsername({ username })` — account.updateUsername ('' removes it);
- `setProfilePhoto({ token })` — the page's upload as the photo
  (photos.uploadProfilePhoto); `removeProfilePhoto()` —
  photos.deletePhotos with the current photo.
A saved name or username also moves the account the status shows.
Telegram's errors become codes the page shows as text.

**Exports**

- `ABOUT_MAX`
- `ABOUT_MAX_PREMIUM`
- `USERNAME`
- `createProfile`

## `js/src/sources/telegram-proxy.js`

The connection proxy, as Telegram Desktop's Settings → Advanced →
Connection type has it (R-Y192; learned, never copied): direct (the
default), a SOCKS5 proxy (host, port, optional user and password) or
an MTProto proxy (host, port, secret).

- `proxyGet()`   — the saved setting as the page may see it: the kind,
  host, port and user name, and only whether a password or a secret
  is set (`passwordSet`, `secretSet`). Those two are write-only;
- `proxySave(body)` — validated and kept (under `secret:telegram:proxy`
  beside the session, never in it). A password or secret left out
  keeps the saved one (for the same host only); an empty password clears it. The connection is
  then dropped and opened again through the existing reopen path, so
  the new proxy is used at once (if reopening fails, the next poll
  opens it, still through the new proxy);
- `proxyCheck({host, port})` — a short TCP connect to the proxy's
  address (the user's own action), its answer `{reachable, ms}`. The
  probe is injected (`env.proxyProbe`) so tests never open a socket.

Neither the password nor the secret is ever logged, returned or put in
an error. GramJS takes the proxy in `proxyOptions` form (see
`gramjsClientFactory`). Voice and video calls are set up through
Telegram's own relays by the page, not this client, so there is no
"use proxy for calls" switch.

**Exports**

- `KINDS`
- `PROXY_ID`
- `createProxy`
- `portOf`
- `proxyOptions`
- `publicProxy`
- `readProxy`
- `secretOf`
- `tcpProbe`
- `validHost`
- `validateProxy`

## `js/src/sources/telegram-qr-login.js`

Sign in to Telegram by QR code, as Telegram Desktop offers it (R-Y203;
learned, never copied): the page shows `tg://login?token=<base64url>`
as a QR code, the user opens Telegram on the phone, Settings > Devices >
Link Desktop Device, and points the phone at the screen.

The flow over MTProto:
  auth.exportLoginToken { api_id, api_hash, except_ids: [] }
    -> auth.loginToken { expires, token }   show it; ask again when it
       expires (Desktop refreshes the code too)
    -> auth.loginTokenSuccess               signed in
    -> auth.loginTokenMigrateTo { dc_id, token }
       switch the client to that data centre and call
       auth.importLoginToken { token }, which answers the same way
  updateLoginToken arrives once the phone confirmed: call
  auth.exportLoginToken again for the answer.
  SESSION_PASSWORD_NEEDED (2-Step Verification) goes on to the password
  step, the same one the phone-number sign-in has.

The controller has the shape of the phone sign-in's (`state`, `account`,
`session`, `submitPassword`, `cancel`), so the routes treat both alike.
Never logged or returned except the code's own URL: the token, the
session, the password.

**Exports**

- `loginUrl`
- `startQrLogin`

## `js/src/sources/telegram-quick-reaction.js`

The quick (double-tap) reaction, as Telegram Desktop's Settings → Chat
Settings → Quick reaction (R-Y206; learned, never copied):
- `quickReaction()` — the account's default reaction, read from
  help.getConfig (`reactions_default`) → `{ ok, emoji }`, `emoji` null
  when it is a custom emoji or none (the page then uses its own);
- `quickReactionSet({ emoji })` — a new one (messages.setDefaultReaction),
  remembered at once.
The emoji is a short string, as the chat reactions' are.

**Exports**

- `createQuickReaction`
- `emojiOf`
- `validEmoji`

## `js/src/sources/telegram-quick-replies.js`

Quick replies, as Telegram Desktop's Settings → Telegram Business →
Quick Replies has them (R-Y179; learned, never copied). A shortcut is a
name ("hello") with a few messages kept on Telegram's side; they are
written to the user's own "chat" (InputPeerSelf) with the shortcut named:
- `quickReplies()` — messages.getQuickReplies → `{ ok, replies: [{ id,
  name, count, preview }] }`, in the order Telegram keeps;
- `quickReplyMessages({ shortcutId })` — messages.getQuickReplyMessages →
  `{ ok, messages: [{ id, text, media }] }`;
- `quickReplyCreate({ name, text })` — the shortcut made by sending its
  first message (messages.checkQuickReplyShortcut first) → `{ ok }`;
- `quickReplyAdd({ shortcutId, text })` — messages.sendMessage into it;
- `quickReplyEdit({ shortcutId, id, text })` — messages.editMessage with
  quickReplyShortcutId; `quickReplyDeleteMessages({ shortcutId, ids })`
  — messages.deleteQuickReplyMessages;
- `quickReplyRename({ shortcutId, name })` —
  messages.editQuickReplyShortcut; `quickReplyDelete({ shortcutId })` —
  messages.deleteQuickReplyShortcut; `quickReplyReorder({ order })` —
  messages.reorderQuickReplies;
- `quickReplySend({ chat, shortcutId })` — the shortcut's messages sent
  to a chat (messages.sendQuickReplyMessages), only when asked.
Telegram's refusals (Premium needed, name taken, too many) become codes.

**Exports**

- `NAME`
- `createQuickReplies`
- `quickFailure`

## `js/src/sources/telegram-readers.js`

Who read a message and who reacted to it, as Telegram's apps list them
(R-Y127; learned, never copied):
- `messageReaders({ chat, id })` — in a small group (Telegram decides:
  at most 100 members, the message a day or two old at most), the people
  who read the user's own message and when (messages.
  getMessageReadParticipants) → `{ ok, readers: [{ id, name, date }] }`,
  `date` in ms, the latest first;
- `messageReactors({ chat, id, emoji?, offset? })` — who reacted, with
  which emoji (messages.getMessageReactionsList), a page at a time →
  `{ ok, count, items: [{ peer, name, emoji, customEmojiId, date, my }],
  next }`, `next` the offset of the following page or null.
- `reportReaction({ chat, id, peer })` — an admin reports the reaction
  a member (`peer`, a user id) left on a group message
  (messages.reportReaction; R-Y195) → `{ ok }`.
Telegram's errors (MSG_TOO_OLD, CHAT_TOO_BIG…) become codes the page
shows as text.

**Exports**

- `createReadersActions`

## `js/src/sources/telegram-repair.js`

One-time repairs of Telegram messages already in the store, each run
once (its marker link says it ran) when the account starts.

`senders-v1`: a message read raw — from an update or a channel's
difference — was stored with its chat as its sender, because GramJS
fills `senderId` only for the messages it builds itself. Its author is
in `raw.fromId` (R-Y28 kept it): the sender is set from there, and the
name from that person's other messages, so a group shows who wrote
what again.

**Exports**

- `nameForwards`
- `repairSenders`
- `rereadUnsupported`

## `js/src/sources/telegram-request-peer.js`

A bot asking for a chat or a person, and a chat's recent places, as
Telegram Desktop has them (R-Y208; learned, never copied):
- `requestPeerCandidates({ type })` — the chats and people the bot's
  "request peer" keyboard button may be answered with: only those that
  satisfy the button's constraints. `type` is `{ kind: 'user' | 'chat' |
  'broadcast', bot?, premium?, creator?, hasUsername?, forum?,
  userAdminRights?: [right names] }` (booleans as the button gave them;
  unset means any). The check runs here, on the entities Telegram sent
  (the user's rights in a chat), never on the page → `{ ok, candidates:
  [{ id, name, username }] }`. What only the bot can fulfil (that it is
  a member, the rights it will get) is left to Telegram;
- `sendRequestedPeers({ chat, msgId, buttonId, peers })` — the answer
  (messages.sendBotRequestedPeer) with the chosen ids as input peers;
- `recentLocations({ chat })` — the places shared in a chat lately
  (messages.getRecentLocations) → `{ ok, places: [{ id, lat, lon, date,
  title, address }] }`, newest first.

**Exports**

- `createRequestPeer`
- `placeOf`
- `satisfies`
- `validPeers`
- `validType`

## `js/src/sources/telegram-ringtones.js`

Notification sounds, as Telegram Desktop's "Sound" in a chat's
notifications has them (R-Y181; learned, never copied):

- `ringtoneList()` — the account's saved ringtones
  (account.getSavedRingtones) → `{ ok, ringtones: [{ id, title,
  duration, size }], limits: { sizeBytes, seconds, count } }`;
- `ringtoneAdd({ token })` — the page's upload (R-Y99) sent as a new
  ringtone (account.uploadRingtone, then account.saveRingtone) →
  `{ ok, ringtone }`; Telegram takes a short, small audio file;
- `ringtoneRemove({ id })` — account.saveRingtone with unsave;
- `ringtoneFile({ id })` — a saved ringtone's audio, downloaded once
  into the app folder, for the page to play when a notification shows.
Telegram's errors become codes the page shows as text. The sound of one
chat is set with that chat's notification settings
(./telegram-notify-settings.js).

**Exports**

- `ID`
- `LIMITS`
- `createRingtones`
- `mimeOfName`
- `ringtoneRow`

## `js/src/sources/telegram-round.js`

**Exports**

- `MAX_ROUND_SECONDS`
- `MAX_ROUND_SIDE`
- `roundAttribute`
- `roundFileOf`
- `roundMime`
- `roundOptions`

## `js/src/sources/telegram-saved-tags.js`

Reaction tags of Saved Messages, as Telegram Desktop has them (R-Y151;
learned, never copied): a saved message tagged with a reaction can be
found by it, and Premium accounts name the tags.
- `savedTags()` — messages.getSavedReactionTags → `{ ok, premium, tags:
  [{ reaction, title, count }] }`; a `reaction` is `{ emoji }` or
  `{ custom }` (a custom emoji's document id); `premium` says the
  account may rename tags;
- `savedTagSearch({ chat, reaction, offsetId? })` — the saved messages
  with that reaction (messages.search in the account's own chat,
  savedReaction, no filter), a page of 50, as the page's message links
  of the Saved Messages chat `chat`, oldest first → `{ ok, messages,
  more }`;
- `savedTagRename({ reaction, title })` — messages.updateSavedReactionTag
  (an empty title removes the name; at most TITLE_MAX characters;
  Premium only).
Telegram's errors become codes the page shows as text.

**Exports**

- `TAG_PAGE`
- `TITLE_MAX`
- `createSavedTags`
- `tagsOf`
- `validReaction`

## `js/src/sources/telegram-scheduled.js`

Scheduled messages, as Telegram's apps keep them (R-Y102; Telegram
Desktop's "Schedule message" and its scheduled messages section,
learned, never copied).

A message sent with a `schedule_date` is not in the chat: Telegram
holds it and sends it then (the chat gets it as a new message). The
chat's scheduled ones are listed apart:

- `scheduledList({ chat })` — messages.getScheduledHistory, as links
  (`sched:telegram:<chat>:<id>`, the time it goes as their time), the
  soonest first. Kept a little while, so opening a chat again does not
  ask again; anything done to them here asks afresh.
- `scheduledSendNow({ chat, ids })` — messages.sendScheduledMessages:
  sent at once (they come into the chat as new messages).
- `scheduledDelete({ chat, ids })` — messages.deleteScheduledMessages.
- `scheduledReschedule({ chat, id, date })` — messages.editMessage with
  a new schedule_date.

"Send when online" (R-Y197): `schedule_date` 0x7FFFFFFE, which
Telegram's clients use for a message held until the other person is
next online; the list shows it as "When online", not as a date.

**Exports**

- `MAX_AHEAD_S`
- `MAX_SCHEDULED_IDS`
- `MIN_AHEAD_S`
- `WHEN_ONLINE`
- `createScheduled`
- `scheduledId`
- `validSchedule`

## `js/src/sources/telegram-search.js`

Search in one chat, as Telegram's apps do it (R-Y98): Telegram is
asked (messages.search through GramJS's getMessages, the chat's every message, not only those the
page holds), newest first, a page at a time; the messages found are
stored as any read ones are, so the chat can show them at once.

`searchChat({ chat, q, offsetId? })` → `{ ids, count, more }`: the
network ids found (newest first), how many Telegram counts in all,
and whether there are older ones (ask again with the last id). With
`links: true` (a hashtag's list, R-Y182) it also answers `messages`
(the found ones as links) and `cursor` (the last id, when there is more).

**Exports**

- `MAX_QUERY`
- `SEARCH_PAGE`
- `createChatSearch`

## `js/src/sources/telegram-security-extras.js`

More of Settings → Privacy and Security (R-Y218; learned, never copied):
- `loginEmailSend({ email })` — account.sendVerifyEmailCode with the
  purpose "login change" → `{ ok, pattern, length }`;
  `loginEmailVerify({ code })` — account.verifyEmail → `{ ok, email }`;
- `recoveryRequest()` — auth.requestPasswordRecovery (the recovery email
  gets a code) → `{ ok, pattern }`; `recoveryConfirm({ code })` —
  auth.recoverPassword with no new settings: the password is removed;
- `passwordReset()` — account.resetPassword → `{ ok, result: 'ok' |
  'wait' | 'failed-wait', until }`; `passwordResetCancel()` —
  account.declinePasswordReset;
- `passkeys()` — account.getPasskeys; `passkeyOptions()` —
  account.initPasskeyRegistration → `{ ok, options }` (WebAuthn JSON);
  `passkeyRegister({ id, rawId, clientData, attestation })` —
  account.registerPasskey (attestation in base64url);
  `passkeyDelete({ id })` — account.deletePasskey;
- `signInCodes()` — the login codes Telegram's service account (777000)
  sent in the last few minutes; `invalidateCodes({ codes })` —
  account.invalidateSignInCodes, asked when the user shares such a code.
A code is never logged or put in an error. Telegram's errors become codes;
a change whose answer never came is `send-unknown` (./telegram-write-outcome.js).

**Exports**

- `FRESH_SECONDS`
- `SERVICE_ID`
- `codesIn`
- `createSecurityExtras`
- `freshCodes`

## `js/src/sources/telegram-security.js`

The security extras of Settings → Privacy and Security (R-Y177; learned,
never copied):
- `securityState()` — account.getPassword + account.getAccountTTL +
  account.getContentSettings → `{ ok, password: { has, hint, hasRecovery,
  emailPending, emailPattern, resetPending }, accountTtlDays, content: {
  enabled, canChange } }`; a part Telegram refuses is `null`, all of them
  refused is an error;
- `setPassword({ current?, password, hint, email? })` — the two-step
  verification set or changed: account.updatePasswordSettings with the
  check and the digest made by the `telegram` package's own SRP helper
  (`computeCheck`, `computeDigest`); a recovery email Telegram must
  confirm answers `{ ok: false, code: 'email-unconfirmed', codeLength }`;
- `removePassword({ current })` — the same call with an empty digest;
- `confirmPasswordEmail({ code })`, `resendPasswordEmail()`,
  `cancelPasswordEmail()` — account.confirmPasswordEmail / resend / cancel;
- `setAccountTtl({ days })` — account.setAccountTTL (30, 90, 180, 365, 548, 730; R-Y212);
- `setSensitive({ enabled })` — account.setContentSettings, only when
  Telegram says it can be changed;
- `setSessionSettings({ hash, secretChats, calls })` —
  account.changeAuthorizationSettings; `setSessionTtl({ days })` —
  account.setAuthorizationTTL.
Passwords and codes live only in the request in memory: never logged,
stored, put in an error or returned. Telegram's errors become codes.

**Exports**

- `ACCOUNT_TTL_DAYS`
- `HINT_MAX`
- `PASSWORD_MAX`
- `SESSION_TTL_DAYS`
- `createSecurity`

## `js/src/sources/telegram-send-as-client.js`

**Exports**

- `PAID_STARS_MAX`
- `inputOf`
- `paidField`
- `rememberInputs`
- `validPaidStars`
- `validSendAs`
- `withSendAs`

## `js/src/sources/telegram-send-as.js`

"Send as", as Telegram Desktop has it (R-Y141; learned, never copied):
in a supergroup (and a channel's discussion group) the small avatar
button left of the box chooses which identity sends.
- `sendAsList({ chat })` — who may send in the chat (channels.getSendAs)
  and who does by default (channels.getFullChannel → defaultSendAs, else
  the user) → `{ ok, current, peers: [{ id, kind, name, username?,
  count?, premium? }], premium }`; kept per chat for a few minutes.
  `kind` is `user`, `channel` or `group`; `premium` on a peer says
  Premium is required to send as it, `premium` on the answer that the
  user has it;
- `sendAsSave({ chat, sendAs })` — the choice kept by Telegram
  (messages.saveDefaultSendAs).
`withSendAs(env, client, id)` is what every send path uses: the client
whose send requests (messages.sendMessage, sendMedia, sendMultiMedia,
sendInlineBotResult — also those GramJS builds inside sendFile) carry
`send_as`. Telegram's refusals become codes the page shows as text.

**Exports**

- `createSendAs`

## `js/src/sources/telegram-send.js`

Sending as the user (MTProto), the way Telegram's own apps do it.

  - Exactly once: every message carries a `random_id`. Telegram drops a
    second request with the same one (RANDOM_ID_DUPLICATE), so a retry
    after a lost answer never posts twice. It is derived from the
    composer's `clientId`, so a retry of the same draft reuses it.
  - Formatting as Telegram Desktop's: `**bold**`, `__italic__`,
    `~~strike~~`, `||spoiler||`, `` `code` ``, ```` ```pre``` ```` and
    `[text](link)` go as entities (./telegram-format.js); a lone `*` or
    `_` stays as typed.
  - Long text is split at Telegram's limit (`message_length_max` from
    the server's config, 4096 by default; UTF-16 units, like JS
    strings), on a line or word break when there is one, never inside
    an emoji, and sent in order.
  - Sending clears the chat's cloud draft (`clear_draft`), as Telegram
    Desktop always does.
  - "Send without sound" (`silent`) and "Schedule message"
    (`schedule_date`), as Desktop's Send button menu (R-Y102).
  - Telegram's errors become codes the composer can explain.

**Exports**

- `DICE`
- `MAX_MESSAGE_LENGTH`
- `diceOf`
- `formattedParts`
- `longOf`
- `previewMedia`
- `randomIdOf`
- `replyHeader`
- `sendError`
- `sendText`
- `splitMessage`
- `splitRanges`
- `withEffect`

## `js/src/sources/telegram-service-names.js`

Who a service message names (R-Y221; learned, never copied). A service
message holds only ids ("added 4711"); the names come in the same
answer from Telegram, in the message's entity map. `actionNamesOf`
reads that map for every person or chat the action names and gives
`{ <peer id>: { name, self } }` — a user by its id, a group by `-id`,
a channel by `-100id` — which the page words as "Ann added Bob" or
"Ann added you". It is kept with the message's `raw` as `actionNames`.

**Exports**

- `actionNamesOf`

## `js/src/sources/telegram-share-media.js`

Sharing a place and a contact from the composer, as Telegram's apps do
(R-Y142; learned, never copied):
- `sendLocation({ chat, lat, lon, accuracy?, live?, replyTo?, clientId?,
  silent?, scheduleDate? })` — a place (messages.sendMedia with
  InputMediaGeoPoint, InputGeoPoint lat/long/accuracyRadius) or, with
  `live` (900, 3600 or 28800 seconds), a live location
  (InputMediaGeoLive with that period) → `{ ok, chat }`;
- `stopLiveLocation({ chat, id })` — "Stop sharing" for our own live
  location message (messages.editMessage with InputMediaGeoLive
  `stopped`, its point taken from the stored message) → `{ ok }`;
- `sendContact({ chat, contact | firstName, lastName, phone, ... })` —
  a contact card (InputMediaContact, vcard ''). A picked `contact` is
  one of the account's contacts (contacts.getContacts) and its phone is
  read here, never taken from the page; a typed card carries its own
  validated phone → `{ ok, chat }`.
- `updateLiveLocation({ chat, id, lat, lon, accuracy?, heading? })` — the
  moving point of our own live location (messages.editMessage with
  InputMediaGeoLive, the new InputGeoPoint and `heading` 1..360; R-Y147),
  with `proximity` (metres, 1..100000) also the radius of "Notify when
  nearby" (proximity_notification_radius; R-Y197)
  → `{ ok }`. A place and a contact take `sendAs` (a peer id): sent as
  that identity in a supergroup (R-Y147).
Telegram's answer goes through the live handler. Errors become codes.

**Exports**

- `LIVE_PERIODS`
- `MAX_ACCURACY`
- `MAX_PROXIMITY`
- `cleanPhone`
- `createShareMedia`
- `validPoint`

## `js/src/sources/telegram-shared.js`

A chat's shared media, as the profile column of Telegram's apps lists
it (R-Y111): how many photos, videos, files, music, links, voice
messages and GIFs the chat has (messages.getSearchCounters), and each
kind's messages, newest first, a page at a time (messages.search with
the kind's filter, through GramJS's getMessages); the messages read
are stored as any read ones are.

`sharedCounts({ chat })` → `{ ok, counts: { photos, … } }`;
`sharedMedia({ chat, kind, offsetId? })` → `{ ok, messages, count,
more, last }`: the messages as links, how many Telegram counts, whether
older ones remain (ask again with `last`).

**Exports**

- `SHARED_KINDS`
- `SHARED_PAGE`
- `createSharedMedia`

## `js/src/sources/telegram-similar-channels.js`

Similar channels, as Telegram Desktop shows them in a channel's info
(R-Y166; learned, never copied):
- `similarChannels({ chat })` — the channels Telegram recommends beside
  a channel (channels.getChannelRecommendations) → `{ ok, channels:
  [{ chat (-100…), title, username, members, broadcast }] }`. Read only.
- `similarJoin({ chat })` — joins a channel (channels.joinChannel); only
  ever asked for by the explicit Join click on a channel's preview →
  `{ ok, chat }`.
Answers are kept five minutes by channel. Errors become codes.

**Exports**

- `createSimilarChannels`
- `similarOf`

## `js/src/sources/telegram-stars.js`

Telegram Stars, as Telegram Desktop shows them (R-Y176; learned, never
copied). Buying Stars is not here: they are bought in the official apps.
- `starsStatus()` — payments.getStarsStatus for the user's own peer →
  `{ ok, balance }`;
- `starsHistory({ filter?, offset? })` — payments.getStarsTransactions
  (`filter` all, in or out; a page of 30) → `{ ok, balance,
  transactions: [{ id, amount (signed), date, title, description, kind,
  source: { kind, name }, refund, pending, failed }], next }`;
- `starGifts({ chat, offset? })` — payments.getSavedStarGifts of a person
  (a page of 24) → `{ ok, count, mine, gifts: [{ msgId, savedId, from,
  fromName, anonymous, date, stars, title, text, hidden, sticker }], next
  }`; each `sticker` is the sticker panel's item (the sticker renderer
  draws it by id, see telegram-stickers.js);
- `starGiftSave({ chat, msgId, unsave })` — payments.saveStarGift: shows
  a gift on the profile or hides it (a WRITE, on a click only);
- `paidReaction({ chat, id, count })` — messages.sendPaidReaction with a
  random id (a WRITE, on the dialog's Send only), 1..PAID_REACTION_MAX;
- `paidMediaUnlock({ chat, id, stars })` — payments.getPaymentForm with
  InputInvoiceMessage, then payments.sendStarsForm with that form id, only
  when the form's price is the `stars` the page showed (a WRITE, on the
  confirmation only); the message is read again after.
Telegram's errors become codes the page shows as text.

**Exports**

- `GIFTS_PAGE`
- `HISTORY_PAGE`
- `PAID_REACTION_MAX`
- `amountOf`
- `createStars`
- `entitiesOf`
- `formPrice`
- `giftsOf`
- `nameOf`
- `peerEntity`
- `sourceOf`
- `transactionsOf`

## `js/src/sources/telegram-stats-more.js`

The rest of Telegram Desktop's statistics views (R-Y195; learned, never
copied), added to the actions of ./telegram-stats.js:
- `messageStats({ chat, id })` — a channel post's views and reactions
  graphs (stats.getMessageStats) → `{ ok, graphs: [{ key, graph }] }`;
- `publicForwards({ chat, id, offset? })` — the public channels that
  shared the post, a page at a time (stats.getMessagePublicForwards) →
  `{ ok, count, items: [{ kind, name, chat?, id?, username?, views?,
  date? }], next }`, `next` the offset of the following page or null;
- `starsRevenue({ chat })` — the Stars a channel (-100…) or a bot (a user
  id) earned: the revenue graph, the balances and the USD rate
  (payments.getStarsRevenueStats) → `{ ok, graph, topHours?, status:
  { current, available, overall, withdrawalEnabled }, usdRate }`; the
  graph may come as a token (`stats.loadAsyncGraph`, the stats-graph
  route). Withdrawing is not offered here.
Read-only. Telegram's errors become codes the page shows as text.

**Exports**

- `FORWARDS_PAGE`
- `createStatsMore`
- `starsOf`

## `js/src/sources/telegram-stats.js`

Statistics of a channel or a big supergroup, as Telegram Desktop's
"Statistics" shows them to its admins (R-Y167; learned, never copied):
- `chatStats({ chat })` — a channel's overview (followers, views, shares
  and reactions per post, enabled notifications), its graphs and its
  recent posts (stats.getBroadcastStats), or a supergroup's overview
  (members, messages, viewing and posting members), graphs, top posters,
  top admins and top inviters (stats.getMegagroupStats) →
  `{ ok, kind: 'broadcast' | 'megagroup', period: { from, to },
  overview: [{ key, current, previous }], notifications?: { part, total },
  graphs: [{ key, graph }], posts?, posters?, admins?, inviters? }`.
- `statsGraph({ chat, token, x? })` — a graph Telegram sent as a token,
  or the zoomed one (stats.loadAsyncGraph; `x` the clicked point, ms)
  → `{ ok, graph }`.
A `graph` is `{ json, zoom? }` (Telegram's chart JSON as text, `zoom` the
token that zooms into a day), `{ token }` (to load) or `{ error }`.

Statistics live on the DC the full channel names (`stats_dc`). GramJS
sends a request to another DC through `client.invoke(request, dcId)`
(a borrowed sender, authorised by exporting the account's key); the DC
is learned from channels.getFullChannel, kept by chat, and when Telegram
still answers STATS_MIGRATE_X the request is asked again on DC X.
R-Y195 adds a post's statistics, public shares and Stars revenue
(./telegram-stats-more.js), and `statsGraph` also takes a bot's id.
Read-only. Telegram's errors become codes the page shows as text.

**Exports**

- `MAX_TOKEN`
- `POSTS_SHOWN`
- `createStats`
- `graphOf`

## `js/src/sources/telegram-sticker-search.js`

Searching stickers and GIFs from the panel by the message box, as
Telegram Desktop's (R-Y112; learned, never copied):

- `stickerSearch({ q, lang })` — an emoji finds the stickers Telegram
  has for it (messages.getStickers); words find stickers by their
  keywords (messages.searchStickers) and sticker sets by name, the
  user's or not (messages.searchStickerSets), each set's stickers
  then asked as any set's are;
- `gifSearch({ q, offset })` — GIFs found by Telegram's @gif bot
  (messages.getInlineBotResults), a page at a time, as Telegram's
  apps search them.

What is found is kept ten minutes and may be sent as the panel's own
(the documents named by id); an expired file reference asks the
search again. Nothing is sent to the bot but the words searched.

**Exports**

- `createStickerSearch`
- `isEmojiQuery`

## `js/src/sources/telegram-sticker-sets.js`

The user's sticker and custom emoji sets, as Telegram Desktop's
Settings → Stickers and emoji manages them (R-Y169; learned, never
copied):
- `setsList({ emojis })` — the installed sets in the user's order
  (messages.getAllStickers, or getEmojiStickers for emoji sets) →
  `{ ok, sets: [{ id, title, count, format, emoji, official }] }`;
- `setsReorder({ ids, emojis })` — a new order (messages.reorderStickerSets);
- `setArchive({ id })` — a set archived (messages.installStickerSet with
  archived), `setRemove({ id })` — removed (uninstallStickerSet),
  `setAdd({ id })` — an archived set installed again;
- `archivedList({ emojis, offsetId, limit })` — the archived sets, a page
  at a time (messages.getArchivedStickers) → `{ ok, count, sets, next }`.
Only sets this list (or the panel) showed may be named, by id. The
panel's lists are asked again after every change. Telegram's errors
become codes the page shows as text.

**Exports**

- `MAX_PAGE`
- `MAX_SETS`
- `SET_ID`
- `createStickerSets`
- `orderOf`
- `settingsSet`

## `js/src/sources/telegram-sticker-trending.js`

Trending stickers and the other extras of the sticker panel, as
Telegram Desktop offers them (R-Y206; learned, never copied):
- `featuredStickers({ emojis, old, offset, limit })` — the trending
  sticker sets (messages.getFeaturedStickers), further ones a page at a
  time (getOldFeaturedStickers), or the trending custom emoji sets
  (getFeaturedEmojiStickers) → `{ ok, count, sets, unread, next }`; each
  set is `{ id, title, count, format, emoji, installed, unread }`;
- `featuredRead({ ids })` — sets seen in the list
  (messages.readFeaturedStickers), so they lose their "new" mark;
- `recentStickersClear()` — "Clear recent stickers"
  (messages.clearRecentStickers);
- `attachedStickers({ chat, id })` — the sticker sets used in a photo
  or video of a stored message (messages.getAttachedStickers).
The sets are learned by the sticker module, so their stickers are asked
as any set's, and Add installs them as the panel's Add does. Telegram's
errors become codes the page shows as text.

**Exports**

- `MAX_PAGE`
- `MAX_READ`
- `SET_ID`
- `createStickerTrending`
- `stickeredOf`

## `js/src/sources/telegram-stickers.js`

Stickers and saved GIFs for the panel by the message box, as Telegram
Desktop's (R-Y105; learned, never copied):

- `stickerPanel({ fresh })` — the user's sticker sets
  (messages.getAllStickers), recently sent (getRecentStickers) and
  favourite ones (getFavedStickers);
- `stickerSet({ id })` — one set's stickers (getStickerSet), asked
  when the panel comes to it;
- `savedGifs({ fresh })` — the saved GIFs (getSavedGifs);
- `stickerPicture({ id | set, full })` — what the panel shows: a
  still sticker itself, else a sticker's or GIF's thumbnail, a set's
  own picture; `full` a video sticker's or GIF's video, or an
  animated sticker's animation (R-Y113), to play while on screen.
  Each downloaded once into the app folder;
- `stickerSave({ id, action })` — the panel's menu (R-Y115): a sticker
  made a favourite or not (messages.faveSticker), taken from the recent
  ones (saveRecentSticker), a GIF saved or not (saveGif);
- `stickerSetInstall({ id, install })` — a set found by a search added
  to the user's (messages.installStickerSet, R-Y116), or one of theirs
  removed (uninstallStickerSet);
- `stickerSetBox({ id, accessHash } | { shortName })` — the set a
  sticker in a chat belongs to (messages.getStickerSet, R-Y124), for
  the box a click on it opens: the set, its stickers and whether it is
  the user's. The set and its documents join the lists, so the install
  above and the send below accept them;
- `sendDocument({ chat, id, replyTo, silent, scheduleDate, clientId })`
  — a sticker or GIF sent as it is (messages.sendMedia); Telegram's
  answer goes through the live handler, so it shows in the chat.

The documents the page may name are only those listed here (by id);
an expired file reference asks their list again, then tries once
more. Lists are kept ten minutes, a set an hour.

**Exports**

- `STICKER_SAVES`
- `connect`
- `connected`
- `createStickers`
- `failureOf`
- `formatOf`
- `inputSet`
- `panelItem`
- `panelSet`
- `runIn`
- `sniff`

## `js/src/sources/telegram-storage.js`

Local storage management, as Telegram Desktop's Settings → Advanced →
Manage local storage has it (R-Y215; learned, never copied): the media
the server cached under `<store>/media/telegram`, counted by kind, and
cleared by kind or all at once; an optional size limit and an age limit
applied on a timer and at start, the least recently used files first.

- `storageUsage()` → `{ ok, total: { bytes, files }, kinds: { photos |
  videos | voice | files | stickers | other: { bytes, files } }, chats:
  [{ chat, bytes, files }] (largest first, at most 100), limits: {
  maxGb, olderDays } }`;
- `storageClear({ kind } | { all: true })` → `{ ok, removed: { bytes,
  files } }`;
- `storageLimits()` / `storageLimitsSet({ maxGb, olderDays })` — the
  limits (maxGb 0, 1, 5 or 20; olderDays 0, 7, 30 or 365; 0 is none),
  kept in `<media>/.cache-limits.json`; setting them applies them;
- `storageEnforce()` applies the limits now → `{ ok, removed }`.

Only metadata is read (name, size, times), plus the small `.type` file
the cache keeps beside a download — its mime type — to tell videos and
voice notes from other files. Only regular files inside the media
folder are counted or removed: a symbolic link is skipped and never
followed, every path is resolved and checked to lie inside the folder
before it is removed, and nothing outside it (the store's database, the
sessions, the exports) is touched. The kind comes from the folder the
file is in (`stickers`, `custom-emoji`, `avatars`, `wallpapers`, …) or,
in a chat's folder, from the file's name and mime type. The least
recently used is judged by the later of a file's access and change time.

**Exports**

- `KINDS`
- `MAX_GB`
- `OLDER_DAYS`
- `chatOfFile`
- `createStorage`
- `expired`
- `kindOfFile`
- `kindOfMime`
- `limitsFrom`
- `validClear`
- `validLimits`

## `js/src/sources/telegram-stories.js`

Viewing Telegram stories, as Telegram Desktop does (R-Y140; learned,
never copied). Read only — posting a story is not here:
- `stories({ state })` — the strip above the chat list
  (stories.getAllStories, not hidden; `hidden: true` the hidden ones,
  R-Y148): the first call has no `state`;
  a call with the `state` an answer gave asks for the next page
  (`next`). → `{ ok, peers: [{ peer, name, self, count, lastId,
  maxReadId, unread }], state, more }` (`notModified` when Telegram
  says nothing changed); each answer also has `stealth: { activeUntil,
  cooldownUntil }` (stories stealth mode, R-Y199);
- `storiesPeer({ chat })` — one peer's stories to show
  (stories.getPeerStories; the skipped and `min` ones read again with
  stories.getStoriesByID) → `{ ok, peer, stories: [{ id, date, expire,
  caption, entities, media: { kind, duration, w, h }, mine, views,
  reactions, reaction }] }`;
- `storiesRead({ chat, maxId })` — they were seen up to `maxId`
  (stories.readStories);
- `storyMedia({ chat, id })` — a story's picture (the largest size) or
  video, for GET /api/telegram/story: found by stories.getStoriesByID,
  downloaded once into `<media>/stories/<chat>/<id>` and served from
  there afterwards. Media areas, reactions and replies are not here.
Telegram's errors become codes the page shows as text.

**Exports**

- `createStories`
- `entityOf`
- `mediaOf`
- `nameOf`
- `peerId`
- `shapeStealth`
- `shapeStory`
- `storyFile`

## `js/src/sources/telegram-story-actions.js`

What Telegram Desktop lets one do with a story besides watching it
(R-Y148; learned, never copied):
- `storyReply({ chat, id, text })` — "Reply privately…": a message to
  the story's owner that answers the story (messages.sendMessage with
  InputReplyToStory); it shows in the chat through the live handler;
- `storyReact({ chat, id, reaction })` — a reaction to the story
  (stories.sendReaction): an emoji, or `''` to take the reaction back
  (ReactionEmpty);
- `storyViews({ chat, id, offset })` — the viewers of one's own story,
  50 at a time (stories.getStoryViewsList) → `{ ok, count, viewsCount,
  reactionsCount, views: [{ kind, user, name, date, reaction }], next }`;
  `next` is the offset of the following page, '' at the end; `q`,
  `justContacts`, `reactionsFirst`, `forwardsFirst` filter and order the
  list, and a forward or repost of the story is an entry of its own
  (`kind` 'forward' | 'repost', R-Y199);
- `storyDelete({ chat, id })` — one's own story deleted
  (stories.deleteStories);
- `storiesHide({ chat, hidden })` — a peer's stories moved to or from
  the hidden list (stories.togglePeerStoriesHidden).
Telegram's errors become codes the page shows as text.

**Exports**

- `VIEWS_LIMIT`
- `badRequest`
- `createStoryActions`
- `reactionOf`
- `shapeView`
- `storyOk`

## `js/src/sources/telegram-story-extras.js`

The rest of Telegram Desktop's story features (R-Y199; learned, never
copied):
- `storyStealth({ past, future })` — "Stealth mode"
  (stories.activateStealthMode: hide the views of the past five minutes
  and/or of the next twenty-five) → `{ ok, stealth: { activeUntil,
  cooldownUntil } }` (unix seconds, from the UpdateStoriesStealthMode
  the answer carries; null when it carries none). A free account gets
  code `premium`, a cooldown still running `cooldown`;
- `storyReactions({ chat, id, reaction, forwardsFirst, offset })` — the
  viewers' "Reactions" list of one's own story
  (stories.getStoryReactionsList) → `{ ok, count, views: [{ kind, user,
  name, date, reaction }], next }`, a reaction, a public forward or a
  public repost each an entry (`kind` 'view' | 'forward' | 'repost');
- `storyReport({ chat, id, option, message })` — "Report" on someone
  else's story (stories.report), the same walk of reasons as
  peerReport's (ReportResult shaped by the same function);
- `storiesViews({ chat, ids })` — fresh counters of one's own stories
  (stories.getStoriesViews) → `{ ok, stories: [{ id, views, reactions,
  forwards }] }`.
Telegram's errors become codes the page shows as text.

**Exports**

- `createStoryExtras`

## `js/src/sources/telegram-story-manage.js`

Managing one's own stories, as Telegram Desktop does (R-Y210; learned,
never copied). Deleting, the viewers, pinning and the archive are in
./telegram-story-actions.js and ./telegram-profile-stories.js; here:
- `storyEdit({ chat, id, caption?, privacy?, users? })` — a story's
  caption and/or whom it is for (stories.editStory with `caption` +
  `entities`, or `privacyRules`; `privacy` is `everyone`, `contacts`,
  `close-friends` or `selected` with `users` ids of contacts) →
  `{ ok, caption?, entities?, privacy? }`. A caption is markdown, as
  the composer's (./telegram-format.js), sent as text and entities;
- `storyLink({ chat, id })` — the t.me link of a story
  (stories.exportStoryLink) → `{ ok, link }`.
Telegram's errors become codes the page shows as text.

**Exports**

- `createStoryManage`
- `editProblem`

## `js/src/sources/telegram-story-post.js`

Posting a story, as Telegram Desktop does (R-Y156; learned, never
copied):
- `storyCanPost()` — stories.canSendStory for the user (InputPeerSelf)
  → `{ ok: true, remains, premium, me: { id, name }, captionMax }`; when the limit is
  reached Telegram's answer becomes `{ ok: false, code: 'too-many' }`
  (`'premium'` when only Premium may post);
- `storyPost({ token, kind, caption, privacy, users, screenshots,
  pinned, period, duration, width, height })` — the page's upload
  (./telegram-upload.js) sent with stories.sendStory as the user's own
  story: a photo as InputMediaUploadedPhoto, a video as
  InputMediaUploadedDocument with DocumentAttributeVideo (streaming,
  length, size). `privacy` is `everyone`, `contacts`, `close-friends`
  or `selected` (then `users` are ids of contacts); `screenshots`
  false means `noforwards`; `pinned` keeps it on the profile; `period`
  (Premium) is 6, 12, 24 or 48 hours in seconds.
Telegram's errors become codes the page shows as words.

**Exports**

- `CAPTION_MAX`
- `CAPTION_MAX_PREMIUM`
- `MAX_SELECTED`
- `MAX_STORY_SECONDS`
- `PERIODS`
- `PRIVACIES`
- `createStoryPost`
- `inputUsersOf`
- `privacyRules`
- `videoMime`

## `js/src/sources/telegram-top-peers.js`

Frequent contacts, as Telegram Desktop's search shows them when the
query is empty (R-Y207; learned, never copied):
- `topPeers()` — contacts.getTopPeers (correspondents) → `{ ok, enabled,
  peers: [{ chat, name, username, kind }] }`; `enabled` false when the
  user turned the list off.
- `removeTopPeer({ chat })` — contacts.resetTopPeerRating (correspondents).
- `setTopPeers({ enabled })` — contacts.toggleTopPeers.

**Exports**

- `TOP_LIMIT`
- `createTopPeers`
- `peopleOf`

## `js/src/sources/telegram-topic-admin.js`

Managing a forum group's topics, as Telegram Desktop does (R-Y153;
learned, never copied):
- `topicIcons()` — the emoji a topic may carry (the default topic icon
  stickers, messages.getStickerSet) → `{ ok, icons: [{ id, emoji }] }`;
- `createTopic({ chat, title, iconColor, iconEmojiId? })` — a new topic
  (messages.createForumTopic);
- `editTopic({ chat, topic, title?, iconEmojiId?, closed?, hidden? })` —
  rename, change the icon (`'0'` takes it off), close or reopen, hide or
  show General (messages.editForumTopic);
- `pinTopic({ chat, topic, pinned })` — messages.updatePinnedForumTopic;
- `deleteTopic({ chat, topic })` — the topic and its messages
  (messages.deleteTopicHistory, until Telegram has nothing left);
- `reorderTopics({ chat, order })` — the pinned topics in a new order
  (messages.reorderPinnedForumTopics with force, R-Y211);
- `toggleForum({ chat, enabled })` — a supergroup's Topics on or off
  (channels.toggleForum).
Telegram's errors become codes the page shows as text.

**Exports**

- `GENERAL`
- `TITLE_MAX`
- `TOPIC_COLORS`
- `createTopicAdmin`
- `pinOrderOf`

## `js/src/sources/telegram-transcribe.js`

Voice and video note transcription, as Telegram Desktop's "→A" button
has it (R-Y175; learned, never copied):
- `transcribeAudio({ chat, id })` — messages.transcribeAudio on the
  message → `{ ok, transcriptionId, text, pending, trialRemains?,
  trialUntil? }`. While `pending` the text is what is known so far and
  the final one comes as updateTranscribedAudio (`transcriptWriter`
  below keeps it as a `transcript:telegram:<chat>:<id>` link the page
  follows) or by asking again. Non-Premium accounts get a trial: how
  many free ones remain and, when none, the date the next is free;
- `rateTranscription({ chat, id, transcriptionId, good })` —
  messages.rateTranscribedAudio.
Telegram's refusals (Premium needed, the transcription failed, a flood
wait) become codes the page shows as text.

**Exports**

- `createTranscribe`
- `transcriptLinkId`
- `transcriptWriter`

## `js/src/sources/telegram-translate-chat.js`

The translate bar's and the summary's server side (R-Y213; learned,
never copied). Translating a chat's messages is `translateMessages`
(./telegram-translate.js); here are:
- `translateAccount()` — `{ ok, premium }`: whether the account has
  Premium, which the bar needs to offer translating whole chats.
- `summarizeMessage({ chat, id, to? })` — messages.summarizeText of a
  long message → `{ ok, text, entities }` (entities as a stored
  message's). Telegram's refusals become codes the page shows in words.

**Exports**

- `createTranslateChat`

## `js/src/sources/telegram-translate.js`

Translating messages, as Telegram Desktop's "Translate" does (R-Y132;
learned, never copied):
- `translateMessages({ chat, ids, to })` — the messages' texts in the
  language `to` (messages.translateText with the peer and the ids) →
  `{ ok, items: [{ id, text, entities }] }`, the entities by className
  as a stored message's. Answers are kept in memory by chat, id and
  language, so asking again costs nothing.
Telegram's refusals (translations off in the chat, the quota used up,
a language it has not, Premium needed) become codes the page shows as
text.

**Exports**

- `CHAT`
- `CODES`
- `LANG`
- `createTranslate`
- `failure`
- `plainEntity`

## `js/src/sources/telegram-ttl.js`

A chat's auto-delete timer, and Saved Messages grouped by the chat they
came from, as Telegram Desktop has them (R-Y143; learned, never copied):

- `setHistoryTtl({ chat, period })` — the chat's timer
  (messages.setHistoryTTL); `period` is 0 (off) or one of TTL_PERIODS
  in seconds; → `{ ok, period }`;
- `savedDialogs({ offsetDate, offsetId, offsetPeer, limit })` — the
  Saved Messages "as chats" list (messages.getSavedDialogs), newest
  first; → `{ ok, dialogs: [{ peer, name, kind, id, date, preview,
  media, pinned }], next, complete }` where `next` is the cursor for
  the following page (`{ offsetDate, offsetId, offsetPeer }`);
- `savedHistory({ chat, peer, before, limit })` — the messages saved
  from one chat (messages.getSavedHistory), oldest first, as the
  page's message links of the Saved Messages chat `chat`;
- `savedDelete({ peer })` — all of them deleted
  (messages.deleteSavedHistory, repeated while Telegram says more).
Telegram's errors become codes the page shows as text.

**Exports**

- `SAVED_PAGE`
- `TTL_PERIODS`
- `createTtl`

## `js/src/sources/telegram-unread.js`

Unread mentions (@) and reactions (♥) of a chat, as Telegram's apps
lead to them (R-Y55): the counts come with the chat list
(`unreadMentionsCount`, `unreadReactionsCount`, kept on the chat's
`read:` link); the buttons above "down" ask which messages they are
and go to the oldest, one per click.

  marks({ chat, kind })        → { ids } oldest first, the messages
                                 written to the store so the chat can
                                 show them (messages.getUnreadMentions /
                                 getUnreadReactions);
  readMarks({ chat, kind, ids, last })
                               → the shown ones are read (their
                                 contents: messages.readMessageContents),
                                 and on the last one the chat's whole
                                 list (readMentions / readReactions).

Asked through the account's queue at `view` priority: the user is
waiting. Only counts are logged.

**Exports**

- `MARK_KINDS`
- `createUnreadMarks`

## `js/src/sources/telegram-updates.js`

Live Telegram updates (MTProto), as plain effects.

GramJS hands a raw-update handler one update at a time (containers are
already unpacked, each update carrying `_entities`: the users and chats
it mentions, keyed by their marked peer id). This module turns one
update into what the app should do about it, without touching the
store, so it is tested with plain objects:

  { kind: 'message', chat, message, entities }  a new message
  { kind: 'edit', chat, message, entities }     an edited message
  { kind: 'delete', chat, ids }                 deleted (chat null: a
                                                user/basic-group delete,
                                                whose ids are account-wide)
  { kind: 'read', chat, maxId }                 the other side read our
                                                messages up to maxId
  { kind: 'read-inbox', chat, maxId, stillUnread } we read theirs up to
                                                maxId (on any device)
  { kind: 'draft', chat, text, date }           the chat's cloud draft
                                                changed (another device)
  { kind: 'typing', chat, user, typing }        someone types (or stops)
  { kind: 'poll', chat, id, pollId, poll, results }
                                                a poll's results moved
  { kind: 'transcript', chat, id, transcriptionId, text, pending }
                                                a voice or video note's
                                                transcription moved
                                                (R-Y175)
  { kind: 'requests', chat, pending, recent, entities }
                                                people waiting to join the
                                                chat, how many and the
                                                latest ids (R-Y161)

  { kind: 'ephemeral', chat, message, entities }
                                                a bot's message for this
                                                user only, new or edited
                                                (layer 232, R-Y223)
  { kind: 'ephemeral-delete', chat, ids }       such messages deleted

  { kind: 'group-call', chat, id, call }        a voice chat / live stream
                                                started, changed or ended
                                                (call null; chat may be
                                                null: found by id, R-Y188)
  { kind: 'group-call-people', id }             its participants changed
  { kind: 'phone-call', phoneCall, entities }   a private call moved: the
                                                raw PhoneCall for the call
                                                machine (R-Y196)

Chat ids are GramJS "marked" peer ids, the same ones dialogs use: a
user's id, `-<id>` for a basic group, `-100<id>` for a channel or
supergroup.

**Exports**

- `chatKindOf`
- `connectionStateOf`
- `messageSenderId`
- `peerChatId`
- `updateEffect`

## `js/src/sources/telegram-upload.js`

Sending files and photos, as Telegram's apps do it (R-Y99; Telegram
Desktop's "Send as photo / as files", learned, never copied).

Two steps, so a group of photos can go as one album:

- `receiveUpload(stream, { name })` keeps one file the page uploads
  in a temporary folder of its own and answers `{ token, name, size }`;
  a file larger than Telegram takes is refused while it streams.
- `sendFiles({ chat, tokens, caption, asPhoto, group, replyTo })`
  sends them: pictures as photos (compressed, shown in the chat) when
  `asPhoto`, else everything as files; with `group`, photos together go
  as albums of up to ten, files together likewise — as Desktop groups
  them; the caption goes with the first. A picture Telegram will not
  take as a photo (too big, too long) goes as a file instead, as
  Desktop does. What Telegram answers is stored at once; the files are
  removed after.

"Send without sound" and "Schedule message" go with every batch
(R-Y102); scheduled ones are not stored — Telegram holds them. A
message `effect` (R-Y161, a decimal string) goes with the first batch
only (messages.sendMedia / sendMultiMedia carry it).

Captions are formatted as messages are (R-Y101,
./telegram-format.js): GramJS is handed the parsed text and entities
as its parse mode, so an album's caption keeps them too.

A voice message (R-Y108): `sendVoice({ chat, token, duration, waveform,
replyTo })` sends one upload — Ogg Opus, as the page recorded it — as
Telegram's voice note: its length in seconds and its waveform (100
values 0..31, packed five bits each, as Telegram keeps it).

A round video (R-Y150): `sendRound({ chat, token, duration, size,
replyTo })` sends one upload (WebM or MP4) as a video note
(./telegram-round.js).

**Exports**

- `ALBUM_SIZE`
- `MAX_CAPTION`
- `MAX_FILES`
- `MAX_UPLOAD`
- `MAX_VOICE_SECONDS`
- `WAVEFORM_SIZE`
- `batchesOf`
- `createFileSender`
- `isImageName`
- `packWaveform`
- `safeName`

## `js/src/sources/telegram-usernames.js`

Several usernames, as Telegram Desktop's profile and channel settings
show them (R-Y170; learned, never copied). A user or a channel may hold
collectible usernames besides the one edited by hand; each is a Username
(`editable`, `active`). `usernamesOf(list)` is that list as the page
keeps it. The two writes, both only on a click:
- `toggleUsername({ username, active, chat? })` — activate or deactivate
  one (account.toggleUsername; for a channel the user owns,
  channels.toggleUsername);
- `reorderUsernames({ order, chat? })` — the active usernames in a new
  order (account.reorderUsernames / channels.reorderUsernames).
The editable username is changed by the profile and chat editors.

**Exports**

- `CHANNEL`
- `MAX_NAMES`
- `NAME`
- `collectibleOf`
- `createUsernames`
- `usernamesOf`
- `validOrder`

## `js/src/sources/telegram-views.js`

Live counters under channel posts, as Telegram Desktop keeps them
(R-Y182; learned, never copied): a post that is on screen is marked
viewed (the count goes up once), and the counters of the posts shown
are asked again from time to time.
- `messageViews({ chat, ids, increment })` — messages.getMessagesViews
  for up to 100 posts → `{ ok, items: [{ id, views, forwards, replies }] }`
  (a counter Telegram does not send is left out of the item). With
  `increment: true` the posts count as seen by the user; the page does
  that once per post and session.
Errors become codes.

**Exports**

- `MAX_VIEW_IDS`
- `createViews`
- `validViewsRequest`
- `viewsOf`

## `js/src/sources/telegram-voice-chat-live.js`

**Exports**

- `groupCallLinkId`
- `groupCallWriter`

## `js/src/sources/telegram-voice-chat.js`

Voice chats, video chats and live streams of groups and channels, as
Telegram Desktop and the web clients have them (R-Y188; learned, never
copied). The page never joins or unmutes by itself: every write below
answers one click.
- `callInfo({ chat })` — the chat's active call, if any (the full chat's
  `call`, then phone.getGroupCall) → `{ ok, call }`, `call` null or
  `{ id, accessHash, title, count, recent (up to three { id, name }), live (a live stream), scheduleDate
  (seconds), subscribed, joinMuted, canStartVideo, canChangeJoinMuted,
  defaultJoinAs }`;
- `callOpen({ id, accessHash })` — the call and its first participants
  (phone.getGroupCall) → `{ ok, call, participants, next, count }`;
- `callParticipants({ id, accessHash, offset })` — a further page
  (phone.getGroupParticipants);
- `callNotify({ id, accessHash, subscribed })` — "Notify me" for a
  scheduled call (phone.toggleGroupCallStartSubscription);
- `callJoinAs({ chat })` — who may join as (phone.getGroupCallJoinAs);
- `callJoin({ id, accessHash, params, joinAs? })` — joins muted
  (phone.joinGroupCall) with the browser's join params JSON; answers
  `{ ok, connection (Telegram's answer JSON), source }`;
- `callLeave({ id, accessHash, source })` — phone.leaveGroupCall;
- `callSelf({ id, accessHash, muted, raiseHand?, joinAs? })` — our own
  mute or raised hand (phone.editGroupCallParticipant, self only).
Telegram's errors become codes the page shows as text.

**Exports**

- `createVoiceChat`
- `peerKey`
- `shapeCall`
- `shapeParticipant`
- `validCall`
- `validChat`
- `validJoinAs`
- `validParams`

## `js/src/sources/telegram-wallpapers.js`

Chat backgrounds, as Telegram Desktop's "Chat background" has them
(R-Y155; learned, never copied):
- `wallpapers({ fresh })` — the wallpapers Telegram offers
  (account.getWallPapers, hash 0) as `{ ok, wallpapers: [page] }`, kept
  ten minutes; each is an image, a pattern over colours, or colours only;
- `wallpaperFile({ id, slug, size })` — a wallpaper's thumbnail or full
  image, downloaded once through Telegram into the app folder. A pattern
  is a gzipped SVG: unzipped and sanitized here, served as image/svg+xml;
- `setChatWallpaper({ chat, id })` — a wallpaper of the list set for one
  chat (messages.setChatWallPaper, for the user only), the one write.
The choice of the app's own background is the page's, kept on its side.
The documents the page may name are those listed (by id) or, for a
chat's own wallpaper, the one Telegram answers for its slug.

**Exports**

- `ID`
- `SLUG`
- `coloursOf`
- `createWallpapers`
- `hexOf`
- `patternSvg`
- `sanitizeSvg`
- `wallpaperPage`

## `js/src/sources/telegram-web-apps.js`

A bot's mini apps (Web Apps), as Telegram Desktop opens them (R-Y168;
learned from Telegram's public Mini Apps documentation, never copied):
- `webAppOpen({ kind, ... })` asks Telegram for the address the app is
  shown from → `{ ok, url, queryId, fullsize, bot? }`:
    'menu'    the bot's menu button (messages.requestWebView, from the
              bot menu): `chat`, `bot`, `url?`;
    'inline'  an inline keyboard button (messages.requestWebView):
              `chat`, `bot`, `url`;
    'simple'  a reply keyboard button (messages.requestSimpleWebView):
              `bot`, `url`;
    'app'     a t.me/bot/app link (messages.getBotApp, then
              messages.requestAppWebView): `username`, `shortName`,
              `startParam?`, `chat?`;
    'main'    a t.me/bot?startapp link (messages.requestMainWebView):
              `username`, `startParam?`, `chat?`.
  `theme` is the app's colours (theme_params); the platform is 'weba',
  the name Telegram's own web client gives, as this is a web client.
- `webAppProlong({ chat, bot, queryId })` keeps a query alive while the
  app is open (messages.prolongWebView, silent) — the page asks every 60
  seconds;
- `webAppSendData({ bot, text, data })` is a reply-keyboard app's
  `web_app_data_send` (messages.sendWebViewData).
The address Telegram answers must be https without credentials, else
nothing is opened. 'attach' (R-Y201): an attachment-menu bot's app, from
the chat, with no address (messages.requestWebView, not from the bot menu).

**Exports**

- `KINDS`
- `MAX_DATA`
- `MAX_TEXT`
- `MAX_URL`
- `PLATFORM`
- `createWebApps`
- `httpsUrl`
- `startParamOk`
- `themeOf`

## `js/src/sources/telegram-write-outcome.js`

**Exports**

- `UNKNOWN_WRITE`
- `writeFailureOf`

## `js/src/sources/telegram.js`

Telegram source adapter.

`parseArchive` accepts the JSON shape produced by Telegram Desktop's
"Export chat history" feature, both per-chat and all-chats exports.
The live side uses Telegram's Bot API (`getUpdates`, `sendMessage`,
`setMyName`, `setMyDescription`) so a user-provided bot token can
pull incoming bot-visible messages and send queued replies.
Greeting stickers (issue #35) go out through `sendSticker`; packs are
enumerated with `getStickerSet`, and their thumbnails are fetched by
the local server (`fetchFile`) because Bot API file links embed the
bot token and must never reach the browser.

Issue #31 / PR #34: `setTyping` shows the bot's typing status via
`sendChatAction`, and `chatMembers` lists what the Bot API exposes
about a chat's members (see the limitation note on the method).

**Exports**

- `createTelegramBotLive`
- `telegramReactionsFromUpdate`
- `telegramSource`
- `telegramUpdatesToLinks`

## `js/src/sources/topcv.js`

topcv.vn source adapter (R-E13).

TopCV exposes candidate messages only inside its web application
(`/tin-nhan`), so the adapter parses the exported notification dump
and sends resume writes to the TopCV CV plan.

**Exports**

- `topcvSource`

## `js/src/sources/upwork.js`

Upwork source adapter (R-S1..R-S12).

Two surfaces in one file:

  - `upworkSource.parseArchive(input)` ingests:
      * an array of GraphQL nodes / `gh-api`-style payloads,
      * the GDPR-style envelope
        `{ jobs, proposals, contracts, rooms, messages,
           transactions, timeLogs }`,
      * raw CSV strings (Upwork "Reports -> Transaction History").
    Output: one `msg:upwork:<external_id>` link per message, plus
    `job:upwork:*`, `proposal:upwork:*`, `contract:upwork:*`,
    `room:upwork:*`, `transaction:upwork:*`,
    `timelog:upwork:<contract>:<weekStart>` sibling links.

  - `createUpworkLive({ token, fetchImpl, baseUrl, organizationId,
                       operationOverrides })` wraps the Upwork
    GraphQL endpoint with `Authorization: Bearer <PAT>`:
      * `searchJobs({ query, sort, limit })` runs
        `marketplaceJobPostingsSearch`.
      * `pullMessages({ stage, perspective, jobId, contractId,
                       roomId })` walks proposal / contract rooms
        and their messages with Relay-style cursor pagination.
      * `listContracts({ perspective })` paginates the contracts
        connection.
      * `post({ text }, { roomId, contractId })` issues the
        `roomsCreateMessage` mutation.

`softCacheRetention(store, { ttlMs, now })` purges live-pulled
Upwork links whose `cacheTtlMs` has expired (R-S12); archive-only
links are left alone because the user owns those rows.

The adapter is dependency-free — same file works in Bun, Node,
Deno, and the browser.

Several Upwork GraphQL field names are unverified publicly because
the docs portal is gated; defaults document the likely names and
`operationOverrides` lets callers patch any operation without
forking the adapter.

**Exports**

- `createUpworkLive`
- `softCacheRetention`
- `upworkPayloadsToLinks`
- `upworkSource`

## `js/src/sources/vcard.js`

**Exports**

- `MAX_CONTACTS`
- `MAX_VCARD_BYTES`
- `decodeVcard`
- `parseVcard`

## `js/src/sources/vietnamworks.js`

vietnamworks.com source adapter (R-E12).

VietnamWorks keeps candidate–recruiter threads inside its Next.js
application (`/my-jobs`, `/my-profile`) with no public API. The
adapter parses the conversation dump the site mails on request and
routes resume writes through the VietnamWorks CV plan.

**Exports**

- `vietnamworksSource`

## `js/src/sources/vk-auth.js`

VK authorization helpers (issue #32).

Kate Mobile (client_id 2685278) used to be the go-to "borrowed" client
for long-lived VK user tokens with the `messages` right. VK stopped
serving its traffic on 2026-09-08 after the per-account monthly call
limits from the 19.08.2026 platform rules took effect, and VK no longer
grants `messages` to new applications at all (Implicit Flow for user
tokens is disabled since 2024-06-25; only apps that requested the right
earlier keep it). See docs/case-studies/issue-32/ for the evidence.

This module keeps what that research found reusable:

 - `VK_TOKEN_SOURCES`: every client_id listed on vkhost.github.io plus
   VK's own native clients, ranked by who publishes them and by what
   the OAuth gate answered when probed. First-party VK apps rank above
   third-party ones so a user never hands a session to a small,
   unknown publisher when a VK-owned client would do.
 - `classifyVkOAuthGate` / `probeVkOAuthGate`: re-run the unauthenticated
   probe so the catalogue can be refreshed when VK changes something.
 - `decodeVkUserScope`: turn the bitmask from
   `account.getAppPermissions` into scope names.
 - `inspectVkToken` / `describeVkError`: tell a user, using only
   documented read-only methods, whether the token they already hold
   can still read messages, and what a VK error code means for them.

Nothing here logs in, stores a token, or picks a borrowed client by
default: the official routes (data archive, community token, an own
VK ID app) stay the primary path.

**Exports**

- `VK_BLANK_REDIRECT`
- `VK_ERROR_HINTS`
- `VK_OAUTH_GATE_OUTCOMES`
- `VK_OAUTH_HOST`
- `VK_RECOMMENDATIONS`
- `VK_TOKEN_SOURCES`
- `VK_TOKEN_SOURCES_PROBED_AT`
- `VK_USER_SCOPE_BITS`
- `buildVkAuthorizeUrl`
- `classifyVkOAuthGate`
- `decodeVkUserScope`
- `describeVkError`
- `inspectVkToken`
- `probeVkOAuthGate`
- `rankVkTokenSources`
- `vkErrorCode`

## `js/src/sources/vk-hosts.js`

The exact VK hosts the page may load from (R-Z20): one list for the CSP
(`img-src`, `media-src`, ../server/index.js) and for the adapter, so a URL
is only offered to a player when the CSP would let the browser fetch it.
Pictures, audio and video come from VK's CDNs; the captcha picture comes
from the API host. Nothing is framed: a VK video page is a link, never an
iframe.

**Exports**

- `VK_CAPTCHA_HOSTS`
- `VK_IMAGE_HOSTS`
- `VK_MEDIA_HOSTS`
- `cspSources`
- `onHosts`
- `vkCaptchaImage`
- `vkMediaUrl`

## `js/src/sources/vk-html-archive.js`

VK's own "Request your data" archive (R-Z8): `messages/<peer>/messages<N>.html`
pages, 50 messages each. VK ships them as Windows-1251 HTML. The page of
one chat looks like

  <div class="message" data-id="123">
    <div class="message__header"><a href="https://vk.com/id7">Ann Lee</a>, 5 янв 2021 в 12:02:33 (ред.)</div>
    <div>text<div class="kludges"><div class="attachment">
      <div class="attachment__description">Фотография</div>
      <a class="attachment__link" href="https://...">Ссылка</a></div></div></div>
  </div>

This reads such a page into the JSON shape the VK adapter already imports
(`{ conversations: [{ peer, chat_settings, messages }] }`), attachments in
the shape of VK's API so one mapper serves both. The archive has no time
zone; times are read in this machine's time zone, like WhatsApp exports
(R-Z9). A sender known only by name keeps the name.
The pages are tolerant of both Russian and English archives.

**Exports**

- `decodeVkHtml`
- `looksLikeVkHtml`
- `parseVkArchiveDate`
- `parseVkHtmlPage`
- `peerFromArchivePath`

## `js/src/sources/vk-limits.js`

VK request pacing and error handling (R-Z8).

VK allows 3 requests per second per user token and 20 per second per
community token (https://dev.vk.com/en/api/api-requests). A sliding
window lets a short burst through and then waits, so a pull of many
chats never earns error 6 ("too many requests per second"). If VK
answers 6 anyway, the call waits with a growing pause and repeats: error
6 means VK refused before doing anything, so repeating is safe (a send
also carries a `random_id`, which VK de-duplicates). After the last try
the failure is a plain coded error, never a crash.
Captcha (error 14) is never repeated by itself: the user has to solve it.

**Exports**

- `VK_COMMUNITY_RPS`
- `VK_USER_RPS`
- `createRateLimiter`
- `isTooMany`
- `vkApiError`
- `vkRandomId`
- `withTooManyBackoff`

## `js/src/sources/vk-longpoll.js`

VK's official Long Poll (R-Z8), for both kinds of token.

 - A USER token uses `messages.getLongPollServer` (lp_version 3) and the
   URL `https://<server>?act=a_check&key&ts&wait=25&mode=2&version=3`.
   A new (4) or edited (5) message event names a message id; the message is
   then read with `messages.getById` (extended, so senders and chats have
   names). Typing events (61, 62, 63) become `typing` links.
 - A COMMUNITY token uses Bots Long Poll: `groups.getLongPollServer`, then
   `message_new` / `message_edit` / `message_reply` / `message_typing_state`
   events that carry the message itself.
 - `failed` answers follow the VK docs: 1 = events lost, take the `ts` it
   gives; 2 = the key expired, ask for a new key and keep `ts`; 3 = the
   information was lost, ask for key and `ts` again. After 1 and 3 events
   may be missing, so the conversations are read once to catch up.
 - The `ts` cursor is saved (pull-state:vk) only AFTER the messages of that
   batch were written to the store; a failed write leaves it, so the batch
   is read again.
 - In the background loop an error backs off (5 s doubling to 5 min; a
   token VK refuses waits the longest); nothing is thrown out of it.

**Exports**

- `PEOPLE`
- `asList`
- `createVkLongPoll`
- `detectMode`
- `pollUrl`
- `stamp`

## `js/src/sources/vk-older.js`

Scroll-back for a VK chat (R-Z20): when the reader reaches the top the page
asks for the page before its oldest message (`start_message_id` + `offset`
1), through the same paced client as the pulls (./vk-limits.js). Messages
already stored are not written again, and an empty page marks the chat
finished (`history:vk:<peer>`, written after the page was stored), so
nothing asks past the beginning. A captcha (error 14) is thrown to the
page, which asks the user; the same request is then repeated once with
`captcha_sid` and `captcha_key` -- never solved by the program. The same
request made twice at once (two scroll events) is one request to VK.

**Exports**

- `OLDER_PAGE`
- `createVkOlder`
- `vkHistoryId`

## `js/src/sources/vk-sync.js`

Keeping VK current (R-Z8): the "Fetch now" pull, history paging, and the
Long Poll of ./vk-longpoll.js, all through the method API of ./vk.js.

A fetch reads the newest conversations (with names), then pages a few
chats' history back with `messages.getHistory` offsets. The offset of each
chat is saved (pull-state:vk `backfill`) only after that page was stored,
so a failed write is read again, and a finished chat is not read twice.
When the Long Poll is not running, one poll with `wait=0` drains pending
events too. A user token is held to 3 requests a second, a community token
to 20 (./vk-limits.js); error 6 backs off.

`older` (./vk-older.js) is scroll-back for a VK chat (R-Z20).

**Exports**

- `createVkInbox`

## `js/src/sources/vk.js`

VK source adapter (R-E1).

Accepts the JSON shape produced by konard/vk-export. The live side
uses VK's method API (`messages.getConversations`, `messages.getHistory`,
`messages.send`, `status.set`, and `account.saveProfileInfo`) behind
an injectable fetch/baseUrl pair for testability. Greeting stickers
(issue #35) go out through `messages.send` with `sticker_id`, and
`listGreetingStickers` finds them via `store.getStickersKeywords`.

Issue #31 / PR #34: the live side also shows typing status
(`messages.setActivity`, the konard/vk-bot read -> typing -> reply
pacing) and lists audiences automation can target: friends
(`friends.get`), community members (`groups.getMembers`) and chat
members (`messages.getConversationMembers`). `vkTypingFromUpdate`
maps long-poll typing events to `typing` links.

VK moved its developer endpoints to the vk.ru domain in 2025
(api.vk.ru, oauth.vk.ru, dev.vk.ru), so that is the default host;
tokens issued through oauth.vk.com work against either host.

**Exports**

- `VK_API_BASE`
- `VK_API_VERSION`
- `VK_REACTION_EMOJI_TO_ID`
- `createVkLive`
- `vkLinksOf`
- `vkMessageLink`
- `vkReachability`
- `vkSource`
- `vkTypingFromUpdate`

## `js/src/sources/web-uis.js`

The networks' own web apps, as plain data (issue #31, R-Y38).

When a network's API cannot do something — no token, a token that may
not write to this person, an action the API simply does not have
(editing a WhatsApp message, reading LinkedIn messages) — the person
can still do it by hand in the web app. `./browser-sender.js` and
`./browser-actions.js` do exactly that, in the persistent browser
profile where the user signed in once, by following this table.

The selectors are BEST-EFFORT: they were chosen from the current public
markup of each web app and cannot be verified here without a
signed-in account. Every web app ships new markup from time to time,
so the table is plain data — pass a patched copy as
`createBrowserSender({ platforms })` to override any entry without
touching this file. Each selector field may be a comma-separated
candidate list; the first candidate that matches wins.

Entry fields:
- `chatUrl(target, { text })` URL of the conversation;
- `listUrl` the page with the chat list (default `loginUrl`);
- `target({ chat, to })` which draft field addresses the chat;
- `loginUrl` where the user signs in once (persistent profile);
- `loggedIn` / `loggedOut` markers telling the two states apart;
- `composer` the message input;
- `prefill` the chat URL already puts the text into the composer;
- `send` `{ selector, key }`: click the button, else press the key;
- `messages` how to read the visible history (see `extractMessages`);
- `chats` how to read the chat list (see `extractChats`);
- `actions` how to edit, delete, react to and forward one message
  (see ./browser-actions.js): `menu` opens the message's menu
  (`'contextmenu'` — a right click — or a selector of a button inside
  the message, shown on hover), then the menu items.

**Exports**

- `WEB_UIS`

## `js/src/sources/whatsapp-archive.js`

WhatsApp "Export chat" reader (R-Z9).

Reads the `.txt` of a chat export (or the text inside the `.zip` of an
export with media) in the two layouts the apps write:
  Android  `12/10/2026, 14:32 - Alice: hi`   `10/12/26, 2:32 PM - Alice: hi`
  iOS      `[12/10/2026, 14:32:11] Alice: hi`   `[2026-04-30, 2:32:11 PM] ...`
with 12 or 24 hour clocks, a day-first, month-first or year-first date
(found by scanning the whole file, see `detectDateOrder`), messages that
run over several lines, system lines, `<Media omitted>`, `<attached: f>`
and `f (file attached)` lines (mapped to the files of the zip).

An export carries no time zone: it is the phone's local clock, read in
THIS machine's time zone (import on a computer set to the phone's zone);
the stored timestamp is that instant as ISO UTC. Message ids are deterministic (chat id, timestamp,
sender and the index among messages sharing both), so importing a file
twice, or two overlapping exports of one chat, never doubles a message.

Limits, said plainly: an unusual sender name containing ": " is read as
a sender plus text; AM/PM markers and "omitted" words are English only.

**Exports**

- `detectDateOrder`
- `parseWhatsAppArchive`

## `js/src/sources/whatsapp-file.js`

Import one WhatsApp "Export chat" file that arrived as bytes (R-Z9,
R-Z15): the `.txt`, or the `.zip` of an export with media. The text is
parsed by ./whatsapp-archive.js. A zip is written to a private temp file
and read with the streaming reader (./archive/zip-file.js); each file
the chat names (`<attached: f>`, `f (file attached)`) is copied into
`<store>/media/whatsapp/<sha256>.<ext>` (0600) and the attachment gets
`path`, `sha256` and `size`, so the page can show it. Without a
`mediaDir` the names are mapped but no bytes are kept.

**Exports**

- `importWhatsAppFile`
- `importWhatsAppPath`

## `js/src/sources/whatsapp-ids.js`

Stable WhatsApp chat ids (R-Z9).

A chat keeps the same id between pulls and imports:
  - a person: the phone number in E.164, `+491701234567` (from the
    `<digits>@c.us` / `@s.whatsapp.net` JID, or a typed number);
  - a group: its JID, `<digits>-<digits>@g.us` (or `<digits>@g.us`);
  - a linked-id contact (`<digits>@lid`): the JID as it is;
  - ONLY for an archive whose chat is a saved contact name (an export
    file carries no number): `name:<hash of the normalised name>`.
    That id cannot match the Web id of the same person, because the
    file has no number; it is stable between re-imports of the same
    chat name and nothing more.

**Exports**

- `archiveChatId`
- `chatIdOf`
- `chatNameFromFile`
- `parseChatRef`
- `stableHash`
- `toE164`

## `js/src/sources/whatsapp-web-signin.js`

"Sign in to WhatsApp Web" (R-Z9).

WhatsApp Web signs in only by a QR code scanned with the phone. This opens
a VISIBLE browser window on web.whatsapp.com in the very profile
directory the browser sender uses (inside the store, owner only), so the
person scans the QR themselves and the session is then there for the
sender. Nothing is automated or hidden:
  - the QR is never read, clicked, solved or forwarded;
  - the window is never headless;
  - no other browser profile is opened or read.
The page is only watched for the chat list (the signed-in marker of
`WEB_UIS.whatsapp.loggedIn`) to report "signed in".

One window at a time: a browser profile cannot be shared, so after the
sign-in is seen the window closes by itself (a few seconds later, so the
session is written to the profile) and the sender can use the profile.

**Exports**

- `createWhatsAppWebSignIn`
- `profileDirIn`

## `js/src/sources/whatsapp.js`

WhatsApp source adapter (R-E4).

Parses the text of WhatsApp's per-chat "Export chat" (Android and iOS
layouts, see ./whatsapp-archive.js; chat ids, see ./whatsapp-ids.js).

The live adapter targets WhatsApp Cloud API: outbound text messages
go to `/{phone-number-id}/messages`, profile updates go to
`/{phone-number-id}/whatsapp_business_profile`, and inbound reads
normalize webhook payloads because Cloud API delivery is webhook-led.
Greeting stickers (issue #35) are `type: 'sticker'` messages carrying
an uploaded media id or a public `.webp` link; outside the 24-hour
customer-service window only approved templates may be sent.

Issue #31 / PR #34: `setTyping` shows a typing indicator. Cloud API
ties typing indicators to the incoming message being answered (it
also marks that message read), so a `messageId` is required.

**Exports**

- `PERSONAL_AUTOMATION_MESSAGE`
- `createWhatsAppCloudLive`
- `whatsappReactionsFromMessages`
- `whatsappSource`
- `whatsappStatusesToUpdates`
- `whatsappWebhookToLinks`

## `js/src/sources/x.js`

X (Twitter) source adapter (R-E3).

Accepts the user's X data archive (`tweet.js` / `direct-messages.js`
extracted into JSON). The live side wraps X API v2 posts and Direct
Messages endpoints with an injectable fetch/baseUrl for tests.

**Exports**

- `createXLive`
- `xSource`
- `xUpdatesToLinks`

## `js/src/storage/app-directory.js`

**Exports**

- `defaultStoreDir`
- `resolveUserStore`

## `js/src/storage/backup-archive.js`

The streaming backup archive, format 2 (R-Z16).

A real store is gigabytes: the old archive (one JSON string holding every
link) cannot even be built past V8's string limit. Format 2 is read and
written a piece at a time, so memory stays flat whatever the store size.

Plain content (what is gzipped), line by line:

  {"format":"meta-sovereign-backup","version":2,"createdAt":...,"secrets":...}
  <one Links Notation record per line, the store's log as it was>
  #end {"lines":N,"secretsExcluded":K,"bytes":B,"sha256":"<of every line above>"}

File on disk: a 28-byte header, then frames of the gzip stream:

  header = "MSBK2\n" | mode (0 plain, 1 AES-256-GCM) | 0 | salt(16) | nonce prefix(4)
  frame  = final flag (1) | length (4, BE) | data (length) | tag (16)

Every frame (up to 1 MB) is sealed on its own: AES-256-GCM with the
nonce `prefix | frame index`, or (no passphrase) a SHA-256 check tag. The
additional data is `header | index | final flag`, so a flipped byte, a
reordered or dropped frame, and a file cut short are all detected, and
a frame is checked before any of it is used. The key is scrypt of the
passphrase and the salt, as before.

**Exports**

- `FORMAT`
- `FRAME_BYTES`
- `archiveContent`
- `archiveError`
- `archiveStages`
- `isArchiveFormat2`
- `isRecordLine`
- `isSecretLine`
- `lastNewlineEnd`
- `quickCheckArchive`
- `scanArchive`
- `sealStage`

## `js/src/storage/backup.js`

Backup helper — snapshots a store into a single timestamped file in the
configured archive folder, and applies a simple keep-last-N retention
policy (R-A4).

Archives are written and read as streams (format 2, `backup-archive.js`,
R-Z16): the store's log is gzipped line by line and sealed in 1 MB
authenticated frames (AES-256-GCM with a passphrase), so a multi-gigabyte
store backs up and restores in flat memory. `data.bin` is not archived: it
is a snapshot of the log and is rebuilt from it when the store opens.
Archives of the earlier format (one JSON document, `.json`/`.json.enc`)
still verify and restore.

**Exports**

- `createBackup`
- `createBackupScheduler`
- `decryptBackup`
- `encryptBackup`
- `isBackupFile`
- `linksOfManifest`
- `makeBackup`
- `pruneBackups`
- `restoreBackup`
- `restoreBackupToDir`
- `verifyBackup`

## `js/src/storage/binary-packet.js`

Fast binary links notation packets (links-notation "Binary links
notation v1") using plain Numbers instead of BigInt, for the hot path
of the doublets store. The byte layout is exactly the one produced and
read by `LinksPacket` / `PacketReader` from the `links-notation` npm
package (cross-checked in tests/doublets-archive.test.js); this module
only trades the 64-bit generality for speed (addresses ≤ 2^53).

External references are returned as `-(value + 1)` so a reference list
stays a flat Number array (external 0 → -1, external 7 → -8).

**Exports**

- `decodePacket`
- `encodePacket`
- `externalRef`
- `externalValue`
- `widthFor`

## `js/src/storage/browser-store.js`

Browser-side links store for offline-first operation.

Implements `UniversalLinksAccess` so any code that talks to the
server store also works against a wholly local store — the SPA can
boot with no network, write/read links, and reconcile later when
a server (or another peer) shows up. The directive: "we should
support all possible ways" of local persistence (IndexedDB,
localStorage, files).

The store keeps the live data in a JS `Map` for synchronous, fast
lookups and persists snapshots to a pluggable *driver*. Drivers
expose `load() -> Promise<snapshot|null>` and `save(snapshot) ->
Promise<void>`; ship-in drivers cover IndexedDB, localStorage, and
an in-memory driver used by tests. Browser code picks the best
driver at boot via `pickBrowserDriver()`.

Snapshot shape: `{ links: Link[] }`. We persist on every mutation
(debounced via micro-task batching) so a tab refresh never loses
data. The driver layer keeps the store synchronous in spirit even
though the API is async, and lets us pivot to file-system storage
(Electron) by adding another driver.

**Exports**

- `createBrowserStore`
- `createDoubletsWebDriver`
- `createInMemoryDriver`
- `createIndexedDbDriver`
- `createLocalStorageDriver`
- `loadDoubletsWebDriver`
- `pickBrowserDriver`
- `pickSnapshotDriver`

## `js/src/storage/clink.js`

link-cli (`clink`) client: find the binary, load a doublets archive
into a database, and talk to `clink --serve` over its text protocol
(one LiNo query per message, terminated by a `.` line; the answer is
one `(before) (after)` change per matched link, then `.`).

Works with both link-cli builds (Rust 1.x, .NET 4.x). Everything that
starts a process or opens a socket is injectable for tests.

**Exports**

- `ClinkError`
- `clinkName`
- `clinkSupports`
- `clinkText`
- `findClink`
- `findUsableClink`
- `importArchive`
- `parseClinkReply`
- `quoteName`
- `replyComplete`
- `startClinkServer`
- `stuff`

## `js/src/storage/disk-space.js`

Free disk space, and the guard for jobs that write a big file (R-Z14).

A snapshot, a compaction or a backup writes a whole new file beside the
old one; on a nearly full disk it would fill the last bytes and make the
live log fail as well. Each of them first asks `enoughSpace` and, when the
disk is short, is skipped with a `*_skipped` event (reason `low_disk`)
that says how much was needed and how much is free.

Where the platform cannot say (`fs.promises.statfs` needs Node 18.15),
the free space is `null` ("unknown") and the job is allowed.

**Exports**

- `LOW_DISK_BYTES`
- `MARGIN_BYTES`
- `diskHealth`
- `enoughSpace`
- `freeBytes`
- `skippedEvent`

## `js/src/storage/doublets-archive.js`

Doublets archive — store records as a deduplicated associative network
of doublets (`source → target` pairs), written in the link-cli store
archive layout: a binary links notation *links packet* followed by a
*names packet* (links-notation `LinksPacket`). The same file can be fed
to `clink --import-binary data.bin` (link-cli 1.x Rust and 4.x .NET),
queried there, and re-exported byte-for-byte (R-A2, R-A3, issue #31).

Network shape (every scalar is a named point link, so equal values are
stored once and every record that mentions them is reachable from them):

  record   = (ms:records object)
  object   = (ms:object cells)        cells = ms:nil | ((key value) cells)
  array    = (ms:array cells)         cells = ms:nil | (value cells)
  string   = point named by the text  ("", digit-only and `ms:` text gets
             an `ms:s:` prefix so names never look like link numbers)
  number   = point named `ms:n:<n>`
  null / true / false = points `ms:null` / `ms:true` / `ms:false`

**Exports**

- `createNetworkEncoder`
- `decodeArchive`
- `encodeArchive`
- `encodeLinksArchive`
- `encodeNetwork`
- `readNetwork`
- `scalarFrom`
- `scalarName`

## `js/src/storage/doublets-mirror.js`

The binary side of the dual store as a mirror of the text side (R-A3):
the links are held in memory once — by the text store, the durable log
— and `data.bin` is a snapshot of that log, written by a worker thread
(`doublets-snapshot-worker.js`).

Holding a second decoded copy and encoding the whole store on the
server's own thread cost a 200k-message store about 1.4 GB more and
froze the server for about 18 s on every snapshot, until the heap ran
out. The snapshot file is the same link-cli archive as before
(`doublets-store.js` reads it).

Writes go through the text store (the dual store writes both sides);
here they only schedule the next snapshot: at most one per
`minIntervalMs`, or ten times what the last one took when that is
longer, doubled after each failure up to an hour. A snapshot older than the log (a crash, a CLI run) is written
again when the store opens.

**Exports**

- `createDoubletsMirror`
- `snapshotInWorker`

## `js/src/storage/doublets-snapshot-worker.js`

Writes the binary snapshot (`data.bin`) of a text log (`data.lino`)
off the server's thread (see `doublets-mirror.js`): the encoding of a
large store takes seconds and a heap of its own, and neither blocks
nor endangers the server. Reads `workerData.from`, writes
`workerData.to` through a temp file, and reports `{ links, bytes }`.

## `js/src/storage/doublets-store.js`

DoubletsStore — UniversalLinksAccess over the binary half of the
associative stack (R-A3, R-G1, R-G2, issue #31).

Records live in memory for reads; after a change the whole store is
written as a doublets network in the link-cli store archive layout
(binary links notation links packet + names packet, see
`doublets-archive.js`). That file is a snapshot: it is written at most
once per interval — `minIntervalMs`, or ten times what the last write
took when that is longer, so a large store does not spend its time
re-encoding — and changes do not wait for it. `flush()` writes now.
The dual store keeps the durable copy in the text log and repairs a
snapshot that missed the last changes (`reconcile`). The file opens
directly in link-cli:

  clink --db store.links --import-binary .meta-sovereign/data.bin

Files written by the earlier `MSDB1` JSON shim are still read and are
migrated to the archive format on the next write.

**Exports**

- `createDoubletsStore`
- `decodeStoreFile`

## `js/src/storage/dual-handoff.js`

**Exports**

- `managedDualStore`

## `js/src/storage/dual-store.js`

DualStore — write-through to both the binary (Doublets) and text
(`.lino`) backends so the unified database is always available in
both forms (R-A3). Reads are served from the binary side because it
is faster; the text side is treated as an authoritative export.

`verify()` cross-checks the two backends and returns the set of
links that disagree; this is the primitive the backup job runs
before snapshotting (R-A4).

The text side is the durable log; the binary side is a snapshot
written on an interval. `reconcile()` brings the binary side back in
line with the text (a snapshot that missed the last writes before a
crash) and is run when the server opens the store.

`openDualStore(dir)` is how the server and the CLI open theirs: the
binary side mirrors the text side (`doublets-mirror.js`), so each link
is held in memory once.

**Exports**

- `createDualStore`
- `openDualStore`
- `openWarmDualStore`

## `js/src/storage/durable.js`

Durable, private file writes shared by the store, the snapshot worker,
the backups and the logs (R-Z2).

A rename is only atomic for the directory entry: without an fsync of
the file first, a power cut can leave the new name pointing at empty
data blocks, and without an fsync of the directory the rename itself
can be lost. `writeFileDurable` does both. Files are private to the
user: 0600, directories 0700 (a no-op on Windows).

**Exports**

- `DIR_MODE`
- `FILE_MODE`
- `ensurePrivateDir`
- `fsyncDir`
- `fsyncFile`
- `renameDurable`
- `renameDurableSync`
- `sweepTemp`
- `tighten`
- `writeFileDurable`
- `writeStreamDurable`

## `js/src/storage/export-encrypted.js`

Encrypted exports (R-K13 … R-K17).

Issue #6 requires that exported data is encrypted by default and
that the user is warned they are responsible for storing the file.

The envelope shape is intentionally identical to the encrypted
backup format produced by `encryptBackup` so a single passphrase
decrypts both surfaces. The only addition is a top-level `warning`
field so any tool that prints the JSON shows the responsibility
statement first.

**Exports**

- `DEFAULT_WARNING`
- `decryptExport`
- `exportEncrypted`
- `writeEncryptedExport`

## `js/src/storage/file-writer.js`

Coalesced whole-file writer shared by the file-backed stores.

Every `request()` resolves once a write that *started after* the request
has finished, so callers keep write-through durability, while requests
that arrive during an in-flight write share a single follow-up write
instead of rewriting the file once each.

**Exports**

- `createFileWriter`

## `js/src/storage/index.js`

**Exports**

- `DEFAULT_WARNING`
- `TOMBSTONE_FIELD`
- `VAULT_KINDS`
- `bulkPurge`
- `createBrowserStore`
- `createDoubletsMirror`
- `createDoubletsStore`
- `createDoubletsWebDriver`
- `createDualStore`
- `createInMemoryDriver`
- `createIndexedDbDriver`
- `createLinoTextStore`
- `createLocalStorageDriver`
- `createMemoryStore`
- `createVault`
- `decodeArchive`
- `decodeStoreFile`
- `decryptExport`
- `decryptWithKey`
- `deletedAtOf`
- `encodeArchive`
- `encodeNetwork`
- `encryptWithKey`
- `exportEncrypted`
- `formatLino`
- `formatLinoRecords`
- `isSecretLinkId`
- `isTombstone`
- `loadDoubletsWebDriver`
- `markDeleted`
- `openDualStore`
- `parseLino`
- `parseLinoRecords`
- `pickBrowserDriver`
- `purgeLink`
- `putAll`
- `readNetwork`
- `snapshotInWorker`
- `softDeleteLink`
- `unmarkDeleted`
- `withSoftDelete`
- `wrapSecretStore`
- `writeEncryptedExport`

## `js/src/storage/lino-handoff.js`

**Exports**

- `logCheckpoint`
- `replayLogTail`
- `verifyCheckpoint`

## `js/src/storage/lino-store.js`

LinoTextStore — UniversalLinksAccess over the text half of the
associative stack: a `.lino` file in Links Notation with one record per
line, encoded by `lino-objects-codec` so every field (bodies with new
lines and quotes, numbers, booleans, null, nested objects) round-trips
exactly and every line parses with the upstream `links-notation`
parser (R-A2, R-A3, R-A5, issue #31):

  (o: (id "msg:vk:1") (tokens ("msg" "vk" "1")) (body "Привет") ...)

The file is a log: a put appends its records and a delete appends a
tombstone (`{ id, '~deleted': true }`, exactly those two keys), so a
write costs the size of what changed, not of the whole store. On load
the records apply in order (a later one replaces an earlier one with
the same id). Once superseded lines outnumber the live links (and pass
`compactAfter`), or superseded text outweighs the live text (and passes
`compactBytes` characters), the file is rewritten with one line per
live link.

Files written by the earlier indented `id token…` format (which kept
only id/tokens/children) are still read and are rewritten in the
record format on the next write.

**Exports**

- `TOMBSTONE_KEY`
- `applyLinoRecords`
- `createLinoTextStore`
- `forEachLiveRecord`
- `formatLinoRecords`
- `parseLinoRecords`
- `readLinoFile`
- `tombstoneRecord`

## `js/src/storage/lino.js`

Indented token-list reader/writer.

A minimal indented subset of Links Notation: each line is a list of
whitespace-separated tokens and indentation encodes nesting. The store
itself now uses the upstream `links-notation` / `lino-objects-codec`
packages (see `lino-store.js` and `doublets-archive.js`); this reader
remains for the indented CV documents and for reading `.lino` stores
written before the switch.

**Exports**

- `formatLino`
- `parseLino`

## `js/src/storage/migrations/0001-email-threads.js`

0001 — email threads and dates as R-Z5 writes them (R-Z17).

Mail read from raw RFC 822 text (IMAP, POP3, `.eml`, `.mbox`) was stored
with the chat (conversation) taken from the whole References header,
else In-Reply-To, else the subject, and with the `Date:` header as it
came. R-Z5 keys a conversation by the FIRST id of References (the root),
else In-Reply-To, else the mail's own Message-ID, else the base subject;
stores `timestamp` as ISO time; and keeps `messageId`, `references` and
`inReplyTo` on the link. Everything needed is in the stored link
(`rawHeaders`, `subject`, `timestamp`), so each mail is recomputed
without the network and without the original bytes.

Not recoverable from what is stored (left as it is, still readable):
the decoded subject of a mail whose subject was an encoded word (the
stored one is what the old reader decoded), and the `raw-<hash>` id of a
mail with no Message-ID. Gmail, Graph and JMAP mail kept their provider
thread ids and only get the ISO time.

Idempotent: it computes the target shape from the stored fields and
writes only what differs.

**Exports**

- `description`
- `from`
- `id`
- `to`
- `up`
- `upgradeEmailLink`

## `js/src/storage/migrations/0002-whatsapp-chat-ids.js`

0002 — stable WhatsApp chat ids (R-Z9, R-Z17).

Before R-Z9 a WhatsApp chat was named by whatever the reader had: the
typed number in any format ("+49 170 123 4567"), the digits of a title,
the page's title, or `unknown` for an export. R-Z9 names it by the
E.164 number, the group JID, the linked-id JID, or (export of a saved
contact, no number in the file) `name:<hash>`.

Recomputed only from stored fields (`chat`, `chatName`, `via`):
  - a chat that parses as a number or JID gets that id;
  - an export chat (no `via: 'browser'`) with a name (`chatName`, or the
    chat text itself) gets `name:<hash>`;
  - a chat read from a page by its title has no number stored, and an
    export chat that was `unknown` without a name has nothing to
    recompute from: both stay as they are, still readable, and are
    counted in the log line `whatsapp_chat_ids_unresolved`.
A page-read message moves to `msg:whatsapp:<new chat>:<key>` (its old id
stays resolvable through `alias:`); a key that is a participant JID (the
old group `data-id` pattern) is not a message id, so such a message and
the counter-numbered export messages keep their ids and only get the new
chat. Idempotent: ids already in the new form are fixed points.

**Exports**

- `description`
- `from`
- `id`
- `newChatId`
- `to`
- `up`

## `js/src/storage/migrations/0003-vk-reactions-docs.js`

0003 — VK reactions as emoji and documents by their kind (R-Z8, R-Z17).

Before R-Z8 a VK reaction was stored as `{ emoji: '3', count }`: the
number VK sends, which a page cannot draw. R-Z8 stores the emoji and
keeps the number as `reactionId`. A VK document of type 3 (gif) or 4
(image) used to be stored as a `file`; R-Z8 stores `gif` / `photo`
(and its `ext`).

Recomputed only from stored fields (`reactions`, and `raw.attachments`
for documents). A numeric reaction VK has no emoji for stays a number;
a message whose `raw` was not kept keeps its attachments. Message ids,
chat ids, senders and times did not change. Idempotent: a reaction
that has `reactionId`, and a non-`file` document, are fixed points.

**Exports**

- `description`
- `from`
- `id`
- `to`
- `up`

## `js/src/storage/migrations/0004-github-external-ids.js`

0004 — GitHub items remember which object on GitHub they are (R-Z11,
R-Z17).

Before R-Z11 a pulled GitHub link kept only its link id and `raw: { id,
url, node_id }`. R-Z11 stores `externalId = { network: 'github', kind,
id, nodeId, owner, repo, number }` and `messageId` (the REST id), which
edit, delete, react and reply use to reach the right endpoint.

Backfilled only from fields already stored: the kind and the number /
REST id from the link id (`msg:github:<kind>:<owner>/<repo>#<n>`), the
owner and repository from `raw.url` (`/repos/o/r/` or a github.com page)
with the link id as the fallback, the REST and node ids from `raw`, a
comment's issue or pull number from its chat (`o/r#12`). A link where
the repository or the object cannot be worked out stays as it is and
keeps refusing edit/delete/react with `no-external-id` (counted as
`unresolved`). Nothing is fetched. Idempotent: a link that has its
`externalId` is a fixed point.

**Exports**

- `description`
- `from`
- `id`
- `referenceOf`
- `to`
- `up`

## `js/src/storage/migrations/0005-archive-ids.js`

0005 — collision-free Facebook / Messenger and LinkedIn message ids,
ISO Facebook times, repaired text (R-Z10, R-Z17).

Before R-Z10 a Facebook message was `msg:facebook:<timestamp_ms>` (two
messages in one millisecond, or in two threads, were one link) with the
number stored as `timestamp`, and a LinkedIn message
`msg:linkedin:<conversation>-<date text>` (two in one second collided).
Now: `msg:facebook:<thread folder>:<ms>:<sender digest>:<n>` and
`msg:linkedin:<conversation>:<ISO time>:<sender digest>:<n>`.

Computed only from stored fields. The thread is the last part of the
stored `chat` (the old `thread_path`); the sender digest is taken over
the sender with its latin-1 mojibake repaired (only when that
round-trips, so honest text is never changed); n is 0 (a collision kept
one survivor). The link is first rewritten in place (ISO `timestamp`,
`chat`, repaired `sender` / `body`, children / tokens for the new id),
then moved with `ctx.rekeyMany`, so the old id stays resolvable through
`alias:`. A Facebook message without `timestamp_ms` (id
`<sender>-<seconds>`) and a LinkedIn message whose date cannot be read
cannot be computed: they are counted (`unresolved`) and left as they
are. Re-importing the archive does not duplicate a migrated message
(the importer checks the old id and its alias). Idempotent.

**Exports**

- `description`
- `from`
- `id`
- `to`
- `up`

## `js/src/storage/migrations/0006-tombstones.js`

0006 — one tombstone shape: `deleted: { at, by, reason }` (R-Z7, R-Z17).

Before R-Z7 the app wrote three kinds of "this message is gone" marks:
`deleted: true` (Telegram live deletes, a removed chat, Facebook and
WhatsApp archives), `{ deleted: true, deletedAt }` (the in-app message
delete) and `deleted: { at, by, reason }` (soft-delete.js). Now only the
last is written.

Mapped from stored fields only:
- `deleted: true` becomes `{ at: null, by: 'unknown', reason: null }`
  (the time and cause were never stored; nothing is invented);
- `{ deleted: true, deletedAt }` (or a bare `deletedAt`) becomes
  `{ at: deletedAt, by: 'user', reason: 'deleted-in-app' }` and loses
  `deletedAt`, the only writer was the in-app delete;
- an object missing `at`, `by` or `reason` gets them as `null` /
  'unknown'; other keys stay;
- `false` / `null` are not tombstones and stay; any other value (text,
  number, list) is kept untouched and counted (`unknown`).
Idempotent: a complete `{ at, by, reason }` is a fixed point.

**Exports**

- `description`
- `from`
- `id`
- `to`
- `up`

## `js/src/storage/migrations/browser-runner.js`

The browser adapter of the migration runner (R-Z17): the same modules
over the page's store (./../browser-store.js), no node:* imports.

The page's store is a snapshot written as a whole by its driver, with no
log to cut back, so there is no rollback: a migration is idempotent, and
`meta:schema` (written after each step, in the snapshot that carries the
step's changes) records which steps are complete. A tab closed half way
through a step runs that step again at the next load and gets the same
result.

**Exports**

- `migrateBrowserStore`

## `js/src/storage/migrations/core.js`

The migration runner's shared core (R-Z17). Browser-safe: no node:*
imports. The Node adapter (./node-runner.js) adds the journal, the free
space check and the rollback by truncating the log; the browser adapter
(./browser-runner.js) runs the same modules over the page's store.

A store's schema version is one link, `meta:schema`:
  { id, tokens, children, version, applied: [{ id, at, ms, changed }], app }
A store without it is version 0 (the shapes before versioning).

A migration is a module exporting `{ id, from, to, description, up(ctx) }`:
a forward-only, idempotent, pure data transform (no network). `ctx`:
  scan({ prefix, where, batchSize }, async (batch) => ...)  copies, in batches
  get(id) / put(link) / putMany(links) / tombstone(id)
  rekey(oldId, newId, { patch }) / rekeyMany(pairs, { fields, children, refMap })
  resolve(id)       follows `alias:<old>` links to the current id
  log(name, counts) a log line with numbers only, never content
  progress(info)    reports `{ scanned, changed }` to whoever listens
  dryRun            true: writes are only counted

**Exports**

- `ALIAS_PREFIX`
- `SCHEMA_ID`
- `createContext`
- `migrationFailed`
- `pendingFrom`
- `runMigrations`
- `same`
- `schemaLink`
- `storeTooNew`
- `versionOf`

## `js/src/storage/migrations/index.js`

The data schema's versions (R-Z17).

`MIGRATIONS` is the ordered chain; each module is
`js/src/storage/migrations/<NNNN>-<slug>.js` exporting
`{ id, from, to, description, up(ctx) }` (see ./core.js for `ctx`).
Adding one: create the module, add its import and its entry below, raise
`CURRENT_SCHEMA` to its `to`. `tests/migrations-registry.test.js` fails
when an id is repeated, a number is skipped, a module is not listed, or
`CURRENT_SCHEMA` is not the last migration's `to`.

Static imports (no directory scan) so the browser bundle carries them.

**Exports**

- `ALIAS_PREFIX`
- `CURRENT_SCHEMA`
- `MIGRATIONS`
- `SCHEMA_ID`
- `createContext`
- `migrationFailed`
- `pendingFrom`
- `runMigrations`
- `same`
- `schemaLink`
- `storeTooNew`
- `versionOf`

## `js/src/storage/migrations/node-runner.js`

The Node adapter of the migration runner (R-Z17): runs the pending
migrations when a writer opens the store, before the server listens or
the CLI acts, and puts the store back as it was if one fails.

Crash safety without copying the store: the log (`data.lino`) is
append-only, so before the first migration its byte length is written,
durably, to `migration.json`. A migration only appends to the log
(compaction is held, the binary snapshot is not running yet). If one
fails, or the process dies and the next open finds `migration.json`, the
log is truncated back to the recorded length (fsync), `data.bin` is
dropped (rebuilt from the log), and the journal is removed. After each
completed migration the journal moves forward to the new length, so a
stop between two keeps the first.

Read-only opens never migrate: an older store is read as it is (readers
accept old shapes); a newer one is refused with STORE_TOO_NEW.

**Exports**

- `JOURNAL`
- `SPACE_FLOOR_BYTES`
- `appVersion`
- `checkReadOnly`
- `dryRunMigrations`
- `migrateOpenStore`
- `recoverJournal`

## `js/src/storage/secret-store.js`

Encrypted-at-rest decorator for `secret:*` links (R-J9 / ROADMAP §8).

`wrapSecretStore({ inner, passphrase })` returns a Universal Links
Access store that transparently encrypts/decrypts the payload of any
link whose `id` starts with `secret:`. Non-secret links pass through
untouched so contacts, messages, patterns etc. keep their normal
shape (the universal store invariant — the data store IS the API —
stays intact).

Cipher: AES-256-GCM, scrypt(N=2^14)-derived key, random salt + IV per
write. The ciphertext envelope is the same JSON shape the encrypted
backup format already uses (see `encryptBackup`/`decryptBackup` in
`./backup.js`) so a single passphrase decrypts both surfaces.

On disk the encrypted link looks like:
  { id: 'secret:telegram:bot-token',
    tokens: ['secret', 'telegram', 'bot-token'], // id parts only
    enc: '{"version":1,"cipher":"aes-256-gcm",...}' }

`tokens` is regenerated from the id so it carries no plaintext, but
the binary store can still index/range-scan by id without knowing
the passphrase. The original `tokens`, `body`, `value`, etc. live
inside `enc` and are restored on read.

If no passphrase is provided, `wrapSecretStore` returns the inner
store unchanged — encryption is opt-in via `MS_SECRET_PASSPHRASE`
(or the `passphrase` option on `startServer`).

**Exports**

- `isSecretLinkId`
- `wrapSecretStore`

## `js/src/storage/soft-delete.js`

Soft-delete tombstones (R-K1 … R-K6).

Issue #6 requires that messages are never physically deleted by
default — even when the upstream service reports a delete. Instead
we keep the link, attach a `deleted: { at, by, reason }` marker, and
only run a destructive `purge` when the operator explicitly
confirms.

The functions in this file are deliberately small and stateless so
they can wrap any `UniversalLinksAccess` implementation (memory,
dual-store, secret-wrapped, browser).

Design notes:

- Soft-delete is a regular `put`. The peer mesh therefore propagates
  tombstones to other devices for free. Mutating handlers on the bus
  already use `handledBy` stamps to dedupe, so a tombstone that
  round-trips through sync does not re-fire the "delete on upstream"
  handler chain.
- Hard-delete (`purge`) is intentionally local. It calls the inner
  store's `delete()` only when `confirm === true` so the operator
  cannot accidentally drop data, and the call never travels over the
  sync bus (the sync `peer` only emits `put`/`delete` events that
  originated locally; the user has to explicitly run `purge` on each
  device).
- `isTombstone` and `markDeleted` are pure helpers exported so
  adapters can stamp links offline (e.g. inside `parseArchive`) when
  they observe upstream deletes.

**Exports**

- `TOMBSTONE_FIELD`
- `bulkPurge`
- `deletedAtOf`
- `isTombstone`
- `markDeleted`
- `purgeLink`
- `softDeleteLink`
- `unmarkDeleted`
- `withSoftDelete`

## `js/src/storage/store-lock.js`

One writer per store folder (R-Z2).

Every process keeps its own in-memory copy of the store and rewrites the
log from it when it compacts, so two writers on one folder lose each
other's writes (a CLI `import` while `serve` runs). The safest and
simplest rule is a lock file, `data.lock`, holding the owner's pid:

  - a second process that wants to WRITE fails fast with code
    `STORE_LOCKED` and a message naming the owner (stop it, or give the
    command another `--store`);
  - read-only commands (`export`, `cv-read`, ...) never take the lock
    and read the log as it is, even while `serve` runs;
  - a lock whose process is gone (a crash, `kill -9`) is stale and is
    taken over; a lock is released when the process exits normally.

The same process may open a folder again (tests and the per-account
stores do): its own pid is never a conflict.

**Exports**

- `LOCK_FILE`
- `acquireStoreLock`

## `js/src/storage/universal.js`

Universal Links Access interface.

Every storage backend (text-only `.lino`, binary doublets, dual store,
or a remote HTTP client) implements the same API so callers do not
care which substrate is underneath. This is requirement R-F8.

A "link" is `{ id: string, tokens: string[], children?: string[] }`.
`tokens` are the human-readable payload; `children` is an optional
list of child link IDs for hierarchical structures.

**Exports**

- `createMemoryStore`
- `putAll`

## `js/src/storage/vault.js`

Master-key vault (R-K7 … R-K12).

The vault holds a single random 256-bit master key on disk, *wrapped*
by one or more "unlock methods". A user can add a passphrase, a PIN,
a passkey-derived secret (WebAuthn `prf` extension produces a 32-byte
blob the browser passes in here), and an authenticator-app TOTP
recovery code. Each method derives its own key via scrypt and seals
a copy of the master key with AES-256-GCM, so adding or removing an
unlock method only re-wraps the master key — none of the data on
disk needs to be re-encrypted (R-K10).

On disk the vault is a JSON document at a path of the caller's
choice (the server uses `<storeDir>/vault.json`). The schema is:

    {
      "kind": "meta-sovereign-vault",
      "version": 1,
      "createdAt": "<iso>",
      "unlocks": [
        {
          "id": "<random-12-byte-hex>",
          "label": "passphrase",
          "kind": "passphrase" | "pin" | "passkey" | "totp-recovery",
          "kdf": { "name": "scrypt", "N": 16384, "r": 8, "p": 1 },
          "salt": "<base64>",
          "iv": "<base64>",
          "tag": "<base64>",
          "wrapped": "<base64 wrapped master key>",
          "addedAt": "<iso>"
        },
        ...
      ]
    }

The plaintext master key never touches disk. `unlock()` reads the
file, finds an entry whose secret matches, and returns a handle that
exposes `encrypt(plaintext)` / `decrypt(envelope)` — both call into
the same AES-256-GCM scheme used by `encryptBackup`, so envelopes
produced by the vault can be opened by `decryptBackup` if you give
it the master key as the passphrase (the `kdf` step then becomes a
no-op key reuse — see `encryptWithKey`).

Loss of all unlock methods means loss of access to the data (R-K12).
That is intentional — there is no recovery backdoor.

**Exports**

- `VAULT_KINDS`
- `createVault`
- `decryptWithKey`
- `encryptWithKey`

## `js/src/storage/write-queue.js`

The writes of an append-only log that a full or failing disk could not
take (R-Z14).

`push` puts bytes in the queue, `write` sends every queued byte to the
file (a partial write leaves the rest at the head, so a retry continues
the very line that was cut and no torn line is left). When a write
fails, `fail(error)` puts the queue in the degraded state: it keeps
what is waiting in memory (up to `maxQueueBytes`, then `guard` refuses
more with STORE_FULL), retries after `retryMs`, doubling up to
`retryMaxMs`, and says so through `onEvent` (`store_degraded`, then
`store_recovered` when a retry succeeds).

The invariant: nothing the queue accepted is dropped silently. It is on
disk, or still queued.

**Exports**

- `MAX_QUEUE_BYTES`
- `RETRY_MAX_MS`
- `RETRY_MS`
- `appendHandle`
- `createWriteQueue`
- `storeError`
- `writeFailed`

## `js/src/sync/bun-server.js`

Bun runtime adapter for the WebSocket sync transport and the
WebRTC signaling broker.

Bun's `node:http` upgrade socket (and `node:net.createConnection`)
do not deliver bytes back and forth in the way the hand-rolled
RFC 6455 server in `ws-transport.js` and `webrtc-signaling.js`
expect — `socket.write(...)` reports `true` but the bytes are
silently dropped. Bun's first-class story for WebSockets is
`Bun.serve({ websocket })` and the global `WebSocket` constructor,
both of which work correctly. This module rebuilds the same public
shapes on top of those primitives so the rest of the codebase does
not need to know which runtime it is on.

Contract:

  prepareBunHttp(httpServer) → registry
    Hijacks `httpServer.listen` so that calling `.listen(port, host,
    cb)` actually starts a `Bun.serve` instance on that port. Until
    `.listen` is called, attach functions can register WS paths +
    handlers via `registry.registerWs(path, handlers)` and the
    fallback HTTP request listener is taken from the original
    `httpServer`'s `request` listeners.

  bunAttachWs(httpServer, { path, handlers }) → handle
    Registers a WS path on the (lazy) Bun server; returns the same
    `{ transport, close, socketCount }` shape as the Node version.

  bunStartSyncWebSocketListener({ port, path }) → handle
    Starts a stand-alone Bun WS server with one /ws path. Returns
    the same `{ port, transport, path, close }` shape as the Node
    version.

  bunConnectSyncWebSocket({ port, host, path }) → { transport, close }
    Wraps the global WebSocket so messages flow as JSON.

  bunAttachSignaling(httpServer, { path }) → handle
    Same shape as `attachSignaling` but uses Bun.serve underneath.

**Exports**

- `bunAttachSignaling`
- `bunAttachSyncWebSocket`
- `bunAttachWs`
- `bunConnectSyncWebSocket`
- `bunStartSyncWebSocketListener`
- `prepareBunHttp`

## `js/src/sync/index.js`

Sync layer (R-F5).

Last-writer-wins-per-link CRDT seed: every link carries a `version`
(Lamport-style). `merge(a, b)` picks the higher version on conflict
and union of children otherwise. `Peer` is transport-agnostic — the
WebRTC adapter is plumbed via `Peer.connect(transport)` so the same
code runs over loopback in tests, WebSocket on a server, or
RTCDataChannel in the browser.

Transport-agnostic primitives live in `./peer.js` so browser code
can import them without pulling in the Node-only TCP / WebSocket
server transports re-exported below.

**Exports**

- `attachSignaling`
- `attachSyncWebSocket`
- `cmp`
- `connectSyncPeer`
- `connectSyncWebSocket`
- `createPeer`
- `createWebRtcTransport`
- `loopback`
- `merge`
- `signalingChannel`
- `startSyncListener`
- `startSyncWebSocketListener`
- `tickVersion`
- `vcCompare`
- `vcInit`
- `vcMerge`
- `vcTick`

## `js/src/sync/peer.js`

Transport-agnostic peer + CRDT primitives.

Lives in its own file so the browser bundle can import `createPeer`
without dragging in `node:net` / `node:http` (which the TCP and
WebSocket *server* transports re-export from `sync/index.js`).

**Exports**

- `cmp`
- `createPeer`
- `loopback`
- `merge`
- `schemaMismatch`
- `tickVersion`
- `vcCompare`
- `vcInit`
- `vcMerge`
- `vcTick`

## `js/src/sync/tcp-transport.js`

TCP transport for the peer abstraction (R-F5 stand-in).

The full WebRTC stack needs an STUN/TURN signalling layer plus
`RTCDataChannel`. Until that lands, this adapter speaks newline-
delimited JSON over a plain TCP socket — same contract the
`loopback` transport uses, but real cross-process. The peer code in
`createPeer` does not change; once the WebRTC adapter is ready it
plugs in via the same `{ send, onMessage }` interface.

**Exports**

- `connectSyncPeer`
- `startSyncListener`

## `js/src/sync/webrtc-signaling.js`

Minimal WebRTC signaling broker.

Two browsers that want to open an `RTCDataChannel` to each other
exchange SDP offers / answers and ICE candidates. The bytes can
flow over any transport — we use a tiny WebSocket relay mounted
on the http server so the SPA only needs one origin.

Each WebSocket joins a *room* identified by a path query
(`?room=foo`). The broker fans every JSON frame to every other
peer in the same room. It is *not* a TURN server; once peers have
exchanged candidates they talk directly. The broker holds zero
application state — losing it just means new peers can't find
each other until it reboots.

**Exports**

- `attachSignaling`

## `js/src/sync/webrtc-transport.js`

WebRTC sync transport.

Two browsers (or one browser + an Electron main, etc.) want to
exchange links without going through the central server. They
connect to the /rtc signaling broker (a WebSocket relay), trade
SDP offers/answers + ICE candidates, then open an RTCDataChannel
and switch to it. Once the data channel is open the broker is no
longer involved — peers talk directly.

The transport exposes the standard `{ send, onMessage }` contract
so `createPeer().connect(transport)` plugs straight in, mirroring
the loopback / TCP / WebSocket transports.

The `signalingChannel` helper isolates the JSON-over-WS plumbing
from RTCPeerConnection so we can test the signaling logic in
Node without `wrtc`. The browser code wires the two together by
calling `createWebRtcTransport({ signaling, RTCPeerConnection })`.

**Exports**

- `createWebRtcTransport`
- `signalingChannel`

## `js/src/sync/ws-frame.js`

RFC 6455 WebSocket framing — minimal text-frame implementation.

The full spec defines binary frames, fragmentation, ping/pong,
extensions, and a handful of close codes. We use WebSockets only
to ship newline-delimited JSON sync events between an http server
and a browser, so we narrow to single-fragment text frames with
lengths up to 64KiB; pings get a pong reply and other control
frames are ignored.

Keeping the implementation in-tree avoids pulling the `ws` package
(and a transitive native build) into the dependency surface — the
issue calls for "no premature optimisation" and the simplest
possible code.

**Exports**

- `acceptKey`
- `createFrameReader`
- `encodeClientTextFrame`
- `encodeTextFrame`
- `isWebSocketUpgrade`
- `rejectForeignOrigin`
- `writeAcceptHandshake`

## `js/src/sync/ws-transport.js`

WebSocket sync transport.

Mounts on top of an existing http.Server so the SPA can keep its
single origin (same port, same /ws path). The transport conforms
to the same `{ send, onMessage }` shape used by `loopback` and
`tcp-transport`, so `createPeer().connect(transport)` plugs into
either substrate without changing the peer code.

Browser clients talk to this via the standard global `WebSocket`,
so no library code ships into the SPA bundle. Node-side clients
use `connectSyncWebSocket` below for cross-process tests.

**Exports**

- `attachSyncWebSocket`
- `connectSyncWebSocket`
- `startSyncWebSocketListener`

## `js/src/web/api-errors.js`

**Exports**

- `API_ERROR_EVENT`
- `ApiErrorToast`
- `KNOWN_CODES`
- `LoadError`
- `errorText`
- `failureOf`
- `logOnce`
- `reportApiFailure`
- `resetApiErrors`

## `js/src/web/app-navigation.js`

**Exports**

- `useAppNavigation`

## `js/src/web/app-notify.js`

**Exports**

- `AppNotifications`

## `js/src/web/app-route.js`

**Exports**

- `APP_ROUTE_KEY`
- `appNavigation`
- `backInApp`
- `chatHash`
- `createAppNavigation`
- `navigateApp`
- `operatorHash`
- `parseAppRoute`
- `sectionHash`
- `splitChatAddress`

## `js/src/web/app.js`

## `js/src/web/app.min.js`

## `js/src/web/appearance.js`

**Exports**

- `SKINS`
- `SKIN_KEY`
- `THEME_KEY`
- `THEME_MODES`
- `currentMode`
- `readAppearance`
- `resolveTheme`
- `setSkin`
- `setThemeMode`
- `useAppearance`
- `useApplyAppearance`

## `js/src/web/apps-model.js`

**Exports**

- `appTarget`
- `collectibleItems`
- `collectibleLabel`
- `cryptoText`
- `failureWord`
- `fiatText`
- `filterApps`
- `learnUrl`
- `mainAppRequest`
- `mergeApps`
- `peerAllowed`
- `shareChats`

## `js/src/web/archive-media-model.js`

**Exports**

- `archiveItem`
- `mediaPathOf`

## `js/src/web/auto-download.js`

**Exports**

- `AUTO_DOWNLOAD_KEY`
- `ChatKindContext`
- `DEFAULTS`
- `DEFAULT_SCOPE`
- `LIMITS_MB`
- `SCOPES`
- `allowedFor`
- `getAutoDownload`
- `readAutoDownload`
- `resetAutoDownload`
- `scopeOfKind`
- `setAutoDownload`
- `settingsFrom`
- `settingsFromPreset`
- `subscribeAutoDownload`
- `useAutoDownloadSettings`
- `useAutoLoad`
- `withChoice`
- `writeAutoDownload`

## `js/src/web/automation-api.js`

**Exports**

- `createAutomationApi`
- `listAutomations`
- `outgoingMessage`

## `js/src/web/automations-model.js`

**Exports**

- `blankAutomation`
- `checkForm`
- `exclusionSummary`
- `fromForm`
- `localizePreset`
- `presetName`
- `selectionAudience`
- `targetsFor`
- `toForm`

## `js/src/web/automations-safety.js`

**Exports**

- `SafetyPanel`

## `js/src/web/automations-state.js`

**Exports**

- `useAutomationsState`

## `js/src/web/automations-view.js`

**Exports**

- `AutomationsScreen`
- `AutomationsView`

## `js/src/web/autopilot-hook.js`

Shared autopilot state (R-Y87): the core hook used by both the chat
screen and the automations page to start, stop, monitor, and watch
each automation's autopilot run.

**Exports**

- `shownAutopilot`
- `useAutopilotBase`

## `js/src/web/bot-keyboard.js`

**Exports**

- `botAskOf`
- `buttonOf`
- `inlineKeyboardOf`
- `legacyButton`
- `peerTypeOf`
- `replyKeyboardOf`

## `js/src/web/business-hours-model.js`

**Exports**

- `DAY`
- `WEEK`
- `allDay`
- `dayNames`
- `daysProblem`
- `formatTime`
- `hoursIn`
- `isOpen`
- `myZone`
- `offsetMinutes`
- `parseTime`
- `rangesText`
- `shiftWeekly`
- `toDays`
- `toWeekly`
- `weekMinute`
- `weekday`
- `zoneLabel`

## `js/src/web/business-menu.js`

**Exports**

- `BusinessButton`
- `BusinessDialog`
- `SECTIONS`
- `sectionsFor`

## `js/src/web/business-messages.js`

**Exports**

- `BusinessMessageDialog`

## `js/src/web/call-model.js`

**Exports**

- `callKind`
- `callLine`
- `formatCallDuration`
- `groupCalls`

## `js/src/web/channel-dm-model.js`

**Exports**

- `approveQuestion`
- `canDecide`
- `cardOf`
- `decideBody`
- `errorText`
- `hasDirectMessages`
- `perMessageNote`
- `priceText`
- `replyBody`
- `scheduleOf`
- `serviceText`
- `suggestBody`

## `js/src/web/chat-account-data.js`

**Exports**

- `ChangePhoneDialog`
- `DEFAULT_DATA_FORM`
- `DELETE_URL`
- `DeleteAccountRow`
- `ExportDataButton`
- `ExportDataDialog`
- `KIND_KEYS`
- `chatsPercent`
- `cleanPhone`
- `dataFormReady`
- `dataRequestOf`
- `delayParts`
- `delayText`

## `js/src/web/chat-account.js`

**Exports**

- `ChatAccountEmpty`
- `ChatAccountNotice`

## `js/src/web/chat-accounts-live.js`

**Exports**

- `ACCOUNT_MESSAGE`
- `accountNotification`
- `sumOthers`
- `switchAccount`
- `useAccountsSummary`

## `js/src/web/chat-accounts.js`

**Exports**

- `AccountAvatar`
- `AccountsDialog`
- `accountLabel`
- `unreadBadge`
- `useAccountsWindow`
- `useActiveAccount`
- `withUnread`

## `js/src/web/chat-actions.js`

What can be done with the open chat's messages, one or a selection of
them, as in Telegram Desktop (R-Y67, R-Y68): reply (quoting the part
of the text selected), edit, pin or unpin, save or copy a picture,
copy the text, a link or the message's link, forward, delete, select
(one, or up to this message), and for the selection copy as text,
forward, delete, unpin, clear; take back a vote or stop a poll
(R-Y74). Telegram messages go through
/api/telegram/*, other networks' through /api/message/* (R-Y38).

**Exports**

- `lastEditable`
- `replyRefOf`
- `replyStep`
- `useChatActions`

## `js/src/web/chat-add-members.js`

**Exports**

- `AddMembers`
- `adminErrorText`
- `announceMembersChanged`
- `canAddMembers`
- `useMembersChanged`

## `js/src/web/chat-admin-rights.js`

**Exports**

- `Aside`
- `MemberPicker`
- `RightsDialog`
- `mayGrant`
- `startRights`

## `js/src/web/chat-admin.js`

**Exports**

- `AdminActions`
- `RIGHTS`
- `SLOW_MODES`
- `changesOf`
- `hasAdminLog`
- `hasForumToggle`
- `hasPermissions`

## `js/src/web/chat-admins.js`

**Exports**

- `AdminsSection`
- `canEditAdmin`
- `hasAdminSection`
- `hasHistorySwitch`
- `kindOf`

## `js/src/web/chat-album.js`

Albums, as Telegram shows them: photos and videos sent together (one
`groupedId`) are one bubble — a grid of them, the caption under it,
one time — not a row each. Telegram stores each item as a message of
its own; the chat draws them as one, and what is done to the album
(forward, delete, select) is done to every item.

- `groupAlbums(messages)` — the rows to draw: an album's items become
  one row, the item with the caption leading (`albumItems` on it).
- `expandAlbums(rows)` — back to every message, for an action.
- `albumRows(ratios)` — the grid: rows of up to four, each as tall as
  its items' proportions let them fill the width.
- `AlbumGrid` — draws it.

**Exports**

- `AlbumGrid`
- `albumOf`
- `albumRows`
- `expandAlbums`
- `groupAlbums`
- `rowIds`

## `js/src/web/chat-apps-search.js`

**Exports**

- `AppsSection`
- `useApps`
- `useSearchFocus`

## `js/src/web/chat-archive-media.js`

**Exports**

- `ArchiveAttachments`

## `js/src/web/chat-attach-bots.js`

**Exports**

- `BotAttachRow`
- `RemoveMenu`
- `botsFor`
- `openAttachBot`
- `openAttachLink`
- `parseAttachLink`
- `peerTypeOf`
- `useAttachBots`

## `js/src/web/chat-attach.js`

**Exports**

- `AttachButton`
- `AttachDialog`
- `DropHint`
- `canAttach`
- `isPicture`
- `pasteFiles`
- `sizeText`
- `useAttach`
- `useDropFiles`

## `js/src/web/chat-attached-button.js`

**Exports**

- `AttachedButton`
- `hasAttachedStickers`
- `registerAttachedDialog`
- `viewerStickers`

## `js/src/web/chat-attached-stickers.js`

**Exports**

- `AttachedStickers`

## `js/src/web/chat-automation.js`

An automation in the chat (R-Y86, R-Y87): its draft for this chat, the
next chat it fits once this one is done (with the user's edited text),
and the autopilot's line — where it is, the monitor, and Stop.

**Exports**

- `AutopilotBar`
- `DraftCard`
- `NextChatBar`
- `autopilotText`
- `useSecondsTo`

## `js/src/web/chat-boosts.js`

**Exports**

- `BoostsRow`
- `canSeeBoosters`
- `hasBoosts`
- `pickSlot`
- `progressOf`

## `js/src/web/chat-bot-commands.js`

**Exports**

- `CommandList`
- `appTarget`
- `matchCommands`
- `useBotCommands`
- `useCommandBox`

## `js/src/web/chat-bot-login.js`

**Exports**

- `isLoginLink`
- `openExternal`
- `openLoginLink`
- `requestBody`
- `setLoginDomains`
- `useBotLogin`
- `writeAllowedOf`

## `js/src/web/chat-bots.js`

**Exports**

- `BotButton`
- `InlineKeyboard`
- `KeyboardToggle`
- `ReplyKeyboard`
- `openButtonApp`
- `openableUrl`
- `useBotPress`
- `useReplyKeyboard`

## `js/src/web/chat-business-bots.js`

**Exports**

- `BotBar`
- `BotDialog`
- `KINDS`
- `botForm`
- `botProblem`
- `botUsername`

## `js/src/web/chat-business-common.js`

**Exports**

- `errorText`
- `useBusinessRead`
- `useSaving`

## `js/src/web/chat-business-hours.js`

**Exports**

- `HoursDialog`
- `startDays`

## `js/src/web/chat-business-link-open.js`

**Exports**

- `businessSlugOf`
- `openBusinessLink`
- `useBusinessLinks`

## `js/src/web/chat-business-links.js`

**Exports**

- `LinksDialog`
- `TEXT_MAX`
- `TITLE_MAX`
- `linkLabel`
- `linkProblem`

## `js/src/web/chat-business-place.js`

**Exports**

- `ADDRESS_MAX`
- `DESCRIPTION_MAX`
- `IntroDialog`
- `LocationDialog`
- `TITLE_MAX`
- `coordinate`
- `locationRequest`

## `js/src/web/chat-business-profile.js`

**Exports**

- `BusinessIntro`
- `BusinessProfile`
- `forgetBusiness`
- `hoursView`
- `useBusinessProfile`

## `js/src/web/chat-calendar.js`

**Exports**

- `countsOf`
- `monthKey`
- `nextOffset`
- `pageBefore`
- `useDayCounts`

## `js/src/web/chat-calls.js`

**Exports**

- `CallsButton`
- `CallsContent`
- `callWhen`

## `js/src/web/chat-channel-dm-thread.js`

**Exports**

- `DmThread`

## `js/src/web/chat-channel-dm.js`

**Exports**

- `ChannelDmRow`

## `js/src/web/chat-channel-limit.js`

**Exports**

- `InactiveChannels`
- `LimitHost`
- `dayOf`

## `js/src/web/chat-collectible.js`

**Exports**

- `CollectibleDialog`
- `CollectibleRows`

## `js/src/web/chat-comments-bar.js`

**Exports**

- `CommentsBar`
- `threadOf`

## `js/src/web/chat-comments.js`

**Exports**

- `useComments`

## `js/src/web/chat-common-chats.js`

**Exports**

- `CommonChatsRow`
- `hasCommonChats`
- `mergeCommon`
- `targetOf`

## `js/src/web/chat-contact-extras.js`

**Exports**

- `ContactExtras`
- `NOTE_MAX`
- `firstNameOf`
- `offersContactExtras`

## `js/src/web/chat-contact-share.js`

**Exports**

- `QrImage`
- `ShareContactDialog`

## `js/src/web/chat-contacts-edit.js`

**Exports**

- `AddContactDialog`
- `CloseFriendsDialog`
- `closeIds`
- `outcomeOf`
- `validForm`

## `js/src/web/chat-contacts-synced.js`

**Exports**

- `SyncedContacts`

## `js/src/web/chat-contacts-window.js`

**Exports**

- `ContactsDialog`
- `REFRESH_MS`
- `filterContacts`
- `mergeStatuses`
- `seenAt`
- `sortContacts`
- `statusLine`
- `useContactsWindow`

## `js/src/web/chat-create.js`

**Exports**

- `About`
- `Field`
- `FormDialog`
- `NewChat`
- `Picker`
- `Title`
- `errorText`
- `useContacts`

## `js/src/web/chat-days.js`

**Exports**

- `Calendar`
- `DayPill`
- `FloatingDay`
- `dayBreaks`
- `dayClosed`
- `dayKeyOf`
- `dayLabel`
- `dayStart`
- `monthCells`
- `monthEnds`
- `useDayJump`
- `useNewer`

## `js/src/web/chat-deleted.js`

**Exports**

- `DeletedBar`
- `deletedWhen`
- `hasDeletedApi`
- `useDeleted`

## `js/src/web/chat-drafts-clear.js`

**Exports**

- `ClearDrafts`
- `ConfirmPortal`
- `ConfirmedClear`
- `useDraftsSync`

## `js/src/web/chat-drag.js`

Selecting messages with the mouse, as Telegram Desktop does (R-Y68,
learned from `history_inner_widget.cpp`, never copied): press on a
message and drag to another, and every message between is selected
(taken away, when the drag began on a selected one). With nothing
selected, a press on the text selects text until the pointer leaves
the message; then it selects messages. A press beside a bubble selects
its message once the pointer moves a few pixels, as one with some
selected does (R-Y83). Rows meet edge to edge, as Desktop's do: a
press in the gap between two bubbles, or beside the column on a wide
window, is on the row at that height. Near the list's top or bottom
the list scrolls on. At most 100 are selected.

**Exports**

- `dragStarts`
- `edgeScroll`
- `rowAt`
- `useDragSelect`

## `js/src/web/chat-edit-mode.js`

**Exports**

- `EditBar`
- `editBody`
- `editOutcome`
- `editableText`
- `hasMedia`
- `useCaretAtEnd`
- `useEditMode`

## `js/src/web/chat-edit.js`

**Exports**

- `EditChat`
- `PhotoButtons`
- `canEditInfo`
- `uploadPhoto`
- `useEdited`

## `js/src/web/chat-effects.js`

Message effects in private chats, as Telegram Desktop and the mobile
apps have them (R-Y149; learned, never copied):
- A message sent with an effect shows its emoji by the time. When it
  first appears (a new message from the other side), or when the badge
  is clicked, the emoji bursts up over the page for a moment. Telegram's
  animation documents are not played: the emoji itself flies. With
  `prefers-reduced-motion` nothing flies.
- Send, right-clicked or long pressed, offers "Send with effect": a
  small panel of the effects Telegram has (./dom.js `telegramEffects`);
  a Premium-only one is locked unless the account has Premium. Picking
  one sends the box's text with it. The files' box (the dialog that
  sends attached files with a caption) offers the same on its Send
  button, and the effect goes with the first file or album (R-Y161).

**Exports**

- `EffectBadge`
- `EffectPanel`
- `autoplays`
- `canEffect`
- `emojiOf`
- `loadEffects`
- `playBurst`
- `reducedMotion`
- `resetEffects`
- `useEffectList`

## `js/src/web/chat-email-body.js`

**Exports**

- `EmailBody`
- `EmailTree`
- `emailBubble`

## `js/src/web/chat-emoji-custom.js`

**Exports**

- `CustomCell`
- `GridSection`
- `GroupEmojiSection`
- `GroupTabs`
- `InstalledSections`
- `PremiumNote`
- `customToken`
- `forgetCustomEmoji`
- `readRecentCustom`
- `saveJson`
- `storedJson`
- `useCustomData`
- `useCustomPanel`
- `useCustomTools`
- `withRecentCustom`

## `js/src/web/chat-emoji-status-search.js`

**Exports**

- `EmojiStatusSearch`

## `js/src/web/chat-emoji-status.js`

**Exports**

- `EmojiStatusDialog`
- `EmojiStatusRow`

## `js/src/web/chat-emoji-suggest.js`

**Exports**

- `colonWord`
- `suggestedEmoji`
- `useEmojiSuggest`

## `js/src/web/chat-emoji-tools.js`

**Exports**

- `useEmojiTools`

## `js/src/web/chat-emoji.js`

The emoji panel by the message box, as Telegram Desktop's (R-Y104;
learned, never copied): the smiley button opens it above the box; the
recently used ones first, then the categories (people, nature, food,
activity, travel, objects, symbols, flags) with a bar to jump between
them and a search by name. A pick goes in at the caret as typing does
(so Undo takes it back) and the panel stays open for more; Escape or a
click elsewhere closes it.

The emoji are Unicode's (./emoji-data.js, generated); the recent ones
stay in this browser. Other tabs (stickers and GIFs, ./chat-stickers.js)
come from the composer; the chosen tab is remembered.

Emoji that take a skin tone (R-Y114) carry a corner mark; a right click
or a press held ~0.4 s opens the six variants above it, and the tone
picked is remembered for that emoji, in the panel and in search.

Search finds emoji by Telegram's words for them in the page's
language (R-Y117; messages.getEmojiKeywords, through the server) when
a Telegram user account is there, then by their English names.

**Exports**

- `emojiCategories`
- `findByKeywords`
- `findEmoji`
- `forgetKeywords`
- `insertAtCaret`
- `itemsOfEmoticons`
- `jumpTo`
- `readTones`
- `rememberTone`
- `toneBases`
- `tonedForm`
- `useEmojiPanel`
- `useInView`
- `useKeywords`
- `withRecent`

## `js/src/web/chat-ephemeral.js`

**Exports**

- `EphemeralMark`
- `ephemeralFor`
- `placeEphemeral`
- `useEphemeral`

## `js/src/web/chat-export.js`

**Exports**

- `DEFAULT_FORM`
- `ExportDialog`
- `ExportMenu`
- `MEDIA_KINDS`
- `canExport`
- `feedExports`
- `formReady`
- `isRunning`
- `percentOf`
- `requestOf`
- `resetExports`
- `sizeText`
- `useExportFeed`

## `js/src/web/chat-fact-check.js`

**Exports**

- `FactCheck`
- `askFactCheck`
- `factOfRaw`
- `forgetFactChecks`

## `js/src/web/chat-failure.js`

Why a message or a draft did not go out, and when it is tried again,
in words (the composer, the notices, the autopilot's line).

**Exports**

- `failureText`
- `isPaidFailure`
- `waitingText`

## `js/src/web/chat-feed.js`

**Exports**

- `applyLinkEvents`
- `chatFeedFor`
- `createChatFeed`

## `js/src/web/chat-folder-edit.js`

**Exports**

- `FolderDelete`
- `FolderEditor`
- `FolderManager`
- `FolderTabMenu`
- `FoldersSettings`
- `tabDragStart`
- `useChatChoices`
- `useFolders`

## `js/src/web/chat-folder-live.js`

**Exports**

- `FOLDERS_LIVE_ID`
- `watchFolders`

## `js/src/web/chat-folder-model.js`

**Exports**

- `FOLDERS_CHANGED`
- `ICONS`
- `KINDS_IN`
- `KINDS_OUT`
- `TAG_COLORS`
- `TITLE_MAX`
- `addlistSlugOf`
- `announceFolders`
- `choicesOf`
- `draftOf`
- `draftProblem`
- `eligibleChats`
- `errorKey`
- `folderWrite`
- `freshSuggestions`
- `isTag`
- `letters`
- `movedOrder`
- `movedTo`
- `requestOf`
- `shareProblem`
- `withPick`

## `js/src/web/chat-folder-share.js`

**Exports**

- `AddlistHost`
- `ChatChecks`
- `LeaveFolder`
- `ShareFolder`
- `openAddlist`

## `js/src/web/chat-folder-tags.js`

**Exports**

- `ColorRow`
- `FolderTags`
- `FolderTagsToggle`
- `TAGS_MAX`
- `tagMap`

## `js/src/web/chat-folder-updates.js`

**Exports**

- `FolderUpdatesBar`
- `UPDATES_REFRESH_MS`
- `folderIdOfKey`
- `updatableFolders`
- `useChatlistUpdates`

## `js/src/web/chat-folders.js`

Telegram's chat folders above the chat list (R-Y103; Telegram
Desktop's and Telegram for macOS's folder tabs, learned, never
copied). The folders come from the server (../sources/
telegram-folders.js); which chats are in one is decided here, from
the chat list, as Telegram's apps decide it:

- a chat the folder excludes by name is never in it;
- one it includes or pins by name always is;
- otherwise its kind must be one the folder takes (contacts, other
  people, groups, channels, bots), and it must not be muted, read or
  archived when the folder leaves those out.

A folder's pinned chats come first, in its own order. "All" is last
by default, or first by an app preference; with no folders the list keeps
its own tabs (all, private, groups, channels).

**Exports**

- `FOLDER_ALL_FIRST_KEY`
- `chatsInFolder`
- `folderKey`
- `folderMatcher`
- `folderTabs`
- `isFolderFilter`
- `peopleOf`
- `unreadChats`
- `useAllFirst`
- `useFolderTools`
- `useTelegramFolders`

## `js/src/web/chat-follow.js`

**Exports**

- `OlderRow`
- `UnreadLine`
- `addedAfter`
- `followMove`
- `useFollow`
- `useKeepPlace`
- `useOlder`
- `useSeen`

## `js/src/web/chat-format-bar.js`

**Exports**

- `FORMAT_BUTTONS`
- `useFormatBar`

## `js/src/web/chat-forum-view.js`

**Exports**

- `ForumViewMenu`
- `stripForum`
- `useForumView`

## `js/src/web/chat-forward.js`

**Exports**

- `ForwardBar`
- `hasCaption`
- `senderNames`
- `stageForward`
- `useForwardStage`

## `js/src/web/chat-games.js`

**Exports**

- `GameCard`
- `gameUrl`
- `hasGameScores`
- `hasPlayButton`
- `isGameMessage`
- `playButton`
- `useGameScores`

## `js/src/web/chat-gestures.js`

A message's touch gestures, as in Telegram Web A (R-Y67,
`useContextMenuHandlers.ts`, `useOuterHandlers.ts`): a long press opens
its menu, a swipe to the left replies to it, a double tap reacts with
the default reaction. A move cancels the press; a mostly-vertical move
is the list scrolling, never a swipe.

**Exports**

- `DOUBLE_TAP_MS`
- `LONG_PRESS_MS`
- `SWIPE_REPLY_PX`
- `swipeOffset`
- `useTouchGestures`

## `js/src/web/chat-gift-code-button.js`

**Exports**

- `GiftCodeCard`
- `GiftCodeLine`

## `js/src/web/chat-gift-manage.js`

**Exports**

- `GiftDialog`
- `Rarity`
- `errorText`

## `js/src/web/chat-gift-unique.js`

**Exports**

- `GiftCodeDialog`
- `GiftHost`
- `UniqueViewer`

## `js/src/web/chat-giveaway.js`

**Exports**

- `GiveawayCard`
- `GiveawayDetails`
- `GiveawayResultsCard`

## `js/src/web/chat-global.js`

**Exports**

- `GlobalResults`
- `MessageRow`
- `marked`
- `openFoundMessage`
- `useGlobalSearch`

## `js/src/web/chat-group-stickers.js`

**Exports**

- `GroupSetRows`
- `GroupSetSection`
- `aside`
- `canSetGroupStickers`
- `setNameOf`
- `useGroupSets`
- `useRedrawOn`

## `js/src/web/chat-history-load.js`

**Exports**

- `watchChatHistory`

## `js/src/web/chat-info.js`

**Exports**

- `infoLine`
- `useChatInfo`

## `js/src/web/chat-inline-bots.js`

**Exports**

- `InlinePanel`
- `canInline`
- `layoutOf`
- `mergeResults`
- `parseInline`
- `useInlineBox`

## `js/src/web/chat-instant-view-open.js`

**Exports**

- `instantTargetOf`
- `ivLinkTarget`
- `onInstantView`
- `openInstantView`
- `openInstantViewLink`
- `rememberInstantUrl`

## `js/src/web/chat-instant-view-render.js`

**Exports**

- `Blocks`
- `Inline`
- `linkOf`

## `js/src/web/chat-instant-view.js`

**Exports**

- `InstantViewHost`
- `errorKey`

## `js/src/web/chat-invite-links.js`

**Exports**

- `EXPIRIES`
- `InviteLinksActions`
- `LIMITS`
- `bodyOf`
- `expireOf`
- `hasInviteLinks`
- `usageText`

## `js/src/web/chat-invite.js`

**Exports**

- `InviteHost`
- `InviteLink`
- `LIMIT_EVENT`
- `hasInviteLink`
- `inviteHashOf`
- `isTooMany`
- `openInvite`
- `useEsc`

## `js/src/web/chat-join-requests.js`

**Exports**

- `Failed`
- `JoinedList`
- `MoreButton`
- `PersonRow`
- `RequestsBar`
- `RequestsDialog`
- `errorText`
- `hasInviteRights`
- `requestsLinkOf`
- `requestsShown`
- `useImporters`

## `js/src/web/chat-jump.js`

**Exports**

- `arrivalStep`
- `goToMessage`
- `mergeNewer`
- `underCeiling`
- `useArrival`
- `useReplyReturns`
- `useStreamJumps`
- `useWindowJump`

## `js/src/web/chat-leaving.js`

**Exports**

- `LEAVE_MS`
- `closePlace`
- `keepLeaving`
- `leaveMs`
- `useLeaving`

## `js/src/web/chat-left-channels.js`

**Exports**

- `LeftChannelsButton`
- `LeftChannelsDialog`

## `js/src/web/chat-link-open.js`

**Exports**

- `forgetResolved`
- `useMessageLinks`

## `js/src/web/chat-link-preview.js`

**Exports**

- `choiceOf`
- `linkOf`
- `useLinkPreview`

## `js/src/web/chat-list-menu.js`

**Exports**

- `MUTE_FOR`
- `REMOVAL`
- `RemoveChatDialog`
- `chatMenuItems`
- `chatMenuRequest`
- `useChatListMenu`

## `js/src/web/chat-list.js`

**Exports**

- `ArchiveHead`
- `ArchiveItem`
- `ChatAvatar`
- `ChatItem`
- `chatPreview`

## `js/src/web/chat-live-locations.js`

**Exports**

- `LiveLocationsBar`
- `useLiveShares`

## `js/src/web/chat-live.js`

**Exports**

- `applyLinkEvents`
- `useComposer`
- `useLiveLinks`
- `useOutboxQueue`

## `js/src/web/chat-manage.js`

**Exports**

- `ManageRows`
- `canDestroy`
- `canLook`

## `js/src/web/chat-marks.js`

**Exports**

- `UnreadMarks`
- `useUnreadMarks`

## `js/src/web/chat-media.js`

**Exports**

- `MAP_SHOT`
- `MediaAudio`
- `MediaCard`
- `MediaFile`
- `MediaSticker`
- `MediaVideo`
- `Poster`
- `clockOf`
- `mapLink`
- `sizeOf`
- `useAudio`
- `useMapUrl`
- `useNearView`
- `useUrl`
- `videoMode`

## `js/src/web/chat-members.js`

**Exports**

- `Members`
- `hasMembers`

## `js/src/web/chat-message-stats.js`

**Exports**

- `hasMessageStats`
- `postLink`
- `useMessageStats`
- `useReadersWithStats`

## `js/src/web/chat-message.js`

**Exports**

- `DeleteDialog`
- `ForwardPicker`
- `MessageBubble`
- `MsgAvatar`
- `MsgContextMenu`
- `PinDialog`
- `QUICK_REACTIONS`
- `QuoteContext`
- `ReplyQuote`
- `ServiceLine`
- `mediaLabel`
- `menuPlace`
- `quotedName`
- `quotedText`

## `js/src/web/chat-model.js`

**Exports**

- `CHAT_FILTERS`
- `CHAT_SORTS`
- `DAY_GROUPS`
- `archiveSummary`
- `avatarFor`
- `byTime`
- `chatKey`
- `chatKind`
- `chatMenuAutomations`
- `chatMessages`
- `cloudDraft`
- `dayGroup`
- `deliveryStatus`
- `filterChats`
- `firstUnreadId`
- `folderChats`
- `groupChats`
- `networkMessageId`
- `readInboxUpTo`
- `readUpTo`
- `senderNames`
- `sortChats`
- `summarizeChats`
- `typingStatus`
- `unreadCount`
- `unreadMarks`

## `js/src/web/chat-moderation.js`

**Exports**

- `ConvertGigagroup`
- `ModerateDialog`
- `ModerationBoxes`
- `NotSpam`
- `TransferDialog`
- `TransferOwnership`
- `answerText`
- `canConvert`
- `canTransfer`
- `deleteModeration`
- `errorText`
- `moderationOptions`

## `js/src/web/chat-music-save.js`

**Exports**

- `isSongMessage`
- `useMusicSave`

## `js/src/web/chat-notify-settings.js`

**Exports**

- `ChatNotifyDialog`
- `NotifyButton`
- `NotifyRow`
- `hasNotifySettings`
- `muteLine`

## `js/src/web/chat-notify-sound.js`

**Exports**

- `SoundPicker`
- `soundOptions`

## `js/src/web/chat-notify.js`

**Exports**

- `FRESH_MS`
- `NOTIFY_KEY`
- `NOTIFY_PREVIEW_KEY`
- `TITLE_COUNT_KEY`
- `freshChats`
- `notificationOf`
- `notifyAllowed`
- `readPref`
- `titled`
- `unreadTotal`
- `useNotifications`
- `usePref`
- `writePref`

## `js/src/web/chat-outbox.js`

**Exports**

- `DRAFTS_KEY`
- `OUTBOX_KEY`
- `afterFailure`
- `cascade`
- `keptDrafts`
- `nextToSend`
- `readSaved`
- `requeueFailed`
- `restoreOutbox`
- `retryDelay`
- `waitsForNetwork`
- `writeSaved`

## `js/src/web/chat-paid-earnings.js`

**Exports**

- `PaidEarnings`
- `isPerson`

## `js/src/web/chat-paid-send.js`

**Exports**

- `mayCharge`
- `usePaidSend`

## `js/src/web/chat-paid.js`

**Exports**

- `Balance`
- `PaidMedia`
- `PaidReactionChip`
- `useBalance`

## `js/src/web/chat-passcode.js`

**Exports**

- `LocalPasscode`
- `passcodeProblem`

## `js/src/web/chat-peer-actions.js`

**Exports**

- `PeerActions`
- `PeerBar`
- `ReportDialog`

## `js/src/web/chat-person-extras.js`

**Exports**

- `BirthdayRow`
- `BirthdaysBlock`
- `PersonalChannelCard`
- `ProfileFrame`
- `headerStyle`
- `usePalettes`
- `useProfileTint`
- `whenText`

## `js/src/web/chat-photo-editor.js`

**Exports**

- `PhotoEditor`

## `js/src/web/chat-photo.js`

A photo in a message: the blurred preview at once, the photo itself
once it comes near the screen, and the full one in a viewer on a
click. It has its own size, from the photo's proportions, as in
Telegram (at most PHOTO_MAX_PX wide, a tall one at least
PHOTO_MIN_PX); in an album it fills its tile (./chat-album.js).

**Exports**

- `MediaPhoto`
- `PHOTO_MAX_PX`
- `PhotoViewer`
- `photoBox`
- `photoBytes`

## `js/src/web/chat-pin-drag.js`

Dragging a pinned chat up or down among the pinned chats, as Telegram
Desktop lets the user (R-Y159; learned, never copied): press on a
pinned row and move the pointer a few pixels — a touch or a pen holds
for a moment first, so the list still scrolls — and the row lifts and
follows the pointer while the rows it passes slide aside, leaving a
gap where it would land. Letting go drops it there; Escape or a
cancelled pointer puts it back. Pointer events, so a mouse, a finger
and a pen all work.

The same gesture reorders the folder tabs (sideways) and the rows of
Settings → Folders (R-Y172): `options` name the rows and the axis.

**Exports**

- `beginPinGesture`
- `dropIndex`
- `slideOf`

## `js/src/web/chat-pin-order.js`

Reordering the pinned chats in the chat list (R-Y159; learned from
Telegram Desktop, never copied). The pinned chats sit on top in
Telegram's own order (their pinned rank, never their date). A pinned
chat is dragged to a new place (chat-pin-drag.js), or moved one place
with "Move up" / "Move down" in its context menu (the Menu key or
Shift+F10 opens it from the keyboard). The new order shows at once and
goes to Telegram (messages.reorderPinnedDialogs, folder 0 or the
Archive's 1); if Telegram refuses, the old order comes back with a
short notice. Unpinned chats cannot be dragged.

**Exports**

- `applyOrder`
- `moveKey`
- `pinnedKeys`
- `reorderRequest`
- `usePinnedOrder`

## `js/src/web/chat-pinned.js`

**Exports**

- `PinnedBar`
- `hiddenKey`
- `mayUnpin`
- `mergePinned`
- `readHidden`
- `writeHidden`

## `js/src/web/chat-pip.js`

**Exports**

- `PipButton`
- `inPip`
- `pipModeOf`
- `togglePip`
- `usePip`

## `js/src/web/chat-poll-create.js`

**Exports**

- `Check`
- `LIMITS`
- `PollDialog`
- `canPoll`
- `canSendMedia`
- `pollBody`
- `useMediaCreate`
- `usePollCreate`

## `js/src/web/chat-poll.js`

A poll, a quiz and a checklist in a chat, as Telegram's apps have them
(R-Y74; ./poll-parts.js reads them):

- Not voted yet: a circle per answer (a box when several may be
  chosen). One answer votes at once; several are ticked, then Vote.
- Voted, or closed: each answer's share (whole percents adding up to
  100), a bar, and a tick on ours; a quiz shows the right answer in
  green and a wrong pick of ours in red, with its explanation (💡).
- Its kind ("Anonymous Poll", "Quiz", "Final results"), the last
  voters' photos in a public poll, the time left when it closes by
  itself, and "N votes" — or View results, who voted for what.
- Telegram sends a poll's results only to who asks: a poll on screen
  asks for them now and then (POLL_REFRESH_MS), as Desktop does.
- A checklist: a box per task, ticked by whoever did it.

Retract vote and Stop poll are in the message's menu
(./chat-selection.js).

**Exports**

- `Checklist`
- `POLL_REFRESH_MS`
- `Poll`
- `PollVotersDialog`
- `StopPollDialog`
- `pollKindKey`

## `js/src/web/chat-prepared-share.js`

**Exports**

- `PreparedShare`
- `usePreparedShare`

## `js/src/web/chat-privacy-paid.js`

**Exports**

- `PRICE_MAX`
- `PaidMessagesSetting`
- `priceOf`

## `js/src/web/chat-privacy.js`

**Exports**

- `PrivacyDialog`
- `errorText`
- `visibleKeys`

## `js/src/web/chat-private-call.js`

**Exports**

- `CallButton`
- `PrivateCallHost`
- `usePrivateCall`

## `js/src/web/chat-profile-extras.js`

**Exports**

- `BirthdayEditor`
- `ColorEditor`
- `ProfileExtrasDialog`
- `colorBody`
- `sameColor`
- `writesOf`

## `js/src/web/chat-profile.js`

**Exports**

- `MyProfile`
- `maskPhone`
- `useUsernameCheck`

## `js/src/web/chat-public-link.js`

**Exports**

- `PublicLinkDialog`
- `canSetType`
- `errorText`
- `nameOfInput`
- `publicNameOf`

## `js/src/web/chat-quick-reaction.js`

**Exports**

- `QuickReactionPicker`
- `forgetQuickReaction`
- `quickPick`
- `useQuickReaction`
- `useRowReactions`

## `js/src/web/chat-reactions.js`

**Exports**

- `ChatReactionsScope`
- `DEFAULT_REACTIONS`
- `ReactionsAction`
- `allowedReactions`
- `hasReactions`
- `settingOf`
- `useAllowedReactions`
- `useChatReactions`

## `js/src/web/chat-read-time.js`

**Exports**

- `ReadTimeLine`
- `forgetReadTimes`
- `hasReadTime`
- `readTimeLine`

## `js/src/web/chat-readers.js`

**Exports**

- `Frame`
- `canReportReaction`
- `hasReactors`
- `hasReaders`
- `reactionsOf`
- `useAnswer`
- `useReaders`

## `js/src/web/chat-remote-media.js`

**Exports**

- `RemoteAttachments`

## `js/src/web/chat-replies-block.js`

**Exports**

- `blockBody`
- `useBlockFromReplies`

## `js/src/web/chat-replies.js`

**Exports**

- `missingReplies`
- `useReplyTargets`

## `js/src/web/chat-report.js`

**Exports**

- `reportIds`
- `useReport`

## `js/src/web/chat-request-peer.js`

**Exports**

- `canRequestPeer`
- `requestErrorText`
- `togglePicked`
- `useRequestPeer`

## `js/src/web/chat-rich-message.js`

**Exports**

- `RichMessage`
- `richButton`

## `js/src/web/chat-round-record.js`

**Exports**

- `MAX_ROUND_MS`
- `MIN_ROUND_MS`
- `ROUND_SIDE`
- `canRecordRound`
- `roundFileName`
- `roundSeconds`
- `roundTimer`
- `roundTypeOf`
- `squareCrop`
- `useRoundVideo`

## `js/src/web/chat-round.js`

**Exports**

- `MediaRound`
- `RING_LENGTH`
- `nextMode`
- `ringDash`
- `roundProgress`

## `js/src/web/chat-row.js`

**Exports**

- `useRowHandlers`

## `js/src/web/chat-saved-gifs.js`

**Exports**

- `useSavedGifs`

## `js/src/web/chat-saved-tags.js`

**Exports**

- `SavedTagBar`
- `SavedTagResults`
- `TITLE_MAX`
- `reactionGlyph`
- `reactionKey`
- `useSavedTags`

## `js/src/web/chat-saved.js`

**Exports**

- `SavedChats`
- `SavedToggle`
- `isSavedChat`
- `pinnedFirst`
- `reorderPinned`
- `savedBubbles`
- `shiftPinned`
- `useSavedView`

## `js/src/web/chat-schedule.js`

The Send button's menu and scheduled messages, as Telegram Desktop's
(R-Y102; learned, never copied):

- A right click (or a long press) on Send: "Send without sound" (the
  other side gets no sound) and "Schedule message" — a day and a time,
  from a minute to a year ahead; Telegram holds the message and sends
  it then.
- A chat with scheduled messages shows a clock by the message box with
  their count; it opens them, the soonest first, by day: each can be
  sent now, moved to another time or deleted.

Telegram user accounts only, as files are (./chat-attach.js); a file's
Send button has the same menu.

R-Y197 (learned, never copied): in a private chat with a person whose
last seen is visible the menu also has "Send when online" — a
`schedule_date` of 0x7FFFFFFE, shown in the list as "When online". In
Saved Messages the same feature is "Set a reminder" and the list is
"Reminders".

**Exports**

- `MAX_AHEAD_MS`
- `MIN_AHEAD_MS`
- `ScheduleDialog`
- `ScheduledButton`
- `ScheduledList`
- `SendMenu`
- `WHEN_ONLINE`
- `canSchedule`
- `canSendWhenOnline`
- `firstGuess`
- `inputsOf`
- `isReminderChat`
- `isWhenOnline`
- `linkWhenOnline`
- `schedulable`
- `sendMenuItems`
- `timeOf`
- `useScheduled`
- `useSendMenu`

## `js/src/web/chat-search.js`

**Exports**

- `SearchBar`
- `SearchButton`
- `localMatches`
- `useChatSearch`

## `js/src/web/chat-security-extras.js`

**Exports**

- `LoginEmail`
- `Passkeys`
- `SecurityExtras`

## `js/src/web/chat-security-forgot.js`

**Exports**

- `Ask`
- `ForgotPassword`
- `Over`
- `ResetNotice`
- `dateText`

## `js/src/web/chat-security.js`

**Exports**

- `ACCOUNT_MONTHS`
- `AccountTtl`
- `SESSION_DAYS`
- `SensitiveContent`
- `SessionSwitches`
- `SessionTtl`
- `TwoStep`
- `daysOfMonths`
- `errorText`
- `monthsOfDays`
- `passwordProblem`
- `useSecurity`

## `js/src/web/chat-selection.js`

Message menu and selection as Telegram Desktop has them (R-Y67, R-Y68).

The menu (HistoryInner::showContextMenu) lists, with nothing selected:
Reply (Quote & Reply when part of the text is selected), Edit,
Pin/Unpin, Retract Vote and Stop Poll on a poll (R-Y74), Save As… and
Copy Image on a photo (Save As… on a sticker),
Copy Text (Copy Selected Text), Copy Link on a link else Copy Message
Link (Copy Post Link in a channel), Forward, Delete, Select. While
messages are selected it lists, on one of them: Reply, Copy Selected
as Text, Forward Selected, Delete Selected, Unpin Selected, Clear
Selection; on another: Reply, Select, Select up to this message.

Selecting: "Select" picks a message; once some are picked a click
anywhere on a row picks or drops it, and a drag from one row to
another picks (or drops, when it began on a picked one) every row
between — at most 100. A drag that leaves the message it began in
turns a text selection into a selection of messages. The chat's top
bar then shows FORWARD n, DELETE n and CANCEL; Esc clears, Ctrl/Cmd+C
copies, Delete asks to delete. Several messages copy as Desktop's
do: "[date time] Name: text", one a line.

Learned from the official clients, never copied (see
docs/CHAT-REFERENCES.md): tdesktop `history_inner_widget.cpp`,
`history_item_text.cpp`, `history_view_top_bar_widget.cpp`.

**Exports**

- `ConversationHeader`
- `MAX_SELECTED`
- `REPLIES_CHAT`
- `SelectionTop`
- `applyDrag`
- `bulkSelect`
- `canBlockFromReplies`
- `canEdit`
- `canReport`
- `copyStamp`
- `isMine`
- `isProtected`
- `menuItems`
- `messageLink`
- `quoteOf`
- `rangeOf`
- `selectedTextIn`
- `selectionText`
- `toggleSelected`
- `useSelection`
- `useSelectionKeys`

## `js/src/web/chat-send-as.js`

**Exports**

- `canChooseSendAs`
- `sendAsField`
- `sendAsOf`
- `useSendAs`

## `js/src/web/chat-send-gift.js`

**Exports**

- `SendGiftRow`
- `canSendGift`

## `js/src/web/chat-service-line.js`

**Exports**

- `ServiceLine`

## `js/src/web/chat-settings.js`

**Exports**

- `SettingsAction`
- `hasSettings`
- `linkedGroup`
- `noForwardsIn`
- `paidStarsOf`
- `settingValue`

## `js/src/web/chat-share.js`

**Exports**

- `ContactDialog`
- `LIVE_CHOICES`
- `LocationDialog`
- `MAX_ACCURACY`
- `ShareDialog`
- `canShare`
- `filterContacts`
- `parseCoordinate`
- `placeBody`
- `placeLabel`
- `positionErrorKey`
- `shareErrorText`
- `typedContactBody`
- `useShare`

## `js/src/web/chat-shared.js`

**Exports**

- `ProfileHead`
- `SHARED_ORDER`
- `SharedMedia`
- `linksIn`
- `useSharedCounts`
- `useSharedList`

## `js/src/web/chat-sidebar.js`

**Exports**

- `NOTICE`
- `Sidebar`
- `noticeInWords`

## `js/src/web/chat-sign-in-code.js`

**Exports**

- `useSignInCodeWarning`

## `js/src/web/chat-similar-bots.js`

**Exports**

- `SimilarBots`
- `hasSimilarBots`

## `js/src/web/chat-similar.js`

**Exports**

- `Card`
- `Preview`
- `SimilarChannels`
- `hasSimilar`
- `similarTarget`

## `js/src/web/chat-stars.js`

**Exports**

- `GiftsRow`
- `StarsDialog`
- `giftKey`
- `hasGifts`

## `js/src/web/chat-state.js`

**Exports**

- `chatFromHash`
- `defaultConfirm`
- `emptyChat`
- `hintChat`
- `mergeTyping`
- `openChat`
- `runNotice`
- `shownAutopilot`
- `useChatState`
- `useLoaded`

## `js/src/web/chat-stats.js`

**Exports**

- `GraphCard`
- `StatsRow`
- `formatStars`
- `formatUsd`
- `hasBotRevenue`
- `hasStats`

## `js/src/web/chat-sticker-box.js`

A sticker set's box, as Telegram Desktop's (R-Y124; learned, never
copied): a click on a sticker in a chat opens a dialog with the set's
title and its stickers; a click on one sends it to the open chat and
closes the box; the button below adds the set ("Add 12 stickers") or,
for one the user has, removes it ("Remove 12 stickers"). Escape or a
click outside closes it. The set is named by the sticker's own
attribute in the stored message (its id and access hash, or its short
name); the stickers come through the server like the panel's.

Also the question asked before a set is removed from the panel.

**Exports**

- `MediaStickerBox`
- `Overlay`
- `RemoveSetDialog`
- `StickerSetBox`
- `stickerSetOf`
- `useEscape`

## `js/src/web/chat-sticker-settings.js`

**Exports**

- `StickerSettingsDialog`

## `js/src/web/chat-sticker-trending.js`

**Exports**

- `FeaturedSets`

## `js/src/web/chat-stickers.js`

Stickers and GIFs in the emoji panel, as Telegram Desktop's (R-Y105;
learned, never copied). The Stickers tab: the favourite stickers, the
recently sent ones, then each of the user's sets, each set's stickers
asked as the list comes to it, with a bar of the sets below to jump
between them. The GIFs tab: the saved GIFs, playing while on screen. A
click sends the sticker or GIF to the chat at once (as a reply, when
one is being written) and closes the panel.

A search box over each tab (R-Y112): an emoji or words find stickers
and sticker sets, the user's or not; words find GIFs as Telegram's
apps do (its @gif bot), more as the list is scrolled to its end.

A right click on a sticker or GIF (R-Y115), as Telegram Desktop's: send
it without sound, schedule it, add a sticker to the favourites or take
it off them, take it off the recent ones, save a GIF or delete it from
the saved ones.

A set found that is not the user's has an Add button by its title
(R-Y116), as Desktop's: it joins the user's sets.

An installed set's title has a Remove button (R-Y124): after an
in-page question the set leaves the user's sets. A click on a sticker
in a chat opens the set's box instead (./chat-sticker-box.js).

Only for a Telegram chat of a user account; the pictures come through
the server (/api/telegram/sticker), never from Telegram to the page.

**Exports**

- `AddSet`
- `GifsTab`
- `Grid`
- `Note`
- `Picture`
- `Section`
- `SetSection`
- `SetThumb`
- `StickersTab`
- `canStickers`
- `forgetGifs`
- `forgetStickers`
- `stickerMenuItems`
- `useStickerTabs`
- `watchGifs`

## `js/src/web/chat-suggest.js`

**Exports**

- `useComposerText`
- `useSuggestionsFor`

## `js/src/web/chat-tab-scroll.js`

**Exports**

- `useSelectedTab`

## `js/src/web/chat-tags.js`

**Exports**

- `TagSearchHost`
- `openTagSearch`
- `parseTag`
- `requestOf`
- `scopesOf`

## `js/src/web/chat-theme-model.js`

**Exports**

- `cssColour`
- `previewOf`
- `readableOn`
- `settingsFor`
- `themeVars`
- `whiteTextFill`

## `js/src/web/chat-theme.js`

**Exports**

- `ChatThemeAction`
- `forgetThemes`
- `rememberTheme`
- `themeEmoticon`
- `useChatTheme`

## `js/src/web/chat-todo-create.js`

**Exports**

- `TodoDialog`
- `changedTodo`
- `todoBody`
- `useTodoCreate`

## `js/src/web/chat-top-peers.js`

**Exports**

- `TopPeersSection`
- `useTopPeers`

## `js/src/web/chat-topic-admin.js`

**Exports**

- `ForumToggle`
- `TopicClosedBar`
- `editBody`
- `pinnedTopicIds`
- `reorderedPins`
- `topicClosedFor`
- `topicDragStart`
- `topicMenuItems`
- `topicRequest`
- `topicRights`
- `useTopicAdmin`

## `js/src/web/chat-topics.js`

**Exports**

- `TOPICS_REFRESH_MS`
- `TopicTabs`
- `shownTopics`
- `topicColor`
- `topicMessages`
- `useForumTopics`
- `viewedChat`

## `js/src/web/chat-transcribe.js`

**Exports**

- `ASK_AGAIN_MS`
- `Transcribable`
- `TranscribeButton`
- `TranscriptText`
- `clearTranscripts`
- `feedTranscripts`
- `transcriptOf`
- `trialNote`
- `useTranscribe`
- `useTranscriptFeed`

## `js/src/web/chat-translate-bar.js`

**Exports**

- `TranslateBar`
- `TranslateSettings`
- `languageName`

## `js/src/web/chat-translate.js`

**Exports**

- `LANGUAGES`
- `SUMMARY_MIN`
- `hasSummary`
- `hasTranslation`
- `startLanguage`
- `useTranslate`

## `js/src/web/chat-translation-switch.js`

**Exports**

- `TranslationSwitch`
- `canSwitchTranslations`
- `forgetTranslationSwitches`
- `switchTranslations`
- `translationsOff`
- `useTranslationSwitches`

## `js/src/web/chat-ttl.js`

**Exports**

- `TTL_MAIN`
- `TTL_MORE`
- `TtlActions`
- `TtlBadge`
- `TtlChoices`
- `hasTtl`
- `periodOf`
- `periodShort`
- `periodWords`
- `useTtlPeriod`

## `js/src/web/chat-usernames.js`

**Exports**

- `ProfileUsernames`
- `UsernamesAction`
- `UsernamesEditor`

## `js/src/web/chat-view.js`

**Exports**

- `ChatScreen`
- `ChatView`
- `addedAfter`
- `autopilotText`
- `failureText`
- `followMove`
- `messageRuns`
- `noticeInWords`
- `reasonText`
- `waitingText`

## `js/src/web/chat-views.js`

**Exports**

- `MAX_BATCH`
- `REFRESH_MS`
- `VIEW_GAP_MS`
- `ViewCount`
- `applyItems`
- `countsViews`
- `createViewBatcher`
- `resetViews`
- `statsOf`
- `useLiveStats`

## `js/src/web/chat-voice-chat.js`

**Exports**

- `VoiceChatBar`

## `js/src/web/chat-voice-hooks.js`

**Exports**

- `useCall`
- `useParticipants`
- `useVoiceSession`

## `js/src/web/chat-voice-panel.js`

**Exports**

- `Notify`
- `VoiceChatPanel`

## `js/src/web/chat-voice.js`

**Exports**

- `LOCK_DISTANCE`
- `MAX_VOICE_MS`
- `MIN_VOICE_MS`
- `WAVEFORM_SIZE`
- `canRecord`
- `levelOf`
- `recordedText`
- `releasedInside`
- `useVoice`
- `waveformOf`

## `js/src/web/chat-wallpaper.js`

**Exports**

- `BACKGROUND_KEY`
- `ChatBackgroundSettings`
- `ChatWall`
- `ChatWallpaperAction`
- `WallLayer`
- `WallpaperGrid`
- `pictureData`
- `rememberOwn`
- `setBackground`
- `useBackground`

## `js/src/web/chat-web-apps.js`

**Exports**

- `SANDBOX`
- `openWebApp`
- `serverBody`
- `useWebAppHost`

## `js/src/web/chat-webpage.js`

**Exports**

- `WebPreview`

## `js/src/web/chat-window.js`

**Exports**

- `CAPTCHA_HOLD_MS`
- `PAGE_SIZE`
- `PREFETCH_SIZE`
- `STALL_MS`
- `askVkOlder`
- `createRefill`
- `firstTimeOf`
- `hasOlder`
- `historyComplete`
- `isStalled`
- `mergePage`
- `retryDelay`
- `useChatWindow`
- `useMoreChats`
- `usePrefetch`
- `windowMessages`

## `js/src/web/client-log.js`

**Exports**

- `errorEntry`
- `installClientLog`
- `mediaRouteOf`
- `traceClient`

## `js/src/web/client.js`

Offline-first SPA client.

Wraps `{ store, server }` so callers can write/read links without
caring whether a server is reachable. The contract:

  - Every write goes to the *local* store first (durable in
    IndexedDB / localStorage) and emits a subscribe event so views
    re-render immediately, with no round-trip lag.
  - When a server is connected the same write replicates over the
    /ws sync transport (vector-clock CRDT — no read-your-write
    surprises). Reads on the server are still useful for derived
    queries (autocomplete, audience, search) which are computed on
    the server side; the client falls back to local equivalents
    when offline.

The client emits a `mode-change` event when it transitions between
"online" (server reachable + sync attached) and "offline" (no
server) so the UI can surface a visible badge.

**Exports**

- `createBuildWatch`
- `createOfflineClient`
- `createRediscovery`

## `js/src/web/cloud-theme-model.js`

**Exports**

- `CLOUD_THEME_KEY`
- `CLOUD_VARS`
- `addthemeSlugOf`
- `applicable`
- `cardLook`
- `cleanChoice`
- `cleanTheme`
- `cloudVars`
- `modeOf`

## `js/src/web/cloud-themes.js`

**Exports**

- `AddthemeHost`
- `CloudThemeSettings`
- `applyCloudTheme`
- `forgetCloudTheme`
- `openThemeLink`
- `resetCloudTheme`
- `useApplyCloudTheme`
- `useCloudTheme`

## `js/src/web/connection-guide.js`

**Exports**

- `ConnectionGuide`
- `ConnectionsConnectFirstCta`
- `LocalServerHelp`
- `isCrossOrigin`

## `js/src/web/connection-guides.js`

**Exports**

- `applyLocalServerOverride`
- `buildProbeHeaders`
- `buildProbeUrl`
- `connectionGuides`
- `credentialsFromLinks`
- `getGuide`
- `getProvider`
- `hasRequiredCredentials`
- `hasSavedCredentials`
- `interpolate`
- `isCrossOrigin`
- `listGuideSections`
- `localServerHelp`
- `networkName`
- `providerCatalogue`
- `tryDirect`

## `js/src/web/connection-prefs.js`

**Exports**

- `BROWSER_ONLY_KEY`
- `CONNECTED_KEY`
- `TELEGRAM_CONNECTED_KEY`
- `rememberServerConnection`
- `rememberTelegramConnection`
- `useBrowserOnlyOffer`
- `useConnectionHistory`

## `js/src/web/connections/browser-sign-ins.js`

**Exports**

- `BrowserSignIns`
- `listOf`
- `serviceName`

## `js/src/web/connections/email-pull.js`

**Exports**

- `EmailPullRow`

## `js/src/web/connections/fetch-now.js`

**Exports**

- `FETCHABLE`
- `FetchNow`
- `pullMessage`

## `js/src/web/connections/github-inbox.js`

**Exports**

- `GithubInbox`

## `js/src/web/connections/github-notifications.js`

**Exports**

- `GithubNotifications`
- `unreadNotifications`

## `js/src/web/connections/hash.js`

**Exports**

- `connectionHash`
- `parseConnectionHash`

## `js/src/web/connections/index.js`

**Exports**

- `ConnectionDetail`
- `ConnectionsList`
- `ProviderAutoImport`
- `ProviderConnectionControls`
- `classifyConnectionState`

## `js/src/web/connections/popularity.js`

**Exports**

- `byPopularity`
- `formatUsers`
- `serviceUsers`

## `js/src/web/connections/recommended.js`

**Exports**

- `RecommendedHeader`

## `js/src/web/connections/setup-steps.js`

**Exports**

- `providerSetupSteps`

## `js/src/web/connections/telegram-qr-login.js`

**Exports**

- `QR_POLL_MS`
- `QrCode`
- `QrPanel`
- `useQrPolling`

## `js/src/web/connections/telegram-sessions.js`

**Exports**

- `TelegramLoginForm`
- `TelegramSessionsPanel`
- `VerifiedMark`
- `announceConnected`

## `js/src/web/connections/whatsapp-web.js`

**Exports**

- `WhatsAppWebPanel`

## `js/src/web/contact-links.js`

**Exports**

- `ContactLinkHost`
- `contactLinkOf`
- `openContactLink`
- `openProfileOf`
- `useProfileRequest`

## `js/src/web/contacts-import.js`

**Exports**

- `ContactsImport`

## `js/src/web/contacts-live.js`

**Exports**

- `CONTACTS_REFRESH_MS`
- `useContactsRevision`
- `watchContacts`

## `js/src/web/custom-emoji.js`

**Exports**

- `CustomEmoji`

## `js/src/web/cv-view.js`

**Exports**

- `CvScreen`
- `CvView`
- `clientFailure`

## `js/src/web/dialog-focus.js`

**Exports**

- `focusablesIn`
- `installDialogFocus`

## `js/src/web/discover.js`

Server autodiscovery for the SPA.

The directive: "All apps must use WebRTC + WebSockets to connect to
the local links server (it can be in localhost or in local network,
we need to make sure we have a way to autodetect it, and configure
manually if everything failed)."

Strategy, tried in order until one returns a healthy `/api/status`:
  1. Same origin (when the SPA was *served* by the server itself —
     e.g. http://localhost:8787/. This is the GitHub Pages and
     "open the bundled index.html in a browser" case if a server
     happens to be reachable on the same origin).
  2. A previously-saved override stored under `metaServer` in the
     injected `storage` (localStorage in the browser).
  3. Runtime shell candidates injected by Electron/Capacitor WebViews.
  4. A short list of common local ports on 127.0.0.1 — over https
     too from an https page: Safari blocks http://127.0.0.1 there but
     reaches a server whose certificate it trusts (R-Y64).
  5. A list of LAN candidates if the page knows them (passed in).

Returns `{ origin: string }` for the first reachable server, or
`null` when none answered. Callers use `null` to mean "go fully
offline, only the local browser store is available".

The function takes `{ fetchImpl, storage, candidates, signal }` so
it is fully unit-testable in plain Node (no DOM globals required).

**Exports**

- `BEACON_PATH`
- `BEACON_WIDTH`
- `DEFAULT_PORTS`
- `DISCOVERY_PATH`
- `clearServerOverride`
- `discoverServer`
- `findServerByPicture`
- `mayNeedPicture`
- `pictureSays`
- `saveServerOverride`

## `js/src/web/discovery-shell.js`

## `js/src/web/disk-banner.js`

**Exports**

- `DiskBanner`
- `diskNotice`
- `useHealth`

## `js/src/web/dom-telegram-calls.js`

**Exports**

- `TELEGRAM_CALLS`

## `js/src/web/dom.js`

**Exports**

- `api`
- `findNearbyServer`
- `h`
- `resetServerBinding`
- `serverPostConfirmed`

## `js/src/web/download/copy.js`

Strings for the download landing page (issue #37), in the four
locales the SPA ships (`js/src/web/locales/`). Kept separate from
the SPA dictionaries so the page loads without React or the app
bundle. Missing keys fall back to English (`translate` in
`model.js`).

**Exports**

- `COPY`
- `LOCALE_NAMES`

## `js/src/web/download/downloads.js`

Desktop download catalogue (issue #37) — the single source of truth
for desktop release asset names.

The same list drives three things, so they can never drift apart:
  - the download landing page (`js/src/web/download/`), which maps a
    GitHub release to per-platform download buttons;
  - `js/scripts/validate-desktop-assets.mjs`, which the desktop
    release workflow runs before and after uploading assets;
  - `desktop/electron-builder.config.cjs`, whose `artifactName`
    templates produce exactly these names (after
    `js/scripts/normalize-desktop-artifacts.mjs`).

Pure ES module with no DOM or Node imports: it runs in the browser
and in Node/Bun/Deno tests alike.

**Exports**

- `ARTIFACT_PREFIX`
- `CHECKSUM_ASSET_NAME`
- `DOWNLOAD_OPTIONS`
- `PLATFORMS`
- `PROVENANCE_ASSET_NAME`
- `RELEASES_API`
- `RELEASES_URL`
- `REPOSITORY`
- `UPDATE_METADATA_ASSETS`
- `assetHref`
- `assetNameFor`
- `detectPlatform`
- `detectPlatformPrecise`
- `expectedReleaseAssets`
- `groupByPlatform`
- `missingAssets`
- `pickDesktopRelease`
- `primaryOptionFor`
- `releaseVersion`
- `resolveDownloads`

## `js/src/web/download/model.js`

Download landing page logic (issue #37) without the DOM: locale
choice, labels, release loading and the view model `page.js`
renders. Pure ES module, so the tests run it under Node, Bun and
Deno.

**Exports**

- `DEFAULT_LOCALE`
- `LOCALES`
- `LOCALE_STORAGE_KEY`
- `MACOS_QUARANTINE_COMMAND`
- `RELEASE_CACHE_KEY`
- `RELEASE_CACHE_TTL_MS`
- `SERVER_COMMANDS`
- `assetMeta`
- `buildViewModel`
- `formatSize`
- `loadDesktopRelease`
- `optionLabel`
- `pickLocale`
- `platformLabel`
- `translate`

## `js/src/web/download/page.js`

Download landing page (issue #37): renders `model.js` view models
into `index.html`. No framework and no build step, so the page is
served as-is from GitHub Pages at `/download/` and stays usable when
the app bundle is not loaded.

## `js/src/web/download/verify.js`

In-browser checksum check for the download page (issue #37): hash a
downloaded installer with WebCrypto and compare it to its line in
the release's SHA256SUMS.txt. Nothing leaves the browser.

**Exports**

- `checksumForFile`
- `sha256Hex`
- `verifyChecksum`

## `js/src/web/effects.js`

**Exports**

- `EFFECTS_KEY`
- `EFFECTS_MODES`
- `detectSlowRendering`
- `frameIntervals`
- `isSlowRendering`
- `probeFrames`
- `resolveEffects`
- `setEffectsMode`
- `useApplyEffects`
- `useEffectsSetting`
- `whenSettled`

## `js/src/web/emoji-data.js`

**Exports**

- `EMOJI_CATEGORIES`
- `EMOJI_TONES`

## `js/src/web/emoji-status-model.js`

**Exports**

- `DURATIONS`
- `activeStatus`
- `statusOfLink`
- `untilOf`

## `js/src/web/emoji-status.js`

**Exports**

- `EmojiStatus`

## `js/src/web/entity-extras.js`

**Exports**

- `EXTRA_KINDS`
- `extraFields`
- `formattedDateText`

## `js/src/web/forum-topics.js`

A forum group's topics, as Telegram's apps tell them apart (R-Y122;
learned, never copied): a message belongs to the topic its reply
header names (`forum_topic`, the topic's first message as
`reply_to_top_id`, or `reply_to_msg_id` when it answers that one); the
message that opened a topic is that topic's own; anything else is in
General, topic 1. Shared by the server's chat index and the page.

**Exports**

- `GENERAL_TOPIC`
- `TOPIC_COLORS`
- `composerReplyId`
- `inTopicOnly`
- `splitTopicKey`
- `topicKey`
- `topicOfMessage`
- `topicReplyId`

## `js/src/web/gif-id.js`

**Exports**

- `gifIdOf`

## `js/src/web/gift-manage-model.js`

**Exports**

- `GIFT_EVENT`
- `availability`
- `backdropStyle`
- `giftActions`
- `giftCodeCardOf`
- `giftCodeSlugOf`
- `giftLinkOf`
- `giftRef`
- `openGiftCode`
- `openGiftLink`
- `openUniqueGift`
- `pinnedAfter`
- `priceWords`
- `rarityWords`
- `transferWaits`

## `js/src/web/giveaway-model.js`

**Exports**

- `audienceWords`
- `channelChat`
- `countryName`
- `dateText`
- `giveawayOf`
- `giveawayResultsOf`
- `prizeWords`
- `serviceWords`

## `js/src/web/greetings-view.js`

**Exports**

- `GreetingsScreen`
- `GreetingsView`
- `clientFailure`
- `offeredStickers`
- `stickerKey`

## `js/src/web/i18n.js`

**Exports**

- `DEFAULT_LOCALE`
- `LOCALE_STORAGE_KEY`
- `LocaleContext`
- `applyLocale`
- `availableLocales`
- `detectInitialLocale`
- `formatChatTime`
- `formatDateTime`
- `formatTime`
- `sentence`
- `translate`
- `useDates`
- `useLocale`
- `useLocaleContext`
- `useT`

## `js/src/web/icons.js`

**Exports**

- `Icon`
- `iconNames`

## `js/src/web/language-switcher.js`

**Exports**

- `LanguageSwitcher`

## `js/src/web/live-clock.js`

**Exports**

- `useNowSeconds`

## `js/src/web/live-follow.js`

**Exports**

- `LIVE_MOVED_M`
- `LIVE_UPDATE_MS`
- `distanceMeters`
- `followedLive`
- `isLiveStopped`
- `liveEnd`
- `markLiveStopped`
- `onLiveStopped`
- `positionBody`
- `shouldUpdateLive`

## `js/src/web/live-place.js`

**Exports**

- `activeShares`
- `canStopLive`
- `distanceParts`
- `headingDegrees`
- `leftLine`
- `liveActive`
- `liveLines`
- `shareOf`
- `timeLeft`

## `js/src/web/live-watch.js`

**Exports**

- `useLiveWatch`

## `js/src/web/locales/en-chat-account.js`

**Exports**

- `enChatAccount`

## `js/src/web/locales/en-chat-more.js`

**Exports**

- `enChatMore`

## `js/src/web/locales/en-chat.js`

**Exports**

- `enChat`

## `js/src/web/locales/en-folders.js`

**Exports**

- `enFolders`

## `js/src/web/locales/en-github.js`

**Exports**

- `enGithub`

## `js/src/web/locales/en-transcribe.js`

**Exports**

- `enTranscribe`

## `js/src/web/locales/en.js`

**Exports**

- `en`

## `js/src/web/locales/hi-chat-account.js`

**Exports**

- `hiChatAccount`

## `js/src/web/locales/hi-chat-more.js`

**Exports**

- `hiChatMore`

## `js/src/web/locales/hi-chat.js`

**Exports**

- `hiChat`

## `js/src/web/locales/hi-folders.js`

**Exports**

- `hiFolders`

## `js/src/web/locales/hi-github.js`

**Exports**

- `hiGithub`

## `js/src/web/locales/hi-transcribe.js`

**Exports**

- `hiTranscribe`

## `js/src/web/locales/hi.js`

**Exports**

- `hi`

## `js/src/web/locales/index.js`

**Exports**

- `DEFAULT_LOCALE`
- `availableLocales`
- `dictionaries`

## `js/src/web/locales/ru-chat-account.js`

**Exports**

- `ruChatAccount`

## `js/src/web/locales/ru-chat-more.js`

**Exports**

- `ruChatMore`

## `js/src/web/locales/ru-chat.js`

**Exports**

- `ruChat`

## `js/src/web/locales/ru-folders.js`

**Exports**

- `ruFolders`

## `js/src/web/locales/ru-github.js`

**Exports**

- `ruGithub`

## `js/src/web/locales/ru-transcribe.js`

**Exports**

- `ruTranscribe`

## `js/src/web/locales/ru.js`

**Exports**

- `ru`

## `js/src/web/locales/zh-chat-account.js`

**Exports**

- `zhChatAccount`

## `js/src/web/locales/zh-chat-more.js`

**Exports**

- `zhChatMore`

## `js/src/web/locales/zh-chat.js`

**Exports**

- `zhChat`

## `js/src/web/locales/zh-folders.js`

**Exports**

- `zhFolders`

## `js/src/web/locales/zh-github.js`

**Exports**

- `zhGithub`

## `js/src/web/locales/zh-transcribe.js`

**Exports**

- `zhTranscribe`

## `js/src/web/locales/zh.js`

**Exports**

- `zh`

## `js/src/web/lottie-sticker.js`

An animated sticker (Telegram's `.tgs`: a Lottie animation, gzipped)
played as Telegram's apps play them (R-Y113): looping while on screen,
still on its first frame when off it or when the system asks for less
motion. Drawn as SVG by lottie-web's light player (no `eval`, no
workers, so the app's content policy stands). Until it is ready — or
when it cannot be read — what is under it (the sticker's picture)
shows.

**Exports**

- `LottieSticker`
- `forgetLottie`
- `lottieText`

## `js/src/web/marketplace-accounts.js`

**Exports**

- `MarketplaceAccounts`

## `js/src/web/media-loading.js`

**Exports**

- `LoadingImage`
- `LoadingPlayer`
- `MediaLoading`
- `useMediaReady`
- `useMediaSource`

## `js/src/web/media-src.js`

**Exports**

- `crossOriginFor`
- `mediaSrc`
- `saveUrl`

## `js/src/web/message-links.js`

**Exports**

- `channelChat`
- `onMessageLink`
- `openMessageLink`
- `parseMessageLink`

## `js/src/web/message-parts.js`

**Exports**

- `attachmentMedia`
- `decodeWaveform`
- `forwardKey`
- `gameOf`
- `parseMedia`
- `parseMessageParts`
- `replyLinkId`
- `serviceInfo`
- `strippedJpegDataUrl`

## `js/src/web/message-text.js`

**Exports**

- `BankCard`
- `DateEntity`
- `MessageText`
- `hrefOf`
- `textTree`

## `js/src/web/nav-items.js`

**Exports**

- `navItems`

## `js/src/web/navigation-counts.js`

**Exports**

- `callKey`
- `missedCallCount`
- `navigationCounts`
- `useNavigationCounts`
- `usePublishChatFeed`

## `js/src/web/notice.js`

**Exports**

- `Notice`
- `reasonText`

## `js/src/web/notify-rules.js`

**Exports**

- `NO_RULES`
- `exceptionState`
- `getNotifyRules`
- `loadNotifyRules`
- `rulesFrom`
- `scopeOf`
- `setNotifyRules`
- `shouldNotify`
- `showPreview`
- `subscribeNotifyRules`
- `withChat`
- `withScope`

## `js/src/web/notify-sound.js`

**Exports**

- `SOUND_KEY`
- `chimeWav`
- `forgetRingtones`
- `playNotifySound`
- `soundOf`

## `js/src/web/operator-model.js`

**Exports**

- `completeOperatorChat`
- `needsAttention`
- `operatorEligible`
- `operatorQueue`
- `operatorReadMax`
- `operatorRevision`

## `js/src/web/operator-order.js`

**Exports**

- `OPERATOR_ORDER_KEY`
- `postponeOperatorChat`
- `readOperatorOrder`
- `useOperatorOrder`

## `js/src/web/operator-prefs.js`

**Exports**

- `DEFAULT_OPERATOR_SCOPE`
- `OPERATOR_SCOPE_KEY`
- `readOperatorScope`
- `setOperatorScope`
- `useOperatorScope`

## `js/src/web/operator-unread.js`

**Exports**

- `useOperatorUnread`

## `js/src/web/operator-view.js`

**Exports**

- `OperatorView`

## `js/src/web/operator-work.js`

**Exports**

- `OPERATOR_WORK_KEY`
- `finishOperatorWork`
- `readOperatorWork`
- `retainOperatorWork`
- `useOperatorWork`

## `js/src/web/outbox-context.js`

**Exports**

- `OutboxContext`

## `js/src/web/outbox-host.js`

**Exports**

- `OutboxHost`

## `js/src/web/paid-portal.js`

**Exports**

- `overPage`

## `js/src/web/paid-send.js`

**Exports**

- `DECLINED`
- `PAID_PREFS_KEY`
- `SEND_CALLS`
- `bindPaid`
- `chatOf`
- `countOf`
- `createGate`
- `guardApi`
- `isSilenced`
- `paidGate`
- `readPrefs`
- `silenced`
- `textParts`
- `totalOf`

## `js/src/web/panel-resize.js`

**Exports**

- `PanelDivider`

## `js/src/web/passcode.js`

**Exports**

- `AUTO_LOCK_CHOICES`
- `LOCKED_EVENT`
- `LOCK_NOW`
- `LockScreen`
- `PASSCODE_CHANGED`
- `idleExpired`
- `isLockKey`
- `secondsOf`
- `useLocalLock`

## `js/src/web/passkey-codec.js`

**Exports**

- `attestationPayload`
- `b64urlToBytes`
- `bytesToB64url`
- `creationOptions`
- `passkeyErrorKey`
- `passkeysSupported`

## `js/src/web/pattern-worker.js`

## `js/src/web/patterns-wasm.js`

**Exports**

- `createWasmPatternMatcher`
- `instantiateWasmPatternMatcher`
- `wasmPatternSourceSupported`

## `js/src/web/peer-avatar.js`

**Exports**

- `AVATAR_SLOTS`
- `PeerAvatar`
- `takeSlot`

## `js/src/web/peer-color.js`

**Exports**

- `PEER_COLORS`
- `peerColorClass`
- `peerColorIndex`

## `js/src/web/person-panel.js`

**Exports**

- `PersonPanel`
- `telegramChatUrl`
- `usePersonLearned`

## `js/src/web/photo-editor-model.js`

**Exports**

- `COLORS`
- `FULL`
- `MIN_CROP_PX`
- `RATIOS`
- `SIZES`
- `TOOLS`
- `addStroke`
- `arrowHead`
- `canRedo`
- `canUndo`
- `cropPixels`
- `extendStroke`
- `fitRatio`
- `flipHorizontal`
- `handlesFor`
- `initialEdit`
- `isEditable`
- `isEdited`
- `isMark`
- `moveCrop`
- `newStroke`
- `outputName`
- `outputType`
- `pushHistory`
- `ratioOf`
- `redoHistory`
- `resizeCrop`
- `rotateLeft`
- `setCrop`
- `startHistory`
- `turnedSize`
- `undoHistory`

## `js/src/web/photo-editor-render.js`

**Exports**

- `fitBox`
- `paintTurned`
- `renderEdited`

## `js/src/web/poll-parts.js`

A poll and a checklist as Telegram's apps show them (R-Y74), from the
stored `messageMediaPoll` / `messageMediaToDo` (layer 225).

- An answer's `option` is bytes, stored as base64 (R-Y28): it is what
  a vote names.
- Results come apart from the poll: `chosen` (our vote), `correct` (a
  quiz's right answer, known once we answered or it closed), `voters`
  per answer and `totalVoters`.
- Shares are whole percents adding up to 100, as Telegram Desktop
  shows them (largest remainders), when each voter chose one answer.

**Exports**

- `TODO_LIMITS`
- `canAppendTasks`
- `canRetract`
- `canStop`
- `nicePercents`
- `parsePoll`
- `parseTodo`
- `peerKeyOf`
- `pollOfMessage`
- `showsResults`
- `taskProblem`
- `tasksOf`

## `js/src/web/privacy-prefs.js`

**Exports**

- `READ_RECEIPTS_KEY`
- `SHARE_TYPING_KEY`
- `readReadReceipts`
- `readShareTyping`
- `useReadReceipts`
- `useShareTyping`
- `writeReadReceipts`
- `writeShareTyping`

## `js/src/web/private-call-model.js`

**Exports**

- `FRESH_MS`
- `LINK_ID`
- `callLinkOf`
- `canCall`
- `elapsedSeconds`
- `endedText`
- `failureKey`
- `isLive`
- `ringsOut`
- `shownCall`
- `statusKey`
- `timerText`

## `js/src/web/profile-extras-model.js`

**Exports**

- `DEFAULT_PROFILE_COLORS`
- `ageOf`
- `birthYears`
- `birthdayDate`
- `birthdayOfForm`
- `colorsOf`
- `daysIn`
- `formOfBirthday`
- `gradientOf`
- `isBirthdayToday`
- `monthName`
- `sameBirthday`

## `js/src/web/profile-music.js`

**Exports**

- `MusicRow`
- `hasMusic`

## `js/src/web/profile-stories-model.js`

**Exports**

- `catalogueOrder`
- `giftText`
- `storiesInOrder`
- `storyChat`
- `topIds`
- `trackLine`

## `js/src/web/profile-stories.js`

**Exports**

- `ProfileStoriesRow`
- `hasProfileStories`

## `js/src/web/proxy-model.js`

**Exports**

- `PROXY_EVENT`
- `openProxyDialog`
- `openProxyLink`
- `parseProxyLink`
- `portOf`
- `secretLooksRight`
- `validHost`

## `js/src/web/qr-code.js`

A small QR code encoder for the Telegram sign-in by QR code (R-Y203;
written from ISO/IEC 18004, no dependency).

Byte mode only (UTF-8), error correction level L or M, versions 1 to 10
(up to 271 bytes at L, 213 at M), which is plenty for `tg://login?token=…`
(about 70 characters). Pieces, all pure:
  Reed-Solomon over GF(256) (polynomial 0x11D), the data split into
  blocks and interleaved, the function patterns (finders, timing,
  alignment, format and version information), the zig-zag data
  placement, the eight masks scored by the four penalty rules.

  encodeQr(text, { ecc: 'M' }) -> { version, size, mask, ecc, modules }
    modules[row][col] is true for a dark module.
  qrPath(modules, quiet) -> one SVG path `d` of all dark modules
  qrSvg(text, options) -> a whole `<svg>` string

**Exports**

- `MAX_VERSION`
- `byteCapacity`
- `dataOrder`
- `encodeQr`
- `formatBits`
- `functionMask`
- `generator`
- `gfMul`
- `interleave`
- `penalty`
- `qrPath`
- `qrSvg`
- `rsEncode`
- `syndrome`
- `versionBits`

## `js/src/web/quick-replies-model.js`

**Exports**

- `CATEGORIES`
- `DAYS`
- `EVERYONE`
- `NAME`
- `NO_ONE`
- `SPECIAL`
- `errorText`
- `forgetQuickReplies`
- `formOf`
- `fromLocalInput`
- `isPerson`
- `nameProblem`
- `quickCommands`
- `reachesAnyone`
- `requestOf`
- `scheduleOf`
- `toLocalInput`
- `useQuickReplies`
- `withCategory`
- `withPerson`

## `js/src/web/quick-replies.js`

**Exports**

- `QuickRepliesDialog`

## `js/src/web/read-retry.js`

**Exports**

- `READ_RECOVERED_EVENT`
- `createRetryingRead`

## `js/src/web/rich-math.js`

**Exports**

- `cachedMath`
- `loadKatex`
- `mathMl`

## `js/src/web/rich-message-model.js`

**Exports**

- `fileKey`
- `quoteRichText`
- `richFiles`
- `richOf`
- `wordsOf`

## `js/src/web/rich-service-model.js`

**Exports**

- `richServiceWords`

## `js/src/web/rich-text-nodes.js`

**Exports**

- `Formula`
- `richKindNode`

## `js/src/web/schema-banner.js`

**Exports**

- `SchemaBanner`
- `schemaTooNew`

## `js/src/web/server-availability.js`

**Exports**

- `createAvailability`

## `js/src/web/server-transport.js`

**Exports**

- `trackServerStream`
- `useBrowserOnline`
- `useServerReconnecting`

## `js/src/web/service-texts.js`

**Exports**

- `WORDED_ACTIONS`
- `fillParams`
- `moneyText`
- `periodOf`
- `serviceTextInfo`

## `js/src/web/settings-confirm.js`

**Exports**

- `ConfirmDialog`

## `js/src/web/settings-fields.js`

**Exports**

- `Check`
- `SelectField`

## `js/src/web/settings-media.js`

**Exports**

- `MediaSettings`
- `limitLabel`

## `js/src/web/settings-notify-extras.js`

**Exports**

- `FROM`
- `ReactionNotifySettings`
- `ResetNotifications`

## `js/src/web/settings-notify.js`

**Exports**

- `TelegramNotifySettings`

## `js/src/web/settings-proxy.js`

**Exports**

- `ProxyHost`
- `ProxySettings`
- `formFromLink`
- `formOf`
- `saveBody`

## `js/src/web/settings-scale.js`

**Exports**

- `ScaleSettings`

## `js/src/web/settings-sounds.js`

**Exports**

- `SoundSettings`
- `ringtoneProblem`

## `js/src/web/settings-storage.js`

**Exports**

- `KINDS`
- `MAX_GB`
- `OLDER_DAYS`
- `StorageSettings`
- `bytesText`

## `js/src/web/settings-view.js`

**Exports**

- `AppearanceSettings`
- `FolderTabSettings`
- `NotificationSettings`
- `OperatorSettings`
- `PrivacySettings`
- `SettingsView`
- `StoriesSettings`

## `js/src/web/shell/app-shell.js`

**Exports**

- `AppShell`
- `COMPACT_MAX`
- `COMPACT_PRIMARY`
- `MEDIUM_MAX`
- `classifyViewport`

## `js/src/web/shortcuts.js`

**Exports**

- `SHORTCUT_GROUPS`
- `ShortcutsButton`
- `ShortcutsDialog`
- `ShortcutsHost`
- `focusListSearch`
- `neighbour`
- `runShortcut`
- `savedChat`
- `shortcutOf`
- `unreadNeighbour`
- `useChatShortcuts`

## `js/src/web/sign-in-code-guard.js`

**Exports**

- `CODE_DECLINED`
- `bindCodeAsk`
- `codesIn`
- `createCodeGate`
- `guardCodes`
- `pageCodeGate`
- `sharedCodes`

## `js/src/web/spinner.js`

Loading, as Telegram's apps show it (R-Y84): an arc that turns while
it grows and shrinks (Desktop's InfiniteRadialAnimation, Web A's
Spinner; learned, never copied).

- `Spinner` — the arc, at the size of the text around it, or `large`.
- `PageLoading` — a page (or a pane) still loading: the arc in its
  middle, shown after a moment so a quick load does not flash.
- `Busy` — a line of text with the arc before it ("Updating…").
- `ChatListSkeleton` — the chat list's rows before they come, as Web A
  draws them: a round avatar and two lines, shimmering.

A button that is working says so with `aria-busy="true"`: app.css puts
the arc in it.

**Exports**

- `Busy`
- `ChatListSkeleton`
- `PageLoading`
- `Spinner`

## `js/src/web/stars-model.js`

**Exports**

- `PAID_MAX`
- `canAfford`
- `clampPaid`
- `paidOf`
- `paidReactionOf`
- `rowLabel`
- `signedStars`
- `sourceKey`
- `starsText`

## `js/src/web/stats-graph.js`

**Exports**

- `changeOf`
- `formatChange`
- `formatCompact`
- `formatNumber`
- `formatPercent`
- `formatX`
- `isHourly`
- `layoutGraph`
- `nearestIndex`
- `niceTicks`
- `parseGraph`
- `percentOf`
- `shareRows`
- `tooltipOf`
- `xRatio`
- `xTickIndexes`

## `js/src/web/sticker-settings-model.js`

**Exports**

- `countKey`
- `moveItem`
- `orderIds`

## `js/src/web/stories-model.js`

**Exports**

- `LIKE`
- `NO_STEALTH`
- `PHOTO_MS`
- `STEALTH_ACTIVE_S`
- `STEALTH_COOLDOWN_S`
- `STORY_REACTIONS`
- `agoParts`
- `clockText`
- `hasUnread`
- `hiddenPeers`
- `joinViews`
- `markSeen`
- `mergePeers`
- `nextPosition`
- `orderStrip`
- `previousPosition`
- `reactionAfter`
- `ringOf`
- `setHidden`
- `showMs`
- `startIndex`
- `stealthAfter`
- `stealthStatus`
- `unreadPeers`
- `viewersBody`
- `visiblePeers`
- `withFreshCounts`

## `js/src/web/stories-pref.js`

**Exports**

- `STORIES_ENABLED_KEY`
- `useStoriesEnabled`

## `js/src/web/stories.js`

**Exports**

- `StoriesStrip`
- `StoryViewerHost`
- `useStories`

## `js/src/web/story-actions.js`

**Exports**

- `ConfirmDelete`
- `OwnFoot`
- `ReactionButtons`
- `ReplyBox`
- `StoryMenu`
- `ViewersPanel`

## `js/src/web/story-extras.js`

**Exports**

- `StealthBadge`
- `StealthDialog`
- `StoryReport`
- `ViewersFilters`
- `ViewersTabs`
- `useViewsRefresh`

## `js/src/web/story-manage-model.js`

**Exports**

- `captionForEdit`
- `editBody`
- `editProblem`
- `editedStory`
- `manageError`
- `manageKeys`
- `manageLabel`

## `js/src/web/story-manage.js`

**Exports**

- `ManageLayer`
- `StoryEditDialog`
- `manageEntries`
- `useStoryManage`

## `js/src/web/story-post-model.js`

**Exports**

- `CAPTION_MAX`
- `DEFAULT_PERIOD`
- `MAX_VIDEO_SECONDS`
- `PERIOD_CHOICES`
- `PRIVACY_CHOICES`
- `captionLimit`
- `errorKey`
- `kindOf`
- `lengthOf`
- `limitOf`
- `postBody`
- `problemOf`

## `js/src/web/story-post.js`

**Exports**

- `AddBadge`
- `Choices`
- `SelectedContacts`
- `StoryPostHost`
- `useStoryPost`

## `js/src/web/story-viewer.js`

**Exports**

- `StoryViewer`

## `js/src/web/telegram-account-scope.js`

**Exports**

- `ACCOUNT_HEADER`
- `ACCOUNT_KEY`
- `ACCOUNT_PARAM`
- `activeAccount`
- `scopedForExtra`
- `scopedUrl`
- `setActiveAccount`

## `js/src/web/telegram-online.js`

**Exports**

- `ModeBadge`
- `badgeOf`
- `useTelegramReach`

## `js/src/web/telegram-status.js`

**Exports**

- `telegramStatusFor`

## `js/src/web/text-shortcuts.js`

Formatting shortcuts in the composer and the edit box, as Telegram
Desktop's (R-Y101): the selection is wrapped in the markdown the
server sends as Telegram's formatting (../sources/telegram-format.js).

  Ctrl/Cmd+B bold          Ctrl/Cmd+I italic
  Ctrl/Cmd+U underline
  Ctrl/Cmd+Shift+X strike  Ctrl/Cmd+Shift+M monospace
  Ctrl/Cmd+Shift+P spoiler Ctrl/Cmd+K link
  Ctrl/Cmd+Shift+N plain text (the selection's formatting removed)

Keys go by their place (`code`), so they work in any keyboard layout.
The change goes in as typing does, so Undo takes it back.

**Exports**

- `applyFormat`
- `formatEdit`
- `formatOfKey`
- `formatShortcut`

## `js/src/web/translate-detect.js`

**Exports**

- `detectLanguage`
- `foreignLanguage`

## `js/src/web/translate-store.js`

**Exports**

- `SKIP_LANGUAGES_KEY`
- `TRANSLATE_CHATS_KEY`
- `closeBar`
- `failureOfChat`
- `forgetTranslateStore`
- `isClosed`
- `missingIds`
- `setTranslateChats`
- `showOriginal`
- `showTranslated`
- `shownLanguage`
- `skipLanguage`
- `skippedLanguages`
- `translateBatch`
- `translateChatsOn`
- `translatedItem`
- `useTranslateStore`
- `useTranslated`

## `js/src/web/tutorial-clear.js`

**Exports**

- `clearOnce`
- `freeBand`
- `placedClear`
- `useClearOfCard`

## `js/src/web/tutorial-follow.js`

**Exports**

- `followLayout`
- `isTall`
- `pageRectOf`
- `screenRectOf`
- `targetFrame`
- `useCardPlacement`
- `useResettle`

## `js/src/web/tutorial-placement.js`

**Exports**

- `ARROW_INSET`
- `GAP`
- `MARGIN`
- `choosePlacement`
- `intersects`

## `js/src/web/tutorial-start.js`

**Exports**

- `anyConnection`
- `shouldAutoOpen`
- `startIndex`
- `useAnyConnection`

## `js/src/web/tutorial.js`

**Exports**

- `SERVICE_EXAMPLES`
- `SPOTLIGHT_ANCHOR_ATTR`
- `TARGET_WAIT_MS`
- `TUTORIAL_PROVIDER_KEY`
- `TUTORIAL_STORAGE_KEY`
- `TUTORIAL_VERSION`
- `TutorialButton`
- `TutorialOverlay`
- `TutorialSpotlight`
- `clearPreference`
- `defaultSteps`
- `findTutorialRect`
- `findTutorialTarget`
- `localizeSteps`
- `navigationFor`
- `placeMatches`
- `readPlace`
- `readPreference`
- `readProgressIndex`
- `rememberProvider`
- `rememberedProvider`
- `stepIndexFromPreference`
- `useSpotlightAnchor`
- `useTutorialPreference`
- `useTutorialRect`
- `useTutorialTarget`
- `writeCompletedPreference`
- `writePreference`
- `writeProgressPreference`

## `js/src/web/ui-scale.js`

**Exports**

- `DEFAULTS`
- `SCALES`
- `TEXT_SIZE`
- `UI_SCALE_KEY`
- `applyUiScale`
- `chatFontSize`
- `factorOf`
- `keyDirection`
- `readUiScale`
- `setUiScale`
- `settingsFrom`
- `stepScale`
- `useApplyUiScale`
- `useUiScale`
- `writeUiScale`

## `js/src/web/use-redraw.js`

**Exports**

- `useRedrawOn`

## `js/src/web/usernames-model.js`

**Exports**

- `activeOrder`
- `arranged`
- `hasExtra`
- `linkOf`
- `movedActive`
- `toggledName`

## `js/src/web/views.js`

**Exports**

- `AudienceView`
- `AutomationView`
- `BackupView`
- `BroadcastView`
- `CallsView`
- `ChatView`
- `ContactsView`
- `FactsView`
- `OperatorView`
- `OutreachView`
- `PatternsView`
- `ProfileView`
- `RepliesView`
- `StatusView`
- `navItems`
- `openContactChat`
- `views`

## `js/src/web/vk-captcha.js`

**Exports**

- `VkCaptchaDialog`
- `askVkCaptcha`

## `js/src/web/voice-chat-model.js`

**Exports**

- `callLinkOf`
- `isScheduled`
- `isSpeaking`
- `kindKey`
- `marksOf`
- `mayUnmute`
- `mergedCall`
- `mergedPages`
- `sortedParticipants`

## `js/src/web/voice-chat-sdp.js`

**Exports**

- `audioPayloads`
- `joinParamsOf`
- `nextSources`
- `remoteSdpOf`
- `signed`
- `unsigned`

## `js/src/web/voice-chat-session.js`

**Exports**

- `createVoiceSession`
- `watchLevel`

## `js/src/web/voice-ogg.js`

**Exports**

- `FLAG_BOS`
- `FLAG_EOS`
- `oggPages`
- `opusPacketSamples`
- `voiceDuration`
- `webmToOgg`

## `js/src/web/wallpaper-css.js`

**Exports**

- `backgroundVars`
- `choiceOf`
- `cleanChoice`
- `gradientCss`
- `layerKind`
- `patternLook`
- `sameChoice`

## `js/src/web/web-app-loading.js`

**Exports**

- `WEB_APP_LOAD_TIMEOUT_MS`
- `WebAppLoading`
- `useWebAppProgress`

## `js/src/web/web-apps-model.js`

**Exports**

- `KNOWN_EVENTS`
- `MAX_DATA`
- `PROLONG_MS`
- `appUrl`
- `buttonShown`
- `hexOf`
- `initialPanel`
- `originOf`
- `outgoing`
- `panelAfter`
- `parseAppLink`
- `readBridgeMessage`
- `startProlong`
- `tgLinkOf`
- `themeParamsOf`
- `viewportOf`

## `js/src/web/web-mode-banner.js`

**Exports**

- `WebModeBanner`

## `js/src/web/web-mode.js`

**Exports**

- `DISMISS_STORAGE_KEY`
- `DOWNLOAD_PAGE_URL`
- `isSafari`
- `runtimeOf`
- `webModeNotice`

## `js/src/web/webpage-kind.js`

**Exports**

- `webpageKindOf`

## `js/src/web/webrtc-sync.js`

Browser-side WebRTC sync wiring.

The SPA already replicates writes over `/ws` when a server is
reachable. This module adds a *peer-to-peer* WebRTC data channel
alongside that path so two browsers can talk without the server
relaying every message (R-J7).

Wire-up:
  1. Open a browser `WebSocket` to `/rtc?room=<room>` on the
     discovered server. The signaling broker fans JSON frames to
     everyone else in the same room.
  2. Wrap that WebSocket in a `signalingChannel` so SDP / ICE
     messages are typed.
  3. Construct `createWebRtcTransport({ initiator: false, ... })` —
     both peers start as followers. When a `peer-joined` event
     arrives (meaning a *new* peer just entered the room behind
     us), we know we're the existing one so we call
     `transport.startAsInitiator()` to send the offer. The newcomer
     sees the offer first and answers it; no race.
  4. Plug the transport into `createPeer(store).connect(transport)`
     so every local write fans out over the data channel and
     remote writes flow into the local store.

The room defaults to `default`; production deployments that want
tenant isolation can set it from the URL or a config endpoint.

`secret:*` links are filtered by `createPeer` itself — they never
traverse this transport (or any sync transport).

**Exports**

- `attachWebRtcSync`
