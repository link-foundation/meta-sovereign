// Page error policies currently used by the first and reopened chat pages.
export const watchChatPages = (context, { errors }) => {
  const aborted =
    /^(Error: )?Fetch API cannot load .+ due to access control checks\.?$/;
  for (const page of context.pages()) {
    page.on('pageerror', (error) => {
      if (!aborted.test(String(error))) {
        errors.push(String(error));
      }
    });
  }
  context.on('page', (page) => {
    page.on('pageerror', (error) => errors.push(String(error)));
  });
};
