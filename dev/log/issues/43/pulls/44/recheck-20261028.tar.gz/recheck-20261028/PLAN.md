# Issue 43 / PR 44 CI follow-up plan

- [x] Read complete issue, issue comments, PR conversation comments, inline comments and reviews; inventory all requirements and existing implementation/evidence.
- [x] Preserve fresh run timestamps, commit SHAs, all current workflow logs and failed-job artifacts; analyze actual failures and timeline.
- [x] Fetch the default branch, merge if needed, and preserve branch history on issue-43-1924384484c0.
- [x] Research primary documentation and known existing solutions for the identified failure.
- [x] Add a minimum reproducing regression test or experiment before the fix; retain scripts in experiments/ and diagnostics in this evidence directory.
- [x] Implement the root-cause fix across affected paths; keep quality gates and existing features enabled.
- [x] Run focused checks sequentially with limited memory/concurrency; use GitHub CI for full suites and matrices.
- [ ] Review diff, add any required changeset, commit and push atomic work only to the prepared branch.
- [ ] Verify fresh CI against the pushed SHA; download and review failed logs and fix every failing check.
- [ ] Update PR title/body, preserve closing references and manual prerequisites, record final evidence, mark PR ready and verify clean working tree.
