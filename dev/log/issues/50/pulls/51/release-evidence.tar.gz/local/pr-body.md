The merged dependency updates left default-branch checks failing. This PR updates every detected dependency ecosystem, adapts the launchers and release tooling to current versions, and repairs the browser CI setup without dropping runtime, browser or desktop coverage.

Fixes #50

R-Z33: current dependencies and toolchains across the repository.

Changes include Node 26.12.1/npm 12.2.1, Rust 1.99.1 with edition 2024, Python 3.15.2, Swift 6.4.1 via checksummed Swiftly 1.2.0, Capacitor 8.6.0, Electron 45.1.0, current Actions and hosted images, and identical digest-pinned Docker bases. The npm lock is regenerated. Mobile and Electron launchers now read the declared peer ranges; npm 12 registry/pack JSON formats are supported; Node's stable glob replaces the handwritten documentation traversal. A major changeset records the raised Node floor. Python and Swift use only standard/system libraries, so no artificial dependency manifests were added.

Complete scope, alternatives, migration sources and retained parent constraints:

- [Requirements and root causes](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/README.md)
- [Every npm dependency: before/current/latest and retention reasons](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/NPM.md) — 519 distinct names, including separately resolved optional native/mobile peers
- [Every Action, runtime, toolchain and image](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/TOOLS.md)
- [Validation, failure log references and remaining verification](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/VALIDATION.md)
- [Checksummed raw issue/comments, registry data and CI evidence](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/evidence.tar.gz)

Reproductions and verification:

- Mobile CLI: mocked subprocess regression fails against the previous hardcoded Capacitor 7.6.2 and passes with the declared peer. The fixture explicitly uses Node across Node/Bun/Deno runners.
- npm 12: registry array-response regression fails before normalization; pack smoke verifies the new package-keyed metadata and a real installed package consumer.
- Chromium: preserved main logs show `No usable sandbox!`; workflow regression verifies the Linux namespace setup before the sandboxed browser launch.
- WebKit: preserved main logs show the cross-origin Pages fixture cannot find Chromium; workflow regression requires Chromium alongside the selected engine.
- Focused local JavaScript/Rust checks, web/API builds, workflow lint, and root plus optional-peer security audits pass. Both npm audits report zero vulnerabilities. Full suites and platform/browser matrices run in GitHub CI, following AGENTS.md and the local memory limit.
- Original merged PR source head `a07bac8fe56ead12ae56916f21108a38d7271378` passes all five workflows: 43 successful PR check results, with only event-inapplicable jobs skipped. Checks and release has 33 successful jobs, including all nine runtime/OS lanes, both complete 41-scenario browser suites, native/container checks and every quality gate. All five desktop targets pass. Completed Checks and desktop logs contain no npm/runtime deprecation diagnostics.


Original merged PR workflow evidence (all runs match `a07bac8f`):

| Workflow | Result |
| --- | --- |
| [Checks and release](https://github.com/link-foundation/meta-sovereign/actions/runs/40788640783) | Passed |
| [Desktop: all five targets](https://github.com/link-foundation/meta-sovereign/actions/runs/40788640852) | Passed |
| [Pages](https://github.com/link-foundation/meta-sovereign/actions/runs/40788640792) | Passed |
| [Link checking](https://github.com/link-foundation/meta-sovereign/actions/runs/40788640808) | Passed |
| [Standalone scheduled-security workflow](https://github.com/link-foundation/meta-sovereign/actions/runs/40789527424) | Passed |

Default-branch verification is incomplete. This PR was merged at `dc30f00aefb2c1a89c64bf7e7fa78ef80a860fe7`. All tests and quality gates passed again, and [Pages](https://github.com/link-foundation/meta-sovereign/actions/runs/40790628783), [links](https://github.com/link-foundation/meta-sovereign/actions/runs/40790628767) and [security](https://github.com/link-foundation/meta-sovereign/actions/runs/40790641642) passed. However, [main Checks and release](https://github.com/link-foundation/meta-sovereign/actions/runs/40790628774) failed in release versioning: the old legacy-peer install removed a validated peer from package-lock.json, and the strict guard correctly refused publication. The desktop workflow skipped publication after that failure. No 1.0.0 release was published.

The tested repair is preserved on the original branch in [commit 2f248948](https://github.com/link-foundation/meta-sovereign/commit/2f24894801211a1be01e3552e2643789148f3657). Both release entry points now use npm version metadata synchronization; the guard is unchanged. A failing-before regression now passes, seven focused checks pass, and both complete version-and-commit flows pass against disposable local Git remotes. [Post-merge analysis and evidence](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/POST-MERGE.md) record the failure and reproduction. Issue 50 remains unfinished: this PR is already merged, and authorization is needed to depart from the explicit single-PR requirement before creating a follow-up PR from the same branch.

Additional repair-branch verification exposed a Bun 1.4.4 backup cleanup race in [run 40793790696](https://github.com/link-foundation/meta-sovereign/actions/runs/40793790696): an async-generator pipeline can reject before the destination opens/closes, allowing a temporary file to appear after cleanup. The standalone reproduction fails before the repair; the new regression and the exact existing failure pass locally after [fe810031](https://github.com/link-foundation/meta-sovereign/commit/fe810031). The shared durable-stream helper now waits for destination close before unlinking. [Upstream Bun report](https://github.com/oven-sh/bun/issues/47277) includes the executed reduced case and Node contrast.

The repair branch also corrects the runtime inventory to the official Node **26.13.0 LTS** release, with matching engines, all CI pins, both Docker digests and all four instruction locales. npm's Node wrapper dist-tag differs from the official distribution index. [Commit 4ced4574](https://github.com/link-foundation/meta-sovereign/commit/4ced4574) includes the refreshed 519-name registry inventory, current tool/action checks and 82-file checksummed supplemental evidence. On the verified official Node binary, 39 focused checks pass; both complete release flows also pass with pinned npm 12.2.1. The final screenshot below shows this repair-branch runtime requirement. These additional commits are **not integrated into main**.

Repair-source CI at `4ced4574`: [standalone security](https://github.com/link-foundation/meta-sovereign/actions/runs/40796241484) and [links](https://github.com/link-foundation/meta-sovereign/actions/runs/40796244255) pass. [Checks](https://github.com/link-foundation/meta-sovereign/actions/runs/40796238163) passes both complete browser suites and eight runtime lanes but fails Windows/Deno at the CLI fixture's ten-second readiness polling limit. A finite delayed-copy experiment reproduces that exact failure. The fixture now awaits the existing post-initialization CLI readiness message, reports child startup errors, and retains all subsequent control assertions; five focused regressions pass. Default-off release timing traces support diagnosis. Fresh exact-source CI remains required. The main release and resulting desktop publication remain unverified until the delivery constraint is resolved.

Upstream findings and retained compatibility workarounds:

- [Browser Commander dependency-range update](https://github.com/link-foundation/browser-commander/issues/168#issuecomment-6480636859)
- [Released Swift setup action rejects current Swift and uses deprecated Node runtime](https://github.com/swift-actions/setup-swift/pull/806#issuecomment-6480670984)
- [actionlint current hosted-runner labels](https://github.com/rhysd/actionlint/issues/682#issuecomment-6480731810)
- [electron-builder deprecated updater comparator](https://github.com/electron-userland/electron-builder/issues/10016)
- [WebKit EventSource navigation-cancellation reproduction](https://github.com/microsoft/playwright/issues/43120#issuecomment-6483530675)
- [Bun pipeline settles before destination close](https://github.com/oven-sh/bun/issues/47277)
- [cifrante Windows/Deno native failure](https://github.com/sanyok12345/cifrante/issues/1)

The runtime download instructions were updated in all four locales. Real-browser screenshots show the changed Node requirement:

Before:

![Previous Node requirement](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/local/node-before.png?raw=true)

After:

![Current Node requirement](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/local/node-after.png?raw=true)


WebKit regression evidence: stale discovery could schedule a retry after navigation and reload the successor document during its tutorial. New failing-before tests cover initial/automatic/manual discovery, in-flight build reloads and event-stream lifetimes. The prior macOS run40786024399 passed selection and tutorial, exposing a separate media-loading failure that was reduced to a native EventSource cancellation diagnostic. The exact browser/origin/native-name policy is tested without suppressing genuine exceptions. Final macOS WebKit run40788640783 passes all41 scenarios, including selection, the complete tutorial and media-loading.

Selection, failing CI capture and passing macOS scenario:

![Selection before](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/screenshots/selection-before.png?raw=true)

![Selection after](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/screenshots/selection-after.png?raw=true)

Tutorial, failed-run capture (card had returned after the transient reload) and passing full-walkthrough capture. Navigation traces and automated regressions establish the transient failure; a still image alone cannot:

![Tutorial failed-run capture](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/screenshots/tutorial-before.png?raw=true)

![Tutorial passing walkthrough](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/screenshots/tutorial-after.png?raw=true)

