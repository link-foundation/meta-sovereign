Bun 1.4.4 (38afee6c8), Linux x64; also observed in a macOS 26 CI run. Node 26.12.1 passes the same reduced reproduction.

A failed `pipeline(source, gzip, asyncGeneratorStage, fsWriteStream)` can reject while the destination is still opening/closing. Atomic-write cleanup immediately after rejection may see ENOENT, then find the temporary file created after cleanup. This broke a backup failure-cleanup assertion in [our CI job](https://github.com/link-foundation/meta-sovereign/actions/runs/40793790696/job/123185854617).

The example uses only Node APIs, at most 20 tiny sequential attempts, owned temporary files, and finally waits for close and removes its fixture. The failure is intermittent: the saved Linux run failed at attempt 15. Attaching a close observer before starting the pipeline changes the timing, so the repro deliberately observes close only in final cleanup.

Save as `repro.mjs`, run `bun repro.mjs`, then `node repro.mjs`:

```js
// Standalone bounded Bun/Node contrast: no project imports or dependencies.
import assert from 'node:assert/strict';
import { createWriteStream, promises as fs } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { createGzip } from 'node:zlib';

const dir = await fs.mkdtemp(join(tmpdir(), 'bun-pipeline-close-'));
console.log({ node: process.version, bun: globalThis.Bun?.version });
try {
  for (let attempt = 0; attempt < 20; attempt += 1) {
    const events = [];
    const temp = join(dir, 'archive.tmp');
    const output = createWriteStream(temp, { flags: 'w', mode: 0o600 });
    const source = new Readable({
      read() {
        this.destroy(new Error('source unavailable'));
      },
    });
    try {
      await assert.rejects(
        pipeline(
          source,
          createGzip(),
          async function* (input) {
            yield 'header';
            yield* input;
          },
          output
        ),
        /source unavailable/
      );
      events.push(`rejected: closed=${output.closed}`);
      await fs.unlink(temp).catch((error) => {
        assert.equal(error.code, 'ENOENT');
        events.push('unlink: ENOENT');
      });
      const remaining = await fs.readdir(dir);
      if (remaining.length) console.log({ attempt, events, remaining });
      assert.deepEqual(remaining, []);
    } finally {
      const closed = output.closed ? Promise.resolve() : new Promise((resolve) => output.once('close', resolve));
      output.destroy();
      await closed;
      await fs.unlink(temp).catch(() => {});
    }
  }
  console.log('No temporary files remain after failed pipelines');
} finally {
  await fs.rm(dir, { recursive: true, force: true });
}

```

Observed Bun output before the assertion:

```text
attempt: 15
events: [ "rejected: closed=false", "unlink: ENOENT" ]
remaining: [ "archive.tmp" ]
```

Node completes with `No temporary files remain after failed pipelines`.

Expected: pipeline completion/rejection should wait for the fs.WriteStream to close, as documented by [Node pipeline](https://nodejs.org/api/stream.html#streampipelinesource-transforms-destination-callback), so a failed write can clean up its destination reliably.

Local workaround: register a close promise on the output before calling pipeline; on failure explicitly destroy it, await close, then unlink. Await close on success before fsync/rename too. The regression fails before that change and passes afterwards on Bun; the original backup assertion also passes.

Suggested upstream correction: ensure rejection from an intermediate async-generator stage tears down and awaits the actual final Writable before settling the pipeline promise. Add an error-path regression with a real fs.WriteStream and a source that errors while opening is pending. I have not identified the exact implementation branch yet.

I searched current pipeline issues. #44770 tracks paths that never settle and #45724 tracks an async generator as the final entry; this reproduction instead settles too early with a file stream as the final entry.
