Current-version EventSource variant of the same document-replacement mechanism, reduced from our WebKit CI failure.

Tested Node26.12.1, Playwright1.64.1, Linux x64 with its bundled WebKit. macOS26 Intel CI emitted the same EventSource diagnostic during a normal reload. The app-free reproduction uses only an owned loopback HTTP server, no application/CORS rule/authentication/interception, and two cells:

1. No-navigation control: one EventSource opens; the SSE endpoint receives exactly one request; no pageerror, window.error or unhandledrejection.
2. Hold the replacement document's response after its request reaches the server. Through an existing old-document handle, construct a new same-origin EventSource. It emits error and never reaches the SSE endpoint. Playwright reports Error.name `EventSource cannot load http` and message `/127.0.0.1:<port>/events due to access control checks.` Neither window.error nor unhandledrejection fires. Release the replacement response; navigation completes normally.

Executed reproduction: https://github.com/link-foundation/meta-sovereign/blob/0691b2b1/experiments/issue50-eventsource-navigation.mjs

Run after installing Playwright1.64.1 and its bundled WebKit: `node experiments/issue50-eventsource-navigation.mjs`. The script asserts the successful control, navigation error, unchanged server ingress, empty DOM error/rejection observers and native diagnostic, then closes the browser/server.

This matches ThreadableLoader::logError's explicit EventSource branch and the cancellation provenance already tracked by WebKit329152: https://bugs.webkit.org/show_bug.cgi?id=329152 . A cancellation should retain its cancellation type before that logging path rather than become AccessControl. No released engine fix is claimed.

Local workaround: close page-owned streams and prevent late subscriptions after pagehide. For the unavoidable provisional-navigation window, the browser test policy recognizes only this demonstrated native Error.name/message, WebKit and the exact fixture origin; genuine exceptions, malformed/foreign URLs and other engines still fail. Those boundaries have regression tests. Production media assertions and all browser cases remain enabled.
