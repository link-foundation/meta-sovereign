The merged dependency updates left default-branch checks failing. This PR updates every detected dependency ecosystem, adapts the launchers and release tooling to current versions, and repairs the browser CI setup without dropping runtime, browser or desktop coverage.

Fixes #50

R-Z33: current dependencies and toolchains across the repository.

Changes include Node 26.12.1/npm 12.2.1, Rust 1.99.1 with edition 2024, Python 3.15.2, Swift 6.4.1 via checksummed Swiftly 1.2.0, Capacitor 8.6.0, Electron 45.1.0, current Actions and hosted images, and identical digest-pinned Docker bases. The npm lock is regenerated. Mobile and Electron launchers now read the declared peer ranges; npm 12 registry/pack JSON formats are supported; Node's stable glob replaces the handwritten documentation traversal. A major changeset records the raised Node floor. Python and Swift use only standard/system libraries, so no artificial dependency manifests were added.

Complete scope, alternatives, migration sources and retained parent constraints:

- [Requirements and root causes](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/README.md)
- [Every npm dependency: before/current/latest and retention reasons](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/NPM.md) — 519 distinct names, including separately resolved optional native/mobile peers
- [Every Action, runtime, toolchain and image](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/TOOLS.md)
- [Validation, failure log references and remaining verification](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/VALIDATION.md)
- [Checksummed raw issue/comments, registry data and CI evidence](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/evidence.tar.gz)

Reproductions and verification:

- Mobile CLI: mocked subprocess regression fails against the previous hardcoded Capacitor 7.6.2 and passes with the declared peer. The fixture explicitly uses Node across Node/Bun/Deno runners.
- npm 12: registry array-response regression fails before normalization; pack smoke verifies the new package-keyed metadata and a real installed package consumer.
- Chromium: preserved main logs show `No usable sandbox!`; workflow regression verifies the Linux namespace setup before the sandboxed browser launch.
- WebKit: preserved main logs show the cross-origin Pages fixture cannot find Chromium; workflow regression requires Chromium alongside the selected engine.
- Focused local JavaScript/Rust checks, web/API builds, workflow lint, and root plus optional-peer security audits pass. Both npm audits report zero vulnerabilities. Full suites and platform/browser matrices run in GitHub CI, following AGENTS.md and the local memory limit.
- Latest-head Checks, Pages, link checking and all five desktop targets are being verified. Pending checks are not counted as passing.

Default-branch verification: enabling repository vulnerability alerts repaired the original dependency-review HTTP 403. Its rerun exposed the two browser workflow omissions repaired here. After final PR checks pass, integrate through this PR and verify main independently, as issue #50 explicitly requires.

Upstream findings and retained compatibility workarounds:

- [Browser Commander dependency-range update](https://github.com/link-foundation/browser-commander/issues/168#issuecomment-6480636859)
- [Released Swift setup action rejects current Swift and uses deprecated Node runtime](https://github.com/swift-actions/setup-swift/pull/806#issuecomment-6480670984)
- [actionlint current hosted-runner labels](https://github.com/rhysd/actionlint/issues/682#issuecomment-6480731810)
- [electron-builder deprecated updater comparator](https://github.com/electron-userland/electron-builder/issues/10016)
- [WebKit EventSource navigation-cancellation reproduction](https://github.com/microsoft/playwright/issues/43120#issuecomment-6483530675)
- [cifrante Windows/Deno native failure](https://github.com/sanyok12345/cifrante/issues/1)

The runtime download instructions were updated in all four locales. Real-browser screenshots show the changed Node requirement:

Before:

![Previous Node requirement](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/local/node-before.png?raw=true)

After:

![Current Node requirement](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/local/node-after.png?raw=true)


WebKit regression evidence: stale discovery could schedule a retry after navigation and reload the successor document during its tutorial. New failing-before tests cover initial/automatic/manual discovery, in-flight build reloads and event-stream lifetimes. macOS run40786024399 passes the complete selection and tutorial scenarios. Its separate media-loading failure was reduced to a native EventSource cancellation diagnostic; the exact browser/origin/native-name policy is tested without suppressing genuine exceptions. The focused actual media scenario now passes.

Selection, failing CI capture and passing macOS scenario:

![Selection before](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/screenshots/selection-before.png?raw=true)

![Selection after](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/screenshots/selection-after.png?raw=true)

Tutorial, failed-run capture (card had returned after the transient reload) and passing full-walkthrough capture. Navigation traces and automated regressions establish the transient failure; a still image alone cannot:

![Tutorial failed-run capture](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/screenshots/tutorial-before.png?raw=true)

![Tutorial passing walkthrough](https://github.com/link-foundation/meta-sovereign/blob/issue-50-d289f94d6edd/dev/log/issues/50/pulls/51/screenshots/tutorial-after.png?raw=true)
