Consumer revalidation for https://github.com/link-foundation/meta-sovereign/pull/51 on 2026-10-28: current `browser-commander@0.34.0` still declares `links-notation@^0.25.2`, while the current Links Notation registry `latest` is `0.27.1`.

Minimal reproduction in an empty temporary directory (Node 26.12.1 / npm 12.2.1):

```sh
npm init -y
npm install --ignore-scripts browser-commander@0.34.0 links-notation@0.27.1
npm ls links-notation
```

The resulting tree has root `links-notation@0.27.1` and Browser Commander's nested `links-notation@0.25.2`. This is a dependency currency/deduplication request; no grammar or browser failure has been established from these two versions. The consumer retains the nested version and does not force an incompatible 0.x override. Please assess `^0.27.1`, run trace/import/export compatibility tests, migrate any changed grammar APIs, and update the range when compatible. This extends the same request in this issue to the latest releases.
