Revalidated against current actionlint 1.7.12 while updating https://github.com/link-foundation/meta-sovereign/pull/51 on 2026-10-28. `ubuntu-26.04` and `ubuntu-26.04-arm` still produce `label ... is unknown`. The same registry gap affects `windows-11-vs2026-arm`, now listed in https://github.com/actions/runner-images#available-images.

Minimal repro: a workflow with `on: push`, one job using `runs-on: ubuntu-26.04` (repeat for the other two labels), and `steps: [{run: echo ok}]`; run actionlint 1.7.12. Locally reproduced all three errors. Our consumer uses the documented narrow workaround:

```yaml
self-hosted-runner:
  labels:
    - ubuntu-26.04
    - ubuntu-26.04-arm
    - windows-11-vs2026-arm
```

This permits only the verified hosted labels and keeps other workflow validation enabled. Suggested upstream change: add these three labels to the built-in runner-label table and its tests, then release the validator. Linking here rather than opening another duplicate of #682.
