Additional current downstream evidence from https://github.com/link-foundation/meta-sovereign/pull/51 (2026-10-28): the latest published setup-swift release, v2.4.0 / `7ca6abe6b3b0e8b5421b88be48feee39cbf52c6a`, fails on `macos-15` for exact `swift-version: '6.4.1'`:

```text
Unexpected error, unable to continue.
Version "6.4.1" is not available
```

The same job also emits the Node 20 action-runtime deprecation warning described in #804. Minimal workflow: checkout, setup-swift@v2.4.0 with `swift-version: '6.4.1'`, then `swift --version`. Actual failing job: https://github.com/link-foundation/meta-sovereign/actions/runs/40768445874/job/123099055552 . Swift 6.4.1 is published at https://forums.swift.org/t/announcing-swift-6-4-1/90029 .

Our consumer workaround is to replace this action with the official version-pinned Swiftly 1.2.0 macOS installer and `swiftly install 6.4.1 --use --assume-yes`, retaining toolchain validation. Please publish the supported Swiftly installer/runtime migration (including exact-patch validation) in a released action so consumers can remove that bootstrap step. This PR appears to cover the needed direction; linking evidence here instead of opening a duplicate issue.
