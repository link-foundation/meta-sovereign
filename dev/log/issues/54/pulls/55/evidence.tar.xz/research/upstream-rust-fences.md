Found at `0ece2cf2c2745c3574ffb65dbabdfcadd7163c14`, `scripts/create-github-release.rs:108-143`, while auditing https://github.com/link-foundation/meta-sovereign/pull/55. The section scanner treats Markdown headings inside fenced example code as real release boundaries, silently deleting the rest of the notes.

Minimal CHANGELOG.md:

````markdown
## [1.2.3]

Example:

```md
## [9.9.9]
```

Remaining details.

## [1.2.2]
old
````

Expected: the 1.2.3 body contains the whole fenced example and `Remaining details.`. Actual: the body ends at `Example:` and the opening fence, leaving invalid Markdown and dropping real release information. A requested version that appears only inside a fenced example can also select example text as release notes.

Reproduce from the template root (no real publishing):

```sh
# In an isolated copy of the template, put the example below in CHANGELOG.md.
# Stub gh so this rehearsal cannot publish:
fixture=$(mktemp -d)
trap 'rm -rf "$fixture"' EXIT
printf '#!/bin/sh\ncat\n' > "$fixture/gh"
chmod +x "$fixture/gh"
PATH="$fixture:$PATH" CARGO_BUILD_JOBS=1 rust-script scripts/create-github-release.rs --release-version 1.2.3 --repository fixture/repo
```

The JS and Python snapshot functions were executed offline and both returned the truncated body. The Rust source has the same boundary error in `next_section_re`, which matches `^## [` without fence state; the above CLI reproduction uses a local gh stub. No Rust template build was run on the constrained downstream machine.

Workaround: use indented example code or avoid version-shaped headings inside fenced changelog examples until the scanner is fixed. Do not silently delete the example or the later prose from the actual release.

Suggested fix: find exact release headings only outside Markdown code fences (both backticks and tildes, matching closing delimiter/length), or parse Markdown to an AST and slice by top-level heading offsets. Preserve body bytes/indentation, fail explicitly on missing required entries, and add tests for a fenced next-version heading, a target version only inside a fence, CRLF and multiple change subsections. The downstream PR adds these regressions in `js/tests/ci-github-release.test.js` and fixes its shared release-content helper; the Rust/Python publication programs are template-specific and are not vendored into the product.
