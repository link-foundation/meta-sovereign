The same fence-awareness gap also affects JavaScript release metadata: `scripts/format-release-notes-helpers.mjs` at the reported immutable revision scans `ENTRY_HASH` across the entire Markdown body, including code examples.

Offline reproduction after the template's normal setup:

```js
import { buildReleaseDescription } from './scripts/format-release-notes-helpers.mjs';
const body = '### Patch Changes\n\n- abcdef123: real change\n\n```md\n- deadbeef: example\n```';
console.log(buildReleaseDescription(body).commitHashes);
```

Observed: `['abcdef123', 'deadbeef']`; expected: `['abcdef123']`. A formatter then queries `/commits/deadbeef/pulls`. That can fail or attach an unrelated PR; strict lookup handling exposes it as a formatting failure rather than making the example metadata.

We reproduced the actual helper offline, and a downstream CLI regression first failed on a simulated 404 for the example commit. The repair shares the fence scanner between version extraction and commit extraction, ignores indented code too, preserves the original Markdown, and now passes all 12 release tests. Workaround: avoid commit-shaped example bullets until repaired. Suggested fix: scan only Markdown list metadata outside fenced/indented code, preferably using the same Markdown traversal for version boundaries and hashes (or a CommonMark AST for a general editor). Include backtick/tilde fences and indented examples in regression coverage. The reusable source rehearsal is `experiments/issue-54/rehearse-template-notes.py` in the downstream PR.
