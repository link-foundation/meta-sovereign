Found at `0a3957d8195271829aa3cd5adce58a98fe73be2b`, `scripts/create-github-release.mjs:99-115`, while auditing https://github.com/link-foundation/meta-sovereign/pull/55. The section scanner treats Markdown headings inside fenced example code as real release boundaries, silently deleting the rest of the notes.

Minimal CHANGELOG.md:

````markdown
## 1.2.3

Example:

```md
## 9.9.9
```

Remaining details.

## 1.2.2
old
````

Expected: the 1.2.3 body contains the whole fenced example and `Remaining details.`. Actual: the body ends at `Example:` and the opening fence, leaving invalid Markdown and dropping real release information. A requested version that appears only inside a fenced example can also select example text as release notes.

Reproduce from the template root (no real publishing):

```sh
node --input-type=module <<'JS'
import { extractReleaseNotes } from './scripts/create-github-release.mjs';
console.log(extractReleaseNotes('## 1.2.3\n\nExample:\n\n```md\n## 9.9.9\n```\n\nRemaining details.\n\n## 1.2.2\nold', '1.2.3'));
JS
```

The JS and Python snapshot functions were executed offline and both returned the truncated body. The Rust source has the same boundary error in `next_section_re`, which matches `^## [` without fence state; the above CLI reproduction uses a local gh stub. No Rust template build was run on the constrained downstream machine.

Workaround: use indented example code or avoid version-shaped headings inside fenced changelog examples until the scanner is fixed. Do not silently delete the example or the later prose from the actual release.

Suggested fix: find exact release headings only outside Markdown code fences (both backticks and tildes, matching closing delimiter/length), or parse Markdown to an AST and slice by top-level heading offsets. Preserve body bytes/indentation, fail explicitly on missing required entries, and add tests for a fenced next-version heading, a target version only inside a fence, CRLF and multiple change subsections. The downstream PR adds these regressions in `js/tests/ci-github-release.test.js` and fixes its shared release-content helper; the Rust/Python publication programs are template-specific and are not vendored into the product.
