Confirmed with the current stable 1.7.12 Docker distribution at `rhysd/actionlint@sha256:b1934ee5f1c509618f2508e6eb47ee0d3520686341fec936f3b79331f9315667` during https://github.com/link-foundation/meta-sovereign/pull/55. Runner 2.338.0 successfully resolves and executes `uses: $/.github/actions/npm-cache`, while actionlint rejects the same reference as missing a ref.

Minimal reproduction:

```yaml
name: Self-reference
on: workflow_dispatch
jobs:
  check:
    runs-on: ubuntu-24.04
    steps:
      - uses: $/.github/actions/npm-cache
```

Run the pinned image against this workflow: the valid reference produces `[action] specifying action ... in invalid format because ref is missing`.

Our temporary workaround uses `paths` to ignore only that exact action reference/diagnostic in its two calling workflow files. A separate contract verifies that the referenced action exists. A real bundled-checker rehearsal confirms a different invalid reference and a genuine ShellCheck SC2086 still fail; no global action/shell rule is disabled. The exception has an explicit removal condition when support ships.

Suggested implementation: recognize `$/<nonempty-relative-path>` as a distinct same-repository reference before remote `owner/repo@ref` validation, preserve validation of malformed/empty paths, and add action/composite/reusable-workflow cases. The downstream reproducible positive/negative experiment is `experiments/issue-54/rehearse-actionlint.py` in the linked PR. No duplicate issue opened because this report already tracks the cause.
