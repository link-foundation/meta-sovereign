An additional source of incomplete PR evidence at the same immutable template revision is the unpaginated `/commits/{sha}/pulls` query plus `find()`, which keeps only one relevant PR from the first page. We reproduced this offline against the actual template formatter in the downstream virtual-command fixture: return 30 valid PRs from page one and a 31st on page two; the template PATCH contains only `#1`. The downstream initial repair that iterated page one still omitted `#31`, caught by a failing regression before adding pagination.

Reproduction using the downstream PR's reusable offline fixture and the immutable template source:

```sh
node experiments/issue-54/rehearse-github-release.mjs notes-pages 200 PATH_TO_TEMPLATE/scripts/format-release-notes.mjs
```

No API calls or publication occur. The fixture records the PATCH body. Expected: all relevant PRs across all pages; observed: only `#1` with the template, or `#1`–`#30` when merely replacing `find` with a first-page loop.

Workaround: fetch every commit-to-PR result with `gh api ENDPOINT --paginate --slurp` before formatting, then supply the complete deduplicated PR metadata. Suggested fix: validate the array of page arrays, flatten all pages, iterate every non-version PR, deduplicate numbers across commits, and abort before PATCH on a refused/malformed page. The downstream test `release enrichment includes PRs beyond the first API page` verifies a 31st link and now passes; all 11 release regressions pass locally. This is additional evidence for complete lookup handling, not a request to relax refusal checks.
