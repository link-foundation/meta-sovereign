The current template at `0a3957d8195271829aa3cd5adce58a98fe73be2b` still reports successful formatting after refused/unknown API results. Found while auditing https://github.com/link-foundation/meta-sovereign/pull/55 (issue 54).

1. `scripts/format-github-release.mjs:100-107` catches **every** release lookup failure and calls `process.exit(0)`. A 403/429/500 is mislabeled as “Could not find release”; the required formatting step is green without formatting anything.
2. `scripts/format-release-notes.mjs:155-162` catches failed PR lookups, then PATCHes a body without those links and exits successfully. The generated badge makes subsequent formatting skip this incomplete result.

### Offline reproduction

After the template's normal `npm ci`, run from its root:

```sh
fixture=$(mktemp -d)
trap 'rm -rf "$fixture"' EXIT
cat > "$fixture/gh" <<'SH'
#!/bin/sh
printf '%s\n' 'HTTP 403: refused fixture' >&2
exit 1
SH
chmod +x "$fixture/gh"
PATH="$fixture:$PATH" VERSION=1.2.3 REPOSITORY=fixture/repo COMMIT_SHA=0123456789012345678901234567890123456789 node scripts/format-github-release.mjs
printf 'formatter exit: %s\n' "$?"
```

Observed: `Could not find release for v1.2.3`, exit **0**. Expected: nonzero, no success result. Changing the stub to 429 or 500 has the same effect. No GitHub token, network or release write is involved.

For the second path, make the stub return release JSON with `{"id":123,"body":"- abcdef123: First change"}` for the release GET, return nonzero for `/commits/abcdef123/pulls`, and record any PATCH. Run `format-release-notes.mjs --release-id 123 --release-version 1.2.3 --repository fixture/repo`. It logs the lookup warning, PATCHes the badge, and exits 0.

A reusable command-stream virtual-command fixture and failing-before/passing-after CLI regressions are in `experiments/issue-54/rehearse-github-release.mjs` and `js/tests/ci-github-release.test.js` in the downstream PR. The exact template was also rehearsed offline with a 403: exit 0, no formatter invocation.

### Workaround

Require a successful `gh api repos/OWNER/REPO/releases/tags/TAG` preflight before the wrapper, and preflight every required commit-to-PR query before formatting. Do not use `|| true` or regard permission/network failure as absence. After restoring API access, remove only the generated badge from an affected release and rerun formatting to recover missing links.

### Suggested code fix

Use an explicit HTTP-state release probe: only a valid 200 establishes existence; 404 is missing and must fail when formatting is required; 401/403/429/5xx, transport errors and malformed payloads must fail. Let commit-to-PR lookup errors propagate before PATCH; a valid empty array is the only evidence for “no PR”. Preserve the original notes and collect all unique relevant PRs, as in the fixes for #236/#242. Add offline regressions for every error state, malformed JSON/shape, no writes on unknown state, and successful idempotent retries.
