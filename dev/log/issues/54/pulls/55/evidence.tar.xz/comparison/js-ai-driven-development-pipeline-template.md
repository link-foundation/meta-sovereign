# Complete file comparison: js-ai-driven-development-pipeline-template

Commit: `0a3957d8195271829aa3cd5adce58a98fe73be2b`. Every blob in the recursive tree is listed.

| Template file | Local file / disposition | Content |
| --- | --- | --- |
| `.changeset/README.md` | `.changeset/README.md` — Compare implementation/configuration with local counterpart | equal |
| `.changeset/config.json` | `.changeset/config.json` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.changeset/fix-repository-audits-and-test-coverage.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `.changeset/release-formatter-exact-moves.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `.changeset/reliable-template-ci-helpers.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `.changeset/reliable-template-pipelines.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `.changeset/repository-pipeline-repairs.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `.changeset/transient-links-bun-pin.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `.gitattributes` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `.github/actions/publish-dockerhub/action.yml` | Registry-image publishing: not a current product publication target | template-specific |
| `.github/actions/setup-buildx-resilient/action.yml` | Registry-image publishing: not a current product publication target | template-specific |
| `.github/codeql/codeql-config.yml` | `.github/codeql/codeql-config.yml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.github/workflows/example-app.yml` | Workflow role mapped in TEMPLATE-COMPARISON.md | template-specific |
| `.github/workflows/javascript-first-example.yml` | Workflow role mapped in TEMPLATE-COMPARISON.md | template-specific |
| `.github/workflows/javascript-first-gate.yml` | Workflow role mapped in TEMPLATE-COMPARISON.md | template-specific |
| `.github/workflows/links.yml` | `.github/workflows/links.yml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.github/workflows/release.yml` | `.github/workflows/release.yml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.github/workflows/security.yml` | `.github/workflows/security.yml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.github/workflows/workflows.yml` | Workflow role mapped in TEMPLATE-COMPARISON.md | template-specific |
| `.github/zizmor.yml` | `.github/zizmor.yml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.gitignore` | `.gitignore` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.husky/pre-commit` | `.husky/pre-commit` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.jscpd.json` | `.jscpd.json` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.lycheeignore` | `.lycheeignore` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.prettierignore` | `.prettierignore` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.prettierrc` | `.prettierrc` — Compare implementation/configuration with local counterpart | equal |
| `.secretlintrc.json` | `.secretlintrc.json` — Compare implementation/configuration with local counterpart | equal |
| `AGENTS.md` | `AGENTS.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `CHANGELOG.md` | `CHANGELOG.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `LICENSE` | `LICENSE` — Compare implementation/configuration with local counterpart | equal |
| `README.md` | `README.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `bin/example-package-name.js` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `bunfig.toml` | `bunfig.toml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `deno.json` | `deno.json` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `deno.lock` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `docs/BEST-PRACTICES.md` | `docs/BEST-PRACTICES.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `docs/CI-TIMEOUT-BUDGETS.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/CONTRIBUTING.md` | `docs/CONTRIBUTING.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `docs/ISSUE-199-RELEASE-ANALYSIS.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/ISSUE-203-ANALYSIS.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/ISSUE-216-ANALYSIS.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/ISSUE-228-ANALYSIS.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/ISSUE-262-ANALYSIS.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-13/README.md` | `docs/case-studies/issue-13/README.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `docs/case-studies/issue-13/hive-mind-issue-960.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-13/hive-mind-pr-961-diff.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-13/hive-mind-pr-961.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-21/README.md` | `docs/case-studies/issue-21/README.md` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-21/ci-logs/run-20803315337.txt` | `docs/case-studies/issue-21/ci-logs/run-20803315337.txt` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-21/ci-logs/run-20885464993.txt` | `docs/case-studies/issue-21/ci-logs/run-20885464993.txt` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-21/issue-111-data.txt` | `docs/case-studies/issue-21/issue-111-data.txt` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-21/issue-113-data.txt` | `docs/case-studies/issue-21/issue-113-data.txt` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-21/pr-112-data.json` | `docs/case-studies/issue-21/pr-112-data.json` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-21/pr-112-diff.patch` | `docs/case-studies/issue-21/pr-112-diff.patch` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-21/pr-114-data.json` | `docs/case-studies/issue-21/pr-114-data.json` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-21/pr-114-diff.patch` | `docs/case-studies/issue-21/pr-114-diff.patch` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-212/README.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-212/validation/baseline-regressions.log.gz` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-212/validation/bun-tests.log.gz` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-212/validation/checks-and-release-37557125805.log.gz` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-212/validation/commit-message-crlf-after.log.gz` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-212/validation/commit-message-crlf-before.log.gz` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-212/validation/deno-tests.log.gz` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-212/validation/node-tests.log.gz` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-212/validation/security-37555257997.log.gz` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-23/README.md` | `docs/case-studies/issue-23/README.md` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-23/data/hive-mind-check-version.mjs` | `docs/case-studies/issue-23/data/hive-mind-check-version.mjs` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-23/data/hive-mind-ci.yml` | `docs/case-studies/issue-23/data/hive-mind-ci.yml` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-23/data/hive-mind-eslint.config.mjs` | `docs/case-studies/issue-23/data/hive-mind-eslint.config.mjs` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-23/data/hive-mind-release.yml` | `docs/case-studies/issue-23/data/hive-mind-release.yml` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-23/data/issue-1126-details.txt` | `docs/case-studies/issue-23/data/issue-1126-details.txt` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-23/data/issue-1141-comments.json` | `docs/case-studies/issue-23/data/issue-1141-comments.json` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-23/data/issue-1141-details.txt` | `docs/case-studies/issue-23/data/issue-1141-details.txt` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-23/data/pr-1127-conversation-comments.json` | `docs/case-studies/issue-23/data/pr-1127-conversation-comments.json` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-23/data/pr-1127-diff.txt` | `docs/case-studies/issue-23/data/pr-1127-diff.txt` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-23/data/pr-1127-review-comments.json` | `docs/case-studies/issue-23/data/pr-1127-review-comments.json` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-23/data/pr-1142-conversation-comments.json` | `docs/case-studies/issue-23/data/pr-1142-conversation-comments.json` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-23/data/pr-1142-diff.txt` | `docs/case-studies/issue-23/data/pr-1142-diff.txt` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-23/data/pr-1142-review-comments.json` | `docs/case-studies/issue-23/data/pr-1142-review-comments.json` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-25/DETAILED-COMPARISON.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-25/README.md` | `docs/case-studies/issue-25/README.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `docs/case-studies/issue-25/data/hive-mind-file-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-25/data/issue-1274-case-study.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-25/data/issue-1278-case-study.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-25/data/template-file-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-29/README.md` | `docs/case-studies/issue-29/README.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `docs/case-studies/issue-3/README.md` | `docs/case-studies/issue-3/README.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `docs/case-studies/issue-3/created-issues.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-3/issue-data.json` | `docs/case-studies/issue-3/issue-data.json` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `docs/case-studies/issue-3/original-format-release-notes.mjs` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-3/reference-pr-59-diff.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-3/reference-pr-59.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-3/release-v0.1.0.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-3/repositories-with-same-script.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-3/research-notes.md` | `docs/case-studies/issue-3/research-notes.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `docs/case-studies/issue-31/README.md` | `docs/case-studies/issue-31/README.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `docs/case-studies/issue-31/web-capture-pr49-commits.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-33/README.md` | `docs/case-studies/issue-33/README.md` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-33/ci-logs/release-24395209194.txt` | `docs/case-studies/issue-33/ci-logs/release-24395209194.txt` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-33/ci-logs/upstream-nodejs-62430.json` | `docs/case-studies/issue-33/ci-logs/upstream-nodejs-62430.json` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-33/ci-logs/upstream-npm-cli-9151.json` | `docs/case-studies/issue-33/ci-logs/upstream-npm-cli-9151.json` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-33/ci-logs/upstream-runner-images-13883.json` | `docs/case-studies/issue-33/ci-logs/upstream-runner-images-13883.json` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-36/README.md` | `docs/case-studies/issue-36/README.md` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-36/ci-logs/release-24399965550.txt` | `docs/case-studies/issue-36/ci-logs/release-24399965550.txt` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-38/CASE-STUDY.md` | `docs/case-studies/issue-38/CASE-STUDY.md` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-40/CICD-COMPARISON.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/README.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/ci-run-25212337438.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/ci-runs-branch.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/downstream-web-capture-issue-98.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/downstream-web-capture-pr-99.diff` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/downstream-web-capture-pr-99.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/issue-40.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/js-cicd-files.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/js-template-file-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/pr-43.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/related-js-merged-prs.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/rust-cicd-files.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/rust-template-file-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/rust-template-head.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/shields-broken-prefixed-badge.svg` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/shields-broken-prefixed-prerelease-badge.svg` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/shields-working-normalized-badge.svg` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/data/shields-working-prerelease-badge.svg` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/rust-template/create-github-release.rs` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-40/rust-template/release.yml` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/README.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/hive-mind-check-file-line-limits.sh` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/hive-mind-file-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/hive-mind-issue-1593-case-study.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/hive-mind-issue-1593-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/hive-mind-issue-1593.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/hive-mind-issue-1730-case-study.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/hive-mind-issue-1730-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/hive-mind-issue-1730.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/js-template-check-file-line-limits-before.sh` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/js-template-eslint.config.js` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/js-template-file-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/js-template-issue-41-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/js-template-issue-41.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/js-template-release.yml` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/js-template-warn-threshold-search-before.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/rust-template-check-file-size.rs` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/rust-template-created-issue-url.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/rust-template-file-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/rust-template-issue-40.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/rust-template-issues.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/rust-template-max-lines-search.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-41/data/rust-template-release.yml` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/README.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/data/ci-runs-branch.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/data/issue-42-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/data/issue-42.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/data/js-template-file-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/data/js-template-pre-fix-head.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/data/link-foundation-my-package-search.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/data/link-foundation-package-name-search.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/data/pr-45-conversation-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/data/pr-45-review-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/data/pr-45-reviews.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/data/pr-45.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/data/related-merged-prs-check-release-needed.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/data/related-merged-prs-publish-to-npm.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/data/rust-template-ci-cd-findings.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/data/rust-template-file-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-42/data/rust-template-head.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/README.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/artifacts/universal-app-mobile.png` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/artifacts/universal-app-web.png` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/actions-checkout-release.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/actions-configure-pages-release.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/actions-deploy-pages-release.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/actions-setup-node-release.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/actions-upload-artifact-release.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/actions-upload-pages-artifact-release.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/bun-test-final.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/changeset-status-after-stage.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/check-file-line-limits-final-2.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/check-mjs-syntax-final-2.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/deep-sdk-capacitor.config.ts` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/deep-sdk-electron-package.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/deep-sdk-file-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/deep-sdk-gh-pages.yml` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/deep-sdk-package.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/deep-sdk-repo.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/deno-test-final.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/example-desktop-package-final-2.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/example-mobile-sync-final-2.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/example-web-build-final-2.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/issue-56-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/issue-56.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/link-foundation-code-search.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/npm-capacitor-cli.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/npm-capacitor-core.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/npm-check-final-4.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/npm-electron-forge-cli.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/npm-install-root.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/npm-install-universal-app-node20-compatible.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/npm-test-final-3.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/npm-vite.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/pr-57.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/recent-merged-prs.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/universal-app-test-before.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/universal-app-test-final-2.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/validate-changeset-final.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/vk-bot-desktop-build-renderer.mjs` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/vk-bot-desktop-electron-main.cjs` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/vk-bot-desktop-file-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/vk-bot-desktop-js-workflow.yml` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/vk-bot-desktop-package.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-56/data/vk-bot-desktop-repo.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/README.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/actions-configure-pages-release.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/actions-deploy-pages-release.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/actions-upload-artifact-release.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/actions-upload-pages-artifact-release.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/bun-test.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/check-file-line-limits.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/check-mjs-syntax.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/checks-and-release-25733140225.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/checks-and-release-25733140225.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/checks-and-release-25743983223.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/ci-run-25743983223.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/csharp-template-file-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/csharp-template-release.yml` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/deno-test.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/example-app-25733140224.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/example-app-25733140224.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/example-desktop-package.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/example-mobile-sync.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/example-web-build.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/issue-58-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/issue-58.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/js-template-file-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/link-foundation-example-package-name-search.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/main-ci-runs.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/npm-check-final.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/npm-example-package-name-view.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/npm-global-install.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/npm-install-after-metadata.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/npm-install-universal-app.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/npm-install.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/npm-pack-dry-run-final.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/npm-test-2.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/npm-whoami.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/pages-enable-result.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/pages-status-after-enable.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/pr-57.diff` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/pr-57.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/pr-59-conversation-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/pr-59-review-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/pr-59-reviews.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/pr-59.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/python-template-file-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/python-template-release.yml` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/regression-after-2.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/regression-after-3.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/regression-after.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/regression-before.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/rust-template-file-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/rust-template-release.yml` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/secretlint.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-58/data/validate-changeset.log` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-7/BEST-PRACTICES-COMPARISON.md` | `docs/case-studies/issue-7/BEST-PRACTICES-COMPARISON.md` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-7/FORMATTER-COMPARISON.md` | `docs/case-studies/issue-7/FORMATTER-COMPARISON.md` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-7/current-repository-analysis.json` | `docs/case-studies/issue-7/current-repository-analysis.json` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-7/effect-template-analysis.json` | `docs/case-studies/issue-7/effect-template-analysis.json` — Compare implementation/configuration with local counterpart | equal |
| `docs/case-studies/issue-75/CASE-STUDY.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-93/README.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-93/data/ci-runs-issue-93.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-93/data/issue-93-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-93/data/issue-93.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-93/data/link-foundation-eslint-rules-search.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-93/data/link-foundation-no-changelog-comments-search.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-93/data/merged-prs-case-study.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-93/data/merged-prs-eslint.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-93/data/npm-search-eslint-changelog-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-93/data/pr-94.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/javascript-first.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/screenshots/example-app/example-app-en-dark.png` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/screenshots/example-app/example-app-en-light.png` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/screenshots/example-app/example-app-ru-dark.png` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/screenshots/example-app/example-app-ru-light.png` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/screenshots/example-app/example-app.png` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `eslint-rules/no-changelog-comments.js` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `eslint.config.js` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `examples/basic-usage.js` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/Dockerfile` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/README.md` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/cases.json` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/check-parity.mjs` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/generate.mjs` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/generated/lib.rs` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/generated/typed-ir.json` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/inventory.json` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/native-check.mjs` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/native.mjs` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/pins.json` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/universal-app/README.md` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/universal-app/capacitor.config.json` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/universal-app/electron/main.cjs` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/universal-app/electron/preload.cjs` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/universal-app/index.html` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/universal-app/package-lock.json` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/universal-app/package.json` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/universal-app/public/favicon.svg` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/universal-app/src/App.js` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/universal-app/src/main.js` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/universal-app/src/styles.css` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/universal-app/vite.config.js` | Template sample product; preserve existing multi-language application | template-specific |
| `experiments/budget-runner-demo.sh` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/ci-lockfile-probe.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/cli-symlink-probe.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/codemod-visible-skips.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/find-conditional-tests.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/issue-141-multilang-ignore-list.sh` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/issue-203-changesets-version.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/issue-212-regressions.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/issue-212-secretlint.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/issue-216-ci-fixtures.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/issue-216-release-dry-run.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/issue-254-plan.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `experiments/issue-262-crlf-checkout.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/release-notes-fixture.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-changeset-scripts.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-check-release-needed.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-detect-changes.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-failure-detection.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-format-major-changes.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-format-minor-changes.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-format-no-hash.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-format-patch-changes.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-issue75-buildx-mirror-fallback.sh` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/trace-changeset-fixture.cjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/use-m-cdn-unreachable.mjs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `package-lock.json` | `package-lock.json` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `package.json` | `package.json` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/bootstrap-dependencies.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/changeset-version.mjs` | `js/scripts/changeset-version.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/check-changesets.mjs` | `js/scripts/check-changesets.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/check-ci-workflows.mjs` | `js/scripts/check-ci-workflows.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/check-dependency-graph.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-docker-build.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-docker-publish.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-file-line-limits.sh` | `js/scripts/check-file-line-limits.sh` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/check-mjs-syntax.sh` | `js/scripts/check-mjs-syntax.sh` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/check-package-manager.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-pages.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-pipeline-status.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-release-needed.mjs` | `js/scripts/check-release-needed.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/check-required-docs.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-staged-formatting.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-status-gate-covers-all-jobs.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-version.mjs` | `js/scripts/check-version.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/check-web-archive.mjs` | `js/scripts/check-web-archive.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/create-github-release.mjs` | `js/scripts/create-github-release.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/create-manual-changeset.mjs` | `js/scripts/create-manual-changeset.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/debug-print.mjs` | `js/scripts/debug-print.mjs` — Compare implementation/configuration with local counterpart | equal |
| `scripts/detect-code-changes.mjs` | `js/scripts/detect-code-changes.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/format-github-release.mjs` | `js/scripts/format-github-release.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/format-release-notes-helpers.mjs` | `js/scripts/format-release-notes-helpers.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/format-release-notes.mjs` | `js/scripts/format-release-notes.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/github-actions-log.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/github-release-state.mjs` | `js/scripts/github-release-state.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/install-git-hooks.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/instant-version-bump.mjs` | `js/scripts/instant-version-bump.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/js-paths.mjs` | `js/scripts/js-paths.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/land-via-pull-request.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/lint-changed-lines.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/lint.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/merge-changesets.mjs` | `js/scripts/merge-changesets.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/npm-registry.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/package-info.mjs` | `js/scripts/package-info.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/pr-comparison.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/preflight-credentials.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/publish-failure-classifier.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/publish-retry.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/publish-to-npm.mjs` | `js/scripts/publish-to-npm.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/push-failure-classifier.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/push-main-with-rebase-retry.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/read-job-cancel-in-progress.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/recheck-broken-links.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/release-metadata.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/release-naming.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/run-command.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/run-with-budget-warning.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/sanitize-npm-userconfig.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/setup-npm.mjs` | `js/scripts/setup-npm.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/simulate-fresh-merge.sh` | `js/scripts/simulate-fresh-merge.sh` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/smoke-test-package.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/update-preview-images.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/use-module.mjs` | `js/scripts/use-module.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/validate-changeset.mjs` | `js/scripts/validate-changeset.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/version-and-commit.mjs` | `js/scripts/version-and-commit.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/wait-for-npm.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `src/index.d.ts` | `js/src/index.d.ts` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `src/index.js` | `js/src/index.js` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `tests/action-versions.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/bootstrap-dependencies.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/bot-commit-attribution.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/bounded-run.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/changeset-config.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/check-changesets.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/check-file-line-limits.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/check-pages.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/check-release-needed.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/check-staged-formatting.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/check-web-archive.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/checkout-credentials.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/ci-timeouts.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/ci-workflow-policy.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/commit-message.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/container-jobs.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/create-github-release.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/debug-print.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/dependency-graph.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/deprecated-packages.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/detect-code-changes.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/docker-build.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/docker-publish.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/fixtures/lychee-report.md` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/fixtures/pages-stub/gh` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/fixtures/preflight-stub/curl` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/fixtures/wayback-fetch.mjs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/github-actions-log.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/helpers/bounded-run.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/helpers/conditional-registration.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/helpers/env.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/helpers/network.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/helpers/skip.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/index.test.js` | `js/tests/index.test.js` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `tests/install-git-hooks.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/issue-228-regressions.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/issue-262-regressions.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/javascript-first-gate.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/land-via-pull-request.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/links-workflow.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/lint-changed-lines.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/merge-changesets.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/network-skip-reason.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/no-changelog-comments.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/npm-registry.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/package-info.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/package-manager.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/package-metadata.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/pipeline-requirements.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/pipeline-status.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/pr-guards.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/publish-failure-classifier.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/publish-retry.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/push-failure-classifier.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/push-main-with-rebase-retry.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/recheck-broken-links.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/release-badge.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/release-metadata.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/release-naming.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/release-notes-description.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/release-notes-integration.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/release-preflight.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/required-docs.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/run-with-budget-warning.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/sanitize-npm-userconfig.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/scripts-use-module-adoption.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/security-workflow.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/setup-buildx-resilient.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/setup-npm.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/simulate-fresh-merge.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/smoke-test-package.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/status-gate-coverage.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/tag-prefix.test.js` | `js/tests/tag-prefix.test.js` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `tests/transient-links.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/universal-app.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/use-module-integration.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/use-module.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/version-and-commit.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/visible-skips.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/wait-for-npm.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/wayback-cli.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/wayback-retry.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/workflow-permissions.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/workflow-reliability.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/workflows-lint.test.js` | Template regression/example; equivalent local contracts and product tests | template-specific |
