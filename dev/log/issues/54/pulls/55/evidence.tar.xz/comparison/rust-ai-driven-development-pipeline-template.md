# Complete file comparison: rust-ai-driven-development-pipeline-template

Commit: `0ece2cf2c2745c3574ffb65dbabdfcadd7163c14`. Every blob in the recursive tree is listed.

| Template file | Local file / disposition | Content |
| --- | --- | --- |
| `.github/actions/setup-buildx-resilient/action.yml` | Registry-image publishing: not a current product publication target | template-specific |
| `.github/codeql/codeql-config.yml` | `.github/codeql/codeql-config.yml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.github/workflows/desktop-release.yml` | `.github/workflows/desktop-release.yml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.github/workflows/javascript-first-example.yml` | Workflow role mapped in TEMPLATE-COMPARISON.md | template-specific |
| `.github/workflows/javascript-first-gate.yml` | Workflow role mapped in TEMPLATE-COMPARISON.md | template-specific |
| `.github/workflows/links.yml` | `.github/workflows/links.yml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.github/workflows/release.yml` | `.github/workflows/release.yml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.github/workflows/security.yml` | `.github/workflows/security.yml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.github/workflows/workflows.yml` | Workflow role mapped in TEMPLATE-COMPARISON.md | template-specific |
| `.github/zizmor.yml` | `.github/zizmor.yml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.gitignore` | `.gitignore` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.lycheeignore` | `.lycheeignore` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.pre-commit-config.yaml` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `.secretlintrc.json` | `.secretlintrc.json` — Compare implementation/configuration with local counterpart | equal |
| `AGENTS.md` | `AGENTS.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `CHANGELOG.md` | `CHANGELOG.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `CONTRIBUTING.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `Cargo.lock` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `Cargo.toml` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `LICENSE` | `LICENSE` — Compare implementation/configuration with local counterpart | equal |
| `README.md` | `README.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `changelog.d/20261026_120000_pipeline_safety.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/README.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-11/README.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-11/analysis-crates-io.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-11/analysis-set-output.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-11/analysis-workflow-dispatch.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-11/online-research.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-17/README.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-19/README.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-19/ci-logs/ci-run-20885464993.log.gz` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-19/pr-114-data/issue-113-details.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-19/pr-114-data/pr-commits.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-19/pr-114-data/pr-conversation-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-19/pr-114-data/pr-details.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-19/pr-114-data/pr-diff.patch` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-19/pr-114-data/pr-review-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-19/pr-114-data/pr-reviews.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-19/pr-114-data/solution-draft-log-1.txt.gz` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-19/pr-114-data/solution-draft-log-2.txt.gz` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-21/README.md` | `docs/case-studies/issue-21/README.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `docs/case-studies/issue-21/browser-commander-issue-27.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-21/browser-commander-issue-29.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-21/browser-commander-issue-31.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-21/browser-commander-issue-33.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-21/browser-commander-rust.yml` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-25/README.md` | `docs/case-studies/issue-25/README.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `docs/case-studies/issue-29/README.md` | `docs/case-studies/issue-29/README.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `docs/case-studies/issue-32/README.md` | `docs/case-studies/issue-32/README.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `docs/case-studies/issue-34/README.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/README.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/downstream-meta-after-run-24985948212.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/downstream-meta-after-run-24985948212.log.gz` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/downstream-meta-before-run-24983875003.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/downstream-meta-before-run-24983875003.log.gz` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/downstream-meta-ontology-issue-3.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/downstream-meta-ontology-pr-4.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/issue-38-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/issue-38.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/js-template-issue-search.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/main-run-24465255225.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/main-run-24465255225.log.gz` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/main-runs.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/pr-39-conversation-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/pr-39-review-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/pr-39-reviews.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/pr-39.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/pr-branch-runs.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/pr-run-25212295127.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/pr-run-25212295127.log.gz` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/raw-data/rust-template-issue-search.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/template-data/js-template-ci-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/template-data/js-template-links.yml` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/template-data/js-template-release.yml` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/template-data/rust-template-ci-tree.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/template-data/rust-template-release-after.yml` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-38/template-data/rust-template-release-before.yml` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-52/README.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-52/raw-data/issue-52-comments.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-52/raw-data/issue-52.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-52/raw-data/js-issue-62.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-52/raw-data/vk-bot-desktop-issue-51.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-52/raw-data/vk-bot-desktop-pr-52.json` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/case-studies/issue-69/README.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/ci-cd/troubleshooting.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/download/index.html` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/issue-188-analysis.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/issue-194-analysis.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/issue-215-analysis.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/javascript-first.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/screenshots/desktop-download-page.png` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `examples/basic_usage.rs` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/.dockerignore` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/Cargo.lock` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/Cargo.toml` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/Dockerfile` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/check-parity.mjs` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/fixtures.json` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/generate.mjs` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/ir.json` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/native.mjs` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/native.test.mjs` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/parity.json` | Template sample product; preserve existing multi-language application | template-specific |
| `examples/javascript-first/src/lib.rs` | Template sample product; preserve existing multi-language application | template-specific |
| `experiments/issue-139-multi-language-detect-code-changes.sh` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/issue-188-regressions.py` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/issue-190-rename-regressions.py` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/issue-192-release-io-regressions.py` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/issue-193-zizmor-inputs.py` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/issue-215-regressions.py` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-changelog-parsing.rs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-crates-io-check.rs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-detect-code-changes.sh` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-issue141-manifest-printf-quoting.sh` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-issue143-throttled-crates-io-probe.rs` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-issue69-buildx-mirror-fallback.sh` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-version-check-dependencies.sh` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/test-version-check.sh` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `lychee.toml` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `scripts/bump-version.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/changelog-files.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-cargo-lock.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-cargo-warnings.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-changelog-fragment.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-crate-size.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-dependency-graph.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-file-size.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-pipeline-status.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-release-needed.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-required-docs.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-version-modification.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-web-archive.mjs` | `js/scripts/check-web-archive.mjs` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/check-web-archive.test.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-workflow-tools.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/collect-changelog.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/crates-publish-preflight.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/crates-publish-preflight.test.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/create-changelog-fragment.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/create-github-release.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/desktop-release-resolve.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/detect-code-changes.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/fixtures/lychee-report.md` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/get-bump-type.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/get-version.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/git-config.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/github-output.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/install-rust-script.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/javascript-first.test.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/package-desktop.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/preflight-credentials.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/publish-crate.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/read-job-cancel-in-progress.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/recheck-broken-links.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/recheck-broken-links.test.mjs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/release-index.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/release-naming.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/run-javascript-first.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/run-with-budget-warning.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/rust-paths.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/simulate-fresh-merge.sh` | `js/scripts/simulate-fresh-merge.sh` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/smoke-test-published-crate.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/test-scripts.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/version-and-commit.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/version-and-commit/crates-io.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/version-and-commit/tests.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/wait-for-crate.rs` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `src/lib.rs` | Template sample product; preserve existing multi-language application | template-specific |
| `src/main.rs` | Template sample product; preserve existing multi-language application | template-specific |
| `src/sum.rs` | Template sample product; preserve existing multi-language application | template-specific |
| `tests/integration/mod.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/integration/sum.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/changelog_parsing.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/desktop_release_resolve.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_119.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_127.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_135.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_141.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_143.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_147.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_149.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_150.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_156.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_157.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_160.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_161.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_163.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_168.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_171.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_172.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_188.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/issue_193.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/mod.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/release_naming_tests.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/version_and_commit_behind_check.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/version_and_commit_tag_order.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/workflow_desktop_release.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/workflow_release.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/workflow_release_gates.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/workflow_security.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/ci-cd/workspace_manifest_resolution.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/mod.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/unit/sum.rs` | Template regression/example; equivalent local contracts and product tests | template-specific |
