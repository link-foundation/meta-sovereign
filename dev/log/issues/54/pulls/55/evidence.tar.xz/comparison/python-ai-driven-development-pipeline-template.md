# Complete file comparison: python-ai-driven-development-pipeline-template

Commit: `317c243a7cc832b0abfe4d30989c5095d17fcd78`. Every blob in the recursive tree is listed.

| Template file | Local file / disposition | Content |
| --- | --- | --- |
| `.github/actionlint.yaml` | `.github/actionlint.yaml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.github/codeql/codeql-config.yml` | `.github/codeql/codeql-config.yml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.github/workflows/docs.yml` | Workflow role mapped in TEMPLATE-COMPARISON.md | template-specific |
| `.github/workflows/links.yml` | `.github/workflows/links.yml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.github/workflows/release.yml` | `.github/workflows/release.yml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.github/workflows/security.yml` | `.github/workflows/security.yml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.github/workflows/workflows.yml` | Workflow role mapped in TEMPLATE-COMPARISON.md | template-specific |
| `.github/zizmor.yml` | `.github/zizmor.yml` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.gitignore` | `.gitignore` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.lycheeignore` | `.lycheeignore` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `.pre-commit-config.yaml` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `.ruff.toml` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `.secretlintrc.json` | `.secretlintrc.json` — Compare implementation/configuration with local counterpart | equal |
| `CHANGELOG.md` | `CHANGELOG.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `CONTRIBUTING.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `LICENSE` | `LICENSE` — Compare implementation/configuration with local counterpart | equal |
| `README.md` | `README.md` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `changelog.d/20251218_133759_drakonard_issue_1_3b50e2f12be6.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260509_204000_issue_6_release_metadata.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260515_000000_issue_8_docs_pages.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260529_222900_issue_9_preview_regeneration.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260604_170000_issue_16_release_notes_limit.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260609_000000_issue_18_manual_release_skip.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260614_000000_issue_20_published_package_smoke_test.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260614_issue_21_python_monorepo_releases.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260628_issue_24_file_size_warnings.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260703_issue_26_docs_pages_opt_in.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260703_issue_27_codecov_token_gate.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260703_issue_28_git_default_branch_env.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260722_issue_32_node24_actions.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260722_issue_33_release_permissions.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260722_issue_34_codecov_v7_input.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260722_issue_35_ci_release_guards.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260727_issue_40_change_detection.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260801_issue_42_workflow_hardening.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260802_issue_44_mypy_python_39.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260802_issue_45_changelog_check.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260809_issue_48_security_scanning.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260809_issue_49_broken_links.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260809_issue_50_pipeline_timeout_status.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260812_issue_54_archived_broken_links.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260812_issue_55_multi_arch_docker.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260816_issue_58_dependency_audit.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260820_issue_60_step_execution_budgets.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260828_issue_62_workflow_lint.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260903_issue_64_workflow_audit.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260909_issue_66_pipeline_hardening.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260915_issue_83_pipeline_false_negatives.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20260927_issue_85_86_release_changelog_artifact.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20261005_issue_91_ci_links.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20261007_issue_100_fragment_replacements.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20261007_issue_93_changelog_validation.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20261007_issue_98_ci_release_recovery.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20261010_issue_102_zizmor_reproduction.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/20261024_pipeline_safeguards.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/README.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `changelog.d/fragment_template.md.j2` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/api.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/conf.py` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/index.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/preview-regeneration.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `docs/requirements.txt` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `examples/basic_usage.py` | Template sample product; preserve existing multi-language application | template-specific |
| `experiments/issue_98_analysis.md` | Documentation/release fragment; compare policy, do not import template product history | template-specific |
| `experiments/reproduce_actionlint_queue.py` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/reproduce_partial_release.py` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `experiments/reproduce_zizmor_scope.py` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `lychee.toml` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `pyproject.toml` | Language/tool/project configuration; reviewed applicability in TEMPLATE-COMPARISON.md | template-specific |
| `scripts/audit_dependencies.py` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/bump_version.py` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-dependency-graph.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-pipeline-status.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check-required-docs.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check_file_size.py` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check_release.py` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/check_web_archive.py` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/create_github_release.py` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/create_manual_changeset.py` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/detect_code_changes.py` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/format_release_notes.py` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/preflight-credentials.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/publish_to_pypi.py` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/read-job-cancel-in-progress.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/read_manifest.py` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/recheck_broken_links.py` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/release_naming.py` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/run-with-budget-warning.sh` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/simulate-fresh-merge.sh` | `js/scripts/simulate-fresh-merge.sh` — Compare implementation/configuration with local counterpart | different: full diff archived |
| `scripts/smoke_test_published_package.py` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/validate_changeset.py` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `scripts/version_and_commit.py` | Script role mapped in TEMPLATE-COMPARISON.md; language-specific implementation | template-specific |
| `src/my_package/__init__.py` | Template sample product; preserve existing multi-language application | template-specific |
| `src/my_package/py.typed` | Template sample product; preserve existing multi-language application | template-specific |
| `tests/__init__.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_audit_dependencies.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_check_dependency_graph.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_check_file_size.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_check_pipeline_status.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_check_release.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_check_required_docs.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_check_web_archive.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_create_github_release.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_detect_code_changes.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_issue_118_workflows.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_issue_91.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_issue_98.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_my_package.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_preflight_credentials.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_preview_regeneration_docs.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_project_metadata.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_read_manifest.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_recheck_broken_links.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_release_workflow.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_run_with_budget_warning.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_simulate_fresh_merge.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_smoke_test_published_package.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_validate_changeset.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_version_and_commit.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/test_workflows.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
| `tests/workflow_helpers.py` | Template regression/example; equivalent local contracts and product tests | template-specific |
