### Minimal reproduction

Node 26.12.1, store2 2.14.4:

```sh
node --trace-warnings -e "require('store2')"
```

The import emits `ExperimentalWarning: localStorage is not available because --localstorage-file was not provided.` The stack points to `dist/store2.js:264`, where the local area's initializer evaluates the bare `localStorage` global inside try/catch. This does not require using the storage API.

A deterministic probe, independent of Node's warning policy, also shows the read:

```js
let reads = 0;
Object.defineProperty(globalThis, 'localStorage', {
  configurable: true,
  get() { reads += 1; return undefined; }
});
require('store2');
console.log(reads); // 1
```

### Impact and cause

Node exposes localStorage as a lazy accessor. Reading it emits a warning when no storage file is configured; try/catch catches exceptions but cannot prevent warnings. We encountered this transitively through teleproto's eagerly loaded optional StoreSession while our application only uses StringSession. Its explicit disk area does not need a browser-global default area. Our three-OS CI emitted 21 warnings; the focused trace isolates this line. The current source at `2fd7c93ac24855b98a56c05566cc19f2bb3e4229` still contains the same eager initializer.

### Workarounds and proposed repair

A dedicated headless Node process can use `--no-experimental-webstorage` (verified locally), which disables Node's experimental Web Storage process-wide. Avoid configuring an unnecessary process-wide persistent storage file merely to silence an unused default area.

A consuming library can defer loading store2/the disk driver until that driver is actually used. Our downstream adapter preserves all original session classes, globals and warning handlers; https://github.com/sanyok12345/teleproto/issues/53 tracks that initialization issue.

For store2 itself, consider deferring default-area initialization, or inspecting the storage descriptor outside a browser before invoking a lazy getter, selecting the existing memory fallback when browser storage is unavailable. Preserve ordinary injected data-property storage, working browser storage, denied-origin handling and explicit `store.area(name, customStorage)` support. If supporting native Node persistent storage is intended, make that an explicit selection rather than implicitly triggering the getter on every import.

Regression coverage should instrument an accessor and assert a headless import does not read it, then check injected/browser/custom storage round trips, the existing fake-memory fallback and unrelated warning visibility. No broad warning suppression is needed.

Full downstream trace and before/after evidence: https://github.com/link-foundation/meta-sovereign/pull/53, under `dev/log/issues/52/pulls/53/`. The downstream repair avoids the unused eager import; this report does not claim an upstream release is fixed.
