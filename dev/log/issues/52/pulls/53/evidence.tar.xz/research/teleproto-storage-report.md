### Reproduction

With Node 26.12.1 and the latest published teleproto 1.232.0 (store2 2.14.4):

```sh
node --trace-warnings -e "require('teleproto')"
```

No client, session or Telegram network connection is needed. The import emits:

```text
ExperimentalWarning: localStorage is not available because --localstorage-file was not provided.
    at Object.get (node:internal/webstorage:42:21)
    at get (node:internal/process/pre_execution:488:58)
    at .../node_modules/store2/dist/store2.js:264:43
```

Our CI observes this seven times per OS, on Linux, Windows and macOS. It is not from our browser preference helper: a focused offline rich-message test and the trace above isolate the transitive dependency.

### Cause

`index.js` loads `sessions/index.js` eagerly. That module eagerly imports `StoreSession`, which eagerly imports `store2`. store2 initializes its default local area by evaluating the bare `localStorage` global inside try/catch. Node exposes this as a lazy getter: merely evaluating it emits a warning. Catching exceptions cannot prevent a warning.

This occurs even when the application uses only `StringSession` and never constructs the disk driver. In contrast, StoreSession itself uses an explicit custom `node-localstorage` area.

### Workarounds and suggested code fix

For a dedicated headless Node process, `--no-experimental-webstorage` avoids initializing Node's experimental Web Storage; it disables that feature process-wide. Configuring `--localstorage-file` unnecessarily creates process-wide persistent browser-style storage and is not appropriate just to silence an unused driver import.

Our downstream compatibility adapter instead registers the same four `sessions` CommonJS exports as lazy getters before importing teleproto. String/Memory/Session retain their original constructors, and StoreSession still loads the original implementation if explicitly requested. No global descriptor, dependency file or warning handler is modified. Two fresh-process regressions first fail on the unmodified package, then pass through the adapter: unused storage is never read, the original global descriptor stays intact, disk sessions remain available, and actual imports emit no storage warning.

Suggested upstream repair: make the StoreSession export lazy at the JavaScript/CommonJS boundary, and defer `require('store2')` inside StoreSession until construction (or create the disk area without probing browser-global storage). A TypeScript re-export compiled to an eager require is insufficient. For store2 itself, inspect the global descriptor outside a browser before reading a lazy accessor, preserving ordinary injected storage and browser origin/error handling.

Add offline tests that import the root package and sessions without touching an instrumented native-storage getter, construct/use StringSession, and still construct/reopen an actual disk-backed StoreSession when requested. Keep unrelated warnings observable.

Downstream investigation/fix: https://github.com/link-foundation/meta-sovereign/pull/53. Full trace, before/after regressions and raw three-OS CI logs are retained in its checksummed `dev/log/issues/52/pulls/53/` evidence archive.
