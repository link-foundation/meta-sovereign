async (page) => (async (page, fixture, check) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      language
    );
    await page.goto(`${fixture.base}/?vkLocale=${language}#conn-vk/manual`);
    const panel = page.locator(`[data-${fixture.feature}]`);
    const ready = () =>
      page.waitForFunction((feature) => {
        const input = document.querySelector(feature);
        return input && !input.disabled;
      }, `[data-${fixture.feature}] ${fixture.readySelector}`);
    // A mounted heading and an enabled control distinguish loading from absence.
    await panel
      .getByRole('heading', { name: words.title, exact: true })
      .waitFor();
    await ready();
    for (const key of fixture.keys) {
      if (!(await panel.innerText()).includes(words[key])) {
        throw Error(`Missing ${language}.${key}`);
      }
    }
    const { focus, ...checked } = await check(page, {
      panel,
      words,
      ready,
      feature: fixture.feature,
      fixture,
      action: async (name) => {
        await panel.locator(`[data-action=${fixture.feature}-${name}]`).click();
        await ready();
      },
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await panel.locator(focus).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-${fixture.evidenceName}/mcp-${language}-phone.png`,
    });
    result.push({ language, translated: true, ...checked });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:46049","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","feature":"vk-friends","evidenceName":"vk-configured","readySelector":"input[type=checkbox]","control":"http://127.0.0.1:37891","hints":{"en":"Accepts up to {percent}% of distinct incoming requesters observed by this account, ranked by mutual friends, within the configured friend capacity and batch limit. Repeated reviews do not increase allowance. Priority requests come first and do not spend this allowance, but still require capacity; unknown attempts keep their reservation.","ru":"Принимает до {percent}% разных входящих заявителей этого аккаунта по числу общих друзей, в пределах заданного числа друзей и размера пакета. Повторный просмотр не увеличивает квоту. Приоритетные заявки идут первыми и не расходуют квоту, но также требуют свободного места; неизвестные попытки сохраняют резерв.","zh":"按共同好友排序，在设定的好友容量和批次限制内，接受此账户观察到的不同请求者中最多 {percent}%。重复审核不会增加名额。优先请求先处理且不消耗该名额，但同样需要可用容量；结果未知的尝试保留预留名额。","hi":"इस खाते में देखे गए अलग अनुरोधकर्ताओं में से अधिकतम {percent}% को साझा मित्रों के क्रम में, तय मित्र क्षमता और बैच सीमा के भीतर स्वीकारता है। दोबारा समीक्षा से कोटा नहीं बढ़ता। प्राथमिक अनुरोध पहले आते हैं और कोटा नहीं लेते, लेकिन उनके लिए भी जगह चाहिए; अज्ञात प्रयास आरक्षण रखते हैं।"},"keys":["acceptancePolicy","desktop-configured"],"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"VK friend requests","acceptancePolicy":"Incoming acceptance policy","desktop-configured":"Lifetime quota with friend capacity"},"ru":{"title":"Заявки в друзья ВКонтакте","acceptancePolicy":"Правила приёма входящих","desktop-configured":"Квота за всё время и предел числа друзей"},"hi":{"title":"VK मित्र अनुरोध","acceptancePolicy":"आने वाले अनुरोध स्वीकारने की नीति","desktop-configured":"पूरे समय का कोटा और मित्रों की क्षमता"},"zh":{"title":"VK 好友请求","acceptancePolicy":"收到请求的接受规则","desktop-configured":"累计名额与好友容量"}}}, (async (page, { panel, ready, fixture }) => {
  const choice = panel.locator('[data-friend-field=acceptancePolicy]');
  await choice.selectOption('desktop-configured');
  await ready();
  const percentage = panel.locator('[data-friend-field=topPercentMutuals]');
  await percentage.fill('12.5');
  await panel.locator('[data-action=vk-friends-save]').click();
  await ready();
  await page.reload();
  await ready();
  if ((await percentage.inputValue()) !== '12.5' ||
      (await choice.inputValue()) !== 'desktop-configured' ||
      !(await panel.innerText()).includes(fixture.hints[await page.locator('html').getAttribute('lang')].replace('{percent}', '12.5'))) {
    throw new Error('Configured choice, percentage or translated hint lost');
  }
  await page.request.post(`${fixture.control}/refuse`);
  await percentage.fill('35');
  await panel.locator('[data-action=vk-friends-save]').click();
  await panel.getByRole('alert').waitFor();
  const refused = await (await page.request.get(fixture.control)).json();
  if ((await percentage.inputValue()) !== '35' || refused.settings.topPercentMutuals !== 12.5) {
    throw new Error('Refused percentage overwrote saved policy or lost owner draft');
  }
  await page.request.post(`${fixture.control}/allow`);
  await page.reload();
  await ready();
  const result = await (await page.request.get(fixture.control)).json();
  if ((await percentage.inputValue()) !== '12.5' || result.syntheticFriendCalls || result.messages) {
    throw new Error('Read-only recovery changed configuration or issued effects');
  }
  return { focus: '[data-friend-field=topPercentMutuals]', savedChoiceRetained: true, fractionalPercentage: true, refusedDraftRetained: true, syntheticFriendCalls: 0, messages: 0 };
}))