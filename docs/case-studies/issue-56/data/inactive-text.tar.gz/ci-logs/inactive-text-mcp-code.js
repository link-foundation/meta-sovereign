async (page) => {
  const mcpCrypto = {randomUUID:()=>crypto.randomUUID(),randomBytes:n=>Buffer.from(crypto.getRandomValues(new Uint8Array(n)))};
  const process = {env:{}};
  var inactiveContract = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    openBrowserAnswerWatch: () => openBrowserAnswerWatch
  });

  // mcp:node:crypto
  var randomUUID = () => mcpCrypto.randomUUID();
  var randomBytes = (n) => mcpCrypto.randomBytes(n);

  // js/src/sources/browser-inactive-view.js
  var browserInactiveView = ({ operation, token }) => {
    const key = /* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1");
    const current = (state2) => state2.interrupted || document.hasFocus() ? "owner-active" : "ready";
    if (operation === "open" && !window[key]) {
      if (document.hasFocus()) {
        return { state: "owner-active" };
      }
      const state2 = { token, interrupted: false };
      state2.interrupt = () => {
        state2.interrupted = true;
        state2.notify?.();
      };
      state2.events = [
        "pointerdown",
        "keydown",
        "wheel",
        "touchstart",
        "touchmove",
        "input"
      ];
      state2.mark = (event) => {
        if (!event.isTrusted && event === state2.ownedInput) {
          return;
        }
        if (event.isTrusted || event.type === "input") {
          state2.interrupt();
        }
      };
      state2.focus = () => {
        if (document.hasFocus()) {
          state2.interrupt();
        }
      };
      for (const type of state2.events) {
        document.addEventListener(type, state2.mark, {
          capture: true,
          passive: true
        });
      }
      window.addEventListener("focus", state2.focus, true);
      document.addEventListener("visibilitychange", state2.focus, true);
      window[key] = state2;
    }
    const state = window[key];
    if (!state || state.token !== token) {
      return { state: state ? "busy" : "unavailable" };
    }
    const status = current(state);
    if (operation === "release") {
      state.releaseRelay?.();
      for (const type of state.events) {
        document.removeEventListener(type, state.mark, true);
      }
      window.removeEventListener("focus", state.focus, true);
      document.removeEventListener("visibilitychange", state.focus, true);
      delete window[key];
    }
    return { state: status };
  };
  var linkBrowserInactiveOwner = async ({ token }) => {
    const state = window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")];
    if (!state || state.token !== token) {
      return false;
    }
    if (state.releaseRelay) {
      return state.relayReady;
    }
    const owner = window.top === window;
    const peers = /* @__PURE__ */ new Set();
    const type = "meta-sovereign.browser-inactive-owner.v1";
    const send = (peer, operation) => {
      try {
        peer.postMessage({ type, token, operation }, "*");
      } catch {
        state.interrupted = true;
      }
    };
    let complete;
    let timer;
    const ready = owner ? Promise.resolve(true) : new Promise((resolve) => {
      complete = resolve;
      timer = setTimeout(() => resolve(false), 1e3);
    });
    state.relayReady = ready;
    const ownerStatus = () => state.interrupted || document.hasFocus() ? "owner-active" : "ready";
    const receive = (event) => {
      const data = event.data;
      if (data?.type !== type || data.token !== token || !event.source) {
        return;
      }
      if (owner && event.source !== window && data.operation === "observe") {
        if (peers.size >= 64 && !peers.has(event.source)) {
          return;
        }
        peers.add(event.source);
        send(event.source, ownerStatus());
      } else if (!owner && event.source === window.top) {
        if (data.operation === "owner-active") {
          state.interrupt();
          complete(false);
        } else if (data.operation === "ready") {
          complete(true);
        }
      }
    };
    state.notify = () => {
      for (const peer of peers) {
        send(peer, "owner-active");
      }
    };
    state.releaseRelay = () => {
      window.removeEventListener("message", receive, true);
      clearTimeout(timer);
      complete?.(false);
      peers.clear();
      delete state.notify;
    };
    window.addEventListener("message", receive, true);
    if (!owner) {
      send(window.top, "observe");
    }
    const linked = await ready;
    clearTimeout(timer);
    return linked;
  };
  var failure = (state) => {
    if (process.env.MS_BROWSER_HISTORY_DEBUG === "1") {
      console.error("[browser-inactive-view]", { state });
    }
    return Object.assign(
      new Error("The inactive provider view is no longer owned."),
      {
        code: `browser-background-${state}`,
        historyReason: state === "owner-active" ? state : "document-changed",
        fallback: false
      }
    );
  };
  var prepareBrowserInactiveView = async (page2) => {
    const context = page2.context();
    if (context.browser()?.browserType().name() !== "chromium") {
      throw failure("focus-unavailable");
    }
    let session;
    try {
      session = await context.newCDPSession(page2);
      await session.send("Emulation.setFocusEmulationEnabled", {
        enabled: false
      });
    } catch {
      throw failure("focus-unavailable");
    } finally {
      await session?.detach().catch(() => {
      });
    }
  };
  var withInactiveBrowserView = async (document2, read, { relayOwner = false } = {}) => {
    if (["evaluateOwner", "evaluate"].some(
      (method) => typeof document2?.[method] !== "function"
    )) {
      throw failure("unavailable");
    }
    const token = randomUUID();
    const control = async (operation) => {
      for (const method of ["evaluateOwner", "evaluate"]) {
        const result = await document2[method]({
          fn: browserInactiveView,
          args: [{ operation, token }]
        });
        if (result.state !== "ready") {
          throw failure(result.state);
        }
      }
    };
    try {
      await document2.prepareInactiveView?.();
      await control("open");
      if (relayOwner) {
        for (const method of ["evaluateOwner", "evaluate"]) {
          const result2 = await document2[method]({
            fn: linkBrowserInactiveOwner,
            args: [{ token }]
          });
          if (!result2) {
            throw failure("owner-unverified");
          }
        }
        await control("status");
      }
      const result = await read(() => control("status"), token);
      await control("status");
      return result;
    } finally {
      await Promise.allSettled(
        ["evaluate", "evaluateOwner"].map(
          (method) => document2[method]({
            fn: browserInactiveView,
            args: [{ operation: "release", token }]
          })
        )
      );
    }
  };

  // js/src/sources/browser-choice-document.js
  var failure2 = () => Object.assign(
    new Error("The visible provider chat document changed or is ambiguous"),
    {
      code: "answer-chat-unverified",
      fallback: false
    }
  );
  var browserDocumentIdentity = (selector) => {
    const key = /* @__PURE__ */ Symbol.for("meta-sovereign.browser-choice-document.v1");
    window[key] ??= crypto.randomUUID();
    return { key: window[key], rows: document.querySelectorAll(selector).length };
  };
  var browserFrameVisible = (node) => {
    if (!node.isConnected || !node.getClientRects().length) {
      return false;
    }
    for (let parent = node; parent; parent = parent.parentElement) {
      const style = getComputedStyle(parent);
      if (parent.hidden || parent.getAttribute("aria-hidden") === "true" || style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) {
        return false;
      }
    }
    return true;
  };
  var trusted = (address, origins) => {
    const url = new URL(address);
    return origins.includes(url.origin) && !url.username && !url.password;
  };
  var inChat = (frame, ui, target) => {
    const url = new URL(frame.url());
    return trusted(url.href, ui.location.origins) && new RegExp(ui.location.pathPattern).exec(url.pathname)?.[1] === String(target);
  };
  var visibleFrame = async (frame, main, ui) => {
    for (let current = frame; current && current !== main; current = current.parentFrame()) {
      if (!trusted(current.url(), ui.documents.ancestorOrigins)) {
        return false;
      }
      const element = await current.frameElement();
      try {
        if (!await element.evaluate(browserFrameVisible)) {
          return false;
        }
      } finally {
        await element.dispose();
      }
    }
    return true;
  };
  var inList = (frame, ui) => trusted(frame.url(), ui.location.origins) && new RegExp(ui.chatScan.pathPattern).test(new URL(frame.url()).pathname);
  var chooseDocument = async (page2, ui, target, list = false) => {
    if (!page2 || !trusted(page2.url(), ui.documents.ownerOrigins)) {
      throw failure2();
    }
    const main = page2.mainFrame();
    const ownerRoute = new RegExp(ui.location.pathPattern).exec(
      new URL(page2.url()).pathname
    );
    if (list ? !new RegExp(ui.chatScan.pathPattern).test(new URL(page2.url()).pathname) : ownerRoute && ownerRoute[1] !== String(target)) {
      throw failure2();
    }
    const frames = page2.frames();
    if (frames.length > ui.documents.maxFrames) {
      throw failure2();
    }
    const candidates = [];
    const selector = list ? ui.chats.item : ui.messages.item;
    for (const frame of frames) {
      const matching = list ? inList(frame, ui) : inChat(frame, ui, target);
      if (matching && await visibleFrame(frame, main, ui)) {
        const identity = await frame.evaluate(browserDocumentIdentity, selector);
        if (identity.rows) {
          candidates.push({ frame, identity, frameUrl: frame.url() });
        }
      }
    }
    if (candidates.length !== 1) {
      throw failure2();
    }
    const owner = await main.evaluate(browserDocumentIdentity, selector);
    return { ...candidates[0], owner: owner.key, url: page2.url() };
  };
  var resolveBrowserDocument = async (commander, page2, ui, target, list = false) => {
    if (!ui.documents) {
      return commander;
    }
    let selected;
    try {
      selected = await chooseDocument(page2, ui, target, list);
    } catch {
      throw failure2();
    }
    const assertCurrent = async () => {
      try {
        const current = await chooseDocument(page2, ui, target, list);
        if (current.frame !== selected.frame || current.frameUrl !== selected.frameUrl || current.identity.key !== selected.identity.key || current.owner !== selected.owner || current.url !== selected.url) {
          throw failure2();
        }
      } catch {
        throw failure2();
      }
    };
    const ownerFrame = page2.mainFrame();
    return {
      async prepareInactiveView() {
        await assertCurrent();
        await prepareBrowserInactiveView(page2);
        await assertCurrent();
      },
      async evaluateOwner({ fn, args = [] }) {
        if (args.length > 1) {
          throw failure2();
        }
        if (args[0]?.operation === "release") {
          return ownerFrame.evaluate(fn, args[0]);
        }
        await assertCurrent();
        const result = await ownerFrame.evaluate(fn, args[0]);
        await assertCurrent();
        return result;
      },
      async evaluate({ fn, args = [] }) {
        if (args.length > 1) {
          throw failure2();
        }
        if (args[0]?.operation === "release") {
          return selected.frame.evaluate(fn, args[0]);
        }
        await assertCurrent();
        const value = selected.frame === page2.mainFrame() ? await commander.evaluate({ fn, args }) : await selected.frame.evaluate(fn, args[0]);
        await assertCurrent();
        return value;
      },
      async clickButton({ selector, inactiveToken }) {
        await assertCurrent();
        if (inactiveToken) {
          for (const frame of /* @__PURE__ */ new Set([ownerFrame, selected.frame])) {
            const { state } = await frame.evaluate(browserInactiveView, {
              operation: "status",
              token: inactiveToken
            });
            if (state !== "ready") {
              throw Object.assign(
                new Error("Inactive reply ownership changed."),
                {
                  code: `browser-background-${state}`,
                  fallback: false,
                  dispatched: false
                }
              );
            }
          }
        }
        if (selected.frame === page2.mainFrame()) {
          await commander.clickButton({
            selector,
            scrollIntoView: !inactiveToken,
            ...inactiveToken ? { activation: "dom", scroll: "none" } : {},
            waitForNavigation: false,
            waitAfterClick: 0,
            verify: false
          });
        } else if (inactiveToken) {
          await selected.frame.locator(selector).evaluate((node) => node.click());
        } else {
          await selected.frame.locator(selector).click({ timeout: 5e3 });
        }
      }
    };
  };
  var resolveBrowserChoiceDocument = (commander, page2, ui, target) => resolveBrowserDocument(commander, page2, ui, target);

  // js/src/sources/browser-choice-visibility.js
  var watchChoiceView = (attempt, stop = false) => {
    if (!stop) {
      attempt.viewChanged = (event) => {
        if (event.type !== "pointerdown" || event.target !== attempt.node && !attempt.node.contains(event.target)) {
          attempt.preserveView = true;
        }
      };
    }
    for (const type of [
      "wheel",
      "touchmove",
      "keydown",
      "input",
      "pointerdown"
    ]) {
      document[stop ? "removeEventListener" : "addEventListener"](
        type,
        attempt.viewChanged,
        true
      );
    }
  };
  var revealChoiceReply = (spec, attempt, current, message) => {
    if (attempt.preserveView) {
      return "owner-activity";
    }
    const composer = current.composer;
    if (composer && String(composer.value ?? composer.textContent ?? "")) {
      return "owner-draft";
    }
    const pattern = new RegExp(spec.messages.idPattern);
    const nodes = [...document.querySelectorAll(spec.messages.item)].filter(
      (node) => pattern.exec(node.getAttribute(spec.messages.idAttribute) ?? "")?.[1] === message.id
    );
    if (nodes.length !== 1) {
      return "unavailable";
    }
    try {
      nodes[0].scrollIntoView({
        block: "nearest",
        inline: "nearest",
        behavior: "instant"
      });
      return "revealed";
    } catch {
      return "unavailable";
    }
  };

  // mcp:node:timers/promises
  var setTimeout2 = (ms) => page.waitForTimeout(ms);

  // js/src/sources/browser-pending-turn.js
  var browserPendingTurn = (rows) => {
    const validText = (value, limit, empty = false) => typeof value === "string" && value.length <= limit && (empty || Boolean(value.trim()));
    const end = rows.findLastIndex((row) => row.outgoing || row.service);
    const last = rows[end];
    const messages = rows.slice(end + 1).map(({ id, body }) => ({ id, body }));
    const boundary = last ? {
      kind: last.service ? "service" : "outgoing",
      id: last.id,
      body: last.body
    } : { kind: "rendered-start" };
    if (messages.length > 20 || messages.reduce((size, row) => size + String(row.body ?? "").length, 0) > 24e3) {
      return { code: "answer-history-limited" };
    }
    const relevant = last ? [last, ...messages] : messages;
    if (relevant.some(
      (row) => !validText(row.id, 480) || !validText(row.body, 6e3, row === last)
    ) || new Set(relevant.map((row) => row.id)).size !== relevant.length) {
      return { code: "answer-history-unverified" };
    }
    return { boundary, messages };
  };
  var checkedBrowserPendingTurn = (turn, question) => {
    if (turn === void 0) {
      return void 0;
    }
    const boundary = turn?.boundary;
    if (!Array.isArray(turn?.messages) || turn.messages.length > 20 || !["rendered-start", "outgoing", "service"].includes(boundary?.kind)) {
      return null;
    }
    const rows = turn.messages.map((row) => ({ id: row?.id, body: row?.body }));
    if (boundary.kind !== "rendered-start") {
      rows.unshift({
        id: boundary.id,
        body: boundary.body,
        outgoing: boundary.kind === "outgoing",
        service: boundary.kind === "service"
      });
    }
    const value = browserPendingTurn(rows);
    const latest = rows.at(-1);
    return !value.code && latest?.id === question.id && latest.body === question.body && Boolean(latest.outgoing) === question.outgoing && !latest.service ? value : null;
  };

  // js/src/sources/browser-choice-reader.js
  var browserChoiceSuggestions = (spec, group, all, visible, text) => {
    if (!spec.choices.genericGroup || !group.matches(spec.choices.genericGroup) || group.closest(spec.messages.item)) {
      return false;
    }
    const offered = all.filter((node) => group.contains(node) && visible(node));
    const pattern = new RegExp(spec.choices.genericPattern, "iu");
    return offered.length > 0 && offered.some((node) => pattern.test(text(node)));
  };
  var browserChoiceHistory = (spec, visible, text, historyOnly = false) => {
    const unavailable = (code) => ({ code });
    const validLocation = (url2, match2) => spec.location.origins.includes(url2.origin) && Boolean(match2?.[1]);
    const validRows = (rows2) => !rows2.some((row) => !row.id || row.body.length > 6e3) && new Set(rows2.map((row) => row.id)).size === rows2.length;
    const bodyOf = (node) => String(node.querySelector(spec.messages.body)?.innerText ?? "").trim();
    const url = new URL(location.href);
    const match = new RegExp(spec.location.pathPattern).exec(url.pathname);
    if (!validLocation(url, match)) {
      return unavailable("answer-chat-unverified");
    }
    const chat = match[1];
    const candidates = [...document.querySelectorAll(spec.messages.item)];
    if (candidates.length > 500) {
      return unavailable("answer-history-limited");
    }
    const idPattern = new RegExp(spec.messages.idPattern);
    const serviceTitle = spec.messages.serviceTitlePattern ? new RegExp(spec.messages.serviceTitlePattern, "iu") : null;
    const rows = candidates.filter(visible).map((node) => ({
      node,
      id: idPattern.exec(node.getAttribute(spec.messages.idAttribute) ?? "")?.[1],
      body: bodyOf(node),
      outgoing: node.matches(spec.messages.outgoing) || Boolean(node.querySelector(spec.messages.outgoing)),
      ...serviceTitle?.test(text(node.querySelector(spec.messages.serviceTitle))) ? { service: true } : {}
    }));
    if (!validRows(rows)) {
      return unavailable("answer-history-unverified");
    }
    const messages = rows.map(({ node, ...row }) => ({
      ...row,
      timestamp: spec.messages.timestampAttribute ? node.getAttribute(spec.messages.timestampAttribute) : null
    }));
    const latest = rows.at(-1);
    const pendingTurn = historyOnly ? void 0 : browserPendingTurn(messages);
    if (pendingTurn?.code) {
      return pendingTurn;
    }
    return {
      chat,
      latest,
      messages,
      pendingTurn,
      questionAvailable: Boolean(latest?.body) && !latest.service
    };
  };
  var readBrowserChoices = (spec, internal = false, historyOnly = false) => {
    const text = (node) => String(node?.textContent ?? "").replace(/\s+/gu, " ").trim();
    const visible = (node) => {
      if (!node?.isConnected || !node.getClientRects().length) {
        return false;
      }
      for (let parent = node; parent; parent = parent.parentElement) {
        const style = getComputedStyle(parent);
        if (parent.hidden || parent.getAttribute("aria-hidden") === "true" || style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) {
          return false;
        }
      }
      return true;
    };
    const unavailable = (code) => ({ code });
    const validControls = (controls2) => controls2.length <= 100 && !controls2.some((node) => !text(node) || text(node).length > 6e3);
    const history = browserChoiceHistory(spec, visible, text, historyOnly);
    if (history.code) {
      return history;
    }
    const { chat, latest, messages, pendingTurn, questionAvailable } = history;
    if (!questionAvailable) {
      return historyOnly ? { chat, messages } : unavailable("answer-question-unavailable");
    }
    const all = [...document.querySelectorAll(spec.choices.button)];
    if (all.length > 1e3) {
      return unavailable("answer-options-limited");
    }
    const groups = [...document.querySelectorAll(spec.choices.group)].filter(
      (group) => visible(group) && !browserChoiceSuggestions(spec, group, all, visible, text)
    );
    const attached = groups.filter((group) => {
      const dialog = group.closest('[role="dialog"]');
      if (dialog && !dialog.contains(latest.node)) {
        return false;
      }
      const parent = group.closest(spec.messages.item);
      if (parent) {
        return parent === latest.node;
      }
      const bound = group.getAttribute(
        spec.choices.questionAttribute ?? "data-question-id"
      );
      return bound ? bound === latest.id : Boolean(latest.node.compareDocumentPosition(group) & 4);
    }).filter(
      (group, _index, selected) => !selected.some((other) => other !== group && group.contains(other))
    );
    if (groups.length > 100 || attached.length > 1) {
      return unavailable("answer-options-ambiguous");
    }
    const shown = all.filter(visible);
    const yes = /^(?:yes|да|हाँ|是)[.!]?$/iu;
    const no = /^(?:no|нет|नहीं|否)[.!]?$/iu;
    const unscoped = shown.filter((node) => {
      const owner = node.closest(spec.messages.item);
      const dialog = node.closest('[role="dialog"]');
      return (!owner || owner === latest.node) && (!dialog || dialog.contains(latest.node)) && !groups.some((group) => group.contains(node)) && (yes.test(text(node)) || no.test(text(node)));
    });
    const pair = unscoped.length === 2 && unscoped.some((node) => yes.test(text(node))) && unscoped.some((node) => no.test(text(node)));
    const controls = shown.filter(
      (node) => attached.some((group) => group.contains(node)) || spec.choices.attachedButtons && latest.node.contains(node) || pair && unscoped.includes(node)
    );
    if (!validControls(controls)) {
      return unavailable("answer-options-unverified");
    }
    const enabled = controls.filter(
      (node) => !node.matches(':disabled,[disabled],[aria-disabled="true"]') && !node.closest('[inert],[aria-disabled="true"]')
    );
    const strictOptions = [attached.length, pair, controls.length].some(Boolean);
    const answerOptions = enabled.map(text);
    if (historyOnly) {
      return {
        chat,
        messages: messages.map(
          (row) => row.id === latest.id ? { ...row, strictOptions, answerOptions } : row
        )
      };
    }
    const composers = [...document.querySelectorAll(spec.composer)].filter(
      visible
    );
    if (composers.length > 1) {
      return unavailable("answer-composer-ambiguous");
    }
    const result = {
      chat,
      question: { id: latest.id, body: latest.body, outgoing: latest.outgoing },
      strictOptions,
      answerOptions,
      optionsShown: controls.map(text),
      messages,
      pendingTurn
    };
    return internal ? { ...result, controls: enabled, composer: composers[0] } : result;
  };

  // js/src/sources/browser-reply-guard.js
  var browserReplyAdmission = (state, reservation) => {
    if (state.attempts.has(reservation)) {
      return "send-in-doubt";
    }
    if (state.attempts.size >= 32) {
      const completed = [...state.attempts].find(
        ([_key, attempt]) => attempt.confirmed
      );
      if (!completed) {
        return "answer-choice-capacity";
      }
      state.attempts.delete(completed[0]);
    }
    return null;
  };
  var armBrowserReply = (input, context, current, node, valid) => {
    const { state, identity, snapshot } = context;
    const reservation = identity(current);
    const code = browserReplyAdmission(state, reservation);
    if (code) {
      return { code };
    }
    const attempt = {
      node,
      token: input.token,
      reservation,
      before: current.messages.map((row) => row.id),
      allowed: false,
      clicked: false
    };
    const selector = `[data-meta-answer-choice="${input.token}"]`;
    attempt.guard = (event) => {
      const tagged = event.target.closest?.(selector);
      if (!tagged && event.target !== attempt.node && !attempt.node.contains(event.target)) {
        return;
      }
      if (tagged !== attempt.node || !valid(snapshot(), attempt) || attempt.clicked) {
        event.preventDefault();
        event.stopImmediatePropagation();
        attempt.blocked = true;
        return;
      }
      attempt.allowed = true;
      attempt.clicked ||= event.type === "click";
    };
    node.setAttribute("data-meta-answer-choice", input.token);
    watchChoiceView(attempt);
    for (const type of ["pointerdown", "mousedown", "click"]) {
      document.addEventListener(type, attempt.guard, true);
    }
    state.attempts.set(reservation, attempt);
    return { armed: true, selector };
  };

  // js/src/sources/browser-choice-controller.js
  var createChoiceContext = (input, read) => {
    const { spec, expected } = input;
    const key = /* @__PURE__ */ Symbol.for("meta-sovereign.browser-answer-choice.v1");
    const state = window[key] ??= {
      owners: /* @__PURE__ */ new WeakMap(),
      observed: /* @__PURE__ */ new WeakSet(),
      attempts: /* @__PURE__ */ new Map()
    };
    const snapshot = (historyOnly = false) => read(spec, true, historyOnly);
    const inactiveKey = /* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1");
    const inactive = input.inactiveToken && window[inactiveKey];
    const inactiveReady = () => !input.inactiveToken || inactive && window[inactiveKey] === inactive && inactive.token === input.inactiveToken && !inactive.interrupted && !document.hasFocus();
    const identity = (value) => JSON.stringify([value.chat, value.question?.id, value.question?.body]);
    const ownershipIdentity = (value) => JSON.stringify([identity(value), value.pendingTurn]);
    const samePending = (value) => expected.pendingTurn ? JSON.stringify(value.pendingTurn) === JSON.stringify(expected.pendingTurn) : expected.pendingMessages ? JSON.stringify(value.pendingTurn?.messages) === JSON.stringify(expected.pendingMessages) : value.pendingTurn?.messages.length === 1;
    const same = (value) => inactiveReady() && !value.code && !value.question.outgoing && identity(value) === identity(expected) && samePending(value) && JSON.stringify(value.answerOptions) === JSON.stringify(expected.answerOptions);
    const valueOf = (node) => node ? String("value" in node ? node.value : node.textContent ?? "") : "";
    const writable = (node) => Boolean(node) && !node.matches(
      ':disabled,[disabled],[readonly],[inert],[aria-disabled="true"],[aria-readonly="true"]'
    ) && !node.closest('[inert],[aria-disabled="true"]');
    const write = (node, value) => {
      if (!writable(node) || !inactiveReady()) {
        return false;
      }
      const prototype = node instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
      if (!setter || !("value" in node)) {
        return false;
      }
      state.writing = true;
      const event = new Event("input", { bubbles: true });
      if (inactive) {
        inactive.ownedInput = event;
      }
      try {
        setter.call(node, value);
        node.dispatchEvent(event);
        node.dispatchEvent(new Event("change", { bubbles: true }));
        return valueOf(node) === value;
      } finally {
        if (inactive?.ownedInput === event) {
          delete inactive.ownedInput;
        }
        state.writing = false;
      }
    };
    const clearOwned = (current) => {
      const node = current.composer;
      const owner = node && state.owners.get(node);
      if (owner && owner.identity === ownershipIdentity(current) && valueOf(node) === owner.text) {
        const attempt = state.attempts.get(identity(current));
        if (attempt?.allowed && !attempt.confirmed) {
          return false;
        }
        state.owners.delete(node);
        return write(node, "");
      }
      return !valueOf(node);
    };
    const own = (current, text) => {
      const node = current.composer;
      const owner = { identity: ownershipIdentity(current), text };
      state.owners.set(node, owner);
      if (!state.observed.has(node)) {
        state.observed.add(node);
        node.addEventListener("input", () => {
          if (!state.writing) {
            state.owners.delete(node);
          }
        });
      }
      return owner;
    };
    const clean = (attempt) => {
      attempt.clearDraft?.();
      watchChoiceView(attempt, true);
      attempt.node.removeAttribute("data-meta-answer-choice");
      for (const node of document.querySelectorAll("[data-meta-answer-choice]")) {
        if (node.getAttribute("data-meta-answer-choice") === attempt.token) {
          node.removeAttribute("data-meta-answer-choice");
        }
      }
      for (const type of ["pointerdown", "mousedown", "click"]) {
        document.removeEventListener(type, attempt.guard, true);
      }
    };
    return {
      state,
      snapshot,
      identity,
      ownershipIdentity,
      same,
      valueOf,
      writable,
      own,
      write,
      clearOwned,
      clean
    };
  };
  var readChoiceHistory = (_input, { snapshot }) => snapshot(true);
  var readChoicePublic = (_input, context) => {
    const { snapshot, clearOwned, valueOf } = context;
    const current = snapshot();
    if (current.code) {
      return current;
    }
    if (current.optionsShown.length) {
      clearOwned(current);
    }
    const { controls: _controls, composer, ...result } = current;
    return { ...result, hasDraft: Boolean(valueOf(composer)) };
  };
  var prefillChoiceDraft = (input, context) => {
    const { snapshot, same, valueOf, write, own } = context;
    const current = snapshot();
    if (!same(current) || current.strictOptions || !current.composer || valueOf(current.composer)) {
      return { code: "answer-draft-preserved" };
    }
    const node = current.composer;
    if (!write(node, input.text)) {
      return { code: "answer-prefill-unverified" };
    }
    own(current, input.text);
    return same(snapshot()) ? { prefilled: true } : { code: "answer-prefill-unverified" };
  };
  var armChoiceClick = (input, context) => {
    const { option } = input;
    const { snapshot, same, clearOwned, valueOf } = context;
    const current = snapshot();
    const candidates = current.controls?.filter(
      (node) => String(node.textContent).replace(/\s+/gu, " ").trim() === option
    ) ?? [];
    if (!same(current) || !current.strictOptions || candidates.length !== 1) {
      return { code: "answer-choice-changed" };
    }
    if (!clearOwned(current)) {
      return { code: "answer-draft-preserved" };
    }
    return armBrowserReply(
      input,
      context,
      current,
      candidates[0],
      (fresh, attempt) => same(fresh) && fresh.controls.includes(attempt.node) && !valueOf(fresh.composer)
    );
  };
  var matchingChoiceReplies = (input, current, attempt) => {
    const { expected, option } = input;
    const questionIndex = current.messages?.findIndex((row) => row.id === expected.question.id) ?? -1;
    const matchesReply = (row) => row.outgoing && !row.service && !attempt.before.includes(row.id) && row.body === (option ?? input.text);
    return !current.code && current.chat === expected.chat && questionIndex >= 0 ? current.messages.slice(questionIndex + 1).filter(matchesReply) : [];
  };
  var readChoiceReceipt = (input, context) => {
    const { state, snapshot, clean } = context;
    const attempt = [...state.attempts.values()].find(
      (entry) => entry.token === input.token
    );
    if (!attempt) {
      return { code: "send-unknown" };
    }
    const current = snapshot();
    const matches = matchingChoiceReplies(input, current, attempt);
    const confirmed = (input.text === void 0 ? attempt.allowed : attempt.clicked) && matches.length === 1;
    if (confirmed || input.finish) {
      clean(attempt);
    }
    if (confirmed) {
      if (!attempt.confirmed) {
        attempt.reveal = revealChoiceReply(
          input.spec,
          attempt,
          current,
          matches[0]
        );
      }
      attempt.confirmed = true;
      return { sent: true, messageId: matches[0].id, reveal: attempt.reveal };
    }
    if (input.finish && !attempt.allowed && attempt.blocked) {
      state.attempts.delete(attempt.reservation);
      return {
        code: input.text === void 0 ? "answer-choice-changed" : "answer-text-changed",
        dispatched: false
      };
    }
    return { code: "send-unknown", blocked: Boolean(attempt.blocked) };
  };
  var releaseChoiceClick = ({ token }, { state, clean }) => {
    const attempt = [...state.attempts.values()].find(
      (entry) => entry.token === token
    );
    if (attempt) {
      clean(attempt);
    }
    return { released: true };
  };

  // js/src/crm/question-recognition.js
  var W = "[\\p{L}\\p{M}\\p{N}_]";
  var start = (source2) => new RegExp(`^(?:${source2})(?!${W})`, "iu");
  var QUESTION_START = start(
    "\u043A\u0430\u043A|\u0447\u0442\u043E|\u0447\u0435\u043C|\u0433\u0434\u0435|\u043A\u0443\u0434\u0430|\u043E\u0442\u043A\u0443\u0434\u0430|\u043A\u043E\u0433\u0434\u0430|\u043F\u043E\u0447\u0435\u043C\u0443|\u0437\u0430\u0447\u0435\u043C|\u043A\u0442\u043E|\u043A\u0435\u043C|\u043A\u0430\u043A\u043E\u0439|\u043A\u0430\u043A\u0430\u044F|\u043A\u0430\u043A\u043E\u0435|\u043A\u0430\u043A\u0438\u0435|\u0441\u043A\u043E\u043B\u044C\u043A\u043E|\u043C\u043E\u0436\u043D\u043E|\u043D\u0435\u043B\u044C\u0437\u044F \u043B\u0438|\u043D\u0435 \u043F\u043E\u0434\u0441\u043A\u0430\u0436\u0435\u0442\u0435|\u043F\u043E\u0434\u0441\u043A\u0430\u0436\u0438|\u043F\u043E\u0434\u0441\u043A\u0430\u0436\u0438\u0442\u0435|\u0435\u0441\u0442\u044C \u043B\u0438|\u0431\u044B\u043B \u043B\u0438|\u0431\u044B\u043B\u0430 \u043B\u0438|\u0431\u044B\u043B\u0438 \u043B\u0438|how|what|where|when|why|who|which|do you|did you|are you|can you|could you|would you|is there|have you"
  );
  var REQUEST = start(
    "please\\s+(?:tell|share|describe|provide|send)|tell\\s+(?:me|us)|describe\\s+your|share\\s+your|\u0440\u0430\u0441\u0441\u043A\u0430\u0436\u0438\u0442\u0435|\u0440\u0430\u0441\u0441\u043A\u0430\u0436\u0438|\u0443\u043A\u0430\u0436\u0438\u0442\u0435|\u0443\u043A\u0430\u0436\u0438|\u043D\u0430\u043F\u0438\u0448\u0438\u0442\u0435|\u043D\u0430\u043F\u0438\u0448\u0438|\u043F\u0440\u0438\u0448\u043B\u0438\u0442\u0435|\u043F\u0440\u0438\u0448\u043B\u0438|\u0443\u0442\u043E\u0447\u043D\u0438\u0442\u0435|\u0443\u0442\u043E\u0447\u043D\u0438|\u0441\u043E\u043E\u0431\u0449\u0438\u0442\u0435|\u0441\u043E\u043E\u0431\u0449\u0438|\u043E\u043F\u0438\u0448\u0438\u0442\u0435|\u043E\u043F\u0438\u0448\u0438|\u043F\u043E\u0434\u0435\u043B\u0438\u0442\u0435\u0441\u044C|\u043F\u043E\u0434\u0435\u043B\u0438\u0441\u044C|\u043F\u0440\u0438\u0432\u0435\u0434\u0438(?:\u0442\u0435)?\\s+\u043F\u0440\u0438\u043C\u0435\u0440"
  );
  var HINDI_WORD = "\u0915\u094D\u092F\u093E|\u0915\u0939\u093E\u0901|\u0915\u0939\u093E\u0902|\u0915\u092C|\u0915\u094D\u092F\u094B\u0902|\u0915\u0948\u0938\u0947|\u0915\u094C\u0928|\u0915\u093F\u0938(?:\u0915\u093E|\u0915\u0940|\u0915\u0947|\u0947)?|\u0915\u093F\u0924\u0928(?:\u093E|\u0940|\u0947)";
  var HINDI_START = start(HINDI_WORD);
  var HINDI_SUBJECT = new RegExp(
    `^(?:\u0906\u092A|\u0924\u0941\u092E|\u0906\u092A\u0915\u093E|\u0906\u092A\u0915\u0940|\u0906\u092A\u0915\u0947|\u0924\u0941\u092E\u094D\u0939\u093E\u0930\u093E|\u0924\u0941\u092E\u094D\u0939\u093E\u0930\u0940|\u0924\u0941\u092E\u094D\u0939\u093E\u0930\u0947)(?!${W})[^\u0964.!?\\r\\n]{0,100}?(?<!${W})(?:${HINDI_WORD})(?!${W})`,
    "u"
  );
  var HINDI_REQUEST = new RegExp(
    `^(?:\u0915\u0943\u092A\u092F\u093E(?!${W})[^\u0964.!?\\r\\n]{0,160}?(?<!${W}))?(?:\u092C\u0924\u093E\u0907\u090F|\u092C\u0924\u093E\u090F\u0902|\u092C\u0924\u093E\u092F\u0947\u0902|\u092C\u0924\u093E\u0913|\u0938\u093E\u091D\u093E \u0915\u0930\u0947\u0902|\u092D\u0947\u091C\u0947\u0902|\u092A\u094D\u0930\u0926\u093E\u0928 \u0915\u0930\u0947\u0902|\u0909\u0932\u094D\u0932\u0947\u0916 \u0915\u0930\u0947\u0902|\u0932\u093F\u0916\u0947\u0902)(?!${W})`,
    "u"
  );

  // js/src/automation/question-subjects.js
  var names = [
    ["go", ["go", "golang"]],
    ["csharp", ["c#", "\u0441#", "csharp", "c-sharp"]],
    ["cpp", ["c++", "\u0441++", "cpp"]],
    ["c", ["c", "\u0441\u0438"]],
    ["javascript", ["javascript", "js", "\u0434\u0436\u0430\u0432\u0430\u0441\u043A\u0440\u0438\u043F\u0442"]],
    ["typescript", ["typescript", "ts"]],
    ["java", ["java", "\u0434\u0436\u0430\u0432\u0430"]],
    ["python", ["python", "\u043F\u0438\u0442\u043E\u043D"]],
    ["rust", ["rust"]],
    ["ruby", ["ruby"]],
    ["php", ["php"]],
    ["swift", ["swift"]],
    ["kotlin", ["kotlin"]],
    ["scala", ["scala"]],
    ["docker", ["docker", "\u0434\u043E\u043A\u0435\u0440"]],
    ["kubernetes", ["kubernetes", "k8s"]],
    ["mongodb", ["mongodb", "mongo"]],
    ["postgresql", ["postgresql", "postgres"]],
    ["mysql", ["mysql"]],
    ["redis", ["redis"]],
    ["aws", ["aws"]],
    ["azure", ["azure"]],
    ["gcp", ["gcp"]],
    ["react", ["react", "reactjs"]],
    ["angular", ["angular"]],
    ["vue", ["vue", "vuejs"]],
    ["git", ["git", "\u0433\u0438\u0442"]],
    ["github", ["github"]],
    ["linkedin", ["linkedin"]],
    ["telegram", ["telegram", "\u0442\u0435\u043B\u0435\u0433\u0440\u0430\u043C"]],
    ["lead", ["lead", "\u0442\u0438\u043C\u043B\u0438\u0434", "\u0442\u0435\u0445\u043B\u0438\u0434"]],
    ["junior", ["junior"]],
    ["senior", ["senior"]],
    ["usd", ["usd", "\u0434\u043E\u043B\u043B\u0430\u0440", "\u0434\u043E\u043B\u043B\u0430\u0440\u043E\u0432", "dollar", "dollars"]],
    [
      "rub",
      [
        "rub",
        "rur",
        "\u0440\u0443\u0431",
        "\u0440\u0443\u0431\u043B\u0435\u0439",
        "\u0440\u0443\u0431\u043B\u044F\u0445",
        "\u0440\u0443\u0431\u043B\u0438",
        "\u0440\u0443\u0431\u043B\u044C",
        "rubles",
        "roubles"
      ]
    ],
    ["eur", ["eur", "euro", "euros", "\u0435\u0432\u0440\u043E"]],
    ["gbp", ["gbp"]],
    ["inr", ["inr"]],
    ["cny", ["cny", "rmb"]],
    ["vnd", ["vnd"]],
    ["jpy", ["jpy"]],
    ["employment:ip", ["\u0438\u043F"]],
    ["employment:gph", ["\u0433\u043F\u0445"]],
    ["employment:self", ["\u0441\u0430\u043C\u043E\u0437\u0430\u043D\u044F\u0442\u044B\u0439", "\u0441\u0430\u043C\u043E\u0437\u0430\u043D\u044F\u0442\u044B\u043C\u0438", "\u0441\u0430\u043C\u043E\u0437\u0430\u043D\u044F\u0442\u043E\u0441\u0442\u044C"]]
  ];
  var aliases = new Map(
    names.flatMap(([key, values]) => values.map((name) => [name, key]))
  );

  // js/src/automation/question-options.js
  var explicitChoice = /\b(?:choose|select|pick)\s+(?:one|an?\s+option|from)\b|выбер(?:и|ите)\s+(?:один|одну|вариант|из)|(?:एक|कोई)\s+विकल्प\s+चुन|请(?:选择|选取)(?:一个|一项)|选择一个/iu;
  var answerChoiceState = (question, input = {}) => {
    const options = input.options === void 0 ? [] : input.options;
    if (!Array.isArray(options) || options.length > 100 || options.some(
      (option) => typeof option !== "string" || !option.trim() || option.length > 6e3
    ) || input.strictOptions !== void 0 && typeof input.strictOptions !== "boolean") {
      throw new Error(
        "Answer choices require bounded text and a boolean strictOptions"
      );
    }
    return {
      options,
      strictOptions: input.strictOptions === true || options.length > 0 || input.questionMode !== "field" && explicitChoice.test(question)
    };
  };

  // js/src/automation/question-turns.js
  var ACK_WORDS = new Set(
    "\u043E\u043A \u043E\u043A\u0435\u0439 \u0445\u043E\u0440\u043E\u0448\u043E \u043F\u043E\u043D\u044F\u043B \u043F\u043E\u043D\u044F\u043B\u0430 \u0441\u043F\u0430\u0441\u0438\u0431\u043E \u0431\u043B\u0430\u0433\u043E\u0434\u0430\u0440\u044E \u043F\u0440\u0438\u043D\u044F\u0442\u043E \u043E\u0442\u043B\u0438\u0447\u043D\u043E \u044F\u0441\u043D\u043E \u0437\u0430 \u0432\u0430\u0448 \u0432\u0430\u0448\u0438 \u043E\u0442\u0432\u0435\u0442 \u043E\u0442\u0432\u0435\u0442\u044B \u043E\u0442\u043A\u043B\u0438\u043A \u043F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0441\u0442\u0438 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044E \u0443\u0447\u0442\u0443 \u043E\u043F\u044B\u0442 hello hi thanks thank you for the your answer answers details information understood noted okay ok got it \u0928\u092E\u0938\u094D\u0924\u0947 \u0927\u0928\u094D\u092F\u0935\u093E\u0926 \u8C22\u8C22 \u597D\u7684".split(
      " "
    )
  );
  var CONSENT_WORDS = new Set(
    "yes no yeah yep sure okay ok yes of course let s lets continue please thanks thank you maybe perhaps da \u0434\u0430 \u043D\u0435\u0442 \u043A\u043E\u043D\u0435\u0447\u043D\u043E \u0430\u0433\u0430 \u0443\u0433\u0443 \u0445\u043E\u0440\u043E\u0448\u043E \u043E\u043A \u0434\u0430\u0432\u0430\u0439\u0442\u0435 \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u043C \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0430\u0442\u044C \u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0441\u043F\u0430\u0441\u0438\u0431\u043E \u0431\u043B\u0430\u0433\u043E\u0434\u0430\u0440\u044E \u043D\u0435 \u0443\u0432\u0435\u0440\u0435\u043D \u0443\u0432\u0435\u0440\u0435\u043D\u0430 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E \u0939\u093E\u0901 \u0939\u093E\u0902 \u091C\u0940 \u0928\u0939\u0940\u0902 \u0920\u0940\u0915 \u091C\u093E\u0930\u0940 \u0930\u0916\u0947\u0902 \u0927\u0928\u094D\u092F\u0935\u093E\u0926 \u662F \u597D\u7684 \u7EE7\u7EED \u662F\u7684 \u4E0D \u8C22\u8C22".split(
      " "
    )
  );

  // js/src/automation/question-pending-plan.js
  var validPendingMessage = (message) => message && typeof message.id === "string" && Boolean(message.id.trim()) && message.id.length <= 600 && typeof message.body === "string" && Boolean(message.body.trim()) && message.body.length <= 6e3;
  var checkedPendingMessages = (messages, question) => {
    if (!Array.isArray(messages) || !messages.length || messages.length > 20 || !messages.every(validPendingMessage) || new Set(messages.map((message) => message.id)).size !== messages.length || messages.reduce((size, message) => size + message.body.length, 0) > 24e3 || messages.at(-1).body !== question) {
      throw new Error("Pending messages must be a complete bounded turn.");
    }
    return messages.map(({ id, body }) => ({ id, body }));
  };

  // js/src/sources/browser-text-controller.js
  var textReplyOpen = (spec) => {
    const nodes = [
      ...document.querySelectorAll('p,span,div,[role="status"],[role="alert"]')
    ];
    if (nodes.length > 5e3) {
      return false;
    }
    const pattern = new RegExp(spec.textReply.closedText, "iu");
    return !nodes.some(
      (node) => !node.children.length && browserFrameVisible(node) && pattern.test(node.textContent)
    );
  };
  var textReplyButtons = (spec) => [...document.querySelectorAll(spec.textReply.send)].filter(
    (node) => browserFrameVisible(node) && !node.matches(':disabled,[disabled],[aria-disabled="true"]') && !node.closest('[inert],[aria-disabled="true"]')
  );
  var armTextReply = (input, context) => {
    const {
      snapshot,
      same,
      state,
      identity,
      own,
      valueOf,
      write,
      writable,
      clearOwned
    } = context;
    const current = snapshot();
    if (!same(current) || current.strictOptions || !writable(current.composer) || !textReplyOpen(input.spec)) {
      return { code: "answer-text-changed" };
    }
    if (valueOf(current.composer)) {
      return { code: "answer-draft-preserved" };
    }
    const code = browserReplyAdmission(state, identity(current));
    if (code) {
      return { code };
    }
    const composer = current.composer;
    if (!write(composer, input.text)) {
      return { code: "answer-prefill-unverified" };
    }
    const owner = own(current, input.text);
    const valid = (fresh2, attempt2) => same(fresh2) && !fresh2.strictOptions && textReplyOpen(input.spec) && fresh2.composer === composer && writable(composer) && state.owners.get(composer) === owner && valueOf(composer) === input.text && !attempt2.preserveView && textReplyButtons(input.spec).length === 1 && textReplyButtons(input.spec)[0] === attempt2.node;
    const buttons = textReplyButtons(input.spec);
    const fresh = snapshot();
    if (buttons.length !== 1 || !valid(fresh, { node: buttons[0] })) {
      clearOwned(current);
      return { code: "answer-text-changed" };
    }
    const armed = armBrowserReply(input, context, fresh, buttons[0], valid);
    const attempt = state.attempts.get(identity(current));
    if (armed.armed) {
      attempt.clearDraft = () => {
        if (!attempt.allowed && state.owners.get(composer) === owner) {
          clearOwned(current);
        }
      };
    } else {
      clearOwned(current);
    }
    return armed;
  };

  // js/src/sources/browser-choices.js
  var methods = {
    read: readChoicePublic,
    history: readChoiceHistory,
    prefill: prefillChoiceDraft,
    arm: armChoiceClick,
    armText: armTextReply,
    receipt: readChoiceReceipt,
    release: releaseChoiceClick
  };
  var source = `(input) => {
  const watchChoiceView = (${watchChoiceView.toString()});
  const revealChoiceReply = (${revealChoiceReply.toString()});
  const browserFrameVisible = (${browserFrameVisible.toString()});
  const browserReplyAdmission = (${browserReplyAdmission.toString()});
  const matchingChoiceReplies = (${matchingChoiceReplies.toString()});
  const armBrowserReply = (${armBrowserReply.toString()});
  const textReplyButtons = (${textReplyButtons.toString()});
  const textReplyOpen = (${textReplyOpen.toString()});
  const browserPendingTurn = (${browserPendingTurn.toString()});
  const browserChoiceSuggestions = (${browserChoiceSuggestions.toString()});
  const browserChoiceHistory = (${browserChoiceHistory.toString()});
  const context = (${createChoiceContext.toString()})(input, ${readBrowserChoices.toString()});
  const methods = {${Object.entries(methods).map(([name, method]) => `${name}: ${method.toString()}`).join(",")}};
  return methods[input.operation](input, context);
}`;
  var browserChoicePage = new Function(`return (${source})`)();
  var failure3 = (code) => Object.assign(
    new Error(
      {
        "answer-draft-preserved": "The provider composer contains an owner draft; review it before selecting an answer",
        "send-unknown": "The option may have been selected; inspect the provider chat before trying again",
        "send-in-doubt": "This question already has a selection attempt; inspect the provider chat before trying again"
      }[code] ?? "The current provider question or answer controls could not be verified"
    ),
    {
      code,
      fallback: false,
      ...["send-unknown", "send-in-doubt"].includes(code) ? { ambiguous: true, outcome: "unknown" } : {}
    }
  );
  var browserChoiceSpec = (ui) => {
    if (!ui.choices || !ui.location || !ui.messages.idPattern || !ui.messages.outgoing) {
      throw failure3("answer-choice-required");
    }
    return {
      choices: ui.choices,
      location: ui.location,
      messages: ui.messages,
      composer: ui.composer,
      ...ui.textReply ? { textReply: ui.textReply } : {}
    };
  };
  var evaluate = (commander, input) => commander.evaluate({ fn: browserChoicePage, args: [input] });
  var readBrowserHistory = async (commander, ui, target) => {
    const value = await evaluate(commander, {
      spec: browserChoiceSpec(ui),
      operation: "history"
    });
    if (value.code || value.chat !== String(target)) {
      throw failure3(value.code ?? "answer-chat-unverified");
    }
    return value.messages;
  };
  var readBrowserAnswerChoices = async (commander, ui, target) => {
    const value = await evaluate(commander, {
      spec: browserChoiceSpec(ui),
      operation: "read"
    });
    if (value.code || value.chat !== String(target)) {
      throw failure3(value.code ?? "answer-chat-unverified");
    }
    const choices = answerChoiceState(value.question.body, {
      options: value.answerOptions,
      strictOptions: value.strictOptions
    });
    return { ...value, ...choices, answerOptions: choices.options };
  };
  var prefillBrowserAnswer = async (commander, ui, expected, text) => {
    if (typeof text !== "string" || !text.trim() || text.length > 12e3 || answerChoiceState(expected.question.body, {
      options: expected.answerOptions
    }).strictOptions) {
      throw failure3("bad-draft");
    }
    const result = await evaluate(commander, {
      spec: browserChoiceSpec(ui),
      operation: "prefill",
      expected,
      text
    });
    if (!result.prefilled) {
      throw failure3(result.code);
    }
    return result;
  };
  var expectedPendingTurn = (draft, question, prefix) => {
    const pendingTurn = checkedBrowserPendingTurn(draft.answer.pendingTurn, {
      id: question.id.slice(prefix.length),
      body: question.body,
      outgoing: false
    });
    if (pendingTurn === null) {
      throw failure3("answer-choice-required");
    }
    return pendingTurn;
  };
  var expectedPendingMessages = (messages, prefix, question) => {
    if (messages.length === 1) {
      return void 0;
    }
    try {
      if (messages.some((message) => !message.id?.startsWith(prefix))) {
        throw failure3("answer-choice-required");
      }
      return checkedPendingMessages(
        messages.map((message) => ({
          id: message.id.slice(prefix.length),
          body: message.body
        })),
        question.body
      );
    } catch {
      throw failure3("answer-choice-required");
    }
  };
  var expectedQuestion = (draft, target) => {
    const messages = draft.answer?.turn?.messages;
    const question = Array.isArray(messages) && messages.at(-1);
    const prefix = `msg:${draft.source}:${target}:`;
    if (!question || question.id !== draft.answer.message || typeof question.id !== "string" || !question.id.startsWith(prefix) || typeof question.body !== "string" || question.body.length > 6e3 || draft.text !== draft.answer.option || !draft.answer.strictOptions) {
      throw failure3("answer-choice-required");
    }
    let answerOptions;
    try {
      answerOptions = JSON.parse(question.options);
      answerChoiceState(question.body, {
        options: answerOptions,
        strictOptions: true
      });
    } catch {
      throw failure3("answer-choice-required");
    }
    const pendingTurn = expectedPendingTurn(draft, question, prefix);
    const pendingMessages = expectedPendingMessages(messages, prefix, question);
    return {
      chat: String(target),
      question: { id: question.id.slice(prefix.length), body: question.body },
      answerOptions,
      ...pendingTurn ? { pendingTurn } : {},
      ...pendingMessages ? { pendingMessages } : {}
    };
  };
  var validWait = (receiptMs, pollMs) => Number.isSafeInteger(receiptMs) && receiptMs >= 0 && receiptMs <= 3e4 && Number.isSafeInteger(pollMs) && pollMs >= 1 && pollMs <= 1e3;
  var selectBrowserAnswer = async (commander, ui, draft, target, { receiptMs = 1e4, pollMs = 100 } = {}) => {
    if (!validWait(receiptMs, pollMs)) {
      throw failure3("bad-draft");
    }
    const expected = expectedQuestion(draft, target);
    const spec = browserChoiceSpec(ui);
    const result = await dispatchBrowserReply(
      commander,
      {
        spec,
        expected,
        option: draft.answer.option
      },
      { receiptMs, pollMs }
    );
    return {
      via: "browser",
      source: draft.source,
      chat: String(target),
      messageId: result.messageId,
      option: draft.answer.option
    };
  };
  var issueBrowserReply = async (commander, selector, inactiveToken) => {
    try {
      await commander.clickButton({
        selector,
        scrollIntoView: !inactiveToken,
        ...inactiveToken ? { inactiveToken, activation: "dom", scroll: "none" } : {},
        waitForNavigation: false,
        waitAfterClick: 0,
        verify: false
      });
    } catch (error) {
      if (inactiveToken && error?.dispatched === false) {
        throw error;
      }
    }
  };
  var dispatchBrowserReply = async (commander, request, { receiptMs, pollMs, inactiveToken, verifyCurrent }) => {
    if (!validWait(receiptMs, pollMs)) {
      throw failure3("bad-draft");
    }
    const input = {
      ...request,
      ...inactiveToken ? { inactiveToken } : {},
      token: randomBytes(16).toString("hex")
    };
    try {
      await verifyCurrent?.();
      const armed = await evaluate(commander, {
        ...input,
        operation: input.text === void 0 ? "arm" : "armText"
      });
      if (!armed.armed) {
        throw failure3(armed.code);
      }
      await verifyCurrent?.();
      await issueBrowserReply(commander, armed.selector, inactiveToken);
      const deadline = Date.now() + receiptMs;
      for (; ; ) {
        let result;
        const finish = Date.now() >= deadline;
        try {
          result = await evaluate(commander, {
            ...input,
            operation: "receipt",
            finish
          });
        } catch {
          throw failure3("send-unknown");
        }
        if (result.sent) {
          return result;
        }
        if (finish) {
          throw failure3(result.code);
        }
        await setTimeout2(pollMs);
      }
    } finally {
      try {
        await evaluate(commander, { ...input, operation: "release" });
      } catch {
      }
    }
  };

  // js/src/sources/browser-text-reply.js
  var failure4 = (code) => Object.assign(
    new Error("The frozen provider text reply could not be verified."),
    { code, fallback: false }
  );
  var checkedTextSnapshot = (target, expected) => {
    const question = expected?.question;
    const pendingTurn = question && checkedBrowserPendingTurn(expected.pendingTurn, question);
    if (expected?.chat !== String(target) || expected.strictOptions !== false || !Array.isArray(expected.answerOptions) || expected.answerOptions.length || !question || question.outgoing !== false || !pendingTurn || answerChoiceState(question.body, { options: [] }).strictOptions) {
      throw failure4("bad-draft");
    }
    return {
      chat: String(target),
      strictOptions: false,
      question: { id: question.id, body: question.body, outgoing: false },
      pendingTurn,
      answerOptions: []
    };
  };
  var checkedTextReply = (ui, target, expected, text) => {
    if (!ui.documents || !ui.textReply?.send || !ui.textReply.closedText) {
      throw failure4("answer-text-unavailable");
    }
    if (typeof text !== "string" || !text.trim() || text.length > 12e3) {
      throw failure4("bad-draft");
    }
    return checkedTextSnapshot(target, expected);
  };
  var sendBrowserTextReply = async (commander, ui, target, expected, text, options = {}) => {
    const frozen = checkedTextReply(ui, target, expected, text);
    const result = await dispatchBrowserReply(
      commander,
      { spec: browserChoiceSpec(ui), expected: frozen, text },
      {
        receiptMs: options.receiptMs ?? 1e4,
        pollMs: options.pollMs ?? 100,
        inactiveToken: options.inactiveToken,
        verifyCurrent: options.verifyCurrent
      }
    );
    return {
      via: "browser",
      source: ui.id,
      chat: String(target),
      messageId: result.messageId,
      text
    };
  };
  var sendInactiveBrowserTextReply = async (document2, ui, target, expected, text, options) => {
    let receipt;
    try {
      return await withInactiveBrowserView(
        document2,
        async (inactive, token) => {
          receipt = await sendBrowserTextReply(
            document2,
            ui,
            target,
            expected,
            text,
            {
              ...options,
              inactiveToken: token,
              verifyCurrent: async () => {
                await options.verifyCurrent();
                await inactive();
              }
            }
          );
          return receipt;
        },
        { relayOwner: true }
      );
    } catch (error) {
      if (receipt) {
        return receipt;
      }
      throw error;
    }
  };

  // js/src/sources/browser-chat-list-state.js
  var scrollOwnerActive = (state) => state.interrupted || state.inactiveToken && (window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")]?.token !== state.inactiveToken || window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")].interrupted || document.hasFocus()) || (state.drafts ?? []).some(
    ([node, value]) => !node.isConnected || node.value !== value
  ) || state.composer && document.querySelectorAll(state.composer).length !== state.drafts.length;
  var restoreScroll = (state, { restore, history, item, idAttribute }) => {
    if (!restore || scrollOwnerActive(state) || !state.visible(state.root)) {
      return false;
    }
    if (!history) {
      state.root.scrollTop = state.original;
      return true;
    }
    const anchor = [...state.root.querySelectorAll(item)].find(
      (node) => node.getAttribute(idAttribute) === state.anchor?.id
    );
    if (anchor) {
      state.root.scrollTop += anchor.getBoundingClientRect().top - state.root.getBoundingClientRect().top - state.anchor.offset;
      state.restoring = true;
      return true;
    }
    if (!state.restoring) {
      state.root.scrollTop = state.original + (state.reversed ? 0 : state.root.scrollHeight - state.originalHeight);
      state.restoring = true;
    }
    return false;
  };
  var historyAnchor = (root, cells, idAttribute) => {
    const bounds = root.getBoundingClientRect();
    const anchor = cells.find((node) => {
      const rect = node.getBoundingClientRect();
      return rect.bottom > bounds.top && rect.top < bounds.bottom;
    });
    return anchor && {
      id: anchor.getAttribute(idAttribute),
      offset: anchor.getBoundingClientRect().top - bounds.top
    };
  };
  var scrollRoot = (cell) => {
    let root = cell?.parentElement;
    while (root && !/^(?:auto|scroll)$/.test(getComputedStyle(root).overflowY)) {
      root = root.parentElement;
    }
    return root ?? document.scrollingElement;
  };
  var openScroll = ({ token, item, composer, idAttribute, scope, inactiveToken }, visible) => {
    const history = scope === "history";
    const cell = [...document.querySelectorAll(item)].find(visible);
    const root = scrollRoot(cell);
    if (!root || !cell) {
      return { refused: "unavailable" };
    }
    const cells = history ? [...document.querySelectorAll(item)].filter(visible) : [];
    if (history && (cells.length > 500 || cells.some((node) => !root.contains(node)))) {
      return { refused: "unavailable" };
    }
    const state = {
      token,
      inactiveToken,
      root,
      visible,
      original: root.scrollTop,
      originalHeight: root.scrollHeight,
      anchor: history ? historyAnchor(root, cells, idAttribute) : void 0,
      reversed: getComputedStyle(root).flexDirection === "column-reverse",
      composer,
      interrupted: false,
      drafts: composer ? [...document.querySelectorAll(composer)].map((node) => [
        node,
        node.value
      ]) : []
    };
    state.events = [
      "pointerdown",
      "keydown",
      "wheel",
      "touchstart",
      "touchmove",
      "input"
    ];
    state.mark = (event) => {
      if (event.isTrusted || history) {
        state.interrupted = true;
      }
    };
    for (const type of state.events) {
      document.addEventListener(type, state.mark, {
        capture: true,
        passive: true
      });
    }
    state.scroll = (event) => {
      if (event.target === root || root === document.scrollingElement && event.target === document) {
        state.pendingScroll = false;
      }
    };
    document.addEventListener("scroll", state.scroll, {
      capture: true,
      passive: true
    });
    const previous = root.scrollTop;
    root.scrollTop = history && !state.reversed ? root.scrollHeight : 0;
    state.pendingScroll = previous !== root.scrollTop;
    return state;
  };
  var browserScrollState = (input, visible, openScroll2, restoreScroll2, scrollOwnerActive2) => {
    const {
      operation,
      token,
      item,
      top,
      restore,
      scope = "list",
      idAttribute
    } = input;
    const history = scope === "history";
    const key = /* @__PURE__ */ Symbol.for(
      history ? "meta-sovereign.browser-conversation-history.v1" : "meta-sovereign.browser-chat-list.v1"
    );
    const release = (state2) => {
      document.removeEventListener("scroll", state2.scroll, true);
      for (const type of state2.events) {
        document.removeEventListener(type, state2.mark, true);
      }
      const restored = restoreScroll2(state2, {
        restore,
        history,
        item,
        idAttribute
      });
      delete window[key];
      return { state: "released", restored };
    };
    const read = (state2) => {
      if (scrollOwnerActive2(state2)) {
        return { state: "owner-active" };
      }
      if (!visible(state2.root)) {
        return { state: "changed" };
      }
      if (operation === "move") {
        const previous = state2.root.scrollTop;
        state2.root.scrollTop = top;
        state2.pendingScroll = previous !== state2.root.scrollTop;
      }
      const { scrollTop, scrollHeight, clientHeight } = state2.root;
      if (clientHeight <= 0 || !Number.isFinite(scrollHeight)) {
        return { state: "unavailable" };
      }
      return {
        state: "ready",
        top: scrollTop,
        height: scrollHeight,
        view: clientHeight,
        bottom: scrollTop + clientHeight >= scrollHeight - 2,
        loading: Boolean(
          state2.pendingScroll || state2.root.querySelector('[aria-busy="true"], [role="progressbar"]')
        ),
        ...history ? {
          reversed: state2.reversed,
          oldest: state2.reversed ? scrollTop <= -(scrollHeight - clientHeight) + 2 : scrollTop <= 2
        } : {}
      };
    };
    if (operation === "open") {
      if (window[key]) {
        return { state: "busy" };
      }
      if (scrollOwnerActive2({ inactiveToken: input.inactiveToken })) {
        return { state: "owner-active" };
      }
      const state2 = openScroll2(input, visible);
      if (state2.refused) {
        return { state: state2.refused };
      }
      window[key] = state2;
    }
    const state = window[key];
    if (!state || state.token !== token) {
      return { state: "unavailable" };
    }
    if (operation === "restore") {
      restoreScroll2(state, { restore, history, item, idAttribute });
    }
    return operation === "release" ? release(state) : read(state);
  };
  var browserChatListState = new Function(`return (input) => {
  const visible = (${browserFrameVisible.toString()});
  const scrollOwnerActive = (${scrollOwnerActive.toString()});
  const restoreScroll = (${restoreScroll.toString()});
  const historyAnchor = (${historyAnchor.toString()});
  const scrollRoot = (${scrollRoot.toString()});
  const openScroll = (${openScroll.toString()});
  return (${browserScrollState.toString()})(input, visible, openScroll, restoreScroll, scrollOwnerActive);
}`)();

  // js/src/sources/browser-scan-control.js
  var createBrowserScanControl = (document2, spec) => {
    const token = randomUUID();
    return {
      token,
      control: (operation, extra = {}) => document2.evaluate({
        fn: browserChatListState,
        args: [{ ...spec, operation, token, ...extra }]
      })
    };
  };

  // js/src/sources/browser-scan-options.js
  var bounded = (value, fallback, minimum, maximum) => {
    const result = value ?? fallback;
    if (!Number.isInteger(result) || result < minimum || result > maximum) {
      throw Object.assign(new Error("Invalid bounded browser scan setting"), {
        code: "bad-chat-scan",
        fallback: false
      });
    }
    return result;
  };
  var normalizeChatScanOptions = (options = {}) => ({
    limit: bounded(options.limit, 500, 1, 5e3),
    maxPasses: bounded(options.maxPasses, 100, 1, 500),
    budgetMs: bounded(options.budgetMs, 3e4, 100, 12e4),
    waitMs: bounded(options.waitMs, 150, 10, 1e3),
    endWaitMs: bounded(options.endWaitMs, 2e3, 100, 1e4)
  });

  // js/src/sources/browser-conversation-history.js
  var stopped = (historyReason) => {
    throw Object.assign(new Error("Conversation history traversal stopped"), {
      historyReason
    });
  };
  var mergeConversationWindow = (known, incoming) => {
    if (!known.length) {
      return incoming.slice();
    }
    const positions = new Map(known.map((row, index) => [row.id, index]));
    const shared = incoming.findIndex((row) => positions.has(row.id));
    if (shared < 0) {
      stopped("history-gap");
    }
    const offset = positions.get(incoming[shared].id);
    if (shared > 0 && offset !== 0) {
      stopped("history-gap");
    }
    for (let index = shared; index < incoming.length; index++) {
      if (JSON.stringify(incoming[index]) !== JSON.stringify(known[offset + index - shared])) {
        stopped("conversation-changed");
      }
    }
    return [...incoming.slice(0, shared), ...known];
  };
  var releaseConversation = async (control, pause, waitMs, verifyCurrent) => {
    let restored = false;
    let restore;
    try {
      await verifyCurrent?.();
      restore = (await control("status")).state === "ready";
      if (restore) {
        await control("restore", { restore: true });
        await pause(waitMs);
        await verifyCurrent?.();
        restore = (await control("status")).state === "ready";
      }
    } catch {
      restore = false;
    }
    try {
      restored = Boolean((await control("release", { restore })).restored);
    } catch {
    }
    return restored;
  };
  var conversationTracker = (settings, ui, now) => {
    let rows = [];
    let passes = 0;
    let previous;
    let stableSince;
    return {
      get passes() {
        return passes;
      },
      loading() {
        passes++;
      },
      accept(found, state) {
        const merged = mergeConversationWindow(rows, found);
        if (merged.length > settings.limit || merged.reduce((sum, row) => sum + row.body.length, 0) > 1e6) {
          stopped("history-limit");
        }
        rows = merged;
        passes++;
        if (state.oldest && !state.loading && rows[0]?.service && ui.historyScan?.startAtService) {
          return "provider-start";
        }
        const signature = JSON.stringify([state.top, state.height, found]);
        if (state.oldest && !state.loading && signature === previous) {
          stableSince ??= now();
          if (now() - stableSince >= settings.endWaitMs) {
            return "rendered-start";
          }
        } else {
          stableSince = void 0;
        }
        previous = signature;
        return null;
      },
      result(reason, restored) {
        return {
          rows,
          coverage: {
            complete: reason === "provider-start",
            scope: "conversation",
            reason,
            passes
          },
          restored
        };
      }
    };
  };
  var scanBrowserConversation = async (document2, ui, target, options = {}, { now = () => globalThis.performance.now(), pause = setTimeout2 } = {}) => {
    const settings = normalizeChatScanOptions(options);
    const { control } = createBrowserScanControl(document2, {
      item: ui.messages.item,
      idAttribute: ui.messages.idAttribute,
      composer: ui.composer,
      scope: "history",
      inactiveToken: options.inactiveToken
    });
    const started = now();
    const observed = conversationTracker(settings, ui, now);
    let reason = "pass-limit";
    let restored;
    const check = async (operation = "status", extra) => {
      if (options.signal?.aborted) {
        stopped("cancelled");
      }
      if (now() - started >= settings.budgetMs) {
        stopped("time-limit");
      }
      await options.verifyCurrent?.();
      const state = await control(operation, extra);
      if (state.state !== "ready") {
        stopped(state.state);
      }
      return state;
    };
    try {
      await check("open");
      while (observed.passes < settings.maxPasses) {
        await pause(settings.waitMs);
        if ((await check()).loading) {
          observed.loading();
          continue;
        }
        const found = (await readBrowserHistory(document2, ui, target)).map(
          ({ strictOptions: _strict, answerOptions: _options, ...row }) => row
        );
        const state = await check();
        const completed = observed.accept(found, state);
        if (completed) {
          reason = completed;
          break;
        }
        await check("move", {
          top: state.top - Math.max(1, Math.floor(state.view * 0.7))
        });
      }
    } catch (error) {
      reason = error.historyReason ?? (error.code === "answer-chat-unverified" ? "document-changed" : "read-failed");
    } finally {
      restored = await releaseConversation(
        control,
        pause,
        settings.waitMs,
        options.verifyRestore ?? options.verifyCurrent
      );
    }
    const result = observed.result(reason, restored);
    if (process.env.MS_BROWSER_HISTORY_DEBUG === "1") {
      console.error("[browser-conversation-history]", {
        ...result.coverage,
        rows: result.rows.length,
        restored
      });
    }
    return result;
  };

  // js/src/sources/browser-answer-watch.js
  var failure5 = () => Object.assign(new Error("The watched provider page changed or closed."), {
    code: "question-watch-page-changed",
    fallback: false
  });
  var openBrowserAnswerWatch = async ({
    commander,
    page: page2,
    ui,
    target,
    queue,
    receiptMs,
    pollMs,
    released
  }) => {
    if (!ui.documents || !page2?.on || !page2?.off) {
      throw failure5();
    }
    const document2 = await resolveBrowserChoiceDocument(
      commander,
      page2,
      ui,
      target
    );
    let changed = false;
    let closed = false;
    let closing;
    const invalidate = () => {
      changed = true;
    };
    const events = ["framenavigated", "framedetached", "close"];
    for (const event of events) {
      page2.on(event, invalidate);
    }
    const pending = /* @__PURE__ */ new Set();
    const verifyCurrent = async (verify) => {
      await verify?.();
      if (closed || changed) {
        throw Object.assign(failure5(), {
          historyReason: closed ? "cancelled" : "document-changed"
        });
      }
    };
    const run = (work) => {
      if (closed || changed) {
        return Promise.reject(failure5());
      }
      const result = queue(async () => {
        if (closed || changed) {
          throw failure5();
        }
        return work();
      });
      pending.add(result);
      result.then(
        () => pending.delete(result),
        () => pending.delete(result)
      );
      return result;
    };
    return {
      read: () => run(() => readBrowserAnswerChoices(document2, ui, target)),
      readInactiveHistory: (options = {}) => {
        normalizeChatScanOptions(options);
        if (!ui.historyScan) {
          throw Object.assign(new Error("Conversation history is unavailable."), {
            code: "unsupported-action",
            fallback: false
          });
        }
        return run(
          () => withInactiveBrowserView(
            document2,
            async (inactive, token) => scanBrowserConversation(document2, ui, target, {
              ...options,
              inactiveToken: token,
              verifyRestore: inactive,
              verifyCurrent: async () => {
                await verifyCurrent();
                await inactive();
              }
            })
          )
        );
      },
      prefill: (expected, text, verify) => run(async () => {
        await verifyCurrent(verify);
        return prefillBrowserAnswer(document2, ui, expected, text);
      }),
      select: (draft, verify) => run(async () => {
        await verifyCurrent(verify);
        return selectBrowserAnswer(document2, ui, draft, target, {
          receiptMs,
          pollMs
        });
      }),
      replyText: (expected, text, verify) => {
        const frozen = checkedTextReply(ui, target, expected, text);
        return run(async () => {
          await verifyCurrent(verify);
          return sendBrowserTextReply(document2, ui, target, frozen, text, {
            receiptMs,
            pollMs
          });
        });
      },
      replyTextInactive: (expected, text, verify) => {
        const frozen = checkedTextReply(ui, target, expected, text);
        return run(
          () => sendInactiveBrowserTextReply(document2, ui, target, frozen, text, {
            receiptMs,
            pollMs,
            verifyCurrent: () => verifyCurrent(verify)
          })
        );
      },
      close() {
        closing ??= (async () => {
          closed = true;
          for (const event of events) {
            page2.off(event, invalidate);
          }
          await Promise.allSettled([...pending]);
          released();
        })();
        return closing;
      }
    };
  };
  return __toCommonJS(stdin_exports);
})();

  const ui={"id":"hh","name":"HeadHunter","loginUrl":"https://hh.ru/account/login","listUrl":"https://hh.ru/chat","loggedIn":"[data-qa^=\"chatik-chat-message-\"], textarea[data-qa=\"text-input\"], iframe[src^=\"https://chatik.hh.ru/\"], [data-qa=\"mainmenu_applicantProfile\"]","loggedOut":"[data-qa=\"account-login-submit\"], form[action*=\"account/login\"]","composer":"textarea[data-qa=\"text-input\"]","location":{"origins":["https://hh.ru","https://www.hh.ru","https://chatik.hh.ru"],"pathPattern":"^/chat/(\\d{1,30})/?$"},"documents":{"ownerOrigins":["https://hh.ru","https://www.hh.ru","https://chatik.hh.ru"],"ancestorOrigins":["https://hh.ru","https://www.hh.ru","https://chatik.hh.ru"],"maxFrames":32},"chatScan":{"pathPattern":"^/chat/?$"},"historyScan":{"startAtService":true},"textReply":{"send":"button[data-qa*=\"send\"]","closedText":"работодатель отключил переписку|переписка будет доступна после приглашения|(?:chat|conversation) (?:is |has been )?closed|(?:messaging|correspondence) (?:is |has been )?disabled"},"choices":{"group":"[class*=\"buttons-wrapper\"], [class*=\"reply-options\"], [data-qa*=\"answer-options\"], [data-qa*=\"question-options\"]","attachedButtons":true,"genericGroup":"[class*=\"buttons-wrapper\"]:not([class*=\"reply-options\"]):not([data-qa*=\"answer-options\"]):not([data-qa*=\"question-options\"])","genericPattern":"^(?:здравствуйте|какая схема оплаты|где находится место работы|можно без опыта|какой график работы|могу работать в гибком графике|у меня есть профильный опыт|hello|नमस्ते|你好)[.!?]*$","button":"button, [role=\"button\"], [role=\"option\"]"},"messages":{"item":"[data-qa^=\"chatik-chat-message-\"]","idAttribute":"data-qa","idPattern":"^chatik-chat-message-(\\d+)$","body":"[data-qa=\"chat-bubble-text\"]","outgoing":"[data-qa=\"status-icon-delivered\"], [data-qa=\"status-icon-read\"], [data-qa=\"status-icon-sent\"]","timestampAttribute":"data-time","serviceTitle":"[data-qa=\"chat-bubble-title\"], [data-qa=\"chat-bubble-author-name\"]","serviceTitlePattern":"^(?:отклик на вакансию|vacancy application|(?:application for|response to) (?:the|a) vacancy|bewerbung)$"},"chats":{"item":"[data-qa^=\"chatik-open-chat-\"], a[href^=\"/chat/\"]","idAttribute":"data-qa","idPattern":"^chatik-open-chat-(\\d{1,30})$","requireId":true,"uniqueIds":true,"link":"a[href^=\"/chat/\"]","linkPattern":"^/chat/(\\d{1,30})(?:[/?#]|$)","title":"[data-qa=\"chat-cell-title\"], [data-qa=\"chat-title\"]","preview":"[class*=\"last-message-color_\"], [data-qa=\"chat-last-message\"]","unread":"[data-qa=\"chat-unread-count\"], [data-qa*=\"badge\"], [data-qa*=\"counter\"]"},"actions":{}}, html="<!doctype html><html lang=\"en\"><meta charset=\"utf-8\">\n<title>Provider answer choice fixture</title><style>\nbody{font:17px system-ui;max-width:680px;margin:50px auto;padding:20px;background:#f5f6f8;color:#20252b}\narticle{background:white;border:1px solid #d8dde5;border-radius:12px;padding:16px;margin:12px 0}\nbutton,textarea{font:inherit;padding:12px;border:1px solid #a7b1c0;border-radius:8px;margin:5px}\ntextarea{display:block;width:90%;height:70px}h1{font-size:24px}.outgoing{margin-left:80px;background:#e4f3e6}\n</style><h1>Employer conversation · isolated fixture</h1>\n<main id=\"history\"><article data-qa=\"chatik-chat-message-101\" data-time=\"2026-11-11T10:00:00Z\">\n<strong>Recruiter bot</strong><p data-qa=\"chat-bubble-text\">Do you have distributed systems experience?</p></article></main>\n<div id=\"choices\"></div><div id=\"starters\"><button>Hello</button><button>Какой график работы?</button></div>\n<label>Provider composer<textarea data-qa=\"text-input\"></textarea></label><button id=\"send\">Send text</button>\n<p id=\"status\" role=\"status\">No answer sent</p>\n<script>\nwindow.fixture={clicks:0,textSends:0,receipt:'normal'};\nwindow.mountChoices=(labels=['Yes.','No.'],disabled=false)=>{\n const root=document.querySelector('#choices'); root.className='reply-options';\n root.replaceChildren(...labels.map(label=>{\n  const button=document.createElement('button');button.textContent=label;button.disabled=disabled;\n  button.onclick=()=>{\n   fixture.clicks++;document.querySelector('#status').textContent='Selected '+label;\n   if(fixture.receipt==='none')return;\n   const append=()=>{\n    const row=document.createElement('article');row.dataset.qa='chatik-chat-message-102';row.className=fixture.receipt==='incoming'?'':'outgoing';\n    const p=document.createElement('p');p.dataset.qa='chat-bubble-text';p.textContent=label;row.append(p);if(row.className){const status=document.createElement(\"span\");status.dataset.qa=\"status-icon-delivered\";row.append(status);}\n    if(fixture.receipt==='historical')document.querySelector('#history').prepend(row);else document.querySelector('#history').append(row);\n    if(fixture.receipt==='duplicate'){const copy=row.cloneNode(true);copy.dataset.qa='chatik-chat-message-103';document.querySelector('#history').append(copy);}\n   };\n   if(fixture.receipt==='delayed')setTimeout(append,100);else append();\n  };return button;\n }));\n};\ndocument.querySelector('#send').onclick=()=>fixture.textSends++;\n</script><script>\ndocument.querySelector('#send').dataset.qa='chatik-send-button';\ndocument.querySelector('#send').onclick=()=>{\n fixture.textSends++;\n const body=document.querySelector('textarea').value;\n document.querySelector('#status').textContent='Native send dispatched; receipt pending';\n if(fixture.receipt==='none')return;\n const append=()=>{\n  const row=document.createElement('article');row.dataset.qa='chatik-chat-message-102';\n  const text=document.createElement('p');text.dataset.qa='chat-bubble-text';text.textContent=body;row.append(text);\n  if(fixture.receipt!=='incoming'){\n   row.className='outgoing';const status=document.createElement('span');status.dataset.qa='status-icon-delivered';row.append(status);\n  }\n  const history=document.querySelector('#history');\n  if(fixture.receipt==='historical')history.prepend(row);else history.append(row);\n  if(fixture.receipt==='duplicate'){const copy=row.cloneNode(true);copy.dataset.qa='chatik-chat-message-103';history.append(copy);}\n  const input=document.querySelector('textarea');input.value='';input.dispatchEvent(new Event('input',{bubbles:true}));\n  document.querySelector('#status').textContent='Provider bubble added: '+body;\n };\n if(fixture.receipt==='delayed')setTimeout(append,50);else append();\n};\nwindow.textReplyState=()=>({\n sends:fixture.textSends, choices:fixture.clicks, draft:document.querySelector('textarea')?.value??null,\n hooks:document.querySelectorAll('[data-meta-answer-choice]').length,\n replies:[...document.querySelectorAll('[data-qa^=\"chatik-chat-message-\"]')].map(n=>({id:n.dataset.qa,body:n.querySelector('p')?.textContent,outgoing:!!n.querySelector('[data-qa=\"status-icon-delivered\"]')})),\n});\n</script></html>", text="Thank you. I have reviewed your message.";
  const ownerHtml="<!doctype html><html><meta charset=\"utf-8\">\n<nav data-qa=\"mainmenu_applicantProfile\">Synthetic owner page</nav><iframe src=\"https://chatik.hh.ru/chat/7\" style=\"width:850px;height:600px;\"></iframe></html>";
  const errors=[];page.on('pageerror',error=>errors.push(error.message));
  let framed=false,released=0;
  await page.route('**/*',route=>route.fulfill({contentType:'text/html',body:framed&&new URL(route.request().url()).hostname==='hh.ru'?ownerHtml:html}));
  const state=frame=>frame.evaluate(()=>({...window.textReplyState(),focused:document.hasFocus(),lease:Boolean(window[Symbol.for('meta-sovereign.browser-inactive-view.v1')])}));
  const commander={
    evaluate:({fn,args})=>page.evaluate(fn,args[0]),
    clickButton:({selector})=>page.locator(selector).evaluate(node=>node.click()),
  };
  const open=()=>inactiveContract.openBrowserAnswerWatch({commander,page,ui,target:'7',receiptMs:100,pollMs:10,queue:work=>work(),released:()=>released++});
  const outcomes=[];
  let handle,other;
  try{
    await page.goto('https://hh.ru/chat/7');await page.bringToFront();
    handle=await open();let expected=await handle.read();
    const before=await state(page);
    let code;
    try{await handle.replyTextInactive(expected,text);}catch(error){code=error.code;}
    if(code!=='browser-background-owner-active'||JSON.stringify(before)!==JSON.stringify(await state(page)))throw new Error('Focused provider changed');
    outcomes.push({name:'focused-no-write',code});
    other=await page.context().newPage();await other.setContent('<textarea>Active owner draft</textarea>');await other.bringToFront();
    await other.locator('textarea').evaluate(node=>node.setSelectionRange(2,8));
    const active=()=>other.evaluate(()=>({focused:document.hasFocus(),value:document.querySelector('textarea').value,selection:[document.querySelector('textarea').selectionStart,document.querySelector('textarea').selectionEnd]}));
    const owner=await active();
    const receipt=await handle.replyTextInactive(expected,text);
    const after=await state(page);
    if(receipt.messageId!=='102'||after.sends!==1||after.focused||after.lease||after.hooks||JSON.stringify(owner)!==JSON.stringify(await active()))throw new Error('Inactive receipt or owner preservation failed');
    outcomes.push({name:'inactive-receipt',receipt,after,owner});
    await page.screenshot({path:"/tmp/gh-issue-solver-1794216540735/docs/screenshots/issue-56-inactive-text/mcp-after.png",fullPage:true});
    await other.screenshot({path:"/tmp/gh-issue-solver-1794216540735/docs/screenshots/issue-56-inactive-text/mcp-owner.png",fullPage:true});
    await handle.close();handle=null;
    framed=true;await page.goto('https://hh.ru/chat/7');
    handle=await open();expected=await handle.read();await other.bringToFront();
    const child=page.frames().find(frame=>frame!==page.mainFrame());
    const locate=child.locator.bind(child);
    child.locator=(selector,options)=>{
      const locator=locate(selector,options);
      if(selector.startsWith('[data-meta-answer-choice=')){
        const evaluate=locator.evaluate.bind(locator);
        locator.evaluate=async(...args)=>{await page.bringToFront();return evaluate(...args);};
      }
      return locator;
    };
    code=null;try{await handle.replyTextInactive(expected,text);}catch(error){code=error.code;}
    const guarded=await state(child);
    if(code!=='answer-text-changed'||guarded.sends||guarded.focused||guarded.hooks||guarded.lease)throw new Error('Embedded final ownership guard failed');
    outcomes.push({name:'embedded-outer-return',code,after:guarded});
    await page.screenshot({path:"/tmp/gh-issue-solver-1794216540735/docs/screenshots/issue-56-inactive-text/mcp-owner-return.png",fullPage:true});
  }finally{await handle?.close();await other?.close();}
  if(released!==2||errors.length)throw new Error('Owned writes did not drain cleanly');
  return {cases:outcomes.length,outcomes,released,pageErrors:errors,liveProvider:false};
}