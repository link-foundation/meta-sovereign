async (page) => {
  const process = {env:{}};
  var conversationContract = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    scanBrowserConversation: () => scanBrowserConversation
  });

  // finite-mcp:node:timers/promises
  var setTimeout2 = () => {
    throw new Error("Use injected pause");
  };

  // finite-mcp:node:crypto
  var randomUUID = () => "independent-mcp-history";

  // js/src/sources/browser-choice-document.js
  var browserFrameVisible = (node) => {
    if (!node.isConnected || !node.getClientRects().length) {
      return false;
    }
    for (let parent = node; parent; parent = parent.parentElement) {
      const style = getComputedStyle(parent);
      if (parent.hidden || parent.getAttribute("aria-hidden") === "true" || style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) {
        return false;
      }
    }
    return true;
  };

  // js/src/sources/browser-chat-list-state.js
  var scrollOwnerActive = (state) => state.interrupted || state.inactiveToken && (window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")]?.token !== state.inactiveToken || window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")].interrupted || document.hasFocus()) || (state.drafts ?? []).some(
    ([node, value]) => !node.isConnected || node.value !== value
  ) || state.composer && document.querySelectorAll(state.composer).length !== state.drafts.length;
  var restoreScroll = (state, { restore, history, item, idAttribute }) => {
    if (!restore || scrollOwnerActive(state) || !state.visible(state.root)) {
      return false;
    }
    const move = (top) => {
      const previous = state.root.scrollTop;
      state.root.scrollTop = top;
      state.pendingScroll ||= previous !== state.root.scrollTop;
    };
    if (!history) {
      move(state.original);
      return true;
    }
    const anchor = [...state.root.querySelectorAll(item)].find(
      (node) => node.getAttribute(idAttribute) === state.anchor?.id
    );
    if (anchor) {
      move(
        state.root.scrollTop + anchor.getBoundingClientRect().top - state.root.getBoundingClientRect().top - state.anchor.offset
      );
      state.restoring = true;
      return true;
    }
    if (!state.restoring) {
      move(
        state.original + (state.reversed || state.tailOnly ? 0 : state.root.scrollHeight - state.originalHeight)
      );
      state.restoring = true;
    }
    return false;
  };
  var historyAnchor = (root, cells, idAttribute) => {
    const bounds = root.getBoundingClientRect();
    const anchor = cells.find((node) => {
      const rect = node.getBoundingClientRect();
      return rect.bottom > bounds.top && rect.top < bounds.bottom;
    });
    return anchor && {
      id: anchor.getAttribute(idAttribute),
      offset: anchor.getBoundingClientRect().top - bounds.top
    };
  };
  var browserChatScrollRoot = (cell) => {
    let root = cell?.parentElement;
    while (root && !/^(?:auto|scroll)$/.test(getComputedStyle(root).overflowY)) {
      root = root.parentElement;
    }
    return root ?? document.scrollingElement;
  };
  var openScroll = ({
    token,
    item,
    composer,
    idAttribute,
    scope,
    inactiveToken,
    allowOwnedInput,
    tailOnly
  }, visible) => {
    const history = scope === "history";
    const cell = [...document.querySelectorAll(item)].find(visible);
    const root = browserChatScrollRoot(cell);
    if (!root || !cell) {
      return { refused: "unavailable" };
    }
    const cells = history ? [...document.querySelectorAll(item)].filter(visible) : [];
    if (history && (cells.length > 500 || cells.some((node) => !root.contains(node)))) {
      return { refused: "unavailable" };
    }
    const state = {
      token,
      inactiveToken,
      root,
      visible,
      original: root.scrollTop,
      originalHeight: root.scrollHeight,
      anchor: history ? historyAnchor(root, cells, idAttribute) : void 0,
      reversed: getComputedStyle(root).flexDirection === "column-reverse",
      composer,
      tailOnly,
      interrupted: false,
      drafts: composer ? [...document.querySelectorAll(composer)].map((node) => [
        node,
        node.value
      ]) : []
    };
    state.events = [
      "pointerdown",
      "keydown",
      "wheel",
      "touchstart",
      "touchmove",
      "input"
    ];
    state.mark = (event) => {
      const inactive = window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")];
      if (allowOwnedInput === true && inactive && inactive.token === inactiveToken && event === inactive.ownedInput && !event.isTrusted) {
        return;
      }
      if (event.isTrusted || history) {
        state.interrupted = true;
      }
    };
    for (const type of state.events) {
      document.addEventListener(type, state.mark, {
        capture: true,
        passive: true
      });
    }
    state.scroll = (event) => {
      if (event.target === root || root === document.scrollingElement && event.target === document) {
        state.pendingScroll = false;
      }
    };
    document.addEventListener("scroll", state.scroll, {
      capture: true,
      passive: true
    });
    const previous = root.scrollTop;
    root.scrollTop = history && !state.reversed ? root.scrollHeight : 0;
    state.pendingScroll = previous !== root.scrollTop;
    return state;
  };
  var browserScrollState = (input, visible, openScroll2, restoreScroll2, scrollOwnerActive2) => {
    const {
      operation,
      token,
      item,
      top,
      restore,
      scope = "list",
      idAttribute
    } = input;
    const history = scope === "history";
    const key = /* @__PURE__ */ Symbol.for(
      history ? "meta-sovereign.browser-conversation-history.v1" : "meta-sovereign.browser-chat-list.v1"
    );
    const release = (state2) => {
      document.removeEventListener("scroll", state2.scroll, true);
      for (const type of state2.events) {
        document.removeEventListener(type, state2.mark, true);
      }
      const restored = restoreScroll2(state2, {
        restore,
        history,
        item,
        idAttribute
      });
      delete window[key];
      return { state: "released", restored };
    };
    const read = (state2) => {
      if (scrollOwnerActive2(state2)) {
        return { state: "owner-active" };
      }
      if (!visible(state2.root)) {
        return { state: "changed" };
      }
      if (operation === "move") {
        const previous = state2.root.scrollTop;
        state2.root.scrollTop = top;
        state2.pendingScroll = previous !== state2.root.scrollTop;
      }
      const { scrollTop, scrollHeight, clientHeight } = state2.root;
      if (clientHeight <= 0 || !Number.isFinite(scrollHeight)) {
        return { state: "unavailable" };
      }
      return {
        state: "ready",
        top: scrollTop,
        height: scrollHeight,
        view: clientHeight,
        bottom: scrollTop + clientHeight >= scrollHeight - 2,
        scrollPending: Boolean(state2.pendingScroll),
        loading: Boolean(
          state2.pendingScroll || state2.root.querySelector('[aria-busy="true"], [role="progressbar"]')
        ),
        ...input.debug ? {
          original: state2.original,
          anchor: state2.anchor,
          rendered: [...state2.root.querySelectorAll(item)].map(
            (node) => node.getAttribute(idAttribute)
          )
        } : {},
        ...history ? {
          reversed: state2.reversed,
          oldest: state2.reversed ? scrollTop <= -(scrollHeight - clientHeight) + 2 : scrollTop <= 2
        } : {}
      };
    };
    if (operation === "open") {
      if (window[key]) {
        return { state: "busy" };
      }
      if (scrollOwnerActive2({ inactiveToken: input.inactiveToken })) {
        return { state: "owner-active" };
      }
      const state2 = openScroll2(input, visible);
      if (state2.refused) {
        return { state: state2.refused };
      }
      window[key] = state2;
    }
    const state = window[key];
    if (!state || state.token !== token) {
      return { state: "unavailable" };
    }
    if (operation === "restore") {
      restoreScroll2(state, { restore, history, item, idAttribute });
    }
    return operation === "release" ? release(state) : read(state);
  };
  var browserChatListState = new Function(`return (input) => {
  const visible = (${browserFrameVisible.toString()});
  const scrollOwnerActive = (${scrollOwnerActive.toString()});
  const restoreScroll = (${restoreScroll.toString()});
  const historyAnchor = (${historyAnchor.toString()});
  const browserChatScrollRoot = (${browserChatScrollRoot.toString()});
  const openScroll = (${openScroll.toString()});
  return (${browserScrollState.toString()})(input, visible, openScroll, restoreScroll, scrollOwnerActive);
}`)();

  // js/src/sources/browser-scan-control.js
  var createBrowserScanControl = (document2, spec) => {
    const token = randomUUID();
    return {
      token,
      control: (operation, extra = {}) => document2.evaluate({
        fn: browserChatListState,
        args: [{ ...spec, operation, token, ...extra }]
      })
    };
  };

  // js/src/sources/browser-native-input.js
  var writeBrowserNativeInput = (node, value, inactive) => {
    const prototype = node instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    if (!setter || !("value" in node)) {
      return false;
    }
    const event = new Event("input", { bubbles: true });
    if (inactive) {
      inactive.ownedInput = event;
    }
    try {
      setter.call(node, value);
      node.dispatchEvent(event);
      node.dispatchEvent(new Event("change", { bubbles: true }));
      return String(node.value) === value;
    } finally {
      if (inactive?.ownedInput === event) {
        delete inactive.ownedInput;
      }
    }
  };

  // js/src/sources/browser-choice-visibility.js
  var watchChoiceView = (attempt, stop = false) => {
    if (!stop) {
      attempt.viewChanged = (event) => {
        if (event.type !== "pointerdown" || event.target !== attempt.node && !attempt.node.contains(event.target)) {
          attempt.preserveView = true;
        }
      };
    }
    for (const type of [
      "wheel",
      "touchmove",
      "keydown",
      "input",
      "pointerdown"
    ]) {
      document[stop ? "removeEventListener" : "addEventListener"](
        type,
        attempt.viewChanged,
        true
      );
    }
  };
  var revealChoiceReply = (spec, attempt, current, message) => {
    if (attempt.preserveView) {
      return "owner-activity";
    }
    const composer = current.composer;
    if (composer && String(composer.value ?? composer.textContent ?? "")) {
      return "owner-draft";
    }
    const pattern = new RegExp(spec.messages.idPattern);
    const nodes = [...document.querySelectorAll(spec.messages.item)].filter(
      (node) => pattern.exec(node.getAttribute(spec.messages.idAttribute) ?? "")?.[1] === message.id
    );
    if (nodes.length !== 1) {
      return "unavailable";
    }
    try {
      nodes[0].scrollIntoView({
        block: "nearest",
        inline: "nearest",
        behavior: "instant"
      });
      return "revealed";
    } catch {
      return "unavailable";
    }
  };

  // js/src/message-link-targets.js
  var messageLinkProperties = (links) => {
    if (links === void 0) {
      return {};
    }
    if (!Array.isArray(links) || links.length > 20 || !links.every(
      (link) => typeof link === "string" && Boolean(link.trim()) && link.length <= 2e3
    ) || links.reduce((size, link) => size + link.length, 0) > 6e3) {
      throw Object.assign(
        new Error("Message link targets must be bounded text."),
        {
          code: "question-links-invalid"
        }
      );
    }
    return links.length ? { links: [...links] } : {};
  };

  // js/src/sources/browser-pending-turn.js
  var browserPendingTurn = (rows) => {
    const validText = (value, limit, empty = false) => typeof value === "string" && value.length <= limit && (empty || Boolean(value.trim()));
    const end = rows.findLastIndex((row) => row.outgoing || row.service);
    const last = rows[end];
    let messages;
    try {
      messages = rows.slice(end + 1).map(({ id, body, links }) => ({
        id,
        body,
        ...messageLinkProperties(links)
      }));
      messageLinkProperties(last?.links);
    } catch {
      return { code: "answer-history-unverified" };
    }
    const boundary = last ? {
      kind: last.service ? "service" : "outgoing",
      id: last.id,
      body: last.body,
      ...messageLinkProperties(last.links)
    } : { kind: "rendered-start" };
    if (messages.length > 20 || messages.reduce((size, row) => size + String(row.body ?? "").length, 0) > 24e3) {
      return { code: "answer-history-limited" };
    }
    const relevant = last ? [last, ...messages] : messages;
    if (relevant.some(
      (row) => !validText(row.id, 480) || !validText(row.body, 6e3, row === last)
    ) || new Set(relevant.map((row) => row.id)).size !== relevant.length) {
      return { code: "answer-history-unverified" };
    }
    return { boundary, messages };
  };

  // js/src/sources/browser-reply-guard.js
  var browserReplyAdmission = (state, reservation) => {
    if (state.attempts.has(reservation)) {
      return "send-in-doubt";
    }
    if (state.attempts.size >= 32) {
      const completed = [...state.attempts].find(
        ([_key, attempt]) => attempt.confirmed
      );
      if (!completed) {
        return "answer-choice-capacity";
      }
      state.attempts.delete(completed[0]);
    }
    return null;
  };
  var armBrowserReply = (input, context, current, node, valid) => {
    const { state, identity, snapshot } = context;
    const reservation = identity(current);
    const code = browserReplyAdmission(state, reservation);
    if (code) {
      return { code };
    }
    const attempt = {
      node,
      token: input.token,
      reservation,
      before: current.messages.map((row) => row.id),
      allowed: false,
      clicked: false
    };
    const selector = `[data-meta-answer-choice="${input.token}"]`;
    attempt.guard = (event) => {
      const tagged = event.target.closest?.(selector);
      if (!tagged && event.target !== attempt.node && !attempt.node.contains(event.target)) {
        return;
      }
      if (tagged !== attempt.node || !valid(snapshot(), attempt) || attempt.clicked) {
        event.preventDefault();
        event.stopImmediatePropagation();
        attempt.blocked = true;
        return;
      }
      attempt.allowed = true;
      attempt.clicked ||= event.type === "click";
    };
    node.setAttribute("data-meta-answer-choice", input.token);
    watchChoiceView(attempt);
    for (const type of ["pointerdown", "mousedown", "click"]) {
      document.addEventListener(type, attempt.guard, true);
    }
    state.attempts.set(reservation, attempt);
    return { armed: true, selector };
  };

  // js/src/sources/browser-text-controller.js
  var textReplyOpen = (spec) => {
    const nodes = [
      ...document.querySelectorAll('p,span,div,[role="status"],[role="alert"]')
    ];
    if (nodes.length > 5e3) {
      return false;
    }
    const pattern = new RegExp(spec.textReply.closedText, "iu");
    return !nodes.some(
      (node) => !node.children.length && browserFrameVisible(node) && pattern.test(node.textContent)
    );
  };
  var textReplyButtons = (spec) => [...document.querySelectorAll(spec.textReply.send)].filter(
    (node) => browserFrameVisible(node) && !node.matches(':disabled,[disabled],[aria-disabled="true"]') && !node.closest('[inert],[aria-disabled="true"]')
  );
  var armTextReply = (input, context) => {
    const {
      snapshot,
      same,
      state,
      identity,
      own,
      valueOf,
      write,
      writable,
      clearOwned
    } = context;
    const current = snapshot();
    if (!same(current) || current.strictOptions || !writable(current.composer) || !textReplyOpen(input.spec)) {
      return { code: "answer-text-changed" };
    }
    if (valueOf(current.composer)) {
      return { code: "answer-draft-preserved" };
    }
    const code = browserReplyAdmission(state, identity(current));
    if (code) {
      return { code };
    }
    const composer = current.composer;
    if (!write(composer, input.text)) {
      return { code: "answer-prefill-unverified" };
    }
    const owner = own(current, input.text);
    const valid = (fresh2, attempt2) => same(fresh2) && !fresh2.strictOptions && textReplyOpen(input.spec) && fresh2.composer === composer && writable(composer) && state.owners.get(composer) === owner && valueOf(composer) === input.text && !attempt2.preserveView && textReplyButtons(input.spec).length === 1 && textReplyButtons(input.spec)[0] === attempt2.node;
    const buttons = textReplyButtons(input.spec);
    const fresh = snapshot();
    if (buttons.length !== 1 || !valid(fresh, { node: buttons[0] })) {
      clearOwned(current);
      return { code: "answer-text-changed" };
    }
    const armed = armBrowserReply(input, context, fresh, buttons[0], valid);
    const attempt = state.attempts.get(identity(current));
    if (armed.armed) {
      attempt.clearDraft = () => {
        if (!attempt.allowed && state.owners.get(composer) === owner) {
          clearOwned(current);
        }
      };
    } else {
      clearOwned(current);
    }
    return armed;
  };

  // js/src/sources/browser-notice-context.js
  var noticeVacancyUrl = (link) => {
    let url;
    try {
      url = new URL(link.href);
      if (!["https://hh.ru", "https://www.hh.ru"].includes(url.origin) || url.username || url.password || !/^\/vacancy\/\d{1,30}\/?$/u.test(url.pathname)) {
        return null;
      }
    } catch {
      return null;
    }
    return `${url.origin}${url.pathname}`;
  };
  var browserNoticeContext = (spec) => {
    const selectors = spec.noticeContext;
    if (!selectors) {
      return null;
    }
    const one = (selector) => {
      const nodes = [...document.querySelectorAll(selector)].filter(
        browserFrameVisible
      );
      return nodes.length === 1 ? nodes[0] : null;
    };
    const company = one(selectors.company)?.textContent?.trim();
    const vacancy = one(selectors.vacancy)?.textContent?.trim();
    const link = one(selectors.link);
    if (!company || company.length > 600 || !vacancy || vacancy.length > 600 || !link) {
      return null;
    }
    const vacancyUrl = noticeVacancyUrl(link);
    if (!vacancyUrl) {
      return null;
    }
    const composer = one(spec.composer);
    return {
      noticeContext: {
        company,
        vacancy,
        vacancyUrl,
        canReply: Boolean(
          composer && !composer.matches(
            ':disabled,[disabled],[readonly],[aria-disabled="true"],[aria-readonly="true"]'
          ) && !composer.closest('[inert],[aria-disabled="true"]') && textReplyOpen(spec)
        )
      }
    };
  };

  // js/src/sources/browser-choice-reader.js
  var browserMessageLinks = (body) => {
    const anchors = body ? [...body.querySelectorAll("a[href]")] : [];
    if (body?.matches("a[href]")) {
      anchors.unshift(body);
    }
    if (anchors.length > 20) {
      throw new Error("Message link targets exceed the capture limit.");
    }
    return messageLinkProperties(
      anchors.map(
        (anchor) => new URL(anchor.getAttribute("href"), document.baseURI).href
      )
    );
  };
  var browserChoiceSuggestions = (spec, group, all, visible, text) => {
    if (!spec.choices.genericGroup || !group.matches(spec.choices.genericGroup) || group.closest(spec.messages.item)) {
      return false;
    }
    const offered = all.filter((node) => group.contains(node) && visible(node));
    const pattern = new RegExp(spec.choices.genericPattern, "iu");
    return offered.length > 0 && offered.some((node) => pattern.test(text(node)));
  };
  var browserChoiceHistory = (spec, visible, text, historyOnly = false) => {
    const unavailable = (code) => ({ code });
    const validLocation = (url2, match2) => spec.location.origins.includes(url2.origin) && Boolean(match2?.[1]);
    const validRows = (rows2) => !rows2.some((row) => !row.id || row.body.length > 6e3) && new Set(rows2.map((row) => row.id)).size === rows2.length;
    const bodyOf = (node) => String(node.querySelector(spec.messages.body)?.innerText ?? "").trim();
    const url = new URL(location.href);
    const match = new RegExp(spec.location.pathPattern).exec(url.pathname);
    if (!validLocation(url, match)) {
      return unavailable("answer-chat-unverified");
    }
    const chat = match[1];
    const candidates = [...document.querySelectorAll(spec.messages.item)];
    if (candidates.length > 500) {
      return unavailable("answer-history-limited");
    }
    const idPattern = new RegExp(spec.messages.idPattern);
    const serviceTitle = spec.messages.serviceTitlePattern ? new RegExp(spec.messages.serviceTitlePattern, "iu") : null;
    let rows;
    try {
      rows = candidates.filter(visible).map((node) => ({
        node,
        id: idPattern.exec(
          node.getAttribute(spec.messages.idAttribute) ?? ""
        )?.[1],
        body: bodyOf(node),
        ...browserMessageLinks(node.querySelector(spec.messages.body)),
        outgoing: node.matches(spec.messages.outgoing) || Boolean(node.querySelector(spec.messages.outgoing)),
        ...serviceTitle?.test(
          text(node.querySelector(spec.messages.serviceTitle))
        ) ? { service: true } : {}
      }));
    } catch {
      return unavailable("answer-history-unverified");
    }
    if (!validRows(rows)) {
      return unavailable("answer-history-unverified");
    }
    const messages = rows.map(({ node, ...row }) => ({
      ...row,
      timestamp: spec.messages.timestampAttribute ? node.getAttribute(spec.messages.timestampAttribute) : null
    }));
    const latest = rows.at(-1);
    const pendingTurn = historyOnly ? void 0 : browserPendingTurn(messages);
    if (pendingTurn?.code) {
      return pendingTurn;
    }
    return {
      chat,
      latest,
      messages,
      pendingTurn,
      questionAvailable: Boolean(latest?.body) && !latest.service
    };
  };
  var readBrowserChoices = (spec, internal = false, historyOnly = false) => {
    const text = (node) => String(node?.textContent ?? "").replace(/\s+/gu, " ").trim();
    const visible = (node) => {
      if (!node?.isConnected || !node.getClientRects().length) {
        return false;
      }
      for (let parent = node; parent; parent = parent.parentElement) {
        const style = getComputedStyle(parent);
        if (parent.hidden || parent.getAttribute("aria-hidden") === "true" || style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) {
          return false;
        }
      }
      return true;
    };
    const unavailable = (code) => ({ code });
    const validControls = (controls2) => controls2.length <= 100 && !controls2.some((node) => !text(node) || text(node).length > 6e3);
    const history = browserChoiceHistory(spec, visible, text, historyOnly);
    if (history.code) {
      return history;
    }
    const { chat, latest, messages, pendingTurn, questionAvailable } = history;
    if (!questionAvailable) {
      return historyOnly ? { chat, messages } : unavailable("answer-question-unavailable");
    }
    const all = [...document.querySelectorAll(spec.choices.button)];
    if (all.length > 1e3) {
      return unavailable("answer-options-limited");
    }
    const groups = [...document.querySelectorAll(spec.choices.group)].filter(
      (group) => visible(group) && !browserChoiceSuggestions(spec, group, all, visible, text)
    );
    const attached = groups.filter((group) => {
      const dialog = group.closest('[role="dialog"]');
      if (dialog && !dialog.contains(latest.node)) {
        return false;
      }
      const parent = group.closest(spec.messages.item);
      if (parent) {
        return parent === latest.node;
      }
      const bound = group.getAttribute(
        spec.choices.questionAttribute ?? "data-question-id"
      );
      return bound ? bound === latest.id : Boolean(latest.node.compareDocumentPosition(group) & 4);
    }).filter(
      (group, _index, selected) => !selected.some((other) => other !== group && group.contains(other))
    );
    if (groups.length > 100 || attached.length > 1) {
      return unavailable("answer-options-ambiguous");
    }
    const shown = all.filter(visible);
    const yes = /^(?:yes|да|हाँ|是)[.!]?$/iu;
    const no = /^(?:no|нет|नहीं|否)[.!]?$/iu;
    const unscoped = shown.filter((node) => {
      const owner = node.closest(spec.messages.item);
      const dialog = node.closest('[role="dialog"]');
      return (!owner || owner === latest.node) && (!dialog || dialog.contains(latest.node)) && !groups.some((group) => group.contains(node)) && (yes.test(text(node)) || no.test(text(node)));
    });
    const pair = unscoped.length === 2 && unscoped.some((node) => yes.test(text(node))) && unscoped.some((node) => no.test(text(node)));
    const controls = shown.filter(
      (node) => attached.some((group) => group.contains(node)) || spec.choices.attachedButtons && latest.node.contains(node) || pair && unscoped.includes(node)
    );
    if (!validControls(controls)) {
      return unavailable("answer-options-unverified");
    }
    const enabled = controls.filter(
      (node) => !node.matches(':disabled,[disabled],[aria-disabled="true"]') && !node.closest('[inert],[aria-disabled="true"]')
    );
    const strictOptions = [attached.length, pair, controls.length].some(Boolean);
    const answerOptions = enabled.map(text);
    if (historyOnly) {
      return {
        chat,
        messages: messages.map(
          (row) => row.id === latest.id ? { ...row, strictOptions, answerOptions } : row
        )
      };
    }
    const composers = [...document.querySelectorAll(spec.composer)].filter(
      visible
    );
    if (composers.length > 1) {
      return unavailable("answer-composer-ambiguous");
    }
    const result = {
      chat,
      question: {
        id: latest.id,
        body: latest.body,
        outgoing: latest.outgoing,
        ...messageLinkProperties(latest.links)
      },
      strictOptions,
      answerOptions,
      optionsShown: controls.map(text),
      messages,
      pendingTurn,
      ...browserNoticeContext(spec)
    };
    return internal ? { ...result, controls: enabled, composer: composers[0] } : result;
  };

  // js/src/sources/browser-choice-controller.js
  var createChoiceContext = (input, read) => {
    const { spec, expected } = input;
    const key = /* @__PURE__ */ Symbol.for("meta-sovereign.browser-answer-choice.v1");
    const state = window[key] ??= {
      owners: /* @__PURE__ */ new WeakMap(),
      observed: /* @__PURE__ */ new WeakSet(),
      attempts: /* @__PURE__ */ new Map()
    };
    const snapshot = (historyOnly = false) => read(spec, true, historyOnly);
    const inactiveKey = /* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1");
    const inactive = input.inactiveToken && window[inactiveKey];
    const inactiveReady = () => !input.inactiveToken || inactive && window[inactiveKey] === inactive && inactive.token === input.inactiveToken && !inactive.interrupted && !document.hasFocus();
    const identity = (value) => JSON.stringify([
      value.chat,
      value.question?.id,
      value.question?.body,
      value.question?.links
    ]);
    const ownershipIdentity = (value) => JSON.stringify([identity(value), value.pendingTurn]);
    const samePending = (value) => expected.pendingTurn ? JSON.stringify(value.pendingTurn) === JSON.stringify(expected.pendingTurn) : expected.pendingMessages ? JSON.stringify(value.pendingTurn?.messages) === JSON.stringify(expected.pendingMessages) : value.pendingTurn?.messages.length === 1;
    const same = (value) => inactiveReady() && !value.code && !value.question.outgoing && identity(value) === identity(expected) && samePending(value) && (!expected.noticeContext || JSON.stringify(value.noticeContext) === JSON.stringify(expected.noticeContext)) && JSON.stringify(value.answerOptions) === JSON.stringify(expected.answerOptions);
    const valueOf = (node) => node ? String("value" in node ? node.value : node.textContent ?? "") : "";
    const writable = (node) => Boolean(node) && !node.matches(
      ':disabled,[disabled],[readonly],[inert],[aria-disabled="true"],[aria-readonly="true"]'
    ) && !node.closest('[inert],[aria-disabled="true"]');
    const write = (node, value) => {
      if (!writable(node) || !inactiveReady()) {
        return false;
      }
      state.writing = true;
      try {
        return writeBrowserNativeInput(node, value, inactive);
      } finally {
        state.writing = false;
      }
    };
    const clearOwned = (current) => {
      const node = current.composer;
      const owner = node && state.owners.get(node);
      if (owner && owner.identity === ownershipIdentity(current) && valueOf(node) === owner.text) {
        const attempt = state.attempts.get(identity(current));
        if (attempt?.allowed && !attempt.confirmed) {
          return false;
        }
        state.owners.delete(node);
        return write(node, "");
      }
      return !valueOf(node);
    };
    const own = (current, text) => {
      const node = current.composer;
      const owner = { identity: ownershipIdentity(current), text };
      state.owners.set(node, owner);
      if (!state.observed.has(node)) {
        state.observed.add(node);
        node.addEventListener("input", () => {
          if (!state.writing) {
            state.owners.delete(node);
          }
        });
      }
      return owner;
    };
    const clean = (attempt) => {
      attempt.clearDraft?.();
      watchChoiceView(attempt, true);
      attempt.node.removeAttribute("data-meta-answer-choice");
      for (const node of document.querySelectorAll("[data-meta-answer-choice]")) {
        if (node.getAttribute("data-meta-answer-choice") === attempt.token) {
          node.removeAttribute("data-meta-answer-choice");
        }
      }
      for (const type of ["pointerdown", "mousedown", "click"]) {
        document.removeEventListener(type, attempt.guard, true);
      }
    };
    return {
      state,
      snapshot,
      identity,
      ownershipIdentity,
      same,
      valueOf,
      writable,
      own,
      write,
      clearOwned,
      clean
    };
  };
  var readChoiceHistory = (_input, { snapshot }) => snapshot(true);
  var readChoicePublic = (input, context) => {
    const { snapshot, clearOwned, valueOf } = context;
    const current = snapshot();
    if (current.code) {
      return current;
    }
    if (!input.preserveDraft && current.optionsShown.length) {
      clearOwned(current);
    }
    const { controls: _controls, composer, ...result } = current;
    return { ...result, hasDraft: Boolean(valueOf(composer)) };
  };
  var prefillChoiceDraft = (input, context) => {
    const { snapshot, same, valueOf, write, own } = context;
    const current = snapshot();
    if (!same(current) || current.strictOptions || !current.composer || valueOf(current.composer)) {
      return { code: "answer-draft-preserved" };
    }
    const node = current.composer;
    if (!write(node, input.text)) {
      return { code: "answer-prefill-unverified" };
    }
    own(current, input.text);
    return same(snapshot()) ? { prefilled: true } : { code: "answer-prefill-unverified" };
  };
  var armChoiceClick = (input, context) => {
    const { option } = input;
    const { snapshot, same, clearOwned, valueOf } = context;
    const current = snapshot();
    const candidates = current.controls?.filter(
      (node) => String(node.textContent).replace(/\s+/gu, " ").trim() === option
    ) ?? [];
    if (!same(current) || !current.strictOptions || candidates.length !== 1) {
      return { code: "answer-choice-changed" };
    }
    if (!clearOwned(current)) {
      return { code: "answer-draft-preserved" };
    }
    return armBrowserReply(
      input,
      context,
      current,
      candidates[0],
      (fresh, attempt) => same(fresh) && fresh.controls.includes(attempt.node) && !valueOf(fresh.composer)
    );
  };
  var matchingChoiceReplies = (input, current, attempt) => {
    const { expected, option } = input;
    const questionIndex = current.messages?.findIndex((row) => row.id === expected.question.id) ?? -1;
    const matchesReply = (row) => row.outgoing && !row.service && !attempt.before.includes(row.id) && row.body === (option ?? input.text);
    return !current.code && current.chat === expected.chat && questionIndex >= 0 ? current.messages.slice(questionIndex + 1).filter(matchesReply) : [];
  };
  var readChoiceReceipt = (input, context) => {
    const { state, snapshot, clean } = context;
    const attempt = [...state.attempts.values()].find(
      (entry) => entry.token === input.token
    );
    if (!attempt) {
      return { code: "send-unknown" };
    }
    const current = snapshot();
    const matches = matchingChoiceReplies(input, current, attempt);
    const confirmed = (input.text === void 0 ? attempt.allowed : attempt.clicked) && matches.length === 1;
    if (confirmed || input.finish) {
      clean(attempt);
    }
    if (confirmed) {
      if (!attempt.confirmed) {
        attempt.reveal = revealChoiceReply(
          input.spec,
          attempt,
          current,
          matches[0]
        );
      }
      attempt.confirmed = true;
      return { sent: true, messageId: matches[0].id, reveal: attempt.reveal };
    }
    if (input.finish && !attempt.allowed && attempt.blocked) {
      state.attempts.delete(attempt.reservation);
      return {
        code: input.text === void 0 ? "answer-choice-changed" : "answer-text-changed",
        dispatched: false
      };
    }
    return { code: "send-unknown", blocked: Boolean(attempt.blocked) };
  };
  var releaseChoiceClick = ({ token }, { state, clean }) => {
    const attempt = [...state.attempts.values()].find(
      (entry) => entry.token === token
    );
    if (attempt) {
      clean(attempt);
    }
    return { released: true };
  };

  // js/src/crm/question-recognition.js
  var W = "[\\p{L}\\p{M}\\p{N}_]";
  var start = (source2) => new RegExp(`^(?:${source2})(?!${W})`, "iu");
  var QUESTION_START = start(
    "\u043A\u0430\u043A|\u0447\u0442\u043E|\u0447\u0435\u043C|\u0433\u0434\u0435|\u043A\u0443\u0434\u0430|\u043E\u0442\u043A\u0443\u0434\u0430|\u043A\u043E\u0433\u0434\u0430|\u043F\u043E\u0447\u0435\u043C\u0443|\u0437\u0430\u0447\u0435\u043C|\u043A\u0442\u043E|\u043A\u0435\u043C|\u043A\u0430\u043A\u043E\u0439|\u043A\u0430\u043A\u0430\u044F|\u043A\u0430\u043A\u043E\u0435|\u043A\u0430\u043A\u0438\u0435|\u0441\u043A\u043E\u043B\u044C\u043A\u043E|\u043C\u043E\u0436\u043D\u043E|\u043D\u0435\u043B\u044C\u0437\u044F \u043B\u0438|\u043D\u0435 \u043F\u043E\u0434\u0441\u043A\u0430\u0436\u0435\u0442\u0435|\u043F\u043E\u0434\u0441\u043A\u0430\u0436\u0438|\u043F\u043E\u0434\u0441\u043A\u0430\u0436\u0438\u0442\u0435|\u0435\u0441\u0442\u044C \u043B\u0438|\u0431\u044B\u043B \u043B\u0438|\u0431\u044B\u043B\u0430 \u043B\u0438|\u0431\u044B\u043B\u0438 \u043B\u0438|how|what|where|when|why|who|which|do you|did you|are you|can you|could you|would you|is there|have you"
  );
  var REQUEST = start(
    "please\\s+(?:tell|share|describe|provide|send)|tell\\s+(?:me|us)|describe\\s+your|share\\s+your|\u0440\u0430\u0441\u0441\u043A\u0430\u0436\u0438\u0442\u0435|\u0440\u0430\u0441\u0441\u043A\u0430\u0436\u0438|\u0443\u043A\u0430\u0436\u0438\u0442\u0435|\u0443\u043A\u0430\u0436\u0438|\u043D\u0430\u043F\u0438\u0448\u0438\u0442\u0435|\u043D\u0430\u043F\u0438\u0448\u0438|\u043F\u0440\u0438\u0448\u043B\u0438\u0442\u0435|\u043F\u0440\u0438\u0448\u043B\u0438|\u0443\u0442\u043E\u0447\u043D\u0438\u0442\u0435|\u0443\u0442\u043E\u0447\u043D\u0438|\u0441\u043E\u043E\u0431\u0449\u0438\u0442\u0435|\u0441\u043E\u043E\u0431\u0449\u0438|\u043E\u043F\u0438\u0448\u0438\u0442\u0435|\u043E\u043F\u0438\u0448\u0438|\u043F\u043E\u0434\u0435\u043B\u0438\u0442\u0435\u0441\u044C|\u043F\u043E\u0434\u0435\u043B\u0438\u0441\u044C|\u043F\u0440\u0438\u0432\u0435\u0434\u0438(?:\u0442\u0435)?\\s+\u043F\u0440\u0438\u043C\u0435\u0440"
  );
  var HINDI_WORD = "\u0915\u094D\u092F\u093E|\u0915\u0939\u093E\u0901|\u0915\u0939\u093E\u0902|\u0915\u092C|\u0915\u094D\u092F\u094B\u0902|\u0915\u0948\u0938\u0947|\u0915\u094C\u0928|\u0915\u093F\u0938(?:\u0915\u093E|\u0915\u0940|\u0915\u0947|\u0947)?|\u0915\u093F\u0924\u0928(?:\u093E|\u0940|\u0947)";
  var HINDI_START = start(HINDI_WORD);
  var HINDI_SUBJECT = new RegExp(
    `^(?:\u0906\u092A|\u0924\u0941\u092E|\u0906\u092A\u0915\u093E|\u0906\u092A\u0915\u0940|\u0906\u092A\u0915\u0947|\u0924\u0941\u092E\u094D\u0939\u093E\u0930\u093E|\u0924\u0941\u092E\u094D\u0939\u093E\u0930\u0940|\u0924\u0941\u092E\u094D\u0939\u093E\u0930\u0947)(?!${W})[^\u0964.!?\\r\\n]{0,100}?(?<!${W})(?:${HINDI_WORD})(?!${W})`,
    "u"
  );
  var HINDI_REQUEST = new RegExp(
    `^(?:\u0915\u0943\u092A\u092F\u093E(?!${W})[^\u0964.!?\\r\\n]{0,160}?(?<!${W}))?(?:\u092C\u0924\u093E\u0907\u090F|\u092C\u0924\u093E\u090F\u0902|\u092C\u0924\u093E\u092F\u0947\u0902|\u092C\u0924\u093E\u0913|\u0938\u093E\u091D\u093E \u0915\u0930\u0947\u0902|\u092D\u0947\u091C\u0947\u0902|\u092A\u094D\u0930\u0926\u093E\u0928 \u0915\u0930\u0947\u0902|\u0909\u0932\u094D\u0932\u0947\u0916 \u0915\u0930\u0947\u0902|\u0932\u093F\u0916\u0947\u0902)(?!${W})`,
    "u"
  );

  // js/src/automation/question-subjects.js
  var names = [
    ["go", ["go", "golang"]],
    ["csharp", ["c#", "\u0441#", "csharp", "c-sharp"]],
    ["cpp", ["c++", "\u0441++", "cpp"]],
    ["c", ["c", "\u0441\u0438"]],
    ["javascript", ["javascript", "js", "\u0434\u0436\u0430\u0432\u0430\u0441\u043A\u0440\u0438\u043F\u0442"]],
    ["typescript", ["typescript", "ts"]],
    ["java", ["java", "\u0434\u0436\u0430\u0432\u0430"]],
    ["python", ["python", "\u043F\u0438\u0442\u043E\u043D"]],
    ["rust", ["rust"]],
    ["ruby", ["ruby"]],
    ["php", ["php"]],
    ["swift", ["swift"]],
    ["kotlin", ["kotlin"]],
    ["scala", ["scala"]],
    ["docker", ["docker", "\u0434\u043E\u043A\u0435\u0440"]],
    ["kubernetes", ["kubernetes", "k8s"]],
    ["mongodb", ["mongodb", "mongo"]],
    ["postgresql", ["postgresql", "postgres"]],
    ["mysql", ["mysql"]],
    ["redis", ["redis"]],
    ["aws", ["aws"]],
    ["azure", ["azure"]],
    ["gcp", ["gcp"]],
    ["react", ["react", "reactjs"]],
    ["angular", ["angular"]],
    ["vue", ["vue", "vuejs"]],
    ["git", ["git", "\u0433\u0438\u0442"]],
    ["github", ["github"]],
    ["linkedin", ["linkedin"]],
    ["telegram", ["telegram", "\u0442\u0435\u043B\u0435\u0433\u0440\u0430\u043C"]],
    ["lead", ["lead", "\u0442\u0438\u043C\u043B\u0438\u0434", "\u0442\u0435\u0445\u043B\u0438\u0434"]],
    ["junior", ["junior"]],
    ["senior", ["senior"]],
    ["usd", ["usd", "\u0434\u043E\u043B\u043B\u0430\u0440", "\u0434\u043E\u043B\u043B\u0430\u0440\u043E\u0432", "dollar", "dollars"]],
    [
      "rub",
      [
        "rub",
        "rur",
        "\u0440\u0443\u0431",
        "\u0440\u0443\u0431\u043B\u0435\u0439",
        "\u0440\u0443\u0431\u043B\u044F\u0445",
        "\u0440\u0443\u0431\u043B\u0438",
        "\u0440\u0443\u0431\u043B\u044C",
        "rubles",
        "roubles"
      ]
    ],
    ["eur", ["eur", "euro", "euros", "\u0435\u0432\u0440\u043E"]],
    ["gbp", ["gbp"]],
    ["inr", ["inr"]],
    ["cny", ["cny", "rmb"]],
    ["vnd", ["vnd"]],
    ["jpy", ["jpy"]],
    ["employment:ip", ["\u0438\u043F"]],
    ["employment:gph", ["\u0433\u043F\u0445"]],
    ["employment:self", ["\u0441\u0430\u043C\u043E\u0437\u0430\u043D\u044F\u0442\u044B\u0439", "\u0441\u0430\u043C\u043E\u0437\u0430\u043D\u044F\u0442\u044B\u043C\u0438", "\u0441\u0430\u043C\u043E\u0437\u0430\u043D\u044F\u0442\u043E\u0441\u0442\u044C"]]
  ];
  var aliases = new Map(
    names.flatMap(([key, values]) => values.map((name) => [name, key]))
  );

  // js/src/automation/question-turns.js
  var ACK_WORDS = new Set(
    "\u043E\u043A \u043E\u043A\u0435\u0439 \u0445\u043E\u0440\u043E\u0448\u043E \u043F\u043E\u043D\u044F\u043B \u043F\u043E\u043D\u044F\u043B\u0430 \u0441\u043F\u0430\u0441\u0438\u0431\u043E \u0431\u043B\u0430\u0433\u043E\u0434\u0430\u0440\u044E \u043F\u0440\u0438\u043D\u044F\u0442\u043E \u043E\u0442\u043B\u0438\u0447\u043D\u043E \u044F\u0441\u043D\u043E \u0437\u0430 \u0432\u0430\u0448 \u0432\u0430\u0448\u0438 \u043E\u0442\u0432\u0435\u0442 \u043E\u0442\u0432\u0435\u0442\u044B \u043E\u0442\u043A\u043B\u0438\u043A \u043F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0441\u0442\u0438 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044E \u0443\u0447\u0442\u0443 \u043E\u043F\u044B\u0442 hello hi thanks thank you for the your answer answers details information understood noted okay ok got it \u0928\u092E\u0938\u094D\u0924\u0947 \u0927\u0928\u094D\u092F\u0935\u093E\u0926 \u8C22\u8C22 \u597D\u7684".split(
      " "
    )
  );
  var CONSENT_WORDS = new Set(
    "yes no yeah yep sure okay ok yes of course let s lets continue please thanks thank you maybe perhaps da \u0434\u0430 \u043D\u0435\u0442 \u043A\u043E\u043D\u0435\u0447\u043D\u043E \u0430\u0433\u0430 \u0443\u0433\u0443 \u0445\u043E\u0440\u043E\u0448\u043E \u043E\u043A \u0434\u0430\u0432\u0430\u0439\u0442\u0435 \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u043C \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0430\u0442\u044C \u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0441\u043F\u0430\u0441\u0438\u0431\u043E \u0431\u043B\u0430\u0433\u043E\u0434\u0430\u0440\u044E \u043D\u0435 \u0443\u0432\u0435\u0440\u0435\u043D \u0443\u0432\u0435\u0440\u0435\u043D\u0430 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E \u0939\u093E\u0901 \u0939\u093E\u0902 \u091C\u0940 \u0928\u0939\u0940\u0902 \u0920\u0940\u0915 \u091C\u093E\u0930\u0940 \u0930\u0916\u0947\u0902 \u0927\u0928\u094D\u092F\u0935\u093E\u0926 \u662F \u597D\u7684 \u7EE7\u7EED \u662F\u7684 \u4E0D \u8C22\u8C22".split(
      " "
    )
  );

  // js/src/sources/browser-scan-options.js
  var bounded = (value, fallback, minimum, maximum) => {
    const result = value ?? fallback;
    if (!Number.isInteger(result) || result < minimum || result > maximum) {
      throw Object.assign(new Error("Invalid bounded browser scan setting"), {
        code: "bad-chat-scan",
        fallback: false
      });
    }
    return result;
  };
  var normalizeChatScanOptions = (options = {}) => {
    if (options.unreadOnly !== void 0 && typeof options.unreadOnly !== "boolean" || options.onHistoryWindow !== void 0 && typeof options.onHistoryWindow !== "function") {
      throw Object.assign(new Error("Invalid browser scan setting"), {
        code: "bad-chat-scan",
        fallback: false
      });
    }
    return {
      limit: bounded(options.limit, 500, 1, 5e3),
      maxPasses: bounded(options.maxPasses, 100, 1, 500),
      budgetMs: bounded(options.budgetMs, 3e4, 100, 12e4),
      waitMs: bounded(options.waitMs, 150, 10, 1e3),
      endWaitMs: bounded(options.endWaitMs, 2e3, 100, 1e4)
    };
  };

  // js/src/sources/browser-choices.js
  var methods = {
    read: readChoicePublic,
    history: readChoiceHistory,
    prefill: prefillChoiceDraft,
    arm: armChoiceClick,
    armText: armTextReply,
    receipt: readChoiceReceipt,
    release: releaseChoiceClick
  };
  var source = `(input) => {
  const messageLinkProperties = (${messageLinkProperties.toString()});
  const browserMessageLinks = (${browserMessageLinks.toString()});
  const writeBrowserNativeInput = (${writeBrowserNativeInput.toString()});
  const watchChoiceView = (${watchChoiceView.toString()});
  const revealChoiceReply = (${revealChoiceReply.toString()});
  const browserFrameVisible = (${browserFrameVisible.toString()});
  const browserReplyAdmission = (${browserReplyAdmission.toString()});
  const matchingChoiceReplies = (${matchingChoiceReplies.toString()});
  const armBrowserReply = (${armBrowserReply.toString()});
  const textReplyButtons = (${textReplyButtons.toString()});
  const textReplyOpen = (${textReplyOpen.toString()});
  const noticeVacancyUrl = (${noticeVacancyUrl.toString()});
  const browserNoticeContext = (${browserNoticeContext.toString()});
  const browserPendingTurn = (${browserPendingTurn.toString()});
  const browserChoiceSuggestions = (${browserChoiceSuggestions.toString()});
  const browserChoiceHistory = (${browserChoiceHistory.toString()});
  const context = (${createChoiceContext.toString()})(input, ${readBrowserChoices.toString()});
  const methods = {${Object.entries(methods).map(([name, method]) => `${name}: ${method.toString()}`).join(",")}};
  return methods[input.operation](input, context);
}`;
  var browserChoicePage = new Function(`return (${source})`)();
  var failure = (code) => Object.assign(
    new Error(
      {
        "answer-draft-preserved": "The provider composer contains an owner draft; review it before selecting an answer",
        "send-unknown": "The option may have been selected; inspect the provider chat before trying again",
        "send-in-doubt": "This question already has a selection attempt; inspect the provider chat before trying again"
      }[code] ?? "The current provider question or answer controls could not be verified"
    ),
    {
      code,
      fallback: false,
      ...["send-unknown", "send-in-doubt"].includes(code) ? { ambiguous: true, outcome: "unknown" } : {}
    }
  );
  var browserChoiceSpec = (ui) => {
    if (!ui.choices || !ui.location || !ui.messages.idPattern || !ui.messages.outgoing) {
      throw failure("answer-choice-required");
    }
    return {
      choices: ui.choices,
      location: ui.location,
      messages: ui.messages,
      composer: ui.composer,
      ...ui.textReply ? { textReply: ui.textReply } : {},
      ...ui.noticeContext ? { noticeContext: ui.noticeContext } : {}
    };
  };
  var evaluate = (commander, input) => commander.evaluate({ fn: browserChoicePage, args: [input] });
  var readBrowserHistory = async (commander, ui, target) => {
    const value = await evaluate(commander, {
      spec: browserChoiceSpec(ui),
      operation: "history"
    });
    if (value.code || value.chat !== String(target)) {
      throw failure(value.code ?? "answer-chat-unverified");
    }
    return value.messages;
  };

  // js/src/sources/browser-conversation-history.js
  var stopped = (historyReason) => {
    throw Object.assign(new Error("Conversation history traversal stopped"), {
      historyReason
    });
  };
  var checkpointHistory = async ({ onHistoryWindow }, chat, rows, check) => {
    if (!onHistoryWindow) {
      return;
    }
    try {
      await onHistoryWindow({ chat: String(chat), rows });
    } catch {
      stopped("history-save-failed");
    }
    await check();
  };
  var mergeConversationWindow = (known, incoming) => {
    if (!known.length) {
      return incoming.slice();
    }
    const positions = new Map(known.map((row, index) => [row.id, index]));
    const shared = incoming.findIndex((row) => positions.has(row.id));
    if (shared < 0) {
      stopped("history-gap");
    }
    const offset = positions.get(incoming[shared].id);
    if (shared > 0 && offset !== 0) {
      stopped("history-gap");
    }
    for (let index = shared; index < incoming.length; index++) {
      if (JSON.stringify(incoming[index]) !== JSON.stringify(known[offset + index - shared])) {
        stopped("conversation-changed");
      }
    }
    return [...incoming.slice(0, shared), ...known];
  };
  var releaseBrowserConversation = async (control, pause, waitMs, verifyCurrent) => {
    let restored = false;
    let restore;
    try {
      await verifyCurrent?.();
      restore = (await control("status")).state === "ready";
      if (restore) {
        await control("restore", { restore: true });
        for (let remaining = 2e3; ; remaining -= waitMs) {
          await pause(waitMs);
          await verifyCurrent?.();
          const state = await control("status");
          restore = state.state === "ready" && !state.scrollPending;
          if (state.state !== "ready" || !state.scrollPending || remaining <= 0) {
            break;
          }
        }
      }
    } catch {
      restore = false;
    }
    try {
      restored = Boolean((await control("release", { restore })).restored);
    } catch {
    }
    return restored;
  };
  var conversationTracker = (settings, ui, now) => {
    let rows = [];
    let passes = 0;
    let previous;
    let stableSince;
    return {
      get passes() {
        return passes;
      },
      loading() {
        passes++;
      },
      accept(found, state) {
        const merged = mergeConversationWindow(rows, found);
        if (merged.length > settings.limit || merged.reduce((sum, row) => sum + row.body.length, 0) > 1e6) {
          stopped("history-limit");
        }
        rows = merged;
        passes++;
        if (state.oldest && !state.loading && rows[0]?.service && ui.historyScan?.startAtService) {
          return "provider-start";
        }
        const signature = JSON.stringify([state.top, state.height, found]);
        if (state.oldest && !state.loading && signature === previous) {
          stableSince ??= now();
          if (now() - stableSince >= settings.endWaitMs) {
            return "rendered-start";
          }
        } else {
          stableSince = void 0;
        }
        previous = signature;
        return null;
      },
      result(reason, restored) {
        return {
          rows,
          coverage: {
            complete: reason === "provider-start",
            scope: "conversation",
            reason,
            passes
          },
          restored
        };
      }
    };
  };
  var scanBrowserConversation = async (document2, ui, target, options = {}, { now = () => globalThis.performance.now(), pause = setTimeout2, readNewest } = {}) => {
    const settings = normalizeChatScanOptions(options);
    const { control } = createBrowserScanControl(document2, {
      item: ui.messages.item,
      idAttribute: ui.messages.idAttribute,
      composer: ui.composer,
      scope: "history",
      inactiveToken: options.inactiveToken
    });
    const started = now();
    const observed = conversationTracker(settings, ui, now);
    let reason = "pass-limit";
    let restored;
    let newestRead = false;
    const check = async (operation = "status", extra) => {
      if (options.signal?.aborted) {
        stopped("cancelled");
      }
      if (now() - started >= settings.budgetMs) {
        stopped("time-limit");
      }
      await options.verifyCurrent?.();
      const state = await control(operation, extra);
      if (state.state !== "ready") {
        stopped(state.state);
      }
      return state;
    };
    try {
      await check("open");
      while (observed.passes < settings.maxPasses) {
        await pause(settings.waitMs);
        if ((await check()).loading) {
          observed.loading();
          continue;
        }
        const found = (await readBrowserHistory(document2, ui, target)).map(
          ({ strictOptions: _strict, answerOptions: _options, ...row }) => row
        );
        const state = await check();
        if (!newestRead) {
          await readNewest?.();
          newestRead = true;
          await check();
        }
        const completed = observed.accept(found, state);
        await checkpointHistory(options, target, found, check);
        if (completed) {
          reason = completed;
          break;
        }
        await check("move", {
          top: state.top - Math.max(1, Math.floor(state.view * 0.7))
        });
      }
    } catch (error) {
      reason = error.historyReason ?? (error.code === "answer-chat-unverified" ? "document-changed" : "read-failed");
    } finally {
      restored = await releaseBrowserConversation(
        control,
        pause,
        settings.waitMs,
        options.verifyRestore ?? options.verifyCurrent
      );
    }
    const result = observed.result(reason, restored);
    if (process.env.MS_BROWSER_HISTORY_DEBUG === "1") {
      console.error("[browser-conversation-history]", {
        ...result.coverage,
        rows: result.rows.length,
        restored
      });
    }
    return result;
  };
  return __toCommonJS(stdin_exports);
})();

  const fixtures = {"ordinary":"<!doctype html><html lang=\"en\">\n<meta charset=\"utf-8\"><title>Conversation history · isolated fixture</title><style>\nbody{font:16px system-ui;margin:24px;background:#eef2f7;color:#172333}#history{height:220px;width:650px;overflow-y:auto;overflow-anchor:none;background:white;border:1px solid #adb9c9;}#rows{height:1200px;width:100%;position:relative;flex-shrink:0}article{box-sizing:border-box;position:absolute;height:100px;width:100%;padding:12px;border-bottom:1px solid #ddd}p{margin:5px 0}.outgoing{background:#e3f7ea}textarea{width:640px;height:65px;margin-top:12px}pre{white-space:pre-wrap;max-width:760px}\n</style><nav data-qa=\"mainmenu_applicantProfile\">Synthetic applicant profile</nav>\n<h1>Conversation with an earlier manual reply</h1><p>12 records, overlapping mounted windows. Ordinary scroll pane. No real account or messages.</p>\n<div id=\"history\"><div id=\"rows\"></div></div>\n<textarea data-qa=\"text-input\">Owner unfinished draft</textarea><pre id=\"result\">Only the current window is mounted.</pre>\n<script>\nconst ids=[13,8,92,4,73,2,61,9,47,3,38,1], reversed=false, marker=true;\nconst history=document.querySelector('#history'),rows=document.querySelector('#rows'),composer=document.querySelector('textarea');\nconst records=ids.map((id,index)=>({id,index,body:index===0?'':index===2?'I already replied manually.':index===11?'Thank you, we selected another candidate.':'Conversation record '+index,outgoing:index===2}));\nwindow.fixture={records,reads:0,clicks:0,sends:0,jump:false,render};\nfunction render(){const position=reversed?1200-history.clientHeight+history.scrollTop:history.scrollTop;const first=window.fixture.jump?0:Math.max(0,Math.floor(position/100)),last=Math.min(12,first+4);rows.innerHTML=records.slice(first,last).map(record=>'<article class=\"'+(record.outgoing?'outgoing':'')+'\" style=\"top:'+(record.index*100)+'px\" data-qa=\"chatik-chat-message-'+record.id+'\" data-time=\"2026-11-11T10:00:00Z\">'+(record.index===0&&marker?'<strong data-qa=\"chat-bubble-title\">Vacancy application</strong>':'')+'<p data-qa=\"chat-bubble-text\">'+record.body+'</p>'+(record.outgoing?'<span data-qa=\"status-icon-delivered\">Sent</span>':'')+'</article>').join('');}\nhistory.addEventListener('scroll',render);history.scrollTop=reversed?-300:300;render();composer.setSelectionRange(6,16);\n</script></html>","reversed":"<!doctype html><html lang=\"en\">\n<meta charset=\"utf-8\"><title>Conversation history · isolated fixture</title><style>\nbody{font:16px system-ui;margin:24px;background:#eef2f7;color:#172333}#history{height:220px;width:650px;overflow-y:auto;overflow-anchor:none;background:white;border:1px solid #adb9c9;display:flex;flex-direction:column-reverse;}#rows{height:1200px;width:100%;position:relative;flex-shrink:0}article{box-sizing:border-box;position:absolute;height:100px;width:100%;padding:12px;border-bottom:1px solid #ddd}p{margin:5px 0}.outgoing{background:#e3f7ea}textarea{width:640px;height:65px;margin-top:12px}pre{white-space:pre-wrap;max-width:760px}\n</style><nav data-qa=\"mainmenu_applicantProfile\">Synthetic applicant profile</nav>\n<h1>Conversation with an earlier manual reply</h1><p>12 records, overlapping mounted windows. Reversed scroll pane. No real account or messages.</p>\n<div id=\"history\"><div id=\"rows\"></div></div>\n<textarea data-qa=\"text-input\">Owner unfinished draft</textarea><pre id=\"result\">Only the current window is mounted.</pre>\n<script>\nconst ids=[13,8,92,4,73,2,61,9,47,3,38,1], reversed=true, marker=true;\nconst history=document.querySelector('#history'),rows=document.querySelector('#rows'),composer=document.querySelector('textarea');\nconst records=ids.map((id,index)=>({id,index,body:index===0?'':index===2?'I already replied manually.':index===11?'Thank you, we selected another candidate.':'Conversation record '+index,outgoing:index===2}));\nwindow.fixture={records,reads:0,clicks:0,sends:0,jump:false,render};\nfunction render(){const position=reversed?1200-history.clientHeight+history.scrollTop:history.scrollTop;const first=window.fixture.jump?0:Math.max(0,Math.floor(position/100)),last=Math.min(12,first+4);rows.innerHTML=records.slice(first,last).map(record=>'<article class=\"'+(record.outgoing?'outgoing':'')+'\" style=\"top:'+(record.index*100)+'px\" data-qa=\"chatik-chat-message-'+record.id+'\" data-time=\"2026-11-11T10:00:00Z\">'+(record.index===0&&marker?'<strong data-qa=\"chat-bubble-title\">Vacancy application</strong>':'')+'<p data-qa=\"chat-bubble-text\">'+record.body+'</p>'+(record.outgoing?'<span data-qa=\"status-icon-delivered\">Sent</span>':'')+'</article>').join('');}\nhistory.addEventListener('scroll',render);history.scrollTop=reversed?-300:300;render();composer.setSelectionRange(6,16);\n</script></html>","stalled":"<!doctype html><html lang=\"en\">\n<meta charset=\"utf-8\"><title>Conversation history · isolated fixture</title><style>\nbody{font:16px system-ui;margin:24px;background:#eef2f7;color:#172333}#history{height:220px;width:650px;overflow-y:auto;overflow-anchor:none;background:white;border:1px solid #adb9c9;}#rows{height:1200px;width:100%;position:relative;flex-shrink:0}article{box-sizing:border-box;position:absolute;height:100px;width:100%;padding:12px;border-bottom:1px solid #ddd}p{margin:5px 0}.outgoing{background:#e3f7ea}textarea{width:640px;height:65px;margin-top:12px}pre{white-space:pre-wrap;max-width:760px}\n</style><nav data-qa=\"mainmenu_applicantProfile\">Synthetic applicant profile</nav>\n<h1>Conversation with an earlier manual reply</h1><p>12 records, overlapping mounted windows. Ordinary scroll pane. No real account or messages.</p>\n<div id=\"history\"><div id=\"rows\"></div></div>\n<textarea data-qa=\"text-input\">Owner unfinished draft</textarea><pre id=\"result\">Only the current window is mounted.</pre>\n<script>\nconst ids=[13,8,92,4,73,2,61,9,47,3,38,1], reversed=false, marker=false;\nconst history=document.querySelector('#history'),rows=document.querySelector('#rows'),composer=document.querySelector('textarea');\nconst records=ids.map((id,index)=>({id,index,body:index===0?'':index===2?'I already replied manually.':index===11?'Thank you, we selected another candidate.':'Conversation record '+index,outgoing:index===2}));\nwindow.fixture={records,reads:0,clicks:0,sends:0,jump:false,render};\nfunction render(){const position=reversed?1200-history.clientHeight+history.scrollTop:history.scrollTop;const first=window.fixture.jump?0:Math.max(0,Math.floor(position/100)),last=Math.min(12,first+4);rows.innerHTML=records.slice(first,last).map(record=>'<article class=\"'+(record.outgoing?'outgoing':'')+'\" style=\"top:'+(record.index*100)+'px\" data-qa=\"chatik-chat-message-'+record.id+'\" data-time=\"2026-11-11T10:00:00Z\">'+(record.index===0&&marker?'<strong data-qa=\"chat-bubble-title\">Vacancy application</strong>':'')+'<p data-qa=\"chat-bubble-text\">'+record.body+'</p>'+(record.outgoing?'<span data-qa=\"status-icon-delivered\">Sent</span>':'')+'</article>').join('');}\nhistory.addEventListener('scroll',render);history.scrollTop=reversed?-300:300;render();composer.setSelectionRange(6,16);\n</script></html>"};
  const expected = ["13","8","92","4","73","2","61","9","47","3","38","1"];
  const ui = {"id":"hh","name":"HeadHunter","loginUrl":"https://hh.ru/account/login","listUrl":"https://hh.ru/chat","loggedIn":"[data-qa^=\"chatik-chat-message-\"], textarea[data-qa=\"text-input\"], iframe[src^=\"https://chatik.hh.ru/\"], [data-qa=\"mainmenu_applicantProfile\"]","loggedOut":"[data-qa=\"account-login-submit\"], form[action*=\"account/login\"]","composer":"textarea[data-qa=\"text-input\"]","location":{"origins":["https://hh.ru","https://www.hh.ru","https://chatik.hh.ru"],"pathPattern":"^/chat/(\\d{1,30})/?$"},"documents":{"ownerOrigins":["https://hh.ru","https://www.hh.ru","https://chatik.hh.ru"],"ancestorOrigins":["https://hh.ru","https://www.hh.ru","https://chatik.hh.ru"],"maxFrames":32},"chatScan":{"pathPattern":"^/chat/?$","unreadFilter":{"control":"label:has(input[data-qa=\"chatik-checkbox-only-unread\"]) input[type=\"checkbox\"]:not([data-qa])","fallback":"input[data-qa=\"chatik-checkbox-only-unread\"]"}},"historyScan":{"startAtService":true},"chatNavigation":{"sameDocument":true},"noticeContext":{"company":"[data-qa=\"participant-info-title\"]","vacancy":"[data-qa=\"chatik-header-sub-header\"]","link":"[data-qa=\"chatik-header-sub-header\"] a[href*=\"/vacancy/\"]"},"textReply":{"send":"button[data-qa*=\"send\"]","closedText":"работодатель отключил переписку|переписка будет доступна после приглашения|(?:chat|conversation) (?:is |has been )?closed|(?:messaging|correspondence) (?:is |has been )?disabled"},"choices":{"group":"[class*=\"buttons-wrapper\"], [class*=\"reply-options\"], [data-qa*=\"answer-options\"], [data-qa*=\"question-options\"]","attachedButtons":true,"genericGroup":"[class*=\"buttons-wrapper\"]:not([class*=\"reply-options\"]):not([data-qa*=\"answer-options\"]):not([data-qa*=\"question-options\"])","genericPattern":"^(?:здравствуйте|какая схема оплаты|где находится место работы|можно без опыта|какой график работы|могу работать в гибком графике|у меня есть профильный опыт|hello|नमस्ते|你好)[.!?]*$","button":"button, [role=\"button\"], [role=\"option\"]"},"messages":{"item":"[data-qa^=\"chatik-chat-message-\"]","idAttribute":"data-qa","idPattern":"^chatik-chat-message-(\\d+)$","body":"[data-qa=\"chat-bubble-text\"]","outgoing":"[data-qa=\"status-icon-delivered\"], [data-qa=\"status-icon-read\"], [data-qa=\"status-icon-sent\"]","timestampAttribute":"data-time","serviceTitle":"[data-qa=\"chat-bubble-title\"], [data-qa=\"chat-bubble-author-name\"]","serviceTitlePattern":"^(?:отклик на вакансию|vacancy application|(?:application for|response to) (?:the|a) vacancy|bewerbung)$"},"chats":{"item":"[data-qa^=\"chatik-open-chat-\"], a[href^=\"/chat/\"]","idAttribute":"data-qa","idPattern":"^chatik-open-chat-(\\d{1,30})$","requireId":true,"uniqueIds":true,"link":"a[href^=\"/chat/\"]","linkPattern":"^/chat/(\\d{1,30})(?:[/?#]|$)","title":"[data-qa=\"chat-cell-title\"], [data-qa=\"chat-title\"]","preview":"[class*=\"last-message-color_\"], [data-qa=\"chat-last-message\"]","unread":"[data-qa=\"chat-unread-count\"], [data-qa*=\"badge\"], [data-qa*=\"counter\"]"},"actions":{}};
  const errors=[]; page.on('pageerror',error=>errors.push(error.message));
  await page.route('**/*', route => route.fulfill({contentType:'text/html',body:fixtures[new URL(route.request().url()).searchParams.get('fixture')??'ordinary']}));
  const document = {evaluate:({fn,args})=>page.evaluate(fn,args[0])};
  const options={waitMs:30,endWaitMs:100,budgetMs:5000};
  const dependencies={now:()=>Date.now(),pause:ms=>page.waitForTimeout(ms)};
  const snapshot=()=>page.evaluate(()=>{const root=document.querySelector('#history'),composer=document.querySelector('textarea');return {top:root.scrollTop,draft:composer.value,selection:[composer.selectionStart,composer.selectionEnd],live:Boolean(window[Symbol.for('meta-sovereign.browser-conversation-history.v1')]),clicks:window.fixture.clicks,sends:window.fixture.sends};});
  const outcomes=[];
  if (true) {
    await page.goto('https://hh.ru/chat/7?fixture=ordinary');
    const before=await snapshot();
    const saved=new Map();
    let windows=0;
    const captured=await conversationContract.scanBrowserConversation(document,ui,'7',{
      ...options,
      onHistoryWindow:async ({chat,rows})=>{
        if(chat!=='7'||!rows.length) throw new Error('Invalid checkpoint identity');
        const mounted=await page.locator('#history article').evaluateAll(nodes=>nodes.map(node=>node.dataset.qa.replace('chatik-chat-message-','')));
        if(!rows.every(row=>mounted.includes(row.id))) throw new Error('Window moved before acknowledgement');
        await page.waitForTimeout(10);
        for(const row of rows) saved.set(row.id,row);
        windows++;
      },
    },dependencies);
    if(!captured.coverage.complete||windows<2||saved.size!==expected.length||!expected.every(id=>saved.has(id))||JSON.stringify(before)!==JSON.stringify(await snapshot())) throw new Error('Acknowledged windows or owner restoration missing');
    let refused=0;
    const stopped=await conversationContract.scanBrowserConversation(document,ui,'7',{
      ...options,
      onHistoryWindow:async()=>{refused++;throw new Error('Private refused checkpoint');},
    },dependencies);
    if(refused!==1||stopped.coverage.reason!=='history-save-failed'||stopped.coverage.complete||!stopped.restored||JSON.stringify(before)!==JSON.stringify(await snapshot())||errors.length) throw new Error('Refused checkpoint did not stop and restore');
    return {cases:2,windows,uniqueMessages:saved.size,acknowledgementBeforeMove:true,refusedWriteStopped:true,ownerRestored:true,errors,liveProvider:false};
  }
  for(const name of ['ordinary','reversed','stalled']){
    await page.goto('https://hh.ru/chat/7?fixture='+name);
    const before=await snapshot();
    if(name!=='stalled') await page.screenshot({path:'docs/screenshots/issue-56-conversation-history/mcp-'+name+'-before.png',fullPage:true});
    const result=await conversationContract.scanBrowserConversation(document,ui,'7',options,dependencies);
    const after=await snapshot();
    if(JSON.stringify(result.rows.map(row=>row.id))!==JSON.stringify(expected)||JSON.stringify(before)!==JSON.stringify(after)||!result.restored||result.coverage.complete!==(name!=='stalled')||!result.rows[2].outgoing) throw new Error('History coverage or owner preservation failed: '+name);
    await page.locator('#result').evaluate((node,result)=>{node.textContent=JSON.stringify({rows:result.rows.map(row=>row.id),manualReplyFound:result.rows[2].outgoing,...result.coverage,restored:result.restored},null,2);},result);
    if(name!=='stalled') await page.screenshot({path:'docs/screenshots/issue-56-conversation-history/mcp-'+name+'-after.png',fullPage:true});
    outcomes.push({name,coverage:result.coverage,restored:result.restored,owner:after});
  }
  await page.goto('https://hh.ru/chat/7?fixture=ordinary');
  let changed=false;
  const result=await conversationContract.scanBrowserConversation(document,ui,'7',options,{now:()=>Date.now(),pause:async ms=>{await page.waitForTimeout(ms);if(!changed){changed=true;await page.locator('textarea').fill('New owner draft');}}});
  const owner=await snapshot();
  if(result.coverage.reason!=='owner-active'||result.restored||result.rows.length||owner.draft!=='New owner draft'||owner.live||owner.clicks||owner.sends||errors.length) throw new Error('Owner interruption or browser error');
  await page.screenshot({path:'docs/screenshots/issue-56-conversation-history/mcp-owner-after.png',fullPage:true});
  outcomes.push({name:'owner-input',coverage:result.coverage,restored:result.restored,owner});
  return {outcomes,errors,liveProvider:false};
}