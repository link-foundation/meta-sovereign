async (page) => (async (page, fixture, check) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      language
    );
    await page.goto(`${fixture.base}/?vkLocale=${language}#conn-vk/manual`);
    const panel = page.locator(`[data-${fixture.feature}]`);
    const ready = () =>
      page.waitForFunction((feature) => {
        const input = document.querySelector(
          `[data-${feature}] input[type=checkbox]`
        );
        return input && !input.disabled;
      }, fixture.feature);
    // A mounted heading and an enabled control distinguish loading from absence.
    await panel
      .getByRole('heading', { name: words.title, exact: true })
      .waitFor();
    await ready();
    for (const key of fixture.keys) {
      if (!(await panel.innerText()).includes(words[key])) {
        throw Error(`Missing ${language}.${key}`);
      }
    }
    const { focus, ...checked } = await check(page, {
      panel,
      words,
      ready,
      feature: fixture.feature,
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await panel.locator(focus).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-${fixture.feature}/mcp-${language}-phone.png`,
    });
    result.push({ language, translated: true, ...checked });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:34315","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","feature":"vk-friends","keys":["hint","enabled","priorityIds","plan","run"],"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"VK friend requests","hint":"Preview priority accounts first, then incoming requests ranked by mutual friends. Confirming a plan may send priority requests or accept incoming ones. Automatic runs start off. Saved user token required; no messages are sent.","enabled":"Run this saved policy automatically","priorityIds":"Priority user IDs, separated by commas","plan":"Prepare review","run":"Confirm reviewed friend actions"},"ru":{"title":"Заявки в друзья ВКонтакте","hint":"Сначала просматриваются приоритетные аккаунты, затем входящие заявки по числу общих друзей. Подтверждение может отправить приоритетные заявки или принять входящие. Автозапуск изначально выключен. Нужен сохранённый токен пользователя; сообщения не отправляются.","enabled":"Автоматически выполнять сохранённые правила","priorityIds":"ID приоритетных пользователей через запятую","plan":"Подготовить просмотр","run":"Подтвердить просмотренные действия"},"hi":{"title":"VK मित्र अनुरोध","hint":"पहले प्राथमिक खातों की समीक्षा करें, फिर साझा मित्रों के क्रम में आने वाले अनुरोधों की। पुष्टि से प्राथमिक अनुरोध भेजे या आने वाले स्वीकार किए जा सकते हैं। स्वचालित चलना शुरू में बंद है। सहेजा उपयोगकर्ता टोकन चाहिए; संदेश नहीं भेजे जाते।","enabled":"सहेजी नीति अपने आप चलाएँ","priorityIds":"प्राथमिक उपयोगकर्ता ID, अल्पविराम से अलग","plan":"समीक्षा तैयार करें","run":"समीक्षित मित्र कार्रवाइयों की पुष्टि करें"},"zh":{"title":"VK 好友请求","hint":"先审核优先账户，再按共同好友排序审核收到的请求。确认计划可能发送优先请求或接受收到的请求。自动运行默认关闭。需要已保存的用户令牌；不会发送消息。","enabled":"自动运行已保存的规则","priorityIds":"优先用户 ID，以逗号分隔","plan":"准备审核","run":"确认已审核的好友操作"}}}, (async (page, { panel, ready }) => {
  const enabled = panel.locator('[data-action=vk-friends-enabled]');
  const previous = await enabled.isChecked();
  await enabled.click();
  await ready();
  const priority = panel.locator('[data-friend-field=priorityIds]');
  const target = Number((await priority.inputValue()) || 99) + 1;
  await priority.fill(String(target));
  await panel.locator('[data-friend-field=maxFriends]').fill('2');
  await panel.locator('[data-friend-field=batchSize]').fill('1');
  await panel.locator('[data-action=vk-friends-save]').click();
  await ready();
  await panel.locator('[data-action=vk-friends-plan]').click();
  await ready();
  await panel.locator('[data-vk-friends-plan=review]').waitFor();
  await panel
    .locator(`[data-friend-id="${target}"][data-friend-reason=eligible]`)
    .waitFor();
  await panel.locator('[data-action=vk-friends-run]').click();
  await ready();
  await panel.locator('[data-vk-friends-status=confirmed]').waitFor();
  await page.reload();
  await ready();
  if (
    (await enabled.isChecked()) === previous ||
    (await priority.inputValue()) !== String(target)
  ) {
    throw Error('Acknowledged policy lost');
  }
  await panel.locator('[data-vk-friends-status=confirmed]').waitFor();
  return {
    focus: '[data-vk-friends-status]',
    reviewed: true,
    acknowledged: true,
    savedChoiceRetained: true,
  };
}))