async (page) => {
  const assert = { equal(a, b) { if (a !== b) throw new Error('Browser assertion failed'); } };
  const translate = (_locale, key) => ({"questions.sharedLoad":"Load profiles","questions.sharedSelect":"Linked profile","questions.shared.id":"Profile identifier","questions.salaryEnabled":"Use configured salary targets","questions.salaryApproved":"Approve complete salary answers for automatic sending","questions.salaryHours":"Work hours per month (empty disables hourly answers)","questions.salaryAdd":"Add salary currency","questions.salaryCode":"Currency code, e.g. USD","questions.salaryKeywords":"Currency words, comma-separated","questions.salary.net":"Monthly net amount","questions.salary.gross":"Monthly gross amount","questions.salaryDefault":"Default salary currency"})[key];
  const applicationAnswerSalary = {"enabled":true,"approved":true,"exchangeMode":"snapshot","defaultCurrency":"RUB","defaultBasis":"net","monthlyHours":160,"currencies":[{"code":"USD","keywords":["USD"],"net":6200,"gross":7400},{"code":"RUB","keywords":["RUB"],"net":450000,"gross":530000}]};
  const applicationPanelBrowser = (fixture) => {
  const { page } = fixture;
  page.setDefaultTimeout(10000);
  const panel = page.locator('[data-application-panel]');
  const action = (name) => panel.locator(`[data-application-action="${name}"]`);
  const confirm = () =>
    panel.locator('[data-application-option="confirm"]').check();
  return {
    page,
    panel,
    action,
    confirm,
    batch() {
      const batch = panel.locator('[data-application-batch]');
      return {
        batch,
        field: (name) =>
          batch.locator(`[data-application-batch-field="${name}"]`),
        button: (name) =>
          batch.locator(`[data-application-batch-action="${name}"]`),
        phase: (name) =>
          batch
            .locator(`[data-application-batch-phase="${name}"]`)
            .waitFor({ timeout: 60000 }),
      };
    },
    screenshot(directory, prefix) {
      return async (name) => {
        if (directory) {
          await mkdir(directory, { recursive: true });
          await panel.screenshot({
            path: join(directory, `${prefix}-${name}.png`),
          });
        }
      };
    },
    async locales(selector, verify = async () => {}) {
      for (const locale of ['ru', 'hi', 'zh', 'en']) {
        await page.evaluate(
          (value) =>
            globalThis.localStorage.setItem('metaSovereignLocale', value),
          locale
        );
        await page.reload();
        await panel.locator(selector).waitFor();
        assert.equal(
          /\bapplication\.[a-z]/iu.test(await panel.innerText()),
          false
        );
        await verify(locale);
      }
    },
    async phone() {
      await page.setViewportSize({ width: 390, height: 1440 });
      assert.equal(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= globalThis.innerWidth
        ),
        true
      );
    },
    async close(owned) {
      await action('close').click();
      await panel.locator('[data-application-state="closed"]').waitFor();
      assert(owned.isClosed());
      assert(fixture.records.every((record) => record.closed));
      assert.deepEqual(fixture.errors, []);
    },
    async confirmed(name) {
      await confirm();
      await action(name).click();
      // Completion includes the new receipt and its renewed owner confirmation.
      await page.waitForFunction(
        () =>
          !document.querySelector('[data-application-option="confirm"]')
            .checked &&
          !document.querySelector('[data-application-action="read"]').disabled
      );
    },
    async select() {
      await page.goto(`${fixture.base}/#/cv`);
      const vacancies = page.locator('[data-vacancies]');
      await vacancies.locator('[data-vacancy-field="query"]').fill('Python');
      await vacancies.locator('[data-vacancy-action="search"]').click();
      await vacancies
        .locator('[data-vacancy-action="collect"]')
        .first()
        .click();
      await panel.locator('[data-application-missing]').waitFor();
      const languagePolicy = panel.locator(
        '[data-application-option="autoSelectResumeLanguage"]'
      );
      if (await languagePolicy.count()) {
        await languagePolicy.uncheck();
      }
      return vacancies;
    },
  };
};
  const configureApplicationAnswerContext = async (panel) => {
  const t = (key) => translate('en', key);
  const context = panel.locator('[data-application-answer-context]');
  const profile = context.locator('[data-shared-profile]');
  await profile.locator(':scope > summary').click();
  await profile
    .getByRole('button', { name: t('questions.sharedLoad'), exact: true })
    .click();
  await profile
    .getByLabel(t('questions.sharedSelect'), { exact: true })
    .selectOption('qa-profile:questionnaire');
  await profile
    .getByLabel(t('questions.shared.id'), { exact: true })
    .filter({ visible: true })
    .waitFor();
  await profile.locator(':scope > summary').click();
  const salary = context.locator('[data-answer-salary]');
  await salary.locator(':scope > summary').click();
  await salary
    .getByLabel(t('questions.salaryEnabled'), { exact: true })
    .check();
  await salary
    .getByLabel(t('questions.salaryApproved'), { exact: true })
    .check();
  await salary
    .getByLabel(t('questions.salaryHours'), { exact: true })
    .fill('160');
  for (const [
    index,
    currency,
  ] of applicationAnswerSalary.currencies.entries()) {
    if (index) {
      await salary
        .getByRole('button', { name: t('questions.salaryAdd'), exact: true })
        .click();
    }
    const row = salary.locator('[data-salary-currency]').nth(index);
    for (const [key, value] of Object.entries({
      Code: currency.code,
      Keywords: currency.keywords.join(', '),
    })) {
      await row
        .getByLabel(t(`questions.salary${key}`), { exact: true })
        .fill(value);
    }
    for (const key of ['net', 'gross']) {
      await row
        .getByLabel(t(`questions.salary.${key}`), { exact: true })
        .fill(String(currency[key]));
    }
  }
  await salary
    .getByLabel(t('questions.salaryDefault'), { exact: true })
    .selectOption('RUB');
  await salary.locator(':scope > summary').click();
};
  return (async (page, makeControls) => {
  const url = new URL(page.url());
  const before = url.searchParams.get('phase') === 'before';
  const stats = url.searchParams.get('stats');
  if (!stats) throw new Error('Supply the owned fixture stats URL.');
  const errors = [];
  page.on('pageerror', (error) => errors.push(String(error)));
  await page.addInitScript(() => {
    if (!localStorage.getItem('context-evidence-initialized')) {
      localStorage.setItem('metaSovereignTutorial', '{"off":true,"v":5}');
      localStorage.setItem('metaSovereignLocale', 'en');
      localStorage.removeItem('meta-sovereign:hh-application-intent');
      localStorage.setItem('context-evidence-initialized', '1');
    }
  });
  await page.setViewportSize({ width: 1200, height: 1050 });
  const controls = makeControls({ page, base: url.origin });
  const { panel, action } = controls;
  await controls.select();
  await panel.locator('[data-application-option="autoSelectResumeLanguage"]').check();
  await panel.locator('[data-application-option="supervised"]').check();
  await action('start').click();
  await panel.locator('[data-application-state="ready"]').waitFor();
  await controls.confirm();
  const pending = page.waitForResponse((response) => response.url().endsWith('/application-advance'));
  await action('enter').click();
  const response = await pending;
  const body = await response.text();
  if (before) {
    if (response.ok() || !body.includes('jobs-application-resume-context')) throw new Error(body);
    await panel.getByText(/jobs-application-unconfirmed/).waitFor();
  } else {
    if (!response.ok()) throw new Error(body);
    try {
      await panel.locator('[data-application-resume-preference="automatic"]').waitFor();
    } catch (error) {
      throw new Error(JSON.stringify({ error: String(error), body, panel: await panel.innerText() }));
    }
    if (!await action('submit').isDisabled()) throw new Error('Send lacks a fresh confirmation.');
  }
  await panel.screenshot({ path: "/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459/docs/screenshots/issue-56-ci-application-context/" + 'context-' + (before ? 'before' : 'after') + '.png' });
  if (!before) {
    await controls.locales('[data-application-resume-preference="automatic"]', async (locale) => {
      if (await page.evaluate(() => localStorage.getItem('metaSovereignLocale')) !== locale) {
        throw new Error('Reload replaced the chosen locale.');
      }
    });
    await controls.phone();
    await panel.screenshot({ path: "/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459/docs/screenshots/issue-56-ci-application-context/" + 'context-phone.png' });
  }
  if (before) {
    await action('recover').click();
    await panel.locator('[data-application-state="review"]').waitFor();
  }
  await action('close').click();
  await panel.locator('[data-application-state="closed"]').waitFor();
  const native = await (await page.request.get(stats)).json();
  if (!native.closed || native.errors.length || errors.length) throw new Error(JSON.stringify({ native, errors }));
  return { before, native, errors, responseStatus: response.status(), automaticChoice: !before,
    locales: before ? 0 : 4, phoneOverflow: false, liveProvider: false };
})(page, applicationPanelBrowser, configureApplicationAnswerContext);
}