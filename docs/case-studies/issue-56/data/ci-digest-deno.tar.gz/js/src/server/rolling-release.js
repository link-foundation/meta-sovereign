// Immutable package snapshots: the old worker never imports files being edited
// or replaced by an installer while its replacement prepares.
import path from 'node:path';
import { promises as fs } from 'node:fs';
import { createHash, randomBytes } from 'node:crypto';
import { fileURLToPath } from 'node:url';

export const PACKAGE_ROOT = fileURLToPath(
  new URL('../../../', import.meta.url)
);
export const rollingDirectory = (storeDir) => path.join(storeDir, 'runtime');
const releaseDirectory = (storeDir) =>
  path.join(rollingDirectory(storeDir), 'releases');
const namesIn = async (root, relative) => {
  const entries = await fs.readdir(path.join(root, relative), {
    withFileTypes: true,
  });
  const all = await Promise.all(
    entries.map((entry) =>
      entry.isDirectory()
        ? namesIn(root, path.join(relative, entry.name))
        : [path.join(relative, entry.name)]
    )
  );
  return all.flat();
};
const runtimeFiles = async (root) => {
  const files = [
    ...(await namesIn(root, 'js/src')),
    ...(await namesIn(root, 'js/bin')),
    'package.json',
  ];
  for (const file of ['package-lock.json', 'bun.lock', 'deno.lock']) {
    if (await fs.stat(path.join(root, file)).catch(() => null)) {
      files.push(file);
    }
  }
  return files.sort();
};
const digest = async (root, names) => {
  const hash = createHash('sha256');
  // Bound both filesystem admission and retained buffers. Hash in manifest
  // order so existing releases keep exactly the same content identity.
  for (let offset = 0; offset < names.length; offset += 4) {
    const batch = names.slice(offset, offset + 4);
    const reads = await Promise.allSettled(
      batch.map((name) => fs.readFile(path.join(root, name)))
    );
    const failure = reads.find((read) => read.status === 'rejected');
    if (failure) {
      // No read may outlive a failed snapshot's cleanup.
      throw failure.reason;
    }
    for (const [index, read] of reads.entries()) {
      hash.update(batch[index]);
      hash.update('\0');
      hash.update(read.value);
      hash.update('\0');
    }
  }
  return hash.digest('hex');
};
const copySnapshot = async (sourceRoot, temp, files, trace) => {
  const directories = new Set(
    files.map((name) => path.dirname(name)).filter((name) => name !== '.')
  );
  for (const directory of directories) {
    await fs.mkdir(path.join(temp, directory), {
      recursive: true,
      mode: 0o700,
    });
  }
  trace('directories_ready');
  // Refill each of four slots independently so a slow copy cannot idle the
  // others. Stop admitting files on failure, but drain every issued copy
  // before cleanup can remove its destination.
  let next = 0;
  let completed = 0;
  const progressEvery = Math.max(1, Math.ceil(files.length / 8));
  let failed = false;
  let failure;
  const copy = async () => {
    while (!failed && next < files.length) {
      const name = files[next++];
      try {
        await fs.copyFile(path.join(sourceRoot, name), path.join(temp, name));
        completed += 1;
        if (completed % progressEvery === 0 || completed === files.length) {
          // At most eight content-free checkpoints distinguish a cold copy
          // backlog from one outstanding operation. Tracing stays opt-in.
          trace(`copy_progress ${completed}/${files.length}`);
        }
      } catch (error) {
        if (!failed) {
          failed = true;
          failure = error;
        }
      }
    }
  };
  await Promise.all(Array.from({ length: Math.min(4, files.length) }, copy));
  if (failed) {
    throw failure;
  }
};
const dependencyDirectory = async (sourceRoot) => {
  for (let root = sourceRoot; ; root = path.dirname(root)) {
    const modules = path.join(root, 'node_modules');
    if (
      await fs.stat(path.join(modules, 'lino-objects-codec')).catch(() => null)
    ) {
      return fs.realpath(modules);
    }
    if (path.dirname(root) === root) {
      throw new Error('cannot locate the installed runtime dependencies');
    }
  }
};

export const verifyRelease = async (storeDir, release) => {
  if (!/^[a-f0-9]{64}$/.test(release?.build ?? '')) {
    throw new Error('invalid server release');
  }
  const root = path.join(releaseDirectory(storeDir), release.build);
  if (
    path.resolve(release.entry) !== path.join(root, 'js/bin/server-worker.js')
  ) {
    throw new Error('invalid release entry');
  }
  const manifest = JSON.parse(
    await fs.readFile(path.join(root, 'release.json'), 'utf8')
  );
  if (
    !Array.isArray(manifest.files) ||
    manifest.files.some(
      (name) =>
        typeof name !== 'string' ||
        path.isAbsolute(name) ||
        name.split(/[\\/]/).includes('..')
    )
  ) {
    throw new Error('invalid release manifest');
  }
  if ((await digest(root, manifest.files)) !== release.build) {
    throw new Error('the prepared server release changed');
  }
  return release;
};

export const stageServerRelease = async ({
  storeDir,
  sourceRoot = PACKAGE_ROOT,
}) => {
  const startedAt = Date.now();
  const files = await runtimeFiles(sourceRoot);
  const trace = (stage) => {
    if (process.env.MS_LIFECYCLE_DEBUG === '1') {
      console.error(
        `[release] ${stage} after ${Date.now() - startedAt} ms (${files.length} files)`
      );
    }
  };
  trace('enumerated');
  const build = await digest(sourceRoot, files);
  trace('hashed');
  const root = path.join(releaseDirectory(storeDir), build);
  const release = { build, entry: path.join(root, 'js/bin/server-worker.js') };
  if (await fs.stat(root).catch(() => null)) {
    const verified = await verifyRelease(storeDir, release);
    trace('existing_verified');
    return verified;
  }
  const temp = `${root}.preparing-${process.pid}-${randomBytes(4).toString('hex')}`;
  await fs.mkdir(temp, { recursive: true, mode: 0o700 });
  try {
    await copySnapshot(sourceRoot, temp, files, trace);
    trace('snapshot_copied');
    if ((await digest(temp, files)) !== build) {
      throw new Error(
        'server files changed while preparing the release; retry with the current version'
      );
    }
    trace('snapshot_verified');
    await fs.symlink(
      await dependencyDirectory(sourceRoot),
      path.join(temp, 'node_modules'),
      process.platform === 'win32' ? 'junction' : 'dir'
    );
    await fs.writeFile(
      path.join(temp, 'release.json'),
      JSON.stringify({ build, files }),
      { mode: 0o600 }
    );
    await fs.rename(temp, root).catch(async (error) => {
      if (!['EEXIST', 'ENOTEMPTY'].includes(error.code)) {
        throw error;
      }
      await verifyRelease(storeDir, release);
    });
    trace('snapshot_ready');
    return release;
  } finally {
    await fs.rm(temp, { recursive: true, force: true });
  }
};
