/**
 * Real-browser tutorial walk-through.
 *
 * Checks what a user actually sees and does, in Chromium and WebKit
 * (Safari's engine) at desktop, short-desktop, tablet and phone sizes:
 *
 *   - every step's card is inside the viewport and never overlaps the
 *     control it points at (so that control stays clickable/visible);
 *   - clicking the highlighted control advances the tour: Connections
 *     → the whole section lit (sign-ins and every service, each
 *     reachable past the card) → Email (first: biggest service) → its
 *     "Enter manually" steps and "Import with browser" panel;
 *   - "Next" on an action step performs the click (the app follows);
 *   - Back goes back, Esc closes; the card takes focus once the user
 *     is in the tour (not on page load: the skip link stays first);
 *   - after the nav drawer scrolls, ring and card are still on the
 *     target in the very same frame (no trailing outline);
 *   - every step is shown on its own page: after a reload (the app
 *     reopens on Chat), after Back across pages, after leaving mid-step
 *     ("Show me"), and when another service than Email is picked.
 *
 * Playwright and its browsers are optional dependencies, so this is
 * not part of `npm test`. Run it explicitly:
 *
 *   RUN_BROWSER_E2E=1 npm run test:e2e:tutorial
 *
 * WebKit is used when installed (`npx playwright install webkit`).
 * Without `RUN_BROWSER_E2E=1`, or without Playwright, it exits 0 with
 * a skip message.
 */

import { promises as fs } from 'node:fs';
import os from 'node:os';
import path from 'node:path';

import { startServer } from '../src/server/index.js';

const skip = (message) => {
  console.log(`[e2e-tutorial-browser] SKIP: ${message}`);
  process.exit(0);
};

if (process.env.RUN_BROWSER_E2E !== '1') {
  skip('set RUN_BROWSER_E2E=1 to run');
}

let playwright;
try {
  playwright = await import('playwright');
} catch {
  skip('playwright is not installed');
}

const VIEWPORTS = [
  { name: 'desktop', width: 1440, height: 900 },
  { name: 'short-desktop', width: 1280, height: 560 },
  { name: 'tablet', width: 800, height: 900 },
  { name: 'phone', width: 390, height: 844 },
].filter(
  (viewport) =>
    !process.env.E2E_VIEWPORTS ||
    process.env.E2E_VIEWPORTS.split(',').includes(viewport.name)
);
if (VIEWPORTS.length === 0) {
  throw new Error(
    `No tutorial viewport matches E2E_VIEWPORTS=${process.env.E2E_VIEWPORTS}`
  );
}

const screenshot = async (page, label) => {
  const dir = process.env.E2E_ARTIFACT_DIR || 'artifacts/browser';
  await fs.mkdir(dir, { recursive: true });
  await page.screenshot({
    path: path.join(dir, `tutorial-${label.replaceAll('/', '-')}.png`),
  });
};

// Owned, empty fixtures only. Keep input/transition tracing opt-in.
const traceTutorial = async (page) => {
  if (process.env.CI_TUTORIAL_DEBUG !== '1') {
    return;
  }
  page.on('framenavigated', (frame) => {
    if (frame === page.mainFrame()) {
      console.log(`[tutorial-navigation] ${frame.url()}`);
    }
  });
  page.on('request', (request) => {
    if (request.isNavigationRequest() && request.frame() === page.mainFrame()) {
      console.log(`[tutorial-document-request] ${request.url()}`);
    }
  });
  page.on('crash', () => console.log('[tutorial-crash]'));
  page.on('console', (message) => {
    if (/^\[(tutorial-|ms-debug)/.test(message.text())) {
      console.log(message.text());
    }
  });
  await page.addInitScript(() => {
    globalThis.metaSovereignDebug = true;
    console.log('[tutorial-document]', globalThis.performance.timeOrigin);
    globalThis.addEventListener('beforeunload', () => {
      console.log('[tutorial-unload]', globalThis.location.href);
    });
    const fetch = globalThis.fetch.bind(globalThis);
    globalThis.fetch = async (...args) => {
      const response = await fetch(...args);
      const url = String(args[0]);
      if (url.includes('probe=1') || url.includes('app.min.js')) {
        console.log(
          '[tutorial-fetch]',
          url,
          response.status,
          response.headers.get('etag')
        );
      }
      return response;
    };
    globalThis.__tutorialEvents = [];
    let previous;
    new globalThis.MutationObserver(() => {
      const step = document.querySelector('[data-tutorial-step]')?.dataset
        .tutorialStep;
      if (step !== previous) {
        previous = step;
        globalThis.__tutorialEvents.push({
          type: 'step',
          step,
          at: Math.round(globalThis.performance.now()),
        });
        console.log('[tutorial-transition]', step ?? 'absent');
      }
    }).observe(document, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ['data-tutorial-step'],
    });
    for (const type of ['pointerdown', 'pointerup', 'click', 'keydown']) {
      document.addEventListener(
        type,
        (event) => {
          const target = event.target?.closest?.(
            '[data-action], [data-tutorial-id]'
          );
          globalThis.__tutorialEvents.push({
            type,
            action: target?.getAttribute('data-action'),
            target: target?.getAttribute('data-tutorial-id'),
            key: type === 'keydown' ? event.key : undefined,
            step: document.querySelector('[data-tutorial-step]')?.dataset
              .tutorialStep,
            at: Math.round(globalThis.performance.now()),
          });
          if (globalThis.__tutorialEvents.length > 100) {
            globalThis.__tutorialEvents.shift();
          }
        },
        true
      );
    }
  });
};

const createPage = async (browser, viewport) => {
  const page = await browser.newPage({ viewport });
  await traceTutorial(page);
  page.setDefaultTimeout(10_000);
  return page;
};

const failures = [];
const check = (ok, label) => {
  if (!ok) {
    failures.push(label);
    console.log(`  ✗ ${label}`);
  }
};

// What CI needs to see when a step fails (R-Z21): Playwright's call
// log (why a click never completed: covered, unstable, off screen),
// the element at the middle of the lit target (tag and class only, no
// page text) and the frame time (a starved renderer shows here).
const failureReport = async (page, error, where) => {
  const ansi = new RegExp(`${String.fromCharCode(27)}\\[[0-9;]*m`, 'g');
  const lines = String(error.message).replace(ansi, '').split('\n');
  const log = lines.indexOf('Call log:');
  const calls = log < 0 ? [] : lines.slice(log + 1, log + 16);
  const probe = await page
    .evaluate(async () => {
      const id = document
        .querySelector('[data-tutorial-overlay]')
        ?.getAttribute('data-tutorial-target');
      const target = id
        ? [...document.querySelectorAll(`[data-tutorial-id="${id}"]`)].find(
            (el) => el.getBoundingClientRect().width > 0
          )
        : null;
      const r = target?.getBoundingClientRect();
      const x = r ? r.left + r.width / 2 : null;
      const y = r
        ? Math.min(
            Math.max(r.top + r.height / 2, 1),
            globalThis.innerHeight - 1
          )
        : null;
      const hit = r ? document.elementFromPoint(x, y) : null;
      const start = globalThis.performance.now();
      for (let i = 0; i < 10; i += 1) {
        await new Promise((done) => globalThis.requestAnimationFrame(done));
      }
      return {
        target: id,
        at: r ? [Math.round(x), Math.round(y)] : null,
        hit: hit ? `${hit.tagName.toLowerCase()}.${hit.className}` : null,
        frameMs: Math.round((globalThis.performance.now() - start) / 10),
        scrollY: Math.round(globalThis.scrollY),
        preference: globalThis.localStorage.getItem('metaSovereignTutorial'),
        events: globalThis.__tutorialEvents,
      };
    })
    .catch((e) => ({ probeFailed: e.message.split('\n')[0] }));
  return [
    `${lines[0]} ${where}`,
    ...calls.map((line) => `      ${line.trim()}`),
    `      probe ${JSON.stringify(probe)}`,
  ].join('\n');
};

const geometry = (page) =>
  page.evaluate(() => {
    const card = document.querySelector('.tutorial-step');
    const overlay = document.querySelector('[data-tutorial-overlay]');
    const id = overlay?.getAttribute('data-tutorial-target');
    const target = id
      ? [...document.querySelectorAll(`[data-tutorial-id="${id}"]`)].find(
          (el) => el.getBoundingClientRect().width > 0
        )
      : null;
    const box = (el) => {
      const r = el.getBoundingClientRect();
      return { top: r.top, left: r.left, width: r.width, height: r.height };
    };
    return {
      step: card?.getAttribute('data-tutorial-step') ?? null,
      side: card?.getAttribute('data-side') ?? null,
      focused: document.activeElement === card,
      card: card ? box(card) : null,
      target: target ? box(target) : null,
      targetId: target ? id : null,
      scrollY: globalThis.scrollY,
      viewport: {
        width: globalThis.innerWidth,
        height: globalThis.innerHeight,
      },
    };
  });

const overlaps = (a, b) =>
  a.left < b.left + b.width - 0.5 &&
  b.left < a.left + a.width - 0.5 &&
  a.top < b.top + b.height - 0.5 &&
  b.top < a.top + a.height - 0.5;

// The part of a rect that is on the screen.
const visiblePart = (r, viewport) => {
  const top = Math.max(r.top, 0);
  const left = Math.max(r.left, 0);
  return {
    top,
    left,
    width: Math.min(r.left + r.width, viewport.width) - left,
    height: Math.min(r.top + r.height, viewport.height) - top,
  };
};

// The click lands on the control, not on the card in front of it.
const assertClickable = async (page, label, selector) => {
  const read = () =>
    page.evaluate((sel) => {
      const el = document.querySelector(sel);
      const r = el?.getBoundingClientRect();
      if (!r) {
        return { found: false };
      }
      const card = document.querySelector('.tutorial-step');
      const c = card.getBoundingClientRect();
      const top = document.elementFromPoint(
        r.left + r.width / 2,
        Math.min(Math.max(r.top + r.height / 2, 1), globalThis.innerHeight - 1)
      );
      const round = (n) => Math.round(n);
      return {
        found: true,
        onCard: Boolean(top?.closest('.tutorial-step')),
        offScreen: r.bottom > globalThis.innerHeight || r.top < 0,
        control: [r.top, r.height].map(round),
        card: [c.top, c.height].map(round),
        compact: card.dataset.compact ?? null,
        viewportHeight: globalThis.innerHeight,
        scrollY: round(globalThis.scrollY),
      };
    }, selector);
  // The card may still be settling (it checks again after layout).
  let hit = await read();
  for (
    let i = 0;
    i < 12 && (!hit.found || hit.onCard || hit.offScreen);
    i += 1
  ) {
    await page.waitForTimeout(250);
    hit = await read();
  }
  check(
    hit.found && !hit.onCard && !hit.offScreen,
    `${label}: ${selector} is under the card or off screen ${JSON.stringify(hit)}`
  );
};

const stepOf = (page) =>
  page
    .locator('[data-tutorial-step]')
    .first()
    .getAttribute('data-tutorial-step')
    .catch(() => null);

const waitForStep = (page, id) =>
  page.waitForSelector(`[data-tutorial-step="${id}"]`, { timeout: 5000 });

// Visible, and settled into its final place (the card is hidden while
// it waits for its target and while it is first measured).
const settle = async (page) => {
  await page.waitForFunction(() => {
    const card = document.querySelector('.tutorial-step');
    return card && globalThis.getComputedStyle(card).visibility !== 'hidden';
  });
  await page.waitForTimeout(250);
};

const assertPlacement = async (page, label, { focus = true } = {}) => {
  const g = await geometry(page);
  const where = `${label} [${g.step}, side=${g.side}]`;
  check(Boolean(g.card), `${where}: card rendered`);
  if (!g.card) {
    console.log(
      await failureReport(page, new Error('Tutorial card disappeared'), where)
    );
    await screenshot(page, label);
    return g;
  }
  const { card, viewport } = g;
  if (g.step === 'backup' && process.env.E2E_ARTIFACT_DIR) {
    await screenshot(page, `${label}-rendered`);
  }
  check(
    card.left >= 0 &&
      card.top >= 0 &&
      card.left + card.width <= viewport.width + 0.5 &&
      card.top + card.height <= viewport.height + 0.5,
    `${where}: card inside viewport ${JSON.stringify(card)} target ${JSON.stringify(g.target)} scrollY ${g.scrollY}`
  );
  if (g.target) {
    // The card never covers what it asks the user to click (R-Z22),
    // docked or not. A target taller than the room beside the card (the
    // whole services grid) is read from its top, so its first
    // screenful - the part the user starts with - must be clear.
    const seen = visiblePart(g.target, viewport);
    const room = viewport.height - card.height - 2 * 12;
    const probe =
      g.target.height > room
        ? { ...seen, height: Math.min(seen.height, 40) }
        : seen;
    if (overlaps(card, probe)) {
      await screenshot(page, `${label}-${g.step}-overlap`);
      if (process.env.CI_TUTORIAL_DEBUG === '1') {
        console.log(
          '[tutorial-overlap]',
          await page.locator('.tutorial-step').evaluate((node) => ({
            size: [node.offsetWidth, node.offsetHeight],
            style: node.getAttribute('style'),
            compact: node.dataset.compact,
          }))
        );
      }
    }
    check(
      !overlaps(card, probe),
      `${where}: card ${JSON.stringify(card)} covers target ${JSON.stringify(g.target)}`
    );
  }
  if (focus) {
    check(g.focused, `${where}: card has focus`);
  }
  return g;
};

// The whole Connections section is lit: sign-ins and every service.
// However the card is placed, each of them can be scrolled clear of it
// and clicked (the last service included).
const assertSectionReachable = async (page, label) => {
  const lit = await page.evaluate(() => {
    const section = document.querySelector(
      '[data-tutorial-id="connections:list"]'
    );
    return {
      signIns: Boolean(
        section?.querySelector('[data-tutorial-id="connections:sign-ins"]')
      ),
      services: section?.querySelectorAll('[data-provider-id]').length ?? 0,
    };
  });
  check(
    lit.signIns && lit.services > 10,
    `${label}: pick must light sign-ins and all services ${JSON.stringify(lit)}`
  );
  const last = await page.evaluate(() => {
    globalThis.scrollTo(0, document.documentElement.scrollHeight);
    const cards = document.querySelectorAll(
      '[data-tutorial-id="connections:list"] [data-provider-id]'
    );
    const r = cards[cards.length - 1].getBoundingClientRect();
    const c = document.querySelector('.tutorial-step').getBoundingClientRect();
    const covered =
      r.left < c.right &&
      c.left < r.right &&
      r.top < c.bottom &&
      c.top < r.bottom;
    return { covered, card: c.top, service: r.bottom };
  });
  check(
    !last.covered,
    `${label}: the last service stays under the card ${JSON.stringify(last)}`
  );
  await page.evaluate(() => globalThis.scrollTo(0, 0));
  await page.waitForTimeout(150);
};

// While the page scrolls the card never jumps: beside a target on the
// page it keeps its distance to it (both scroll together), pinned to
// the screen it does not move at all; the ring stays 6px outside the
// target. Read synchronously after each scroll, as the next frame
// paints it.
const assertSteadyOnScroll = async (page, label) => {
  const drift = await page.evaluate(async () => {
    const card = document.querySelector('.tutorial-step');
    const ring = document.querySelector('.tutorial-spotlight-frame');
    const overlay = document.querySelector('[data-tutorial-overlay]');
    const id = overlay.getAttribute('data-tutorial-target');
    const target = document.querySelector(`[data-tutorial-id="${id}"]`);
    const read = () => {
      const t = target.getBoundingClientRect().top;
      return {
        card: card.getBoundingClientRect().top,
        toTarget: card.getBoundingClientRect().top - t,
        ring: ring.getBoundingClientRect().top - t,
      };
    };
    const follow = card.dataset.follow;
    const first = read();
    let worst = 0;
    let ringWorst = 0;
    for (let i = 0; i < 8; i += 1) {
      globalThis.scrollBy(0, 40);
      const now = read();
      const moved =
        follow === 'page'
          ? Math.abs(now.toTarget - first.toTarget)
          : Math.abs(now.card - first.card);
      worst = Math.max(worst, moved);
      ringWorst = Math.max(ringWorst, Math.abs(now.ring + 6));
    }
    globalThis.scrollTo(0, 0);
    return { follow, worst, ringWorst, scrolled: globalThis.scrollY };
  });
  check(
    drift.worst < 1 && drift.ringWorst < 1,
    `${label}: card or ring moves while the page scrolls ${JSON.stringify(drift)}`
  );
  await page.waitForTimeout(250);
};

// The whole provider page is lit: Back, both tabs and the open panel,
// and the tabs are never under the card (the step tells the user to
// switch between them).
const assertDetailLit = async (page, label, mode) => {
  const lit = await page.evaluate(() => {
    const section = document.querySelector(
      '[data-tutorial-id="connections:detail"]'
    );
    const card = document.querySelector('.tutorial-step');
    const c = card?.getBoundingClientRect();
    const covered = (el) => {
      const r = el.getBoundingClientRect();
      return Boolean(
        c &&
        r.left < c.right &&
        c.left < r.right &&
        r.top < c.bottom &&
        c.top < r.bottom
      );
    };
    const tabs = [...(section?.querySelectorAll('[role="tab"]') ?? [])];
    return {
      mode: section?.getAttribute('data-mode') ?? null,
      back: Boolean(section?.querySelector('.connections-back')),
      tabs: tabs.length,
      tabsCovered: tabs.some(covered),
    };
  });
  check(
    lit.mode === mode && lit.back && lit.tabs === 2 && !lit.tabsCovered,
    `${label}: setup lights the whole ${mode} page ${JSON.stringify(lit)}`
  );
};

// Pick Email by "Enter manually" (the recommended "Import with
// browser" would open a real browser window).
const pickEmailManually = async (page, label) => {
  await page.click(
    '[data-tutorial-id="connections:email"] [data-action="open-connection-detail"]'
  );
  await waitForStep(page, 'setup');
  await settle(page);
  const manual = await assertPlacement(page, label);
  check(
    manual.targetId === 'connections:detail',
    `${label}: setup on "Enter manually" points at ${manual.targetId}`
  );
  await assertDetailLit(page, label, 'manual');
  // The user's own click on the tab takes focus there, as it should.
  await page.click('[data-action="connection-mode-import"]');
  await settle(page);
  const setup = await assertPlacement(page, label, { focus: false });
  check(
    setup.targetId === 'connections:detail',
    `${label}: setup on "Import with browser" points at ${setup.targetId}`
  );
  await assertDetailLit(page, label, 'import');
  check(
    (await placeOf(page)).hash === '#conn-email',
    `${label}: the import tab is #conn-email`
  );
};

// Linux fonts are taller than the ones the layout was tuned on, so the
// card grows. Simulate that on any machine (R-Z22): bigger text and
// looser lines in the card, which must still never cover its target.
const makeCardTall = async (page, tall) =>
  tall &&
  page.addInitScript(() => {
    const style = document.createElement('style');
    style.textContent =
      '.tutorial-step{font-size:1.6em !important;line-height:2.3 !important}';
    document.addEventListener('DOMContentLoaded', () =>
      document.head.append(style)
    );
  });

// The "pick a service" step lights the whole services section and the
// first service stays clickable in front of the card.
const assertPickStep = async (page, label) => {
  const pick = await assertPlacement(page, label);
  check(
    pick.targetId === 'connections:list',
    `${label}: pick lights ${pick.targetId}, not the whole section`
  );
  await assertClickable(
    page,
    label,
    '[data-tutorial-id="connections:email"] [data-action="open-connection-detail"]'
  );
  await assertSteadyOnScroll(page, label);
  await assertSectionReachable(page, label);
};

const walk = async (engineName, viewport, base, tall) => {
  const browser = await playwright[engineName].launch();
  const page = await createPage(browser, viewport);
  await makeCardTall(page, tall);
  // A click that cannot complete fails in 10 s, not 30 (R-Z21).
  const label = [engineName, viewport.name, tall && 'tall-card']
    .filter(Boolean)
    .join('/');
  console.log(`- ${label}`);
  try {
    await page.goto(base, { waitUntil: 'domcontentloaded' });
    await page.evaluate(() => globalThis.localStorage.clear());
    await page.reload({ waitUntil: 'domcontentloaded' });

    await waitForStep(page, 'connect');
    await settle(page);
    // Opened by itself on load: focus stays put, the skip link is
    // still the first Tab stop.
    await assertPlacement(page, `${label}/connect`, { focus: false });
    // (WebKit, like Safari by default, skips links on Tab.)
    if (engineName === 'chromium') {
      await page.keyboard.press('Tab');
      const first = await page.evaluate(
        () => globalThis.document.activeElement?.className ?? ''
      );
      check(
        String(first).includes('skip-link'),
        `${label}: first Tab stop is "${first}", not the skip link`
      );
    }

    // The user does what the step says: click Connections.
    await page.click('[data-tutorial-id="nav:connections"] >> visible=true');
    await waitForStep(page, 'pick');
    await settle(page);
    await assertPlacement(page, `${label}/pick`);
    const first = await page.evaluate(
      () =>
        document
          .querySelector('[data-provider-id]')
          ?.getAttribute('data-provider-id') ?? null
    );
    check(first === 'email', `${label}: first service is ${first}, not email`);

    // Back returns to the previous step; Next on it performs the click.
    await page.click('[data-action="tutorial-back"]');
    await waitForStep(page, 'connect');
    await page.click('[data-action="tutorial-next"]');
    await waitForStep(page, 'pick');
    await settle(page);
    await assertPickStep(page, label);

    await pickEmailManually(page, label);

    // Contacts, then Chat (version 5); "open a chat" only with contacts.
    for (const id of ['contacts', 'chat', 'automation', 'backup']) {
      if (process.env.CI_TUTORIAL_DEBUG === '1') {
        console.log(`[tutorial-next] ${await stepOf(page)} -> ${id}`);
      }
      await page.click('[data-action="tutorial-next"]');
      // "open a chat" passes by itself while there are no contacts.
      if (id === 'chat') {
        const shown = await page
          .waitForSelector('[data-tutorial-step="chat"]', { timeout: 2000 })
          .catch(() => null);
        if (!shown && (await stepOf(page)) === 'contacts-open') {
          await page.click('[data-action="tutorial-next"]');
        }
      }
      await waitForStep(page, id);
      await settle(page);
      await assertPlacement(page, `${label}/${id}`);
    }

    // Short desktop: the drawer scrolls; ring and card must follow in
    // the same frame.
    if (viewport.name === 'short-desktop') {
      // Back to the start.
      for (let i = 0; i < 12; i += 1) {
        if ((await geometry(page)).step === 'connect') {
          break;
        }
        await page
          .click('[data-action="tutorial-back"]', { timeout: 1500 })
          .catch(() => {});
      }
      await waitForStep(page, 'connect');
      await settle(page);
      const drift = await page.evaluate(() => {
        const nav = document.querySelector('nav.permanent-drawer');
        const target = document.querySelector(
          '[data-tutorial-id="nav:connections"]'
        );
        const ring = document.querySelector('.tutorial-spotlight-frame');
        const card = document.querySelector('.tutorial-step');
        const offset = () => {
          const t = target.getBoundingClientRect();
          return {
            ring: ring.getBoundingClientRect().top - t.top,
            card: card.getBoundingClientRect().top - t.top,
          };
        };
        nav.scrollTop = 0;
        const before = offset();
        nav.scrollTop = nav.scrollHeight;
        const after = offset();
        return {
          scrolled: nav.scrollTop,
          anchors: globalThis.CSS.supports('anchor-name: --a'),
          ring: Math.abs(after.ring - before.ring),
          card: Math.abs(after.card - before.card),
        };
      });
      // Chromium applies anchor scroll adjustment on the compositor, so
      // only engines that report it synchronously are asserted.
      if (engineName === 'webkit' && drift.anchors && drift.scrolled > 0) {
        check(
          drift.ring < 1,
          `${label}: ring trails scroll by ${drift.ring}px`
        );
      }
      console.log(`  scroll drift ${JSON.stringify(drift)}`);
    }

    await page.keyboard.press('Escape');
    await page.waitForSelector('[data-tutorial-overlay]', {
      state: 'detached',
      timeout: 3000,
    });
  } catch (error) {
    const at = await geometry(page).catch(() => ({}));
    const message = await failureReport(
      page,
      error,
      `(on step ${at.step}, side=${at.side})`
    );
    failures.push(`${label}: ${message}`);
    console.log(`  ✗ ${message}`);
    await screenshot(page, label).catch(() => {});
  } finally {
    await browser.close();
  }
};

// Edge cases around pages: reloads (the app always reopens on Chat),
// leaving mid-step, Back across pages, and picking another service.
const placeOf = (page) =>
  page.evaluate(() => ({
    view:
      document.querySelector('main[data-view]')?.getAttribute('data-view') ??
      null,
    hash: globalThis.location.hash,
    step:
      document
        .querySelector('.tutorial-step')
        ?.getAttribute('data-tutorial-step') ?? null,
    next:
      document
        .querySelector('[data-action="tutorial-next"]')
        ?.textContent.trim() ?? null,
  }));

const waitForPlace = (page, view, detail) =>
  page.waitForFunction(
    ([v, d]) => {
      const main = document.querySelector('main[data-view]');
      const onDetail = globalThis.location.hash.startsWith('#conn-');
      return main?.getAttribute('data-view') === v && onDetail === d;
    },
    [view, detail],
    { timeout: 5000 }
  );

const edgeCases = async (engineName, viewport, base) => {
  const browser = await playwright[engineName].launch();
  const page = await createPage(browser, viewport);
  const label = `${engineName}/${viewport.name}/pages`;
  console.log(`- ${label}`);
  const at = async (step, view, detail, what) => {
    await waitForStep(page, step);
    await waitForPlace(page, view, detail);
    await settle(page);
    const g = await assertPlacement(page, `${label} ${what}`, {
      focus: false,
    });
    check(g.target !== null, `${label} ${what}: target on screen`);
  };
  try {
    await page.goto(base, { waitUntil: 'domcontentloaded' });
    await page.evaluate(() => globalThis.localStorage.clear());
    await page.reload({ waitUntil: 'domcontentloaded' });
    await waitForStep(page, 'connect');
    await page.click('[data-action="tutorial-next"]');
    await at('pick', 'connections', false, 'pick');

    // 1. Reload on "pick": the app opens on Chat, the tour reopens
    //    Connections and points at Email again.
    await page.reload({ waitUntil: 'domcontentloaded' });
    await at('pick', 'connections', false, 'pick after reload');

    // 2. The user leaves mid-step: the tour stays put, Next becomes
    //    "Show me" and brings them back.
    await page.click('[data-tutorial-id="nav:chat"] >> visible=true');
    await waitForPlace(page, 'chat', false);
    await page.waitForFunction(
      () =>
        document.querySelector('[data-action="tutorial-next"]')?.textContent ===
        'Show me',
      undefined,
      { timeout: 5000 }
    );
    check(
      (await placeOf(page)).step === 'pick',
      `${label}: leaving the page must not advance the tour`
    );
    await page.click('[data-action="tutorial-next"]');
    await at('pick', 'connections', false, 'pick after "Show me"');
    check(
      (await placeOf(page)).next === 'Next',
      `${label}: "Show me" turns back into Next`
    );

    // 3. Another service's "Enter manually": the tour follows that
    //    page and tab.
    await page.click(
      '[data-tutorial-id="connections:telegram"] [data-action="open-connection-detail"]'
    );
    await at('setup', 'connections', true, 'setup on Telegram');
    check(
      (await placeOf(page)).hash === '#conn-telegram/manual',
      `${label}: setup must stay on the chosen service`
    );

    // 4. Back from the provider page: "pick" is on the list, and being
    //    on a provider page a moment ago does not skip it forward.
    await page.click('[data-action="tutorial-back"]');
    await at('pick', 'connections', false, 'pick after Back');
    await page.waitForTimeout(400);
    check(
      (await placeOf(page)).step === 'pick',
      `${label}: Back to "pick" must stay on "pick"`
    );

    // 5. Next reopens the service the user picked (Telegram, on the
    //    same tab), never Email — exactly one step forward.
    await page.click('[data-action="tutorial-next"]');
    await at('setup', 'connections', true, 'setup back on Telegram');
    await page.waitForTimeout(400);
    check(
      (await placeOf(page)).step === 'setup',
      `${label}: one Next must move exactly one step`
    );
    check(
      (await placeOf(page)).hash === '#conn-telegram/manual',
      `${label}: Next after Back must reopen Telegram, not Email`
    );

    // 5b. The app's own "Back to services", then "Show me": Telegram.
    await page.click('[data-action="back-to-connections"]');
    await waitForPlace(page, 'connections', false);
    await page.click('[data-action="tutorial-next"]');
    await at('setup', 'connections', true, '"Show me" back on Telegram');
    check(
      (await placeOf(page)).hash === '#conn-telegram/manual',
      `${label}: "Show me" must reopen Telegram, not Email`
    );

    // 5c. Back to services and reload: still Telegram.
    await page.click('[data-action="back-to-connections"]');
    await waitForPlace(page, 'connections', false);
    await page.reload({ waitUntil: 'domcontentloaded' });
    await at('setup', 'connections', true, 'reload back on Telegram');
    check(
      (await placeOf(page)).hash === '#conn-telegram/manual',
      `${label}: a reload must reopen Telegram, not Email`
    );

    // 6. Reload on "setup": a provider page is reopened.
    await page.reload({ waitUntil: 'domcontentloaded' });
    await at('setup', 'connections', true, 'setup after reload');

    // 7. On to Contacts and past it later in the tour, then Back again
    //    onto "setup": the provider page opens again.
    await page.click('[data-action="tutorial-next"]');
    await waitForStep(page, 'contacts');
    await page.click('[data-tutorial-id="nav:contacts"] >> visible=true');
    await page.waitForSelector(
      '[data-tutorial-step="contacts-open"], [data-tutorial-step="chat"]',
      { timeout: 5000 }
    );
    for (let i = 0; i < 4 && (await stepOf(page)) !== 'setup'; i += 1) {
      await page.click('[data-action="tutorial-back"]');
      await page.waitForTimeout(300);
    }
    await at('setup', 'connections', true, 'setup via Back from Contacts');
  } catch (error) {
    const where = await placeOf(page).catch(() => ({}));
    const message = await failureReport(
      page,
      error,
      `(at ${JSON.stringify(where)})`
    );
    failures.push(`${label}: ${message}`);
    console.log(`  ✗ ${message}`);
    await screenshot(page, label).catch(() => {});
  } finally {
    await browser.close();
  }
};

const engines = [];
for (const name of (process.env.E2E_ENGINES ?? 'chromium,webkit').split(',')) {
  try {
    const browser = await playwright[name].launch();
    await browser.close();
    engines.push(name);
  } catch {
    console.log(`[e2e-tutorial-browser] ${name} not installed, skipped`);
  }
}
if (engines.length === 0) {
  skip('no Playwright browser is installed');
}

const storeDir = await fs.mkdtemp(path.join(os.tmpdir(), 'ms-tutorial-e2e-'));
const handle = await startServer({
  localUi: true,
  port: 0,
  storeDir,
  enableSync: false,
});
const base = `http://127.0.0.1:${handle.port}/`;
try {
  for (const engineName of engines) {
    for (const viewport of VIEWPORTS) {
      await walk(engineName, viewport, base);
      await walk(engineName, viewport, base, true);
    }
    for (const viewport of VIEWPORTS.filter((v) =>
      ['desktop', 'phone'].includes(v.name)
    )) {
      await edgeCases(engineName, viewport, base);
    }
  }
} finally {
  await handle.close();
}

if (failures.length > 0) {
  console.log(`[e2e-tutorial-browser] ${failures.length} failure(s)`);
  process.exit(1);
}
console.log('[e2e-tutorial-browser] all checks passed');
