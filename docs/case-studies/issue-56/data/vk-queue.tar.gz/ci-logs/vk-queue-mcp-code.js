async (page) => {
  const session = await page.context().newCDPSession(page);
  const consoleErrors = [];
  const requestFailures = [];
  page.on('console', (entry) => { if (entry.type() === 'error') consoleErrors.push(entry.text()); });
  page.on('requestfailed', (request) => requestFailures.push({ url: request.url(), error: request.failure()?.errorText }));
  try {
    await session.send('Network.enable');
    await session.send('Network.setCacheDisabled', { cacheDisabled: true });
    return { ...await (async (page) => (async (page, fixture, check) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      language
    );
    await page.goto(`${fixture.base}/?vkLocale=${language}#conn-vk/manual`);
    const panel = page.locator(`[data-${fixture.feature}]`);
    const ready = () =>
      page.waitForFunction((feature) => {
        const input = document.querySelector(feature);
        return input && !input.disabled;
      }, `[data-${fixture.feature}] ${fixture.readySelector}`);
    // A mounted heading and an enabled control distinguish loading from absence.
    await panel
      .getByRole('heading', { name: words.title, exact: true })
      .waitFor();
    await ready();
    for (const key of fixture.keys) {
      if (!(await panel.innerText()).includes(words[key])) {
        throw Error(`Missing ${language}.${key}`);
      }
    }
    const { focus, ...checked } = await check(page, {
      panel,
      words,
      ready,
      feature: fixture.feature,
      fixture,
      action: async (name) => {
        await panel.locator(`[data-action=${fixture.feature}-${name}]`).click();
        await ready();
      },
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await panel.locator(focus).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-${fixture.evidenceName}/mcp-${language}-phone.png`,
    });
    result.push({ language, translated: true, ...checked });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:38251","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","feature":"vk-send-queue","evidenceName":"vk-queue","readySelector":"input[type=checkbox]","keys":["hint","speed","save"],"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"VK automated message queue","hint":"Pace reviewed automated messages in order. Text waits 10–14 seconds plus typing time; stickers wait 6–8 seconds without typing. Read receipts apply only to the incoming message being answered. Saving settings does not send or resume messages. Delivery is shown separately from queue progress.","speed":"Typing speed (characters per minute)","save":"Save speed"},"ru":{"title":"Очередь автоматических сообщений ВКонтакте","hint":"Отправлять проверенные автоматические сообщения по порядку. Текст ждёт 10–14 секунд плюс время набора; стикеры — 6–8 секунд без набора. Прочтение относится только к входящему сообщению, на которое даётся ответ. Сохранение настроек не отправляет и не возобновляет сообщения. Доставка показана отдельно от состояния очереди.","speed":"Скорость набора (символов в минуту)","save":"Сохранить скорость"},"hi":{"title":"VK स्वचालित संदेश कतार","hint":"समीक्षा किए स्वचालित संदेश क्रम से भेजें। पाठ के लिए 10–14 सेकंड और टाइपिंग समय; स्टिकर के लिए बिना टाइपिंग 6–8 सेकंड रुकें। पठन रसीद केवल उत्तर दिए जा रहे आने वाले संदेश पर लागू होती है। सेटिंग सहेजने से संदेश भेजे या फिर शुरू नहीं होते। डिलीवरी कतार की प्रगति से अलग दिखती है।","speed":"टाइपिंग गति (वर्ण प्रति मिनट)","save":"गति सहेजें"},"zh":{"title":"VK 自动消息队列","hint":"按顺序发送已审核的自动消息。文本等待 10–14 秒加上输入时间；贴纸等待 6–8 秒且不显示输入状态。已读回执仅适用于正在回复的收到消息。保存设置不会发送或恢复消息。投递状态与队列进度分开显示。","speed":"输入速度（每分钟字符数）","save":"保存速度"}}}, (async (page, { panel, ready, words }) => {
  const speed = panel.locator('[data-action=vk-queue-speed]');
  await speed.fill('750');
  await panel.getByRole('button', { name: words.save, exact: true }).click();
  await ready();
  await page.reload();
  await ready();
  if ((await speed.inputValue()) !== '750') {
    throw Error('Speed did not survive reload');
  }
  await panel.locator('details').evaluateAll((nodes) =>
    nodes.forEach((node) => {
      node.open = true;
    })
  );
  if ((await panel.locator('[data-vk-queue-receipt]').count()) !== 1) {
    throw Error('Missing queue receipt');
  }
  const text = await panel.innerText();
  if (text.includes('vkQueue.')) {
    throw Error('Untranslated queue state');
  }
  return {
    focus: '[data-vk-queue-receipt]',
    retainedSettings: true,
    providerFreeInspection: true,
  };
})))(page), consoleErrors, requestFailures };
  } finally {
    await session.detach();
  }
}