export const ruApplication = {
  'application.title': 'Проверка отклика в HH',
  'application.hint':
    'Проверьте полную вакансию и ответы. Вход в отклик может сразу отправить его. Для отправки нужно ваше подтверждение; доставка подтверждается только сигналом HH.',
  'application.settings': 'Настройки отклика',
  'application.coverLetter':
    'Проверенное сопроводительное письмо (до 24 000 знаков)',
  'application.autoExact':
    'После заполнения отправлять автоматически, только если все ответы точные и проверены',
  'application.delay': 'Пауза перед автоматической отправкой (0–30 000 мс)',
  'application.testMode':
    'Только просмотр: ответы и действия отклика не отправляются',
  'application.settingsHint':
    'Настройки фиксируются при открытии. Восстановление использует исходные настройки сервера. Письмо не сохраняется в этом браузере. Уже введённый текст сохраняется.',
  'application.slot': 'Слот браузера: {slot}',
  'application.automaticDelay':
    'Автоотправка точных ответов включена с паузой {delay} мс.',
  'application.refused':
    'Действие отклонено. Перед продолжением перечитайте страницу.',
  'application.read': 'Перечитать текущую страницу',
  'application.enter': 'Войти в отклик (возможна немедленная отправка)',
  'application.prefill': 'Заполнить точные проверенные ответы и письмо',
  'application.prefillAutomatic':
    'Заполнить точные ответы и отправить после паузы',
  'application.submit': 'Отправить проверенный отклик',
  'application.backup': 'Сохранить текущие ответы HH',
  'application.restore': 'Восстановить проверенный черновик в пустые поля',
  'application.draft': 'Личный черновик анкеты',
  'application.draftSaved': 'Сохранён на этом сервере: {time}',
  'application.draftHint':
    'Перед восстановлением откройте те же вопросы и поле письма. Сначала проверьте эту личную копию. Существующие ответы сохраняются; восстановление не отправляет отклик и не обучает базу ответов. Копия сохраняется явно и не является очередью повторных попыток.',
  'application.draft.checked': 'Отмечено',
  'application.draft.unchecked': 'Не отмечено',
  'application.restore.restoring':
    'Восстановление начато; прочитайте страницу HH, чтобы проверить текущие значения.',
  'application.restore.restored':
    'Значения черновика проверены в полях HH. Проверьте ответы перед отправкой.',
  'application.restore.refused':
    'Восстановление отклонено; существующие ответы сохранены. Прочитайте страницу снова.',
  'application.restore.partial':
    'Часть значений восстановлена. Прочитайте страницу HH перед продолжением.',
  'application.restore.uncertain':
    'Восстановление не подтверждено. Прочитайте страницу HH перед следующим действием.',
  'application.close': 'Закрыть браузер отклика',
  'application.pause': 'Приостановить проверку',
  'application.noQuestionnaires': 'Отложить анкету в этой проверке',
  'application.sessionHint':
    'Пауза и отсрочка анкеты действуют только в открытой проверке. Они не создают постоянных исключений или очереди повторов.',
  'application.unavailable':
    'Нужен подключённый сервер с поддержкой проверки откликов.',
  'application.choose': 'Соберите описание или выберите сохранённую вакансию.',
  'application.bound':
    'Проверка привязана к исходной вакансии и слоту браузера. Закройте или завершите её перед переходом к новому выбору.',
  'application.unknown':
    'Текущий статус неизвестен. Восстановите его перед действием. Восстановление только читает и не повторяет отправку.',
  'application.missing':
    'Сервер подтвердил отсутствие сохранённой проверки этой вакансии и запроса.',
  'application.failed':
    'Не удалось подтвердить действие или статус отклика. Восстановите статус перед продолжением.',
  'application.working': 'Работа с браузером отклика…',
  'application.confirm':
    'Я проверил полную вакансию и разрешаю указанное действие отклика',
  'application.start': 'Открыть проверку',
  'application.recover': 'Восстановить статус (только чтение)',
  'application.reopen': 'Открыть браузер сохранённой проверки',
  'application.release': 'Завершить проверку и перейти к выбранной вакансии',
  'application.stop': 'Остановить и завершить операцию отклика',
  'application.delivery.none': 'HH пока не подтвердил доставку отклика.',
  'application.delivery.unknown':
    'Доставка неизвестна. Зарезервированное действие могло достичь HH; повторной отправки не будет.',
  'application.delivery.provider-confirmed': 'HH подтвердил доставку отклика.',
  'application.letter.not-requested': 'Прикрепление письма ещё не запрошено.',
  'application.letter.verified': 'Письмо проверено в отклике HH.',
  'application.letter.not-attached': 'Письмо не прикреплено.',
  'application.letter.unavailable': 'Поле письма недоступно.',
  'application.letter.unverified': 'Содержимое письма не подтверждено.',
  'application.letter.owner-conflict':
    'Ваше существующее письмо сохранено; автоотправка заблокирована.',
  'application.state.opening': 'Открытие проверки',
  'application.state.ready': 'Можно войти в отклик',
  'application.state.review': 'Проверьте ответы перед отправкой',
  'application.state.verification': 'Пройдите проверку в браузере HH',
  'application.state.daily-limit': 'Достигнут дневной лимит HH',
  'application.state.external': 'Внешний отклик требует ручной проверки',
  'application.state.delivered': 'Отклик доставлен',
  'application.state.wrong-page': 'Страница не соответствует вакансии',
  'application.state.unavailable': 'Элемент отклика недоступен',
  'application.state.interrupted':
    'Проверка прервана; отправки остаются зарезервированы',
  'application.state.sending': 'Действие отправлено; ожидается подтверждение',
  'application.state.review-delay': 'Пауза перед автоотправкой',
  'application.state.deferred': 'Анкета отложена в этой проверке',
  'application.state.paused': 'Проверка приостановлена',
  'application.state.test-preview':
    'Просмотр завершён; действие отклика не отправлено',
  'application.state.closed': 'Браузер отклика закрыт',
};
