import { runBrowserScenarios } from './helpers/e2e-browser-scenarios.mjs';
import { verifyNativeApplicationDraft } from './helpers/e2e-application-drafts.mjs';
import { verifyApplicationPanel } from './helpers/e2e-application-panel.mjs';
import {
  verifyNativeApplication,
  verifyNativeApplicationGuards,
  verifyNativeApplicationRecovery,
} from './helpers/e2e-job-application.mjs';
await runBrowserScenarios('job-application', [
  verifyNativeApplication,
  verifyNativeApplicationGuards,
  verifyApplicationPanel,
  verifyNativeApplicationRecovery,
  verifyNativeApplicationDraft,
]);
