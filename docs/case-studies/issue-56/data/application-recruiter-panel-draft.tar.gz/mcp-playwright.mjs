async (page) => {
  const {base,stats,search}={"base":"http://127.0.0.1:43259","stats":"http://127.0.0.1:43975","search":"https://hh.ru/search/vacancy?text=Python&area=1&page=2&experience=between3And6"};
  const exceptions=[];
  page.on('pageerror', error=>exceptions.push(error.message));
  await page.setViewportSize({width:1180,height:950});
  await page.addInitScript(()=>{
    localStorage.setItem('metaSovereignTutorial',JSON.stringify({off:true,v:5}));
    localStorage.setItem('metaSovereignLocale','en');
    localStorage.setItem('metaSovereignEffects','on');
  });
  await page.goto(base+'/#/cv');
  const vacancies=page.locator('[data-vacancies]');
  await vacancies.locator('[data-vacancy-field="query"]').fill('Python');
  await vacancies.locator('[data-vacancy-action="search"]').click();
  await vacancies.locator('[data-vacancy-action="collect"]').first().click();
  const panel=page.locator('[data-application-panel]');
  await panel.locator('[data-application-missing]').waitFor();
  const select=(attribute,name)=>panel.locator('[data-application-'+attribute+'="'+name+'"]');
  const option=name=>select('option',name);
  const field=name=>select('batch-field',name);
  const batch=name=>select('batch-action',name);
  await option('autoSelectResumeLanguage').uncheck();
  await option('applyFromVacancyPage').uncheck();
  await option('applicationSearchUrl').fill(search);
  await option('vacancyPreviewSeconds').fill('0');
  await field('urls').fill('https://hh.ru/vacancy/123');
  await field('maxApplications').fill('1');
  await field('confirmBatch').check();
  const tutorial=page.locator('[data-tutorial-overlay]');
  if (await tutorial.isVisible()) {
    await tutorial.getByRole('button',{name:'Turn off tutorial',exact:true}).click();
    await tutorial.waitFor({state:'hidden'});
  }
  await batch('start').click();
  const waiting=select('batch-phase','review');
  await waiting.waitFor();
  await batch('follow').click();
  await select('state','review').waitFor();
  await option('confirm').check();
  await select('action','submit').click();
  const status=select('recruiter-chat','open');
  const receipt=select('delivery','provider-confirmed');
  await status.waitFor();
  await receipt.waitFor();
  const getStats=()=>page.request.get(stats).then(response=>response.json());

  const post=async (path)=>{
    const response=await page.request.post(stats+path);
    if(!response.ok()) throw new Error(await response.text());
  };
  const verify=async (matches)=>{
    let value;
    for(const end=Date.now()+7000;Date.now()<end;){
      value=await getStats();
      if(matches(value)) return value;
      await new Promise(resolve=>setTimeout(resolve,230));
    }
    throw new Error('Expected fixture state was not observed: '+JSON.stringify(value));
  };
  const existing=await verify(row=>row.draft==='I am reviewing the interview details.'&&row.draftWrites===0);
  await post('/vacancy/789');
  await select('recruiter-chat','unverified').waitFor();
  await post('/draft/clear');
  const mismatched=await verify(row=>row.draft===''&&row.draftWrites===0);
  await post('/vacancy/123');
  await status.waitFor();
  const prefilled=await verify(row=>row.draft==='I am available next Wednesday.'&&row.draftWrites===1&&row.revealed);
  await page.setViewportSize({width:390,height:1000});
  await page.reload();
  await waiting.waitFor();
  await batch('follow').click();
  await receipt.waitFor();
  await status.waitFor();
  const recovered=await getStats();
  const width=await page.evaluate(()=>[document.documentElement.scrollWidth,innerWidth]);
  await post('/draft/clear');
  await new Promise(resolve=>setTimeout(resolve,1100));
  const cleared=await getStats();
  if(recovered.draft!==prefilled.draft||recovered.draftWrites!==1||
     cleared.draft!==''||cleared.draftWrites!==1||width[0]!==width[1]||
     [existing,mismatched,prefilled,recovered,cleared].some(row=>row.recruiterSends!==0||row.sends!=='1')||
     exceptions.length) throw new Error(JSON.stringify({existing,mismatched,prefilled,recovered,cleared,width,exceptions}));
  await post('/dismiss');
  await select('batch-phase','completed').waitFor();
  const complete=await getStats();
  if(!complete.closed||complete.outcomes.length!==1||complete.panelOpen||complete.searchVisits.length!==2) throw new Error(JSON.stringify(complete));
  return {existing,mismatched,prefilled,recovered,cleared,complete,width,exceptions};
}
