Final checks: window=12 pass; compatibility=12 pass; browser-final=Chrome pass; final-lint and target-lint pass; build/format pass.
Before migration/mobile logs are intentional failures; after/comparison logs establish the correction. Draft lint preserves the initial review errors and is superseded by final lint.
Reference code was inspected, never executed or copied. MCP fixture has explicit unrelated unsupported-method refusals. Browser-final is the full focused export flow.
