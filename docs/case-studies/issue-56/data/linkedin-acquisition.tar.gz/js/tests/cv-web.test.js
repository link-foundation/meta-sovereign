// Issue #29 / R-V18: the CV screen. `CvScreen` is pure, so rendering it
// server-side with a hand-built state exercises the whole surface —
// catalogue, snapshots, conflicts, sync plan, telemetry and failures —
// without a browser, and in every locale the SPA ships.

import { test } from 'node:test';
import assert from 'node:assert/strict';

import { CvScreen, CvView, clientFailure } from '../src/web/cv-view.js';
import { navItems } from '../src/web/nav-items.js';
import { views } from '../src/web/views.js';
import { availableLocales } from '../src/web/i18n.js';
import { dictionaries } from '../src/web/locales/index.js';
import { listCvPlatforms } from '../src/cv/index.js';
import { api, resetServerBinding } from '../src/web/dom.js';
import { assertStackTable } from './helpers/stack-table.js';
import { screenRenderer } from './util-render.js';

const baseState = (overrides = {}) => ({
  platforms: [
    {
      id: 'habr-career',
      label: 'Habr Career',
      markupAccess: 'verified',
      confidence: { verified: 7, draft: 2 },
    },
    {
      id: 'topcv',
      label: 'TopCV',
      markupAccess: 'draft',
      confidence: { verified: 0, draft: 9 },
    },
  ],
  stored: [],
  selected: ['habr-career'],
  busy: '',
  failures: [],
  comparison: null,
  sync: null,
  telemetry: null,
  toggle: () => {},
  read: () => {},
  compare: () => {},
  planSync: () => {},
  ...overrides,
});

const render = screenRenderer(CvScreen);

test('the CV screen is a registered nav surface', () => {
  assert.ok(
    navItems.some(([id, key]) => id === 'cv' && key === 'nav.cv'),
    'navItems is missing the cv surface'
  );
  assert.equal(views.cv, CvView);
});

test('the catalogue renders one row per platform with its plan confidence', () => {
  const html = render(baseState());
  assert.match(html, /data-platform="habr-career"/);
  assert.match(html, /data-platform="topcv"/);
  assert.match(html, /7 verified \/ 2 draft/);
  assert.match(html, /Never read/);
  for (const action of ['read', 'compare', 'plan-sync', 'apply-sync']) {
    assert.match(html, new RegExp(`data-action="cv-${action}"`));
  }
  // Nothing may be written before a dry run has been planned.
  assert.match(html, /data-action="cv-apply-sync"[^>]*disabled/);
});

test('phones stack the platform table into labelled cards', () => {
  assertStackTable(render(baseState()), 'cv-platforms');
  // The column names are translated like the table headers.
  assertStackTable(render(baseState(), 'ru'), 'cv-platforms');
});

test('a stored snapshot replaces the "never read" marker', () => {
  const html = render(
    baseState({
      stored: [
        {
          platform: 'habr-career',
          capturedAt: '2026-01-02T03:04:05.000Z',
          cv: {},
        },
      ],
    })
  );
  assert.doesNotMatch(
    html.split('data-platform="topcv"')[0],
    /Never read/,
    'the read platform still claims it was never read'
  );
});

test('conflicting fields are listed and agreeing ones are not', () => {
  const html = render(
    baseState({
      comparison: {
        comparison: {
          rows: [
            {
              path: 'basics.name',
              conflict: true,
              missing: ['topcv'],
              values: { 'habr-career': 'Anna', linkedin: 'Anna B.' },
            },
            { path: 'basics.city', conflict: false, missing: [], values: {} },
          ],
        },
      },
    })
  );
  assert.match(html, /data-path="basics\.name" data-conflict="true"/);
  assert.doesNotMatch(html, /data-path="basics\.city"/);
  assert.match(html, /habr-career: &quot;Anna&quot;/);
  assert.match(html, /topcv/);
});

test('an empty comparison says so instead of rendering an empty table', () => {
  const html = render(baseState({ comparison: { comparison: { rows: [] } } }));
  assert.match(html, /No conflicts/);
});

test('a dry run is labelled as such and lists its per-platform actions', () => {
  const html = render(
    baseState({
      sync: {
        dryRun: true,
        actions: [
          {
            platform: 'habr-career',
            writable: 2,
            unsupported: 1,
            paths: ['basics.name'],
          },
        ],
      },
    })
  );
  assert.match(html, /data-dry-run="true"/);
  assert.match(html, /nothing was written/);
  assert.match(html, /2 writable, 1 unsupported — basics\.name/);
});

test('a long path list is previewed, counted and kept in full in the title', () => {
  // A real sync touches hundreds of paths (every field of every
  // experience record). The panel must stay readable without hiding
  // what is about to be written.
  const paths = Array.from({ length: 20 }, (_, index) => `skills[${index}]`);
  const html = render(
    baseState({
      sync: {
        dryRun: true,
        actions: [
          { platform: 'linkedin', writable: 20, unsupported: 0, paths },
        ],
      },
    })
  );
  assert.match(html, /data-paths="20"/);
  assert.match(html, /skills\[5\] \(\+14 more\)/);
  assert.doesNotMatch(html, /skills\[6\] \(/);
  // Nothing is lost: the full list stays available on hover.
  assert.ok(html.includes(`title="${paths.join(', ')}"`));
});

test('failures name the platform, the code and the message', () => {
  const html = render(
    baseState({
      failures: [
        {
          platform: 'topcv',
          code: 'browser-unavailable',
          message: 'install playwright',
        },
      ],
    })
  );
  assert.match(html, /role="alert"/);
  assert.match(html, /topcv: browser-unavailable — install playwright/);
});

test('a thrown error reaches the same failure list as a platform failure', () => {
  const failure = clientFailure('read', new TypeError('fetch failed'));
  assert.deepEqual(failure, {
    platform: 'read',
    code: 'client-error',
    message: 'fetch failed',
  });
  // Whatever was thrown, the screen gets something printable.
  assert.equal(clientFailure('sync', 'boom').message, 'boom');
  assert.match(render(baseState({ failures: [failure] })), /client-error/);
});

test('telemetry runs surface their counts and problems', () => {
  const html = render(
    baseState({
      telemetry: {
        runs: [
          {
            runId: 'run-1',
            platform: 'habr-career',
            mode: 'read',
            startedAt: '2026-01-02T03:04:05.000Z',
            counts: { 'run.start': 1, 'markup.fingerprint': 3 },
            problems: ['selector .page-title__title matched 0 nodes'],
          },
        ],
        events: [],
      },
    })
  );
  assert.match(html, /data-run-id="run-1"/);
  assert.match(html, /run\.start=1 markup\.fingerprint=3/);
  assert.match(html, /matched 0 nodes/);
});

test('a backend without the CV routes says so instead of showing an empty table', () => {
  // `docs/SERVER-PARITY.md`: /api/cv/* is JS only, so the Rust server
  // (or no server at all) leaves the catalogue empty.
  const html = render(baseState({ platforms: [], selected: [] }));
  assert.match(html, /data-cv="unavailable"/);
  assert.match(html, /does not provide the CV routes/);
  assert.doesNotMatch(html, /class="cv-platforms"/);
});

test('an idle telemetry panel explains that no run happened yet', () => {
  assert.match(render(baseState()), /No runs recorded yet/);
});

test('initial CV loading disables actions without claiming the routes are unavailable', () => {
  for (const { id } of availableLocales) {
    const html = render(
      baseState({ platforms: [], selected: [], busy: 'load' }),
      id
    );
    assert.doesNotMatch(html, /data-cv="unavailable"/);
    assert.ok(html.includes(dictionaries[id]['common.loading']));
    for (const action of ['read', 'compare', 'plan-sync', 'apply-sync']) {
      assert.match(html, new RegExp(`data-action="cv-${action}"[^>]*disabled`));
    }
  }
});

test('every locale translates the CV screen', () => {
  for (const { id } of availableLocales) {
    const html = render(baseState(), id);
    assert.doesNotMatch(html, /cv\.[a-zA-Z]+</, `${id}: untranslated cv key`);
    assert.doesNotMatch(html, />nav\.cv</, `${id}: untranslated nav key`);
  }
});

test('each locale defines every key the CV screen and nav use', () => {
  const keys = Object.keys(dictionaries.en).filter(
    (key) => key === 'nav.cv' || key.startsWith('cv.')
  );
  assert.ok(keys.length > 20, 'expected the cv.* key block in en');
  for (const { id } of availableLocales) {
    for (const key of keys) {
      assert.ok(dictionaries[id][key], `${id} is missing ${key}`);
    }
  }
});

test('the offline client answers every CV call the screen makes', async () => {
  for (const method of [
    'cvPlatforms',
    'cvPlan',
    'cvStored',
    'cvRead',
    'cvCompare',
    'cvSync',
    'cvTelemetry',
  ]) {
    assert.equal(typeof api[method], 'function', `api.${method} is missing`);
  }
  // Without a server the calls resolve to an honest "server-required"
  // answer rather than throwing at the user. No server is reachable
  // here, even when the developer's own app listens on a local port:
  // the test must never make a running app read anything.
  const realFetch = globalThis.fetch;
  globalThis.fetch = () => Promise.reject(new Error('offline in tests'));
  resetServerBinding();
  try {
    const read = await api.cvRead({ platforms: ['topcv'] });
    assert.equal(read.failures[0].code, 'server-required');
    const stored = await api.cvStored();
    assert.deepEqual(stored.entries, []);
    const telemetry = await api.cvTelemetry({});
    assert.deepEqual(telemetry.runs, []);
  } finally {
    globalThis.fetch = realFetch;
    resetServerBinding();
  }
});

test('the catalogue covers every platform the CV subsystem knows', () => {
  const ids = listCvPlatforms();
  for (const id of [
    'linkedin',
    'hh',
    'habr-career',
    'naukri',
    'vietnamworks',
    'topcv',
  ]) {
    assert.ok(ids.includes(id), `missing platform ${id}`);
  }
});
