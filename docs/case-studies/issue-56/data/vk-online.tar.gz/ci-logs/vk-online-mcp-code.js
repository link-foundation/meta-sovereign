async (page) => (async (page, fixture, check) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      language
    );
    await page.goto(`${fixture.base}/?vkLocale=${language}#conn-vk/manual`);
    const panel = page.locator(`[data-${fixture.feature}]`);
    const ready = () =>
      page.waitForFunction((feature) => {
        const input = document.querySelector(
          `[data-${feature}] input[type=checkbox]`
        );
        return input && !input.disabled;
      }, fixture.feature);
    // A mounted heading and an enabled control distinguish loading from absence.
    await panel
      .getByRole('heading', { name: words.title, exact: true })
      .waitFor();
    await ready();
    for (const key of fixture.keys) {
      if (!(await panel.innerText()).includes(words[key])) {
        throw Error(`Missing ${language}.${key}`);
      }
    }
    const { focus, ...checked } = await check(page, {
      panel,
      words,
      ready,
      feature: fixture.feature,
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await panel.locator(focus).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-${fixture.feature}/mcp-${language}-phone.png`,
    });
    result.push({ language, translated: true, ...checked });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:40343","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","feature":"vk-online","keys":["hint","enabled","minutes","run"],"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"VK online status","hint":"With your saved user token, request online status at this interval while this server runs. VK confirms each refresh for 15 minutes. This changes your visible presence; it sends no messages. Scheduling starts off.","enabled":"Refresh online status automatically","minutes":"Interval in minutes (1–14)","run":"Mark online now"},"ru":{"title":"Статус ВКонтакте «онлайн»","hint":"С вашим сохранённым токеном пользователя запрашивать статус онлайн с этим интервалом, пока сервер работает. ВКонтакте подтверждает обновление на 15 минут. Это меняет видимость вашего присутствия, но не отправляет сообщения. Изначально выключено.","enabled":"Автоматически обновлять статус онлайн","minutes":"Интервал в минутах (1–14)","run":"Установить онлайн сейчас"},"hi":{"title":"VK ऑनलाइन स्थिति","hint":"इस सर्वर के चलते समय अपने सहेजे उपयोगकर्ता टोकन से इस अंतराल पर ऑनलाइन स्थिति का अनुरोध करें। VK हर अपडेट को 15 मिनट के लिए स्वीकार करता है। इससे आपकी उपस्थिति दिखती है; कोई संदेश नहीं भेजा जाता। शुरू में बंद है।","enabled":"ऑनलाइन स्थिति अपने आप ताज़ा करें","minutes":"मिनटों में अंतराल (1–14)","run":"अभी ऑनलाइन दिखाएँ"},"zh":{"title":"VK 在线状态","hint":"此服务器运行时，用已保存的用户令牌按此间隔请求在线状态。VK 每次确认的有效期为 15 分钟。这会更改他人看到的在线状态，不会发送消息。默认关闭。","enabled":"自动刷新在线状态","minutes":"间隔分钟数（1–14）","run":"立即标记在线"}}}, (async (page, { panel, ready }) => {
  const enabled = panel.locator('[data-action=vk-online-enabled]');
  const previous = await enabled.isChecked();
  await enabled.click();
  await ready();
  if ((await enabled.isChecked()) === previous) {
    throw Error('Save acknowledgement missing');
  }
  const running = page.waitForResponse(
    (response) =>
      response.url().endsWith('/api/vk/online/run') &&
      response.request().method() === 'POST'
  );
  await panel.locator('[data-action=vk-online-run]').click();
  if ((await running).status() !== 200) {
    throw Error('Online action was not acknowledged');
  }
  await ready();
  await panel.locator('[data-vk-online-status=confirmed]').waitFor();
  await page.reload();
  await ready();
  if ((await enabled.isChecked()) === previous) {
    throw Error('Saved choice lost');
  }
  await panel.locator('[data-vk-online-status=confirmed]').waitFor();
  return {
    focus: '[data-vk-online-status]',
    acknowledged: true,
    savedChoiceRetained: true,
  };
}))