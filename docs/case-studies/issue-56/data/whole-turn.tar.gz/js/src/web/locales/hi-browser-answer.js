export const hiBrowserAnswer = {
  'browserAnswer.latestAfterCompleted':
    'पहले के पूर्ण सारांश या स्वीकृत सूचनाओं को उत्तर नहीं चाहिए। विकल्प नवीनतम संदेश के लिए है।',
  'questions.match.pending-turn': 'अनुत्तरित संदेशों के उत्तर',
  'browserAnswer.wholeTurn':
    'मसौदे में सभी अनुत्तरित संदेश शामिल हैं। भरने से पहले हर उत्तर की समीक्षा करें।',
  'browserAnswer.turn': 'दिख रहे अनुत्तरित संदेश: {count}',
  'browserAnswer.latestOnly':
    'नीचे दिया उत्तर अंतिम संदेश के लिए है। पहले के संदेशों की समीक्षा अभी बाकी है।',
  'browserAnswer.boundary.outgoing':
    'मालिक के अंतिम दिख रहे उत्तर के बाद के संदेश। पहले का इतिहास सत्यापित नहीं है।',
  'browserAnswer.boundary.service':
    'अंतिम दिख रही सेवा घटना के बाद के संदेश। पहले का इतिहास सत्यापित नहीं है।',
  'browserAnswer.boundary.rendered-start':
    'मालिक का पिछला उत्तर या सेवा घटना नहीं दिख रही है। पहले का इतिहास अज्ञात है।',
  'browserAnswer.boundary.unknown':
    'इस समीक्षा में केवल अंतिम संदेश है। अनुत्तरित बातचीत का संदर्भ अज्ञात है।',
  'questions.match.accepted-summary': 'स्वीकृत उत्तर का सारांश',
  'questions.acceptedSummary.matched':
    'पूरी हुई प्रश्नावली का सारांश इस मौजूदा विकल्प से मेल खाता है।',
  'questions.acceptedSummary.conflict':
    'सहेजे गए सारांश से एक मौजूदा विकल्प तय नहीं होता। प्रश्न की समीक्षा करें।',
  'questions.acceptedSummary.limited':
    'सहेजे गए इतिहास की पूरी जाँच नहीं हो सकी। प्रश्न की समीक्षा करें।',

  'browserAnswer.title': 'सेवा के ब्राउज़र में उत्तर',
  'browserAnswer.hint':
    'चुनी हुई सेवा की चैट पढ़ें, वर्तमान प्रश्न की समीक्षा करें और दिए गए विकल्पों में से एक भेजें। मौजूदा ड्राफ़्ट सुरक्षित रहते हैं। स्थिति वापस पाने से चयन दोहराया नहीं जाता।',
  'browserAnswer.source': 'सेवा',
  'browserAnswer.chat': 'वेब चैट का संदर्भ',
  'browserAnswer.url': 'आवेदन पृष्ठ का URL (वैकल्पिक)',
  'browserAnswer.inspect': 'वर्तमान प्रश्न और विकल्प पढ़ें',
  'browserAnswer.options': 'अभी दिए गए विकल्प',
  'browserAnswer.select': 'सेवा की चैट में “{option}” भेजें',
  'browserAnswer.prefill': 'समीक्षित ड्राफ़्ट भरें',
  'browserAnswer.prefilled': 'ड्राफ़्ट भर गया; सेवा की चैट में जाँचें',
  'browserAnswer.recover': 'चयन की स्थिति वापस पाएँ',
  'browserAnswer.reload': 'ब्राउज़र की क्षमताएँ और पिछली समीक्षा फिर पढ़ें',
  'browserAnswer.unavailable':
    'इन नियंत्रणों के लिए ब्राउज़र उत्तरों का समर्थन करने वाला सर्वर जोड़ें।',
  'browserAnswer.review':
    'कार्य करने से पहले सेवा के वर्तमान प्रश्न की समीक्षा करें।',
  'browserAnswer.sending':
    'चयन चल रहा है। अगले कार्य से पहले उसकी स्थिति पाएँ।',
  'browserAnswer.sent': 'सेवा ने चुने हुए उत्तर की पुष्टि की।',
  'browserAnswer.markedSent':
    'आपने आउटबॉक्स में इस उत्तर को भेजा हुआ चिह्नित किया।',
  'browserAnswer.unknown':
    'चयन भेजा जा चुका हो सकता है। सेवा की चैट जाँचकर आउटबॉक्स में स्थिति तय करें; अपने आप दोबारा प्रयास नहीं होगा।',
  'browserAnswer.failed':
    'चयन अस्वीकार हुआ। फिर प्रयास करने से पहले वर्तमान प्रश्न पढ़ें।',
  'browserAnswer.receipt': 'सेवा का संदेश प्रमाण: {id}',
  'browserAnswer.ownerDraft':
    'सेवा के इनपुट में ड्राफ़्ट है। विकल्प चुनने से पहले वहीं उसकी समीक्षा करें।',
  'browserAnswer.pending':
    'उत्तर के नियंत्रण अभी आने हैं या बंद हैं। दिखने पर वर्तमान प्रश्न फिर पढ़ें।',
  'browserAnswer.expired': 'यह समीक्षा समाप्त हो गई। वर्तमान प्रश्न फिर पढ़ें।',
  'browserAnswer.error':
    'ब्राउज़र उत्तर की स्थिति अपुष्ट है ({code})। स्थिति वापस पाएँ या वर्तमान प्रश्न फिर पढ़ें।',
  'browserAnswer.unconfirmed':
    'चयन का उत्तर अपुष्ट है। अगला चयन करने से पहले सर्वर की स्थिति पुनः प्राप्त करें।',
  'browserAnswer.outgoing':
    'प्रदाता का अंतिम संदेश भेजा हुआ है। नया प्रश्न आने पर फिर पढ़ें।',
  'browserWatch.hint':
    'इस चैट में ज्ञात उत्तरों पर नज़र रखें। सटीक स्वीकृत उत्तर और पूर्ण सारांश का एकमात्र मेल अपने आप विकल्प चुन सकते हैं। सामान्य पाठ केवल मसौदे में भरा जाता है। मालिक के संपादन सुरक्षित रहते हैं। पृष्ठ बदलने, दोबारा लोड करने या अनिश्चित चयन पर निगरानी रुकती है; सर्वर दोबारा चालू करने से यह फिर शुरू नहीं होती।',
  'browserWatch.minutes': 'मिनट (1–120)',
  'browserWatch.start': 'चैट पर नज़र रखें और ज्ञात विकल्प चुनें',
  'browserWatch.unconfirmed':
    'निगरानी शुरू होने की पुष्टि नहीं हुई। दूसरी निगरानी शुरू करने से पहले सहेजी स्थिति जाँचें।',
  'browserWatch.active': 'प्रदाता की चैट पर निगरानी जारी है।',
  'browserWatch.paused':
    'निगरानी रुकी है। फिर शुरू करने से पहले प्रदाता की चैट जाँचें।',
  'browserWatch.stopped': 'निगरानी बंद है; लंबित कार्रवाई पूरी हो चुकी है।',
  'browserWatch.reason': 'निगरानी विवरण: {code}',
  'browserWatch.recover': 'निगरानी की स्थिति पुनः प्राप्त करें',
  'browserWatch.stop': 'निगरानी रोकें और प्रतीक्षा करें',
  'browserWatch.phase.starting': 'समीक्षित चैट खुल रही है।',
  'browserWatch.phase.waiting': 'नए आने वाले प्रश्न की प्रतीक्षा है।',
  'browserWatch.phase.owner-draft': 'मालिक का मसौदा सुरक्षित है।',
  'browserWatch.phase.pending-options':
    'उत्तर के बटन दिखने या सक्षम होने की प्रतीक्षा है।',
  'browserWatch.phase.review': 'इस प्रश्न की मैन्युअल समीक्षा ज़रूरी है।',
  'browserWatch.phase.ready': 'ज्ञात उत्तर तैयार हो रहा है।',
  'browserWatch.phase.prefilled': 'समीक्षा के लिए मसौदा भर दिया गया है।',
  'browserWatch.phase.sent': 'प्रदाता ने चुने विकल्प की पुष्टि की।',
  'browserWatch.phase.unknown':
    'विकल्प भेजा जा चुका हो सकता है। आउटबॉक्स में परिणाम जाँचें; स्वचालित चयन रुका है।',
  'browserWatch.phase.failed': 'चयन अस्वीकृत हुआ; निगरानी रुकी है।',
  'browserWatch.phase.marked-sent':
    'आपने पहले वाले विकल्प को आउटबॉक्स में भेजा हुआ चिह्नित किया।',
  'browserWatch.selected': 'आखिरी पुष्टि किया गया विकल्प: {option}',
  'browserWatch.phase.selecting':
    'मूल विकल्प चुना जा रहा है; पुष्टि की प्रतीक्षा करें।',
};
