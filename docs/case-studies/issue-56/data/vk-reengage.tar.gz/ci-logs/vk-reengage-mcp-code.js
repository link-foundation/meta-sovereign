async (page) => (async (page, fixture, check) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      language
    );
    await page.goto(`${fixture.base}/?vkLocale=${language}#conn-vk/manual`);
    const panel = page.locator(`[data-${fixture.feature}]`);
    const ready = () =>
      page.waitForFunction((feature) => {
        const input = document.querySelector(
          `[data-${feature}] input[type=checkbox]`
        );
        return input && !input.disabled;
      }, fixture.feature);
    // A mounted heading and an enabled control distinguish loading from absence.
    await panel
      .getByRole('heading', { name: words.title, exact: true })
      .waitFor();
    await ready();
    for (const key of fixture.keys) {
      if (!(await panel.innerText()).includes(words[key])) {
        throw Error(`Missing ${language}.${key}`);
      }
    }
    const { focus, ...checked } = await check(page, {
      panel,
      words,
      ready,
      feature: fixture.feature,
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await panel.locator(focus).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-${fixture.evidenceName}/mcp-${language}-phone.png`,
    });
    result.push({ language, translated: true, ...checked });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:34107","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","feature":"vk-music","evidenceName":"vk-reengage","keys":["hint","greeting","questions","audio","run"],"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"VK music questions","hint":"Scheduling starts off. Review a current friend with nonempty dormant history and write permission. Send the greeting, optional audio, then the question in order, 15 seconds apart. Unread, protected and uncertain conversations are held. Confirmed steps are retained; definite partial delivery needs a new review. Unknown delivery is never replayed.","greeting":"First greeting (up to 500 characters)","questions":"Question variants (one per line, up to 20)","audio":"Native VK audio ID (audioOWNER_ID_AUDIO_ID)","run":"Confirm remaining reviewed steps"},"ru":{"title":"Вопросы о музыке ВКонтакте","hint":"Расписание выключено. Проверьте текущую дружбу, непустую давнюю историю и разрешение писать. Приветствие, необязательное аудио и вопрос отправляются по порядку с паузой 15 секунд. Непрочитанные, защищённые и неопределённые беседы исключены. Подтверждённые шаги сохраняются; частичная отправка требует новой проверки. Неизвестная отправка не повторяется.","greeting":"Первое приветствие (до 500 символов)","questions":"Варианты вопроса (по строке, до 20)","audio":"ID аудио ВКонтакте (audioOWNER_ID_AUDIO_ID)","run":"Подтвердить оставшиеся просмотренные шаги"},"hi":{"title":"VK संगीत प्रश्न","hint":"शेड्यूल बंद है। वर्तमान मित्र, पुरानी गैरखाली हिस्ट्री और लिखने की अनुमति जाँचें। अभिवादन, वैकल्पिक ऑडियो और प्रश्न क्रम से 15 सेकंड के अंतर पर जाते हैं। अपठित, सुरक्षित और अनिश्चित बातचीत रोकी जाती है। पुष्ट चरण सहेजे जाते हैं; आंशिक भेजने को नई समीक्षा चाहिए। अज्ञात भेजना दोहराया नहीं जाता।","greeting":"पहला अभिवादन (500 अक्षर तक)","questions":"प्रश्न विकल्प (हर पंक्ति पर एक, अधिकतम 20)","audio":"मूल VK ऑडियो ID (audioOWNER_ID_AUDIO_ID)","run":"शेष समीक्षित चरणों की पुष्टि करें"},"zh":{"title":"VK 音乐提问","hint":"自动计划默认关闭。审核当前好友、非空且久未联系的历史及发送权限。按问候、可选音频、问题的顺序发送，每步间隔 15 秒。未读、受保护及结果未知的对话暂缓。保留已确认步骤；部分发送需要重新审核。结果未知时绝不重发。","greeting":"第一条问候（最多 500 字符）","questions":"问题选项（每行一个，最多 20 个）","audio":"VK 原生音频 ID（audioOWNER_ID_AUDIO_ID）","run":"确认剩余已审核步骤"}}}, (async (page, { panel, ready }) => {
  for (const [key, value] of [
    ['greeting', 'Hello again!'],
    ['questions', 'What do you think of this track?'],
    ['audio', 'audio-1_23'],
  ]) {
    await panel.locator(`[data-music-field=${key}]`).fill(value);
  }
  for (const action of ['save', 'plan']) {
    await panel.locator(`[data-action=vk-music-${action}]`).click();
    await ready();
  }
  const cooled = await panel.locator('[data-music-reason=cooldown]').count();
  if (!cooled) {
    if (
      (await panel.locator('[data-personal-sequence] li').count()) !== 3 ||
      !(await panel.locator('[data-personal-sequence]').innerText()).includes(
        'audio-1_23'
      )
    ) {
      throw Error('Missing ordered audio review');
    }
    await panel.locator('[data-action=vk-music-run]').click();
    await ready();
  }
  await page.reload();
  await ready();
  await panel.locator('[data-action=vk-music-plan]').click();
  await ready();
  if ((await panel.locator('[data-music-reason=cooldown]').count()) !== 1) {
    throw Error('Cooldown did not survive reload');
  }
  if (await panel.locator('[data-action=vk-music-enabled]').isChecked()) {
    throw Error('Schedule unexpectedly enabled');
  }
  return {
    focus: '[data-vk-music-plan]',
    orderedReview: true,
    cooldown: true,
    automaticOff: true,
  };
}))