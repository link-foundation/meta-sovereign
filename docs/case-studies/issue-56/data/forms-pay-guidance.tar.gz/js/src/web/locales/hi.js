import { hiAnswerModel } from './hi-answer-model.js';
import { hiForms } from './hi-forms.js';
import { hiSharedProfile } from './hi-shared-profile.js';
import { hiProfileImport } from './hi-profile-import.js';
import { hiChatRemoval } from './hi-chat-removal.js';
import { hiFollowTelegram } from './hi-follow-telegram.js';
import { hiFollow } from './hi-follow.js';
import { hiTelegramGreetings } from './hi-telegram-greetings.js';
import { hiChatUsers } from './hi-chat-users.js';
import { hiPublication } from './hi-publication.js';
import { hiBrowser } from './hi-browser.js';
// Hindi locale (issue #18). Keys must mirror ./en.js exactly; the
// parity test in js/tests/i18n.test.js fails the build if they
// drift. Devanagari script renders correctly without bundled fonts on
// every modern OS, but the <html lang="hi"> attribute (set by
// applyLocale in i18n.js) is essential for screen readers and
// font-fallback in the platform Chrome / Safari / Firefox.

import { hiChat } from './hi-chat.js';
import { hiChatMore } from './hi-chat-more.js';
import { hiChatAccount } from './hi-chat-account.js';
import { hiFolders } from './hi-folders.js';
import { hiTranscribe } from './hi-transcribe.js';
import { hiGithub } from './hi-github.js';

import { hiConversation } from './hi-conversation.js';

import { hiFeedback } from './hi-feedback.js';

import { hiStickers } from './hi-stickers.js';

export const hi = {
  ...hiForms,
  ...hiAnswerModel,
  ...hiSharedProfile,
  ...hiProfileImport,
  ...hiChatRemoval,
  ...hiFollow,
  ...hiFollowTelegram,
  ...hiFollowBacklink,
  ...hiTelegramGreetings,
  ...hiChatUsers,
  ...hiPublication,
  'backup.schedule': 'स्वचालित पुनर्प्राप्ति',
  'backup.scheduleHint':
    'निर्धारित और एक बार के बैकअप के लिए ये सेटिंग सहेजें। पहला स्वचालित बैकअप चुने हुए अंतराल के बाद चलेगा।',
  'backup.hours': 'घंटों में अंतराल (0 से बंद)',
  'backup.retention': 'हर प्रारूप की रखी जाने वाली प्रतियाँ (0 से सभी)',
  'backup.formats': 'स्वतंत्र पुनर्प्राप्ति डंप',
  'backup.format.text': 'टेक्स्ट Lino डंप',
  'backup.format.binary': 'बाइनरी Lino डंप',
  'backup.format.archive': 'पुनर्प्राप्ति संग्रह',
  'backup.save': 'पुनर्प्राप्ति सेटिंग सहेजें',
  'backup.saved': 'पुनर्प्राप्ति सेटिंग सहेजी गईं।',
  'backup.created':
    'बैकअप सत्यापित; {count} स्वतंत्र पुनर्प्राप्ति डंप सत्यापित।',
  'backup.restored': '{count} रिकॉर्ड पुनर्स्थापित।',
  'backup.working': 'काम जारी है…',
  'backup.failed':
    'कार्य के परिणाम की पुष्टि नहीं हो सकी। दोबारा प्रयास से पहले फ़ाइल सूची जाँचें।',
  'backup.refused': 'कार्य विफल: {reason}',
  'backup.empty': 'अभी कोई पुनर्प्राप्ति फ़ाइल नहीं है।',
  'backup.rawHint':
    'स्वतंत्र डंप गुप्त रिकॉर्ड शामिल नहीं करते, भले ही संग्रह एन्क्रिप्टेड हो। उनमें आपका अन्य डेटा रहता है। फ़ाइलों को निजी रखें।',
  'backup.unavailable':
    'फ़ाइल बैकअप के लिए संग्रह भंडारण वाले जुड़े सर्वर की आवश्यकता है। पुनर्प्राप्ति सेट करने के लिए समर्थित सर्वर जोड़ें।',
  'backup.restoreAsk':
    '{file} पुनर्स्थापित करें? रिकॉर्ड इस सर्वर में मिलेंगे और समान ID वाले रिकॉर्ड बदलेंगे। किसी बदलाव से पहले पूरी फ़ाइल की जाँच होगी।',
  ...hiBrowser,
  ...hiStickers,
  ...hiFeedback,
  ...hiConversation,

  'nav.calls': 'कॉल',
  'panels.hint':
    'चौड़ाई बदलने के लिए खींचें। रीसेट के लिए डबल क्लिक या Enter दबाएँ।',
  'panels.navigation': 'नेविगेशन की चौड़ाई बदलें',
  'panels.chats': 'चैट सूची की चौड़ाई बदलें',
  'panels.details': 'विवरण की चौड़ाई बदलें',
  ...hiChat,
  ...hiChatMore,
  ...hiChatAccount,
  ...hiFolders,
  ...hiTranscribe,
  ...hiGithub,
  appName: 'meta-sovereign',
  skipLink: 'मुख्य सामग्री पर जाएँ',
  'header.theme': 'थीम',
  'header.themeAria': 'डार्क मोड टॉगल करें',
  'header.tutorial': 'ट्यूटोरियल',
  'header.tutorialAria': 'ट्यूटोरियल खोलें',
  'header.language': 'भाषा',
  'header.languageAria': 'इंटरफ़ेस की भाषा चुनें',
  'header.systemDefault': 'सिस्टम डिफ़ॉल्ट',
  'header.online': 'ऑनलाइन',
  'header.offline': 'ऑफ़लाइन',
  'header.reconnecting': 'फिर से कनेक्ट हो रहा है',
  'settings.connection.title': 'कनेक्शन बहाली',
  'settings.connection.browserOnly':
    'सर्वर या Telegram से जुड़ने के बाद केवल ब्राउज़र मोड का विकल्प दें',
  'settings.connection.hint':
    'डिफ़ॉल्ट रूप से बंद। कनेक्शन टूटने पर वर्तमान पेज बना रहता है, लोडिंग फिर होती है और कतार के संदेश अपने आप भेजे जाते हैं।',
  'header.telegramOffline':
    'Telegram कुछ समय से उपलब्ध नहीं है; कोशिश जारी है। Telegram कनेक्शन खोलें',
  'header.telegramSignIn':
    'Telegram ने यह सत्र समाप्त कर दिया; फिर से साइन इन करें',
  'webMode.title': 'केवल ब्राउज़र मोड',
  'webMode.body':
    'ऐप लोकल सर्वर से जुड़ा नहीं है, इसलिए यह इस ब्राउज़र में सहेजे गए डेटा के साथ काम करता है। मेल और मैसेंजर से इम्पोर्ट, शेड्यूल किए गए ऑटोमेशन, डिवाइसों के बीच सिंक, CV सिंक और ग्रीटिंग्स लोकल सर्वर चलने पर चालू होते हैं। Node.js 26.12.1 या नए के साथ इसे शुरू करें:',
  'webMode.retrying': 'लोकल सर्वर अपने आप खोजा जा रहा है।',
  'webMode.retry': 'फिर से जाँचें',
  'webMode.checking': 'लोकल सर्वर खोजा जा रहा है…',
  'webMode.notFound':
    'ब्राउज़र अभी लोकल सर्वर से जुड़ नहीं सकता। जाँचें कि वह चल रहा है और उसका प्रमाणपत्र विश्वसनीय है। कोशिश अपने आप दोहराई जाएगी।',
  'webMode.download': 'डेस्कटॉप ऐप पाएँ (सर्वर शामिल)',
  'webMode.dismiss': 'छिपाएँ',
  'webMode.safari':
    'Safari इस HTTPS पेज को local HTTP API तक पहुँचने नहीं देता। एक बार node js/bin/meta-sovereign.js trust से local HTTPS certificate पर भरोसा करें, फिर इसी hosted app का उपयोग करें। Localhost UI वैकल्पिक है (--local-ui=true)।',
  'webMode.openLocal': 'सर्वर से ऐप खोलें',
  'webMode.localFound':
    '{origin} पर सर्वर चल रहा है, पर यह ब्राउज़र इस पेज को उस तक पहुँचने नहीं देता। नीचे दिए लिंक से सर्वर से ऐप खोलें।',
  'webMode.trust':
    'Safari को यहाँ से जुड़ने देने के लिए server पर एक बार भरोसा करें: {command} चलाएँ, या सर्वर पर भरोसा करें click करें, Show Details → visit this website चुनें और अपना password डालें। फिर फिर से जाँचें click करें।',
  'webMode.trustLink': 'सर्वर पर भरोसा करें',
  'webMode.localOff':
    '{origin} पर server चल रहा है। वैकल्पिक localhost UI बंद है; GitHub Pages default app है। Safari के लिए HTTPS enable करें और local certificate trust करें। --local-ui=true केवल वैकल्पिक local web app enable करता है।',
  'nav.chat': 'चैट',
  'nav.operator': 'ऑपरेटर',
  'nav.contacts': 'संपर्क',
  'nav.automation': 'स्वचालन',
  'nav.patterns': 'पैटर्न',
  'nav.replies': 'जवाब',
  'nav.facts': 'तथ्य',
  'nav.audience': 'श्रोता',
  'nav.broadcast': 'प्रसारण',
  'nav.outreach': 'पहुँच',
  'nav.profile': 'प्रोफ़ाइल',
  'nav.backup': 'बैकअप',
  'nav.status': 'स्थिति',
  'nav.connections': 'कनेक्शन',
  // Shorter labels for the phone's bottom bar and the tablet rail.
  'nav.short.automation': 'स्वचालन',
  'nav.short.cv': 'CV सिंक',
  'nav.short.connections': 'कनेक्शन',
  'nav.cv': 'CV सिंक',
  'nav.greetings': 'स्टिकर',
  'nav.settings': 'सेटिंग्स',
  'shell.primaryNavAria': 'मुख्य नेविगेशन',
  'shell.more': 'और',
  'shell.moreAria': 'अन्य अनुभाग',
  'common.loading': 'लोड हो रहा है…',
  'common.save': 'सहेजें',
  'common.send': 'भेजें',
  'common.cancel': 'रद्द करें',
  'common.preview': 'पूर्वावलोकन',
  'common.queue': 'क़तार में डालें',
  'common.evaluate': 'चलाएँ',
  'common.infer': 'निकालें',
  'operator.remaining': '{count} बातचीत शेष',
  'operator.empty': 'कोई अपठित बातचीत नहीं',
  'operator.emptyHint': 'नई अपठित बातचीत यहाँ अपने आप दिखाई देगी।',
  'operator.failed':
    'बातचीत को पढ़ा हुआ चिह्नित नहीं किया जा सका। कार्ड यहीं है; फिर से पूरा दबाएँ।',
  'nav.unreadAtLeast': 'कम से कम {count} अपठित',
  'nav.unread.chat': 'सभी फ़ोल्डर में {count} अपठित संदेश, म्यूट चैट छोड़कर',
  'nav.unread.calls': '{count} अपठित मिस्ड कॉल',
  'nav.unread.operator': 'सभी फ़ोल्डर में {count} अधूरी ऑपरेटर बातचीत',
  'nav.unreadCount': '{count} अपठित',
  'marketplace.apiNote':
    'वैकल्पिक API और आर्काइव पहुँच। ब्राउज़र साइन-इन और प्रोफ़ाइल के लिए ऊपर कार्य खाते देखें।',
  'marketplace.title': 'कार्य खाते',
  'marketplace.intro':
    'लोकल सर्वर वाले कंप्यूटर पर ब्राउज़र विंडो में Upwork, Fiverr, PeoplePerHour या Wellfound में साइन इन करें। प्रोफ़ाइल सहेजने के बाद वह कनेक्शन और प्रोफ़ाइल में दिखेगी।',
  'marketplace.show': 'सत्र की विंडो दिखाएँ',
  'marketplace.open': 'साइन-इन ब्राउज़र खोलें',
  'marketplace.capture': 'यह प्रोफ़ाइल सहेजें',
  'marketplace.close': 'सत्र की विंडो बंद करें',
  'marketplace.windowOpen': 'सत्र की विंडो खुली है',
  'marketplace.windowClosed': 'सत्र की विंडो बंद है',
  'marketplace.instructions':
    'खुद साइन इन करें, उसी टैब में अपनी प्रोफ़ाइल खोलें और यह प्रोफ़ाइल सहेजें दबाएँ। विंडो बंद करने पर अगली बार के लिए साइन-इन सत्र बना रहता है।',
  'marketplace.noProfile': 'अभी कोई प्रोफ़ाइल नहीं सहेजी गई।',
  'marketplace.viewProfile': 'साइट पर प्रोफ़ाइल देखें',
  'marketplace.captured': 'प्रोफ़ाइल {at} को सहेजी गई',
  'marketplace.signInObserved': 'साइन-इन {at} को देखा गया',
  'marketplace.working': 'काम हो रहा है…',
  'marketplace.help': 'प्रोफ़ाइल सहायता',
  'marketplace.needsProfile':
    'पहले सत्र की विंडो में अपनी प्रोफ़ाइल खोलें। लॉगिन और जाँच पेज प्रोफ़ाइल के रूप में नहीं सहेजे जा सकते।',
  'marketplace.sessionClosed':
    'सत्र की विंडो बंद है। प्रोफ़ाइल सहेजने के लिए उसे फिर खोलें।',
  'marketplace.pageChanged':
    'पढ़ते समय पेज बदल गया। अपनी प्रोफ़ाइल खोलकर फिर कोशिश करें।',
  'marketplace.browserUnavailable':
    'सर्वर पर ब्राउज़र सुविधा उपलब्ध नहीं है। वहाँ browser-commander और Playwright इंस्टॉल करके फिर कोशिश करें।',
  'marketplace.serverRequired':
    'साइन इन और प्रोफ़ाइल सहेजने के लिए अपडेट किए गए लोकल सर्वर से जुड़ें।',
  'marketplace.failed':
    'कार्य पूरा नहीं हो सका। सत्र की विंडो जाँचकर फिर कोशिश करें।',
  'operator.loading': 'अपठित बातचीत लोड हो रही हैं…',
  'operator.checking': 'Telegram से अपठित स्थिति जाँची जा रही है…',
  'operator.title': 'ऑपरेटर',
  'operator.next': 'अगला (N)',
  'operator.done': 'पूरा (D)',
  'operator.progress': '{current} / {total}',
  'contacts.title': 'संपर्क ({count})',
  'contacts.identity': 'पहचान',
  'contacts.networks': 'नेटवर्क',
  'contacts.chats': 'चैट',
  'contacts.messages': 'संदेश',
  'contacts.lastSeen': 'पिछली बार देखा',
  'contacts.actions': 'कार्रवाइयाँ',
  'contacts.message': 'संदेश',
  'contacts.messageTo': '{name} को संदेश',
  'contacts.addressBook': 'पता पुस्तिका',
  'contacts.showMore': 'और दिखाएँ ({count} शेष)',
  'contacts.import.title': 'संपर्क आयात करें',
  'contacts.import.hint':
    'इस Mac के Contacts से आयात करें, जिनमें synced iCloud, Google और Exchange accounts शामिल हैं, या vCard (.vcf) export चुनें। सहेजने से पहले समीक्षा करें। संपर्क किसी messaging service पर अपलोड नहीं होते।',
  'contacts.import.system': 'macOS / iCloud संपर्क',
  'contacts.import.vcard': 'vCard फ़ाइल चुनें',
  'contacts.import.server': 'संपर्क आयात के लिए नवीनतम local server चाहिए।',
  'contacts.import.permission':
    'macOS permission prompt या System Settings → Privacy & Security → Contacts में app को Contacts access दें, फिर दोबारा कोशिश करें।',
  'contacts.import.expired':
    'पूर्वावलोकन की समय सीमा समाप्त हुई। संपर्कों का फिर पूर्वावलोकन करें।',
  'contacts.import.unavailable':
    'System Contacts macOS पर उपलब्ध है। अन्य systems पर vCard export आयात करें।',
  'contacts.import.tooLarge': 'अधिकतम 10 MB की vCard फ़ाइल चुनें।',
  'contacts.import.failed': 'संपर्क आयात नहीं हो सके: {error}',
  'contacts.import.summary':
    '{created} नए, {updated} अपडेट, {skipped} अपरिवर्तित या छोड़े गए।',
  'contacts.import.apply': '{count} संपर्क आयात करें',
  'contacts.import.cancel': 'रद्द करें',
  'contacts.import.reading':
    'संपर्क पढ़े जा रहे हैं… macOS अनुमति माँग सकता है।',
  'contacts.import.importing': 'संपर्क सहेजे जा रहे हैं…',
  'contacts.import.done': '{count} संपर्क आयात किए गए।',
  'contacts.refresh': 'संपर्क रीफ़्रेश करें',
  'contacts.search': 'संपर्क खोजें',
  'automation.title': 'स्वचालन ग्राफ़',
  'automation.edges': '{count} किनारे',
  'patterns.title': 'पैटर्न',
  'patterns.inferTitle': 'उदाहरणों से रेगेक्स निकालें',
  'patterns.examplesPlaceholder': 'हर पंक्ति में एक उदाहरण',
  'patterns.modeSimple': 'सरल',
  'patterns.modeLcs': 'lcs (परिवर्तनशील अंतराल)',
  'patterns.idPlaceholder': 'पैटर्न ID (जैसे greet)',
  'patterns.labelPlaceholder': 'लेबल',
  'patterns.colId': 'ID',
  'patterns.colRegex': 'रेगेक्स',
  'replies.title': 'जवाब विविधता समूह',
  'replies.newTitle': 'नया / अद्यतन समूह',
  'replies.idPlaceholder': 'समूह ID (जैसे thanks)',
  'replies.variationsPlaceholder': 'हर पंक्ति में एक विविधता',
  'replies.saveGroup': 'समूह सहेजें',
  'facts.title': 'तथ्य ({count})',
  'facts.colQuestion': 'प्रश्न',
  'facts.colAnswer': 'उत्तर',
  'facts.colPattern': 'पैटर्न',
  'audience.title': 'श्रोता निर्माता',
  'audience.hint':
    'ऑपरेटर: AND, OR, NOT, कोष्ठक। आयाम: network:, chat:, sender:, kind:, fact:',
  'audience.queryPlaceholder': 'जैसे network:telegram AND chat:general',
  'audience.contactsCount': '{count} संपर्क',
  'broadcast.title': 'प्रसारण',
  'broadcast.sending': 'भेजा जा रहा है…',
  'broadcast.sent': 'भेज दिया गया।',
  'broadcast.partial': 'कुछ गंतव्यों पर भेजा गया। बाकी परिणाम देखें।',
  'broadcast.failed': 'इस प्रयास में नहीं भेजा गया।',
  'broadcast.unknown':
    'डिलीवरी अनिश्चित है। फिर प्रयास करने से पहले गंतव्य जांचें।',
  'broadcast.queued': 'कतार में; डिलीवरी की पुष्टि नहीं हुई है।',
  'broadcast.cancelled': 'रद्द किया गया।',
  'broadcast.unavailable':
    'भेजने के लिए समर्थित सर्वर जोड़ें। कतार में कुछ नहीं जोड़ा गया।',
  'broadcast.counts':
    '{sent} भेजे · {failed} नहीं भेजे · {unknown} अनिश्चित · {queued} कतार में',
  'broadcast.placeholder': 'चुने गए सभी नेटवर्क के लिए संदेश',
  'outreach.title': 'पहुँच',
  'outreach.hint':
    'सामूहिक-व्यक्तिगत पहुँच। पूर्वावलोकन हमेशा; क़तार वास्तव में भेजती है।',
  'outreach.queryPlaceholder':
    'श्रोता क्वेरी, जैसे network:telegram AND chat:vip',
  'outreach.bodyPlaceholder':
    'मुख्य पाठ। हर प्राप्तकर्ता के लिए वैयक्तिक करने हेतु {name}, {networks}, {chats} का उपयोग करें।',
  'profile.title': 'प्रोफ़ाइल',
  'profile.namePlaceholder': 'नाम',
  'profile.bioPlaceholder': 'परिचय',
  'profile.saveProfile': 'प्रोफ़ाइल सहेजें',
  'profile.resumeTitle': 'रिज़्यूमे',
  'profile.titlePlaceholder': 'पदनाम',
  'profile.bodyPlaceholder': 'अनुभव',
  'profile.saveResume': 'रिज़्यूमे सहेजें',
  'backup.title': 'बैकअप',
  'backup.hint':
    'संग्रह सर्वर स्टोर निर्देशिका में रहते हैं। टोकन और सेशन (गुप्त लिंक) केवल एन्क्रिप्टेड बैकअप में शामिल होते हैं: पासफ़्रेज़ लिखें या सर्वर को MS_SECRET_PASSPHRASE के साथ चलाएँ। सामान्य बैकअप में वे नहीं होते।',
  'backup.passphrasePlaceholder': 'वैकल्पिक पासफ़्रेज़',
  'backup.keepPlaceholder': 'N रखें (वैकल्पिक)',
  'backup.create': 'बैकअप बनाएँ',
  'backup.restore': 'पुनर्स्थापित करें',
  'backup.itemMeta': '{size} बाइट — {timestamp} — {state}',
  'backup.encrypted': 'एन्क्रिप्टेड',
  'backup.plain': 'सादा',
  'status.title': 'स्थिति',
  'settings.title': 'सेटिंग्स',
  'settings.intro':
    'ऐप-स्तरीय प्राथमिकताएँ यहाँ रहती हैं। प्रदाता क्रेडेंशियल, संग्रह आयात और लाइव जाँचें समर्पित कनेक्शन स्क्रीन पर रहती हैं।',
  'settings.openConnections': 'कनेक्शन खोलें',
  'settings.credentials': 'क्रेडेंशियल',
  'settings.optional': '(वैकल्पिक)',
  'settings.storedAs': '{id} के रूप में संग्रहीत',
  'settings.saveCredentials': 'क्रेडेंशियल सहेजें',
  'settings.saving': 'सहेज रहा है...',
  'settings.saved': 'सहेजा गया।',
  'settings.forget': 'भूल जाएँ',
  'settings.forgetting': '{label} भुलाया जा रहा है...',
  'settings.forgotten': '{label} भुला दिया।',
  'settings.archive': 'संग्रह आयात',
  'settings.archivePasteHint': 'या नीचे संग्रह की सामग्री चिपकाएँ:',
  'settings.archivePastePlaceholder': 'यहाँ संग्रह की सामग्री चिपकाएँ',
  'settings.archivePasteWith': '{label} की सामग्री चिपकाएँ',
  'settings.importPasted': 'चिपकाई सामग्री आयात करें',
  'settings.uploading': '{label} लोकल सर्वर को भेजी जा रही है... {percent}%',
  'settings.importing': '{label} आयात हो रहा है...',
  'settings.importedCount': '{label} से {count} संदेश आयात किए।',
  'settings.importFailed': 'आयात विफल: {message}',
  'settings.nothingToImport': 'आयात करने के लिए कुछ नहीं है।',
  'settings.docsLink': 'क्रेडेंशियल कैसे प्राप्त करें ↗',
  'settings.credentialsSaved': 'क्रेडेंशियल सहेजे गए',
  'settings.noCredentials': 'अभी कोई क्रेडेंशियल नहीं',
  'settings.probe.idle': 'एंडपॉइंट: {url}',
  'settings.probe.notReady': 'जाँच सक्षम करने के लिए टोकन दर्ज करें',
  'settings.probe.button': 'सीधे आज़माएँ',
  'settings.probe.probing': 'जाँच रहा है...',
  'settings.probe.connected': 'जुड़ा (HTTP {status})',
  'settings.probe.httpHint': 'API ने {status} लौटाया। {hint}',
  'settings.probe.httpNoHint': 'API ने {status} लौटाया।',
  'settings.probe.cors':
    'ब्राउज़र ने अनुरोध रोका (CORS)। नीचे लोकल सर्वर शुरू करें ताकि कॉल प्रॉक्सी हो सके।',
  'settings.probe.network': 'नेटवर्क त्रुटि: {message}।',
  'settings.probe.fetchFailed': 'fetch विफल',
  'guide.connectFirstHint': 'पहले प्रदाता जोड़ें, तभी यहाँ डेटा दिखेगा।',
  'guide.openSettings': '{target} खोलें',
  'guide.openSettingsTarget': 'कनेक्शन → {label}',
  'guide.openSettingsRoot': 'कनेक्शन',
  'guide.openConnections': '{target} खोलें',
  'guide.openConnectionsTarget': 'कनेक्शन → {label}',
  'guide.openConnectionsRoot': 'कनेक्शन',
  'guide.probeDisabled':
    '{label} जाँच सक्षम करने के लिए कनेक्शन में क्रेडेंशियल दर्ज करें।',
  'guide.useThisServer': 'इस सर्वर का उपयोग करें',
  'guide.fallbackTitle': 'यहाँ अभी कुछ नहीं है।',
  'guide.filesLabel': 'फ़ाइलें: {hint}',
  'guide.envVarLabel': 'पर्यावरण चर: {name}',
  'guide.localServer.title':
    'इस प्रदाता को अनलॉक करने के लिए लोकल सर्वर शुरू करें',
  'guide.localServer.body':
    'समान-मूल लोकल सर्वर प्रदाता अनुरोध को प्रॉक्सी करता है और ब्राउज़र के CORS नियम को बायपास करता है। अपना उपलब्ध रनटाइम चुनें।',
  'guide.localServer.rust': 'Rust (अनुशंसित)',
  'guide.localServer.rustHint':
    'इस रिपॉज़िटरी की शुद्ध-Rust बाइनरी का उपयोग करता है। डिफ़ॉल्ट http://127.0.0.1:8787।',
  'guide.localServer.node': 'Node / Bun / Deno',
  'guide.localServer.nodeHint':
    'पब्लिश किए गए JS सर्वर का पुनः उपयोग करता है। डिफ़ॉल्ट http://127.0.0.1:8787।',
  'guide.localServer.github': 'सीधे GitHub से',
  'guide.localServer.githubHint':
    'जब तक npm 404 देता है, इसका उपयोग करें: npx वही सर्वर GitHub रिपॉज़िटरी से लाता है। डिफ़ॉल्ट http://127.0.0.1:8787।',
  'guide.localServer.docker': 'Docker',
  'guide.localServer.dockerHint':
    'कंटेनर में वही JS सर्वर शुरू करता है। docker/web.Dockerfile देखें।',
  'guide.localServer.overrideHint':
    'सर्वर चलने के बाद, उसका URL नीचे चिपकाएँ और "इस सर्वर का उपयोग करें" क्लिक करें — SPA उसे संग्रहीत करेगा और पुनः लोड होगा।',
  'guide.chat.title': 'आपका एकीकृत इनबॉक्स खाली है।',
  'guide.chat.body':
    'meta-sovereign हर जुड़ी सेवा की हर चैट को एक जगह रखता है। कनेक्शन खोलकर प्रदाता जोड़ें या निर्यात संग्रह आयात करें, फिर यहाँ लौटें।',
  'guide.operator.title': 'ऑपरेटर क़तार खाली है।',
  'guide.operator.body':
    'ऑपरेटर कार्ड स्ट्रीम आपको चैट-दर-चैट अपठित संदेशों के बीच ले जाती है। कनेक्शन खोलकर चैट-सक्षम प्रदाता जोड़ें।',
  'guide.contacts.title': 'अभी कोई संपर्क नहीं।',
  'guide.contacts.body':
    'संपर्क सभी जुड़े प्रदाताओं से एकत्रित होते हैं ताकि नेटवर्क में एक ही व्यक्ति केवल एक बार दिखे। सूची भरने के लिए कनेक्शन में प्रदाता जोड़ें।',
  'guide.automation.title': 'अभी कोई स्वचालन ग्राफ़ नहीं।',
  'guide.automation.body':
    'स्वचालन ग्राफ़ आने वाले संदेशों को पैटर्न से जवाब विविधता तक रूट करते हैं। स्वचालन बनाने से पहले कनेक्शन में प्रदाता डेटा आयात करें।',
  'guide.patterns.title': 'अभी कोई पैटर्न नहीं।',
  'guide.patterns.body':
    'पैटर्न उदाहरण संदेशों से निकाले जाते हैं। कनेक्शन खोलकर प्रदाता जोड़ें या संग्रह आयात करें, फिर उदाहरणों के साथ लौटें।',
  'guide.replies.title': 'अभी कोई जवाब विविधता समूह नहीं।',
  'guide.replies.body':
    'जवाब समूह आपके पिछले बाहर जाने वाले संदेशों से धुँधली समानता द्वारा निकाले जाते हैं। जवाब लाइब्रेरी भरने के लिए कनेक्शन में चैट-सक्षम प्रदाता जोड़ें।',
  'guide.facts.title': 'अभी कोई तथ्य नहीं निकाले।',
  'guide.facts.body':
    'तथ्य आपके पैटर्न द्वारा संदेशों में पाए गए "प्रश्न -> उत्तर" युग्म हैं। कनेक्शन में डेटा जोड़ें, फिर यहाँ कैप्चर पैटर्न बनाएँ।',
  'guide.audience.title': 'अपना पहला श्रोता बनाएँ।',
  'guide.audience.body':
    'AND/OR/NOT तथा network:, chat:, sender:, kind:, fact: जैसे आयामों से संपर्कों को क्रॉस-रेफरेंस करें। पहले कनेक्शन में कम से कम एक प्रदाता जोड़ें।',
  'guide.broadcast.title': 'अभी कोई प्रसारण लक्ष्य नहीं।',
  'guide.broadcast.body':
    'प्रसारण समान संदेश हर जुड़े फ़ीड पर पोस्ट करते हैं। लक्ष्य चेकबॉक्स सक्षम करने के लिए कनेक्शन में सार्वजनिक-पोस्टिंग प्रदाता जोड़ें।',
  'guide.outreach.title': 'अभी कोई पहुँच लक्ष्य नहीं।',
  'guide.outreach.body':
    'सामूहिक-व्यक्तिगत पहुँच श्रोता क्वेरी के हर संपर्क को टेम्प्लेटयुक्त संदेश 1:1 भेजती है। कनेक्शन में चैट-सक्षम प्रदाता जोड़ें।',
  'guide.profile.title': 'अभी कोई प्रोफ़ाइल नहीं।',
  'guide.profile.body':
    'अपनी प्रोफ़ाइल और रिज़्यूमे यहाँ संपादित करें; सहेजने पर हर जुड़े प्रदाता तक पुश हो जाते हैं। प्रोफ़ाइल सिंक के लिए कनेक्शन में कम से कम एक प्रदाता जोड़ें।',
  'guide.backup.title': 'अभी कोई बैकअप संग्रह नहीं।',
  'guide.backup.body':
    'बैकअप लोकल स्टोर के एन्क्रिप्टेड-एट-रेस्ट संग्रह हैं। ऊपर पासफ़्रेज़ सेट करें, सहेजने योग्य डेटा होने पर "बैकअप बनाएँ" क्लिक करें, या डिस्क पर बैकअप रखने के लिए पहले लोकल सर्वर शुरू करें।',
  'guide.status.title': 'स्थिति केवल लोकल स्टोर दिखा रही है।',
  'guide.status.body':
    'स्थिति फ़ील्ड तब दिखती हैं जब सर्वर पहुँच में हो। नीचे लोकल सर्वर शुरू करें, या पूरी तरह ऑफ़लाइन काम करते रहें — SPA सीधे ब्राउज़र स्टोर में लिखता है।',
  'guide.connections.title': 'कनेक्शन',
  'guide.connections.body':
    'बाहरी सेवाएँ इस अलग स्क्रीन पर रहती हैं। प्रदाता चुनें ताकि उसके क्रेडेंशियल दर्ज करें, संग्रह अपलोड करें और लाइव API जाँचें। सेटिंग्स में केवल ऐप-स्तरीय वरीयताएँ रहती हैं।',
  'guide.cv.title': 'CV सिंक्रनाइज़ेशन',
  'guide.cv.body':
    'यह स्क्रीन आपके जॉब-प्लेटफ़ॉर्म प्रोफ़ाइलों पर एक वास्तविक ब्राउज़र सत्र चलाती है: यह हर CV को पढ़ती है, उनकी फ़ील्ड-दर-फ़ील्ड तुलना करती है, और तभी लिखती है जब आप सिंक लागू करते हैं। स्थानीय सर्वर जिस ब्राउज़र प्रोफ़ाइल का उपयोग करता है, उसमें हर प्लेटफ़ॉर्म पर एक बार साइन इन करें — इनमें से अधिकांश बोर्ड के लिए कोई API कुंजी मौजूद ही नहीं है।',
  'guide.greetings.title': 'स्टिकर',
  'guide.greetings.body':
    'जैसे konard/vk-bot VK पर करता है, वैसे ही "हाय" या अभिवादन स्टिकर से एक साथ कई बातचीत शुरू करें। पहले कोई नेटवर्क जोड़ें: स्टिकर की लाइव सूची और भेजना, दोनों लोकल सर्वर में रखे टोकन का उपयोग करते हैं।',
  'guide.settings.title': 'सेटिंग्स',
  'guide.settings.body':
    'ऐप-स्तरीय प्राथमिकताएँ यहाँ रहती हैं। प्रदाता क्रेडेंशियल, संग्रह आयात और लाइव जाँचें समर्पित कनेक्शन स्क्रीन पर रहती हैं।',
  'connections.title': 'कनेक्शन',
  'connections.intro':
    '"ब्राउज़र से आयात करें" से शुरू करें: ऐप सेवा खोलता है, आप वहाँ अपना डेटा डाउनलोड करते हैं, और वह अपने आप आयात हो जाता है। सबसे ज़्यादा इस्तेमाल होने वाली सेवाएँ सबसे ऊपर हैं।',
  'connections.state.connected': 'जुड़ा',
  'connections.state.notConnected': 'जुड़ा नहीं',
  'connections.state.actionRequired': 'कार्रवाई आवश्यक',
  'connections.state.browserSession': 'ब्राउज़र सत्र',
  'connections.session.login': 'साइन-इन पृष्ठ खोलें',
  'connections.session.profile': 'प्रोफ़ाइल पृष्ठ खोलें',
  'connections.session.openCv': 'CV स्क्रीन खोलें',
  'connections.openDetail': 'सेट अप',
  'connections.controlsTitle': 'कनेक्शन नियंत्रण',
  'autoImport.title': 'ब्राउज़र से आयात करें',
  'autoImport.intro':
    '{service} को एक अलग ब्राउज़र विंडो में खोलता है। साइन इन करें, वहाँ डेटा एक्सपोर्ट शुरू करें, और डाउनलोड की गई हर फ़ाइल अपने आप आयात हो जाएगी। अगली बार के लिए आप साइन इन रहेंगे।',
  'autoImport.introCapture':
    '{service} को एक अलग ब्राउज़र विंडो में खोलता है। साइन इन करें, कोई चैट खोलें और "यह चैट सहेजें" दबाएँ। डाउनलोड की गई एक्सपोर्ट फ़ाइलें भी अपने आप आयात होती हैं।',
  'autoImport.start': 'ब्राउज़र खोलें',
  'autoImport.capture': 'यह चैट सहेजें',
  'autoImport.finish': 'समाप्त',
  'autoImport.state.launching': 'ब्राउज़र खुल रहा है…',
  'autoImport.state.waiting':
    'ब्राउज़र खुला है। आपके एक्सपोर्ट की प्रतीक्षा है…',
  'autoImport.state.importing': 'आयात हो रहा है…',
  'autoImport.state.done': 'समाप्त।',
  'autoImport.state.stopped': 'लंबे विराम के बाद रोका गया।',
  'autoImport.state.failed': 'ब्राउज़र नहीं खुल सका: {error}',
  'autoImport.imported': 'आयात किए गए संदेश: {count}',
  'autoImport.unavailable':
    'ब्राउज़र से आयात के लिए इस कंप्यूटर पर meta-sovereign सर्वर चलना चाहिए।',
  'autoImport.unavailableReason': 'ब्राउज़र से आयात उपलब्ध नहीं है: {reason}',
  'common.cancelled': 'रद्द किया गया। कुछ भी नहीं भेजा गया।',
  'outreach.send': 'भेजें',
  'outreach.confirmSend': 'इन लोगों को अभी {count} संदेश भेजें?',
  'greetings.confirmSend': 'अभी {count} अभिवादन भेजें?',
  'cv.confirmApply': 'जॉब प्लेटफ़ॉर्म पर आपके CV में अभी {count} बदलाव लिखें?',
  'profile.savedLocally':
    'इस डिवाइस पर सहेजा गया। दूसरी सेवाओं पर कुछ नहीं बदला।',
  'profile.publishTitle': 'दूसरी सेवाओं पर अपडेट करें',
  'profile.publishHint':
    'सहेजने से आपकी प्रोफ़ाइल और CV यहीं रहते हैं। उन्हें दूसरी सेवाओं पर बदलने के लिए नेटवर्क चुनें और बदलावों की पुष्टि करें।',
  'profile.publish.profile': 'वहाँ प्रोफ़ाइल अपडेट करें',
  'profile.publish.resume': 'वहाँ CV अपडेट करें',
  'profile.confirmPublish.profile':
    '{networks} पर अपनी प्रोफ़ाइल अपडेट करें? वहाँ लोग बदलाव देखेंगे।',
  'profile.confirmPublish.resume':
    '{networks} पर अपना CV अपडेट करें? वहाँ नियोक्ता बदलाव देखेंगे।',
  'settings.privacy.title': 'गोपनीयता',
  'settings.shareTyping': 'दूसरों को दिखाएँ कि मैं टाइप कर रहा हूँ',
  'settings.shareTypingHint':
    'डिफ़ॉल्ट रूप से बंद। चालू होने पर VK और Telegram उस व्यक्ति को "टाइप कर रहे हैं…" दिखाते हैं जिसे आप लिख रहे हैं।',
  'settings.readReceipts': 'चैट पढ़ने पर उसे पढ़ा हुआ चिह्नित करें',
  'settings.readReceiptsHint':
    'डिफ़ॉल्ट रूप से चालू, जैसे Telegram के अपने ऐप में। बंद होने पर यहाँ चैट पढ़ने से Telegram पर वह पढ़ी हुई नहीं मानी जाती: भेजने वाले को ✓✓ नहीं दिखता और अपठित गिनती बनी रहती है।',
  'settings.notify.title': 'सूचनाएँ',
  'settings.notify.on': 'नए संदेश सूचनाओं के रूप में दिखाएँ',
  'settings.notify.preview': 'भेजने वाला और पाठ दिखाएँ',
  'settings.notify.count': 'पेज के शीर्षक में अपठित संख्या',
  'settings.notify.granted': 'यह ब्राउज़र इस पेज की सूचनाएँ दिखाता है।',
  'settings.notify.default':
    'जब आप सूचनाएँ चालू करेंगे, ब्राउज़र अनुमति माँगेगा।',
  'settings.notify.denied':
    'ब्राउज़र की सेटिंग में इस पेज की सूचनाएँ अवरुद्ध हैं।',
  'settings.notify.unsupported': 'यह ब्राउज़र सूचनाएँ नहीं दिखा सकता।',
  // Telegram notification settings (R-Y157).
  'settings.notifyTg.title': 'Telegram सूचनाएँ',
  'settings.notifyTg.intro':
    'आपके Telegram खाते में रखी जाती हैं, इसलिए आपके अन्य डिवाइस भी इनका पालन करते हैं।',
  'settings.notifyTg.users': 'निजी चैट',
  'settings.notifyTg.chats': 'समूह',
  'settings.notifyTg.broadcasts': 'चैनल',
  'settings.notifyTg.on': 'सूचनाएँ',
  'settings.notifyTg.preview': 'संदेश पूर्वावलोकन',
  'settings.notifyTg.stories': 'स्टोरी सूचनाएँ',
  'settings.notifyTg.exceptions': 'अपवाद: {count}',
  'settings.notifyTg.noExceptions': 'कोई अपवाद नहीं',
  'settings.notifyTg.muted': 'म्यूट',
  'settings.notifyTg.mutedUntil': '{time} तक म्यूट',
  'settings.notifyTg.unmuted': 'अनम्यूट',
  'settings.notifyTg.custom': 'कस्टम',
  'settings.notifyTg.failed': 'Telegram ने बदलाव स्वीकार नहीं किया।',
  'connections.enterManually': 'हाथ से दर्ज करें',
  'connections.howToConnect': 'कैसे कनेक्ट करें',
  'connections.recommended': 'अनुशंसित',
  'connections.users': '{count} उपयोगकर्ता',
  'connections.signedInFrom': '{browsers} में साइन इन',
  'autoImport.signedInFrom': 'विंडो {browsers} के आपके साइन-इन के साथ खुलेगी।',
  'signIns.title': 'अपने ब्राउज़र के साइन-इन इस्तेमाल करें',
  'signIns.intro':
    'देखें कि Chrome, Safari, Firefox और दूसरे ब्राउज़र में आप किन सेवाओं में पहले से साइन इन हैं, और आयात विंडो साइन इन के साथ खोलें। आपके ब्राउज़र सिर्फ़ पढ़े जाते हैं, और कुछ भी इस कंप्यूटर से बाहर नहीं जाता।',
  'signIns.scan': 'साइन-इन खोजें',
  'signIns.rescan': 'फिर से देखें',
  'signIns.scanning': 'आपके ब्राउज़र देखे जा रहे हैं…',
  'signIns.none': 'इस कंप्यूटर पर कोई ब्राउज़र नहीं मिला।',
  'signIns.default': 'डिफ़ॉल्ट ब्राउज़र',
  'signIns.found': 'साइन इन: {services}',
  'signIns.nothing': 'इनमें से किसी सेवा में साइन इन नहीं',
  'signIns.needsAccess': 'पूर्ण डिस्क एक्सेस चाहिए',
  'signIns.error': 'पढ़ा नहीं जा सका: {error}',
  'signIns.use': 'ये साइन-इन इस्तेमाल करें',
  'signIns.importing':
    'साइन-इन कॉपी हो रहे हैं… आपका ब्राउज़र या macOS अनुमति माँग सकता है।',
  'signIns.ready': 'तैयार: {services}। हर आयात विंडो साइन इन के साथ खुलेगी।',
  'signIns.readyNone': 'कोई साइन-इन कॉपी नहीं हुआ।',
  'signIns.fdaTitle': 'Safari तक पहुँच की अनुमति दें',
  'signIns.fdaBody':
    'macOS Safari का डेटा सुरक्षित रखता है। System Settings → Privacy & Security → Full Disk Access में {app} चालू करें, फिर meta-sovereign सर्वर दोबारा शुरू करें।',
  'signIns.fdaOpen': 'System Settings खोलें',

  // इस कंप्यूटर पर Telegram साइन-इन (बॉट टोकन और उपयोगकर्ता सेशन) खोजें।
  'telegramSessions.title': 'इस कंप्यूटर पर Telegram सेशन खोजें',
  'telegramSessions.intro':
    'आपके प्रोजेक्ट फ़ोल्डरों में पहले से मौजूद Telegram साइन-इन — बॉट टोकन और उपयोगकर्ता सेशन — ढूँढ़ता है, दोहराव हटाता है, जाँचता है कि हर एक अब भी काम करता है, और प्रति खाता एक दिखाता है। सब कुछ इसी कंप्यूटर पर रहता है; जोड़ते केवल आप हैं।',
  'telegramSessions.scan': 'मेरे Telegram सेशन खोजें',
  'telegramSessions.rescan': 'फिर देखें',
  'telegramSessions.scanning': 'आपके सेशन ढूँढ़ और जाँच रहा हूँ…',
  'telegramSessions.none': 'उन फ़ोल्डरों में कोई Telegram साइन-इन नहीं मिला।',
  'telegramSessions.connect': 'जोड़ें',
  'telegramSessions.kindBot': 'बॉट टोकन',
  'telegramSessions.kindUser': 'उपयोगकर्ता सेशन',
  'telegramSessions.kindTelethon': 'Telethon सेशन फ़ाइल',
  'telegramSessions.badgeBot': 'बॉट',
  'telegramSessions.badgeUser': 'उपयोगकर्ता',
  'telegramSessions.verified': 'Telegram से पुष्टि',
  'telegramSessions.telethonHint': 'साइन इन करने के लिए यह प्रोजेक्ट खोलें',
  'telegramSessions.typeBot': 'बॉट टोकन',
  'telegramSessions.typeSession': 'सेशन से लॉगिन',
  'telegramSessions.typePassword': 'फ़ोन और पासवर्ड से लॉगिन',
  'telegramSessions.more': '+{n} और',
  'telegramSessions.less': 'कम दिखाएँ',
  'telegramSessions.signIn': 'साइन इन करें',
  'telegramSessions.connected': 'कनेक्ट हो गया',
  'telegramSessions.unconfirmed':
    'सेशन आयात की पुष्टि नहीं हुई। आपका पिछला कनेक्शन सुरक्षित है; Telegram जाँचकर फिर प्रयास करें।',

  // MTProto (GramJS) के ज़रिये अपने Telegram यूज़र खाते में साइन इन, konard/telegram-bot की तरह।
  'telegramLogin.title': 'अपने Telegram खाते से लॉग इन करें',
  'telegramLogin.intro':
    'Telegram Desktop की तरह फ़ोन से साइन इन करें — api_id, api_hash और आपका नंबर, फिर Telegram द्वारा भेजा कोड (और 2FA पासवर्ड यदि हो)। सेशन अगली बार के लिए यहाँ सहेजा जाता है।',
  'telegramLogin.apiId': 'API ID',
  'telegramLogin.apiHash': 'API hash',
  'telegramLogin.phone': 'फ़ोन नंबर',
  'telegramLogin.code': 'लॉगिन कोड',
  'telegramLogin.password': '2FA पासवर्ड (यदि हो)',
  'telegramLogin.sendCode': 'कोड भेजें',
  'telegramLogin.signIn': 'साइन इन',
  'telegramLogin.working': 'काम जारी…',
  'telegramLogin.connected': 'साइन इन हो गया',
  'telegramLogin.you': 'आपका खाता',
  'telegramLogin.codeSent':
    'Telegram ने आपके ऐप में एक कोड भेजा है। उसे नीचे दर्ज करें।',
  'telegramLogin.twoFactor':
    'आपके खाते में 2FA पासवर्ड है। पूरा करने के लिए उसे दर्ज करें।',
  // Sign in by QR code (R-Y203)
  'telegramLogin.byQr': 'QR कोड से लॉग इन करें',
  'telegramLogin.byPhone': 'फ़ोन नंबर से लॉग इन करें',
  'telegramLogin.qrStart': 'QR कोड दिखाएँ',
  'telegramLogin.qrAlt': 'Telegram में लॉग इन करने का QR कोड',
  'telegramLogin.qrTitle': 'QR कोड से Telegram में लॉग इन करें',
  'telegramLogin.qrStep1': 'अपने फ़ोन पर Telegram खोलें',
  'telegramLogin.qrStep2':
    'सेटिंग > डिवाइस > डेस्कटॉप डिवाइस लिंक करें पर जाएँ',
  'telegramLogin.qrStep3':
    'लॉगिन की पुष्टि के लिए अपने फ़ोन को इस स्क्रीन की ओर करें',
  'telegramLogin.qrWaiting': 'आपके कोड स्कैन करने की प्रतीक्षा है…',
  // BEGIN setup-steps (issue #25 R-N8) — auto-generated
  'connections.email.setup.step1.title': 'Email क्रेडेंशियल तैयार करें',
  'connections.email.setup.step1.body':
    'नीचे दिए गए दस्तावेज़ खोलें और सेवा की आवश्यकता के अनुसार API टोकन, OAuth क्रेडेंशियल या डेवलपर कुंजी बनाएँ।',
  'connections.email.setup.step2.title': 'meta-sovereign में सहेजें',
  'connections.email.setup.step2.body':
    'क्रेडेंशियल को इस स्क्रीन पर फ़ील्ड में चिपकाएँ। यह `secret:*` कुंजी के तहत सहेजा जाता है और कभी ब्राउज़र नहीं छोड़ता।',
  'connections.email.setup.step3.title': 'जाँच चलाएँ',
  'connections.email.setup.step3.body':
    '"कनेक्शन जाँचें" पर टैप करें — सफल उत्तर क्रेडेंशियल की पुष्टि करता है। विफल होने पर अगले कदम के साथ अनुवादित संकेत दिखेगा।',
  'connections.telegram.setup.step1.title': 'Telegram क्रेडेंशियल तैयार करें',
  'connections.telegram.setup.step1.body':
    'नीचे दिए गए दस्तावेज़ खोलें और सेवा की आवश्यकता के अनुसार API टोकन, OAuth क्रेडेंशियल या डेवलपर कुंजी बनाएँ।',
  'connections.telegram.setup.step2.title': 'meta-sovereign में सहेजें',
  'connections.telegram.setup.step2.body':
    'क्रेडेंशियल को इस स्क्रीन पर फ़ील्ड में चिपकाएँ। यह `secret:*` कुंजी के तहत सहेजा जाता है और कभी ब्राउज़र नहीं छोड़ता।',
  'connections.telegram.setup.step3.title': 'जाँच चलाएँ',
  'connections.telegram.setup.step3.body':
    '"कनेक्शन जाँचें" पर टैप करें — सफल उत्तर क्रेडेंशियल की पुष्टि करता है। विफल होने पर अगले कदम के साथ अनुवादित संकेत दिखेगा।',
  'connections.vk.setup.step1.title': 'VK क्रेडेंशियल तैयार करें',
  'connections.vk.setup.step1.body':
    'नीचे दिए गए दस्तावेज़ खोलें और सेवा की आवश्यकता के अनुसार API टोकन, OAuth क्रेडेंशियल या डेवलपर कुंजी बनाएँ।',
  'connections.vk.setup.step2.title': 'meta-sovereign में सहेजें',
  'connections.vk.setup.step2.body':
    'क्रेडेंशियल को इस स्क्रीन पर फ़ील्ड में चिपकाएँ। यह `secret:*` कुंजी के तहत सहेजा जाता है और कभी ब्राउज़र नहीं छोड़ता।',
  'connections.vk.setup.step3.title': 'जाँच चलाएँ',
  'connections.vk.setup.step3.body':
    '"कनेक्शन जाँचें" पर टैप करें — सफल उत्तर क्रेडेंशियल की पुष्टि करता है। विफल होने पर अगले कदम के साथ अनुवादित संकेत दिखेगा।',
  'connections.x.setup.step1.title': 'X (Twitter) क्रेडेंशियल तैयार करें',
  'connections.x.setup.step1.body':
    'नीचे दिए गए दस्तावेज़ खोलें और सेवा की आवश्यकता के अनुसार API टोकन, OAuth क्रेडेंशियल या डेवलपर कुंजी बनाएँ।',
  'connections.x.setup.step2.title': 'meta-sovereign में सहेजें',
  'connections.x.setup.step2.body':
    'क्रेडेंशियल को इस स्क्रीन पर फ़ील्ड में चिपकाएँ। यह `secret:*` कुंजी के तहत सहेजा जाता है और कभी ब्राउज़र नहीं छोड़ता।',
  'connections.x.setup.step3.title': 'जाँच चलाएँ',
  'connections.x.setup.step3.body':
    '"कनेक्शन जाँचें" पर टैप करें — सफल उत्तर क्रेडेंशियल की पुष्टि करता है। विफल होने पर अगले कदम के साथ अनुवादित संकेत दिखेगा।',
  'connections.whatsapp.setup.step1.title': 'WhatsApp क्रेडेंशियल तैयार करें',
  'connections.whatsapp.setup.step1.body':
    'नीचे दिए गए दस्तावेज़ खोलें और सेवा की आवश्यकता के अनुसार API टोकन, OAuth क्रेडेंशियल या डेवलपर कुंजी बनाएँ।',
  'connections.whatsapp.setup.step2.title': 'meta-sovereign में सहेजें',
  'connections.whatsapp.setup.step2.body':
    'क्रेडेंशियल को इस स्क्रीन पर फ़ील्ड में चिपकाएँ। यह `secret:*` कुंजी के तहत सहेजा जाता है और कभी ब्राउज़र नहीं छोड़ता।',
  'connections.whatsapp.setup.step3.title': 'जाँच चलाएँ',
  'connections.whatsapp.setup.step3.body':
    '"कनेक्शन जाँचें" पर टैप करें — सफल उत्तर क्रेडेंशियल की पुष्टि करता है। विफल होने पर अगले कदम के साथ अनुवादित संकेत दिखेगा।',
  'connections.facebook.setup.step1.title': 'Facebook क्रेडेंशियल तैयार करें',
  'connections.facebook.setup.step1.body':
    'नीचे दिए गए दस्तावेज़ खोलें और सेवा की आवश्यकता के अनुसार API टोकन, OAuth क्रेडेंशियल या डेवलपर कुंजी बनाएँ।',
  'connections.facebook.setup.step2.title': 'meta-sovereign में सहेजें',
  'connections.facebook.setup.step2.body':
    'क्रेडेंशियल को इस स्क्रीन पर फ़ील्ड में चिपकाएँ। यह `secret:*` कुंजी के तहत सहेजा जाता है और कभी ब्राउज़र नहीं छोड़ता।',
  'connections.facebook.setup.step3.title': 'जाँच चलाएँ',
  'connections.facebook.setup.step3.body':
    '"कनेक्शन जाँचें" पर टैप करें — सफल उत्तर क्रेडेंशियल की पुष्टि करता है। विफल होने पर अगले कदम के साथ अनुवादित संकेत दिखेगा।',
  'connections.linkedin.setup.step1.title': 'LinkedIn क्रेडेंशियल तैयार करें',
  'connections.linkedin.setup.step1.body':
    'नीचे दिए गए दस्तावेज़ खोलें और सेवा की आवश्यकता के अनुसार API टोकन, OAuth क्रेडेंशियल या डेवलपर कुंजी बनाएँ।',
  'connections.linkedin.setup.step2.title': 'meta-sovereign में सहेजें',
  'connections.linkedin.setup.step2.body':
    'क्रेडेंशियल को इस स्क्रीन पर फ़ील्ड में चिपकाएँ। यह `secret:*` कुंजी के तहत सहेजा जाता है और कभी ब्राउज़र नहीं छोड़ता।',
  'connections.linkedin.setup.step3.title': 'जाँच चलाएँ',
  'connections.linkedin.setup.step3.body':
    '"कनेक्शन जाँचें" पर टैप करें — सफल उत्तर क्रेडेंशियल की पुष्टि करता है। विफल होने पर अगले कदम के साथ अनुवादित संकेत दिखेगा।',
  'connections.habr-career.setup.step1.title':
    'career.habr.com क्रेडेंशियल तैयार करें',
  'connections.habr-career.setup.step1.body':
    'नीचे दिए गए दस्तावेज़ खोलें और सेवा की आवश्यकता के अनुसार API टोकन, OAuth क्रेडेंशियल या डेवलपर कुंजी बनाएँ।',
  'connections.habr-career.setup.step2.title': 'meta-sovereign में सहेजें',
  'connections.habr-career.setup.step2.body':
    'क्रेडेंशियल को इस स्क्रीन पर फ़ील्ड में चिपकाएँ। यह `secret:*` कुंजी के तहत सहेजा जाता है और कभी ब्राउज़र नहीं छोड़ता।',
  'connections.habr-career.setup.step3.title': 'जाँच चलाएँ',
  'connections.habr-career.setup.step3.body':
    '"कनेक्शन जाँचें" पर टैप करें — सफल उत्तर क्रेडेंशियल की पुष्टि करता है। विफल होने पर अगले कदम के साथ अनुवादित संकेत दिखेगा।',
  'connections.hh.setup.step1.title': 'hh.ru क्रेडेंशियल तैयार करें',
  'connections.hh.setup.step1.body':
    'नीचे दिए गए दस्तावेज़ खोलें और सेवा की आवश्यकता के अनुसार API टोकन, OAuth क्रेडेंशियल या डेवलपर कुंजी बनाएँ।',
  'connections.hh.setup.step2.title': 'meta-sovereign में सहेजें',
  'connections.hh.setup.step2.body':
    'क्रेडेंशियल को इस स्क्रीन पर फ़ील्ड में चिपकाएँ। यह `secret:*` कुंजी के तहत सहेजा जाता है और कभी ब्राउज़र नहीं छोड़ता।',
  'connections.hh.setup.step3.title': 'जाँच चलाएँ',
  'connections.hh.setup.step3.body':
    '"कनेक्शन जाँचें" पर टैप करें — सफल उत्तर क्रेडेंशियल की पुष्टि करता है। विफल होने पर अगले कदम के साथ अनुवादित संकेत दिखेगा।',
  'connections.github.setup.step1.title': 'GitHub क्रेडेंशियल तैयार करें',
  'connections.github.setup.step1.body':
    'नीचे दिए गए दस्तावेज़ खोलें और सेवा की आवश्यकता के अनुसार API टोकन, OAuth क्रेडेंशियल या डेवलपर कुंजी बनाएँ।',
  'connections.github.setup.step2.title': 'meta-sovereign में सहेजें',
  'connections.github.setup.step2.body':
    'क्रेडेंशियल को इस स्क्रीन पर फ़ील्ड में चिपकाएँ। यह `secret:*` कुंजी के तहत सहेजा जाता है और कभी ब्राउज़र नहीं छोड़ता।',
  'connections.github.setup.step3.title': 'जाँच चलाएँ',
  'connections.github.setup.step3.body':
    '"कनेक्शन जाँचें" पर टैप करें — सफल उत्तर क्रेडेंशियल की पुष्टि करता है। विफल होने पर अगले कदम के साथ अनुवादित संकेत दिखेगा।',
  'connections.upwork.setup.step1.title': 'Upwork क्रेडेंशियल तैयार करें',
  'connections.upwork.setup.step1.body':
    'नीचे दिए गए दस्तावेज़ खोलें और सेवा की आवश्यकता के अनुसार API टोकन, OAuth क्रेडेंशियल या डेवलपर कुंजी बनाएँ।',
  'connections.upwork.setup.step2.title': 'meta-sovereign में सहेजें',
  'connections.upwork.setup.step2.body':
    'क्रेडेंशियल को इस स्क्रीन पर फ़ील्ड में चिपकाएँ। यह `secret:*` कुंजी के तहत सहेजा जाता है और कभी ब्राउज़र नहीं छोड़ता।',
  'connections.upwork.setup.step3.title': 'जाँच चलाएँ',
  'connections.upwork.setup.step3.body':
    '"कनेक्शन जाँचें" पर टैप करें — सफल उत्तर क्रेडेंशियल की पुष्टि करता है। विफल होने पर अगले कदम के साथ अनुवादित संकेत दिखेगा।',
  'connections.peopleperhour.setup.step1.title':
    'PeoplePerHour क्रेडेंशियल तैयार करें',
  'connections.peopleperhour.setup.step1.body':
    'नीचे दिए गए दस्तावेज़ खोलें और सेवा की आवश्यकता के अनुसार API टोकन, OAuth क्रेडेंशियल या डेवलपर कुंजी बनाएँ।',
  'connections.peopleperhour.setup.step2.title': 'meta-sovereign में सहेजें',
  'connections.peopleperhour.setup.step2.body':
    'क्रेडेंशियल को इस स्क्रीन पर फ़ील्ड में चिपकाएँ। यह `secret:*` कुंजी के तहत सहेजा जाता है और कभी ब्राउज़र नहीं छोड़ता।',
  'connections.peopleperhour.setup.step3.title': 'जाँच चलाएँ',
  'connections.peopleperhour.setup.step3.body':
    '"कनेक्शन जाँचें" पर टैप करें — सफल उत्तर क्रेडेंशियल की पुष्टि करता है। विफल होने पर अगले कदम के साथ अनुवादित संकेत दिखेगा।',
  'connections.superjob.setup.step1.title': 'SuperJob क्रेडेंशियल तैयार करें',
  'connections.superjob.setup.step1.body':
    'नीचे दिए गए दस्तावेज़ खोलें और सेवा की आवश्यकता के अनुसार API टोकन, OAuth क्रेडेंशियल या डेवलपर कुंजी बनाएँ।',
  'connections.superjob.setup.step2.title': 'meta-sovereign में सहेजें',
  'connections.superjob.setup.step2.body':
    'क्रेडेंशियल को इस स्क्रीन पर फ़ील्ड में चिपकाएँ। यह `secret:*` कुंजी के तहत सहेजा जाता है और कभी ब्राउज़र नहीं छोड़ता।',
  'connections.superjob.setup.step3.title': 'जाँच चलाएँ',
  'connections.superjob.setup.step3.body':
    '"कनेक्शन जाँचें" पर टैप करें — सफल उत्तर क्रेडेंशियल की पुष्टि करता है। विफल होने पर अगले कदम के साथ अनुवादित संकेत दिखेगा।',
  'connections.naukri.setup.step1.title': 'ब्राउज़र ड्राइवर स्थापित करें',
  'connections.naukri.setup.step1.body':
    'Naukri कोई सार्वजनिक API प्रकाशित नहीं करता। स्थानीय सर्वर चलाने वाली मशीन पर Playwright स्थापित करें ताकि browser-commander एक वास्तविक सत्र चला सके।',
  'connections.naukri.setup.step2.title': 'एक बार साइन इन करें',
  'connections.naukri.setup.step2.body':
    'CV स्क्रीन खोलें और एक रीड चलाएँ। ब्राउज़र naukri.com खोलता है — वहाँ एक बार साइन इन करें; ब्राउज़र प्रोफ़ाइल निर्देशिका सत्र को सहेज लेती है।',
  'connections.naukri.setup.step3.title': 'पढ़ें, तुलना करें, सिंक करें',
  'connections.naukri.setup.step3.body':
    'CV पढ़ें, अन्य बोर्डों के साथ अंतर देखें, फिर सिंक की योजना बनाएँ। हर रन मार्कअप फ़िंगरप्रिंट के साथ cv:telemetry में दर्ज होता है, इसलिए टूटा हुआ सिलेक्टर आसानी से दिखता है।',
  'connections.vietnamworks.setup.step1.title': 'ब्राउज़र ड्राइवर स्थापित करें',
  'connections.vietnamworks.setup.step1.body':
    'VietnamWorks कोई सार्वजनिक API प्रकाशित नहीं करता। स्थानीय सर्वर चलाने वाली मशीन पर Playwright स्थापित करें ताकि browser-commander एक वास्तविक सत्र चला सके।',
  'connections.vietnamworks.setup.step2.title': 'एक बार साइन इन करें',
  'connections.vietnamworks.setup.step2.body':
    'CV स्क्रीन खोलें और एक रीड चलाएँ। ब्राउज़र vietnamworks.com खोलता है — वहाँ एक बार साइन इन करें; ब्राउज़र प्रोफ़ाइल निर्देशिका सत्र को सहेज लेती है।',
  'connections.vietnamworks.setup.step3.title': 'पढ़ें, तुलना करें, सिंक करें',
  'connections.vietnamworks.setup.step3.body':
    'CV पढ़ें, अन्य बोर्डों के साथ अंतर देखें, फिर सिंक की योजना बनाएँ। हर रन मार्कअप फ़िंगरप्रिंट के साथ cv:telemetry में दर्ज होता है, इसलिए टूटा हुआ सिलेक्टर आसानी से दिखता है।',
  'connections.topcv.setup.step1.title': 'ब्राउज़र ड्राइवर स्थापित करें',
  'connections.topcv.setup.step1.body':
    'TopCV कोई सार्वजनिक API प्रकाशित नहीं करता। स्थानीय सर्वर चलाने वाली मशीन पर Playwright स्थापित करें ताकि browser-commander एक वास्तविक सत्र चला सके।',
  'connections.topcv.setup.step2.title': 'एक बार साइन इन करें',
  'connections.topcv.setup.step2.body':
    'CV स्क्रीन खोलें और एक रीड चलाएँ। ब्राउज़र topcv.vn खोलता है — वहाँ एक बार साइन इन करें; ब्राउज़र प्रोफ़ाइल निर्देशिका सत्र को सहेज लेती है।',
  'connections.topcv.setup.step3.title': 'पढ़ें, तुलना करें, सिंक करें',
  'connections.topcv.setup.step3.body':
    'CV पढ़ें, अन्य बोर्डों के साथ अंतर देखें, फिर सिंक की योजना बनाएँ। हर रन मार्कअप फ़िंगरप्रिंट के साथ cv:telemetry में दर्ज होता है, इसलिए टूटा हुआ सिलेक्टर आसानी से दिखता है।',
  // END setup-steps
  'connections.back': 'कनेक्शन पर वापस',
  'connections.email.label': 'ईमेल',
  'connections.email.archive.title': '.eml या mbox मेल निर्यात आयात करें',
  'connections.email.archive.hint':
    'अपने प्रदाता से मेल को .eml फ़ाइल या mbox संग्रह के रूप में निर्यात करें (Gmail Takeout mbox फ़ाइल सहित; Takeout की .zip भी वैसे ही चलती है)। फ़ाइल को आयात बॉक्स में डालें और स्रोत "email" चुनें।',
  'connections.email.archive.fileHint': '*.eml, *.mbox',
  'connections.email.api.title': 'ईमेल API और प्रोटोकॉल जोड़ें',
  'connections.email.api.hint':
    'जब CORS अनुमति दे, सीधे ब्राउज़र से JMAP, Gmail API या Microsoft Graph का उपयोग करें। IMAP, POP3 और SMTP को लोकल सर्वर चाहिए क्योंकि ब्राउज़र कच्चे TCP/TLS मेल सॉकेट नहीं खोल सकते।',
  'connections.email.fields.token.label': 'OAuth एक्सेस टोकन',
  'connections.email.fields.host.label': 'IMAP/SMTP सर्वर',
  'connections.email.fields.username.label': 'लॉगिन (ईमेल पता)',
  'connections.email.fields.password.label': 'पासवर्ड या ऐप पासवर्ड',
  'connections.email.errorHints.401':
    'टोकन अस्वीकृत। gmail.readonly स्कोप के साथ नया OAuth टोकन जारी करें।',
  'connections.email.errorHints.403':
    'अपर्याप्त स्कोप। gmail.readonly या jmap अनुमतियों के साथ टोकन फिर से जारी करें।',
  'connections.telegram.label': 'Telegram',
  'connections.telegram.archive.title': 'Telegram Desktop संग्रह आयात करें',
  'connections.telegram.archive.hint':
    'Telegram Desktop -> सेटिंग्स -> Advanced -> Export Telegram data। "Personal chats" + "JSON" चुनें और परिणामी result.json को नीचे आयात बॉक्स में डालें।',
  'connections.telegram.archive.fileHint': 'result.json',
  'connections.telegram.api.title': 'Telegram Bot API जोड़ें',
  'connections.telegram.api.hint':
    'Telegram में @BotFather से बात करें, /newbot चलाएँ, बॉट टोकन कॉपी करके "secret:telegram:bot-token" नाम के सीक्रेट के रूप में चिपकाएँ।',
  'connections.telegram.fields.token.label': 'बॉट टोकन',
  'connections.telegram.errorHints.401':
    'टोकन अस्वीकृत। @BotFather से नया टोकन माँगें या लीक हुए को रद्द करें।',
  'connections.telegram.errorHints.404':
    'एंडपॉइंट नहीं मिला। बॉट टोकन में रिक्त स्थान न होने की पुष्टि करें।',
  'connections.vk.label': 'VK',
  'connections.vk.archive.title': 'VK संवाद संग्रह आयात करें',
  'connections.vk.archive.hint':
    'https://vk.com/data_protection खोलें, अपना संग्रह माँगें और .zip को वैसे ही (या उसकी "messages" फ़ाइलें) आयात बॉक्स में डालें।',
  'connections.vk.archive.fileHint': 'messages*.json',
  'connections.vk.api.title': 'VK API जोड़ें',
  'connections.vk.api.hint':
    'VK अब नए एप्लिकेशन को messages अधिकार नहीं देता, और Kate Mobile टोकन 2026-09-08 से काम नहीं करते। नीचे दिया गया संग्रह आयात बेहतर है। समुदाय की बातचीत के लिए समुदाय एक्सेस कुंजी चिपकाएँ (समुदाय सेटिंग्स → API उपयोग)। VK के अपने वेब क्लाइंट (client_id 6287487, oauth.vk.ru के ज़रिए) का पुराना उपयोगकर्ता टोकन शायद अब भी काम करे — खाता फ़्रीज़ होने का जोखिम आपका। मान "secret:vk:access-token" के रूप में सहेजा जाता है।',
  'connections.vk.fields.token.label': 'एक्सेस टोकन',
  'connections.vk.errorHints.401':
    'VK ने टोकन अस्वीकार किया (त्रुटि 5)। नया टोकन बनाएँ: Kate Mobile या VK Admin जैसे अवरुद्ध क्लाइंट के टोकन वापस नहीं आएँगे।',
  'connections.x.label': 'X (Twitter)',
  'connections.x.archive.title': 'X डेटा संग्रह आयात करें',
  'connections.x.archive.hint':
    'सेटिंग्स -> आपका खाता -> अपने डेटा का संग्रह डाउनलोड करें। तैयार होने पर .zip को वैसे ही (या उसके data/ फ़ोल्डर से tweets.js और direct-messages.js) आयात बॉक्स में डालें।',
  'connections.x.archive.fileHint': 'tweets.js, direct-messages.js',
  'connections.x.api.title': 'X API v2 जोड़ें',
  'connections.x.api.hint':
    'https://developer.x.com/ पर ऐप बनाएँ, उपयोगकर्ता-संदर्भ बेयरर टोकन उत्पन्न करें और "secret:x:token" के रूप में चिपकाएँ।',
  'connections.x.fields.token.label': 'बेयरर टोकन',
  'connections.x.errorHints.401':
    'बेयरर टोकन अस्वीकृत। X डेवलपर पोर्टल में नया टोकन उत्पन्न करें।',
  'connections.x.errorHints.403': 'टोकन वैध है पर users.read स्कोप नहीं है।',
  'connections.whatsapp.label': 'WhatsApp',
  'connections.whatsapp.archive.title': 'WhatsApp चैट निर्यात आयात करें',
  'connections.whatsapp.archive.hint':
    'WhatsApp ऐप में, चैट खोलें -> ... -> अधिक -> चैट निर्यात (मीडिया के साथ या बिना)। परिणामी "WhatsApp Chat with NAME.txt" या .zip को आयात बॉक्स में डालें।',
  'whatsapp.web.terms':
    'WhatsApp की शर्तें WhatsApp Web या अनौपचारिक क्लाइंट के स्वचालित या बड़े पैमाने पर उपयोग की अनुमति नहीं देतीं। यहाँ इसका उपयोग केवल आपकी अपनी चैट खोलने और आपके खुद पुष्टि किए संदेश भेजने के लिए होता है; अभिवादन और ऑटोमेशन कभी निजी WhatsApp पर नहीं भेजते।',
  'whatsapp.web.title': 'WhatsApp Web (निजी खाता)',
  'whatsapp.web.signIn': 'WhatsApp Web में साइन इन करें',
  'whatsapp.web.close': 'विंडो बंद करें',
  'whatsapp.web.opening': 'विंडो खुल रही है…',
  'whatsapp.web.waiting':
    'WhatsApp Web की विंडो खुली है। फ़ोन पर: WhatsApp > लिंक्ड डिवाइस > डिवाइस लिंक करें, और QR कोड खुद स्कैन करें।',
  'whatsapp.web.signedIn':
    'WhatsApp Web में साइन इन हो गया ({when} को पुष्टि हुई)।',
  'whatsapp.web.closed':
    'साइन इन नहीं है। विंडो यहीं, आपके सामने खुलेगी और कोड केवल आप स्कैन करते हैं।',
  'whatsapp.web.failed': 'WhatsApp Web नहीं खुल सका: {error}',
  'whatsapp.web.zipFailed': 'zip पढ़ा नहीं जा सका: {error}',
  'whatsapp.web.zipImported': '{label}: {count} संदेश आयात हुए।',
  'connections.whatsapp.archive.fileHint': 'WhatsApp Chat with *.txt',
  'connections.whatsapp.api.title': 'WhatsApp Cloud API जोड़ें',
  'connections.whatsapp.api.hint':
    'Meta for Developers ऐप बनाएँ, WhatsApp उत्पाद जोड़ें, अस्थायी या सिस्टम-यूज़र एक्सेस टोकन कॉपी करें और फ़ोन नंबर ID (WHATSAPP_PHONE_NUMBER_ID) नोट करें।',
  'connections.whatsapp.fields.token.label': 'एक्सेस टोकन',
  'connections.whatsapp.fields.phoneNumberId.label': 'फ़ोन नंबर ID',
  'connections.whatsapp.errorHints.400':
    'Meta ने 400 लौटाया। एक्सेस टोकन और ऐप के Live मोड में होने की पुष्टि करें।',
  'connections.whatsapp.errorHints.401':
    'एक्सेस टोकन अस्वीकृत। Meta Business में नया सिस्टम-यूज़र टोकन उत्पन्न करें।',
  'connections.facebook.label': 'Facebook',
  'connections.facebook.archive.title': 'Facebook डाउनलोड आयात करें',
  'connections.facebook.archive.hint':
    'सेटिंग्स और गोपनीयता -> सेटिंग्स -> आपकी जानकारी -> अपनी जानकारी डाउनलोड करें। "JSON" चुनें और जो श्रेणियाँ चाहिए (संदेश, पोस्ट) चुनें।',
  'connections.facebook.archive.fileHint': 'messages_*.json, posts_*.json',
  'connections.facebook.api.title': 'Facebook Graph API जोड़ें',
  'connections.facebook.api.hint':
    'अपने Meta for Developers ऐप में Facebook पेज जोड़ें, पेज एक्सेस टोकन (FACEBOOK_PAGE_ACCESS_TOKEN) उत्पन्न करें और पेज ID (FACEBOOK_PAGE_ID) नोट करें।',
  'connections.facebook.fields.token.label': 'पेज एक्सेस टोकन',
  'connections.facebook.fields.pageId.label': 'पेज ID',
  'connections.facebook.errorHints.400':
    'Graph ने 400 लौटाया। पुष्टि करें कि एक्सेस टोकन समाप्त नहीं हुआ (पेज टोकन अल्पकालिक होते हैं)।',
  'connections.facebook.errorHints.401':
    'एक्सेस टोकन अस्वीकृत। Graph API Explorer में नया पेज टोकन फिर से जारी करें।',
  'connections.linkedin.label': 'LinkedIn',
  'connections.linkedin.archive.title': 'LinkedIn डेटा निर्यात आयात करें',
  'connections.linkedin.archive.hint':
    'सेटिंग्स और गोपनीयता -> डेटा गोपनीयता -> अपने डेटा की प्रति प्राप्त करें। "विशिष्ट कुछ चाहिए?" चुनें और "Messages" + "Posts" माँगें। LinkedIn से आई .zip (या उसमें से messages.csv) आयात बॉक्स में डालें।',
  'connections.linkedin.archive.fileHint': 'messages.csv, Shares.csv',
  'connections.linkedin.api.title': 'LinkedIn REST API जोड़ें',
  'connections.linkedin.api.hint':
    'https://www.linkedin.com/developers/ पर ऐप बनाएँ, "Share on LinkedIn" + "Sign In with LinkedIn using OpenID Connect" उत्पाद माँगें, और OAuth2 एक्सेस टोकन तथा अपना author URN (LINKEDIN_AUTHOR_URN) चिपकाएँ।',
  'connections.linkedin.fields.token.label': 'एक्सेस टोकन',
  'connections.linkedin.fields.authorUrn.label': 'लेखक URN',
  'connections.linkedin.errorHints.401':
    'OAuth2 एक्सेस टोकन अस्वीकृत। auth code प्रवाह दोबारा चलाएँ।',
  'connections.habr-career.label': 'career.habr.com',
  'connections.habr-career.archive.title':
    'career.habr.com आवेदन JSON आयात करें',
  'connections.habr-career.archive.hint':
    'career.habr.com पर अपना खाता खोलें, "Отклики на вакансии" पर जाएँ और JSON में निर्यात क्रिया का उपयोग करें। फ़ाइल सहेजें और SPA में लोड करें।',
  'connections.habr-career.archive.fileHint': 'applications.json',
  'connections.habr-career.api.title': 'career.habr.com निजी API जोड़ें',
  'connections.habr-career.api.hint':
    'career.habr.com -> Settings -> Tokens से व्यक्तिगत एक्सेस टोकन उत्पन्न करें और "secret:habr-career:token" के रूप में चिपकाएँ।',
  'connections.habr-career.fields.token.label': 'व्यक्तिगत एक्सेस टोकन',
  'connections.habr-career.errorHints.401':
    'career.habr.com ने टोकन अस्वीकृत किया। Settings -> Tokens से फिर से जारी करें।',
  'connections.hh.label': 'hh.ru',
  'connections.hh.archive.title': 'hh.ru वार्तालाप संग्रह आयात करें',
  'connections.hh.archive.hint':
    'पहले से प्राप्त वार्तालाप के वास्तविक संदेशों वाली JSON फ़ाइल आयात करें। केवल वार्तालाप सूची में संदेश इतिहास नहीं होता। लाइव इतिहास के लिए API टोकन भरें और अभी लाएँ चुनें।',
  'connections.hh.archive.fileHint': 'negotiations.json',
  'connections.hh.api.title': 'hh.ru API जोड़ें',
  'connections.hh.api.hint':
    'https://dev.hh.ru/ पर ऐप पंजीकृत करें, OAuth से अपने HH खाते को अधिकृत करें और नीचे उपयोगकर्ता एक्सेस टोकन भरें। चैट पहुँच ऐप और खाते की अनुमतियों पर निर्भर है।',
  'connections.hh.fields.token.label': 'एक्सेस टोकन',
  'connections.hh.errorHints.401':
    'hh.ru ने टोकन अस्वीकृत किया। https://dev.hh.ru/ पर अपने ऐप के माध्यम से रिफ़्रेश करें।',
  'connections.github.label': 'GitHub',
  'connections.github.archive.title': 'gh api JSON डंप आयात करें',
  'connections.github.archive.hint':
    '`gh api` से JSON डंप सहेजें (जैसे `gh api repos/OWNER/REPO/issues --paginate > issues.json`) या लिफ़ाफ़ा `{ issues, comments, pulls, reviews, reviewComments, discussions }` और फ़ाइल यहाँ डालें।',
  'connections.github.archive.fileHint':
    'issues.json, pulls.json, comments.json, envelope.json',
  'connections.github.api.title': 'GitHub REST API जोड़ें',
  'connections.github.api.hint':
    'https://github.com/settings/personal-access-tokens पर fine-grained personal access token बनाएँ; issues, pull requests और जिन रिपॉज़िटरी को क्लोन करना है उन पर पढ़ने की अनुमति दें, और टिप्पणी पोस्ट करनी हो तो issues पर लिखने की अनुमति भी दें। "secret:github:access-token" के रूप में चिपकाएँ।',
  'connections.github.fields.token.label': 'व्यक्तिगत एक्सेस टोकन',
  'connections.github.errorHints.401':
    'टोकन अस्वीकृत। https://github.com/settings/personal-access-tokens पर नया personal access token जारी करें।',
  'connections.github.errorHints.403':
    'GitHub ने 403 लौटाया। टोकन में स्कोप कमज़ोर हो सकते हैं (issues:read, pull_requests:read, contents:read) या द्वितीयक रेट लिमिट लग सकती है।',
  'connections.github.errorHints.404':
    'रिपॉज़िटरी नहीं मिली या दिखाई नहीं देती। पुष्टि करें कि टोकन को लक्ष्य owner/repo पर पहुँच है।',
  'connections.upwork.label': 'Upwork',
  'connections.upwork.archive.title': 'Upwork डेटा निर्यात आयात करें',
  'connections.upwork.archive.hint':
    'Upwork पर लेन-देन इतिहास (Reports → Transaction History → Download CSV), प्रति-कार्य संग्रह और आंतरिक एडमिन लिफ़ाफ़े (`{ jobs, contracts, rooms, messages, transactions }`) निर्यात किए जा सकते हैं। परिणामी CSV या JSON फ़ाइल यहाँ डालें और स्रोत "upwork" चुनें।',
  'connections.upwork.archive.fileHint':
    'transactions.csv, jobs.json, contracts.json, envelope.json',
  'connections.upwork.api.title': 'Upwork GraphQL API जोड़ें',
  'connections.upwork.api.hint':
    'https://www.upwork.com/services/api/apply पर OAuth2 ऐप पंजीकृत करें, 3-legged authorisation-code प्रवाह चलाएँ और एक्सेस टोकन को "secret:upwork:access-token" के रूप में चिपकाएँ। वैकल्पिक रिफ़्रेश टोकन "secret:upwork:refresh-token" पर रखें।',
  'connections.upwork.fields.token.label': 'OAuth एक्सेस टोकन',
  'connections.upwork.fields.refreshToken.label': 'रिफ़्रेश टोकन',
  'connections.upwork.fields.organizationId.label': 'संगठन (टेनेंट) ID',
  'connections.upwork.errorHints.401':
    'Upwork ने एक्सेस टोकन अस्वीकृत किया। पंजीकृत OAuth2 ऐप के माध्यम से रिफ़्रेश करें या authorisation-code प्रवाह दोबारा चलाएँ।',
  'connections.upwork.errorHints.403':
    'टोकन वैध पर स्कोप कम। आवश्यक messaging, search और reports स्कोप के साथ फिर से जारी करें।',
  'connections.upwork.errorHints.429':
    'Upwork ने रेट-लिमिट लगाया। बैक ऑफ़ करें; API ToS के अनुसार एडाप्टर 24 घंटे तक परिणाम कैश रखता है।',
  'connections.peopleperhour.label': 'PeoplePerHour',
  'connections.peopleperhour.archive.title':
    'PeoplePerHour डेटा निर्यात आयात करें',
  'connections.peopleperhour.archive.hint':
    'PeoplePerHour खाता-स्तरीय निर्यात GDPR डेटा-विषय एक्सेस अनुरोध बंडल (Settings → Privacy → Request my data) और Earnings CSV (Reports → Earnings → Export) के माध्यम से देता है। परिणामी JSON या CSV को यहाँ डालें और स्रोत "peopleperhour" चुनें।',
  'connections.peopleperhour.archive.fileHint':
    'projects.json, proposals.json, workstreams.json, earnings.csv',
  'connections.peopleperhour.api.title': 'PeoplePerHour REST API जोड़ें',
  'connections.peopleperhour.api.hint':
    'PeoplePerHour डेवलपर पोर्टल (https://www.peopleperhour.com/site/developers) पर OAuth2 ऐप पंजीकृत करें, authorisation-code प्रवाह चलाएँ और एक्सेस टोकन को "secret:peopleperhour:access-token" के रूप में चिपकाएँ। वैकल्पिक रिफ़्रेश टोकन "secret:peopleperhour:refresh-token" पर रखें। PPH API ToS के अनुसार एडाप्टर हर प्रतिक्रिया को 24 घंटे कैश रखता है।',
  'connections.peopleperhour.fields.accessToken.label': 'OAuth एक्सेस टोकन',
  'connections.peopleperhour.fields.refreshToken.label': 'रिफ़्रेश टोकन',
  'connections.peopleperhour.errorHints.401':
    'PeoplePerHour ने एक्सेस टोकन अस्वीकृत किया। पंजीकृत OAuth2 ऐप के माध्यम से रिफ़्रेश करें या authorisation-code प्रवाह दोबारा चलाएँ।',
  'connections.peopleperhour.errorHints.403':
    'टोकन वैध पर स्कोप कम। आवश्यक projects, proposals और workstreams स्कोप के साथ फिर से जारी करें।',
  'connections.peopleperhour.errorHints.429':
    'PeoplePerHour ने रेट-लिमिट लगाया। बैक ऑफ़ करें; API ToS के अनुसार एडाप्टर 24 घंटे तक परिणाम कैश रखता है।',
  'connections.superjob.label': 'superjob.ru',
  'connections.superjob.archive.title': 'SuperJob प्रतिक्रिया संग्रह आयात करें',
  'connections.superjob.archive.hint':
    'superjob.ru पर अपना आवेदक कैबिनेट खोलें -> "Отклики" और JSON निर्यात क्रिया का उपयोग करें। फ़ाइल सहेजें और यहाँ लोड करें।',
  'connections.superjob.archive.fileHint': 'responses.json',
  'connections.superjob.api.title': 'SuperJob API जोड़ें',
  'connections.superjob.api.hint':
    'https://api.superjob.ru/register/ पर ऐप पंजीकृत करें, गुप्त कुंजी को SUPERJOB_APP_ID के रूप में और एक्सेस टोकन को "secret:superjob:token" के रूप में चिपकाएँ।',
  'connections.superjob.fields.appId.label': 'App ID (X-Api-App-Id)',
  'connections.superjob.fields.token.label': 'एक्सेस टोकन',
  'connections.superjob.errorHints.401':
    'SuperJob ने App ID अस्वीकृत किया। आवेदक कैबिनेट में फिर से जाँचें।',
  'connections.naukri.label': 'naukri.com',
  'connections.naukri.archive.title':
    'Naukri रिक्रूटर इनबॉक्स निर्यात आयात करें',
  'connections.naukri.archive.hint':
    'naukri.com -> "Recruiter messages" खोलें, ब्राउज़र निर्यात का उपयोग करें (या नेटवर्क टैब से लौटा JSON सहेजें) और फ़ाइल यहाँ लोड करें।',
  'connections.naukri.archive.fileHint': 'inbox.json',
  'connections.naukri.session.title':
    'स्थानीय ब्राउज़र सत्र में एक बार साइन इन करें',
  'connections.naukri.session.hint':
    'स्थानीय सर्वर शुरू करें, CV स्क्रीन खोलें और एक रीड चलाएँ। ब्राउज़र naukri.com खोलता है; वहाँ एक बार साइन इन करें और प्रोफ़ाइल निर्देशिका आगे के रन के लिए सत्र रखती है।',
  'connections.vietnamworks.label': 'vietnamworks.com',
  'connections.vietnamworks.archive.title':
    'VietnamWorks संदेश केंद्र निर्यात आयात करें',
  'connections.vietnamworks.archive.hint':
    'vietnamworks.com -> "My Jobs" -> संदेश खोलें, पृष्ठ द्वारा लोड किया गया JSON सहेजें और उसे यहाँ आयात करें।',
  'connections.vietnamworks.archive.fileHint': 'messages.json',
  'connections.vietnamworks.session.title':
    'स्थानीय ब्राउज़र सत्र में एक बार साइन इन करें',
  'connections.vietnamworks.session.hint':
    'स्थानीय सर्वर शुरू करें, CV स्क्रीन खोलें और एक रीड चलाएँ। ब्राउज़र vietnamworks.com खोलता है; वहाँ एक बार साइन इन करें और प्रोफ़ाइल निर्देशिका आगे के रन के लिए सत्र रखती है।',
  'connections.topcv.label': 'topcv.vn',
  'connections.topcv.archive.title': 'TopCV नियोक्ता संदेश निर्यात आयात करें',
  'connections.topcv.archive.hint':
    'topcv.vn -> "Tin nhắn" खोलें, पृष्ठ द्वारा लोड किया गया JSON सहेजें और उसे यहाँ आयात करें।',
  'connections.topcv.archive.fileHint': 'messages.json',
  'connections.topcv.session.title':
    'स्थानीय ब्राउज़र सत्र में एक बार साइन इन करें',
  'connections.topcv.session.hint':
    'स्थानीय सर्वर शुरू करें, CV स्क्रीन खोलें और एक रीड चलाएँ। ब्राउज़र topcv.vn खोलता है; वहाँ एक बार साइन इन करें और प्रोफ़ाइल निर्देशिका आगे के रन के लिए सत्र रखती है।',
  'tutorial.button': 'ट्यूटोरियल',
  'tutorial.skip': 'चरण छोड़ें',
  'tutorial.next': 'अगला',
  'tutorial.showMe': 'दिखाएँ',
  'tutorial.back': 'पीछे',
  'tutorial.finish': 'समाप्त',
  'tutorial.off': 'ट्यूटोरियल बंद करें',
  'tutorial.progress': 'चरण {current} / {total}',
  'tutorial.connect.title': 'अपनी पहली सेवा जोड़ें',
  'tutorial.connect.body':
    'अपनी चैट और संपर्क एक जगह लाएँ। शुरू करने के लिए "कनेक्शन" खोलें।',
  'tutorial.connect.examples': 'उदाहरण:',
  'tutorial.connect.more': 'और भी',
  'tutorial.welcome.title': 'meta-sovereign में आपका स्वागत है',
  'tutorial.welcome.body':
    'आपका निजी CRM और सभी संदेशों के लिए एक इनबॉक्स। जब तक आप अपना सर्वर न जोड़ें, डेटा आपके डिवाइस पर ही रहता है।',
  'tutorial.chat.title': 'चैट',
  'tutorial.chat.body':
    'सभी जुड़ी सेवाओं की बातचीत, एक ही इनबॉक्स में। नीचे लिखें और जवाब देने के लिए भेजें दबाएँ; सूची के नीचे की पंक्ति जुड़ा खाता और पिछला सिंक दिखाती है; सिंक अपने आप होता है।',
  'tutorial.contacts.title': 'संपर्क',
  'tutorial.contacts.body':
    'जिनसे भी आप बात करते हैं और आपके Telegram संपर्क — हर व्यक्ति एक बार, कई सेवाओं में भी। संपर्क खोलें।',
  'tutorial.contactsOpen.title': 'चैट खोलें',
  'tutorial.contactsOpen.body':
    'किसी व्यक्ति के पास "संदेश" दबाएँ और उनसे चैट खोलें, भले ही आपने पहले कभी न लिखा हो। खोज नाम या @username से ढूँढती है।',
  'tutorial.automation.title': 'ऑटोमेशन',
  'tutorial.automation.body':
    'स्वचालित जवाब: जब कोई संदेश पैटर्न से मेल खाता है, ऐप जवाब का मसौदा बनाता है। आपकी पुष्टि के बिना कुछ नहीं भेजा जाता।',
  'tutorial.backup.title': 'बैकअप',
  'tutorial.backup.body':
    'अपने डेटा की एन्क्रिप्टेड कॉपी सहेजें। इसे केवल आपका पासफ़्रेज़ खोल सकता है।',
  'tutorial.connections.title': 'एक सेवा चुनें',
  'tutorial.connections.body':
    'यहाँ सब कुछ अभी काम करता है: "साइन-इन खोजें" (अनुशंसित, लोकल सर्वर के साथ) दिखाता है कि आपके ब्राउज़रों में किन सेवाओं में आप पहले से साइन इन हैं। किसी भी सेवा पर "ब्राउज़र से आयात करें" (अनुशंसित) आपको साइन इन कराकर एक्सपोर्ट आयात करता है, "हाथ से दर्ज करें" में API कुंजियाँ या फ़ाइल दी जाती है। "आगे" वह सेवा खोलेगा जिसे आपने आख़िरी बार चुना था (शुरू में Email)।',
  'tutorial.connectionDetail.title': 'आयात करें या हाथ से दर्ज करें',
  'tutorial.connectionDetail.body':
    '"ब्राउज़र से आयात करें" टैब पर "ब्राउज़र खोलें" दबाएँ और साइन इन करें, वहाँ डेटा एक्सपोर्ट शुरू करें, डाउनलोड हुई फ़ाइल अपने आप आयात हो जाएगी। खुद करना चाहते हैं? "हाथ से दर्ज करें" पर जाएँ।',

  // CV synchronisation screen (issue #29).
  'cv.title': 'CV सिंक्रनाइज़ेशन',
  'cv.intro':
    'स्थानीय ब्राउज़र सत्र के ज़रिए हर समर्थित जॉब प्लेटफ़ॉर्म से अपना CV पढ़ें, संस्करणों की फ़ील्ड-दर-फ़ील्ड तुलना करें, फिर अपडेट की योजना बनाकर उसे लागू करें। जब तक आप «लागू करें» नहीं दबाते, कुछ भी नहीं लिखा जाता।',
  'cv.use': 'चुनें',
  'cv.platform': 'प्लेटफ़ॉर्म',
  'cv.markup': 'मार्कअप पहुँच',
  'cv.steps': 'योजना चरण',
  'cv.snapshot': 'अंतिम स्नैपशॉट',
  'cv.confidence': '{verified} सत्यापित / {draft} ड्राफ़्ट',
  'cv.noSnapshot': 'कभी नहीं पढ़ा गया',
  'cv.loginPlaceholder': 'प्रोफ़ाइल लॉगिन या id',
  'cv.read': 'चयनित पढ़ें',
  'cv.compare': 'तुलना करें',
  'cv.planSync': 'सिंक की योजना बनाएँ',
  'cv.applySync': 'सिंक लागू करें',
  'cv.busy': 'काम जारी है — ब्राउज़र सत्र प्लेटफ़ॉर्म चला रहा है…',
  'cv.differences': 'अंतर',
  'cv.field': 'फ़ील्ड',
  'cv.values': 'मान',
  'cv.missing': 'यहाँ अनुपस्थित',
  'cv.noConflicts':
    'कोई टकराव नहीं: पढ़ी गई फ़ील्ड पर सभी प्लेटफ़ॉर्म सहमत हैं।',
  'cv.syncTitle': 'सिंक योजना',
  'cv.dryRun': 'ड्राई रन — किसी भी प्लेटफ़ॉर्म पर कुछ नहीं लिखा गया।',
  'cv.applied': 'लागू — सूचीबद्ध प्लेटफ़ॉर्म अपडेट कर दिए गए।',
  'cv.action':
    '{platform}: {writable} लिखने योग्य, {unsupported} असमर्थित — {paths}',
  'cv.morePaths': '(+{count} और)',
  'cv.telemetry': 'हाल के रन',
  'cv.noRuns': 'अभी तक कोई रन दर्ज नहीं हुआ।',
  'cv.unavailable':
    'यह सर्वर CV रूट नहीं देता। JS सर्वर चलाएँ (`meta-sovereign serve`) या `meta-sovereign cv-*` कमांड इस्तेमाल करें, जो ब्राउज़र को स्थानीय रूप से चलाते हैं।',
  'automations.mode.safe': 'सुरक्षित: पुष्टि के लिए मसौदे',
  'automations.mode.auto': 'स्वचालित',
  'automations.reason.none': 'कोई मेल नहीं खाया',
  'automations.reason.network': 'दूसरा नेटवर्क',
  'automations.reason.not-personal': 'निजी चैट नहीं',
  'automations.reason.not-mutual': 'आपने वहाँ कभी नहीं लिखा',
  'automations.reason.talked-recently': 'हाल ही में बात हुई',
  'automations.reason.last-from-me': 'आख़िरी संदेश आपका है',
  'automations.reason.last-from-contact': 'आख़िरी संदेश उनका है',
  'automations.reason.last-from-nobody': 'कोई संदेश नहीं',
  'automations.reason.draft-pending': 'एक मसौदा पहले से इंतज़ार में है',
  'automations.reason.already-sent': 'हाल ही में भेजा जा चुका',
  'automations.reason.already-skipped': 'हाल ही में छोड़ा गया',
  'automations.title': 'ऑटोमेशन',
  'automations.intro':
    'हर ऑटोमेशन तय करता है कि किसे, कब, किन शर्तों पर और कौन-सा संदेश भेजना है। सुरक्षित मोड हर चैट में पुष्टि के लिए ड्राफ़्ट छोड़ता है; स्वचालित मोड टाइपिंग और विराम के साथ भेजता है।',
  'automations.new': 'नया ऑटोमेशन',
  'automations.newName': 'नया ऑटोमेशन',
  'automations.pick':
    'संपादित करने, पूर्वावलोकन करने या चलाने के लिए कोई ऑटोमेशन चुनें, या नया बनाएँ।',
  'automations.preset': 'पहले से तैयार',
  'automations.off': 'बंद',
  'automations.presets.reengage-dormant.name':
    '90 दिनों से चुप संपर्कों को नमस्ते कहें',
  'automations.presets.reengage-dormant.description':
    'जिन निजी चैट में 90 दिनों से कोई संदेश नहीं है, उन्हें नमस्ते भेजा जाता है और पूछा जाता है कि क्या उन्हें या उनके दोस्तों को ऑटोमेशन में मदद चाहिए।',
  'automations.presets.job-search.name': 'खुली नौकरियों के बारे में पूछें',
  'automations.presets.job-search.description':
    'संपर्कों को बताएं कि आप नई भूमिकाओं के लिए तैयार हैं; सहकर्मियों या भर्तीकर्ताओं के दर्शकों के साथ इस्तेमाल करें।',
  'automations.presets.contract-search.name': 'अनुबंध पर काम की पेशकश करें',
  'automations.presets.contract-search.description':
    'संपर्कों को बताएं कि आप अनुबंध पर प्रोजेक्ट लेते हैं; सही लोगों तक पहुँचने के लिए सूचियों का प्रतिच्छेदन करें।',
  'automations.presets.greet-back.name': 'नमस्ते का जवाब दें',
  'automations.presets.greet-back.description':
    'जब कोई निजी चैट में नमस्ते कहे, तो सही रूप में अभिवादन का ड्राफ़्ट बनाएं (दिन में अधिकतम एक बार)।',
  'automations.edit': '{name} संपादित करें',
  'automations.close': 'बंद करें',
  'automations.delete': 'हटाएँ',
  'automations.confirmDelete': 'ऑटोमेशन "{name}" हटाएँ?',
  'automations.preview': 'पूर्वावलोकन',
  'automations.runSafe': 'सहेजें और ड्राफ़्ट बनाएँ',
  'automations.runAuto': 'सहेजें और अभी भेजें',
  'automations.history': 'इतिहास',
  'automations.useSelection': 'चुने गए {count}',
  'automations.section.about': 'ऑटोमेशन',
  'automations.section.triggers': 'कब चलता है',
  'automations.section.audience': 'किसे',
  'automations.section.conditions': 'शर्तें',
  'automations.section.message': 'संदेश',
  'automations.section.pacing': 'गति',
  'automations.field.name': 'नाम',
  'automations.field.description': 'विवरण',
  'automations.field.enabled': 'चालू (शेड्यूल और आने वाले संदेश इसे चलाते हैं)',
  'automations.field.mode': 'मोड',
  'automations.field.audience': 'दर्शक',
  'automations.field.silentDays': 'कम से कम इतने दिन से बात नहीं हुई',
  'automations.field.cooldownDays': 'इतने दिन तक दोबारा नहीं',
  'automations.field.mutual': 'सिर्फ़ वे चैट जिनमें आपने भी लिखा',
  'automations.field.personal': 'सिर्फ़ निजी चैट',
  'automations.field.lastFrom': 'आख़िरी संदेश किसका',
  'automations.field.networks': 'नेटवर्क (ख़ाली: सभी)',
  'automations.field.form': 'संबोधन',
  'automations.field.limit': 'हर बार ज़्यादा से ज़्यादा',
  'automations.field.dailyCap': 'हर दिन ज़्यादा से ज़्यादा',
  'automations.field.minDelay': 'विराम कम से कम (सेकंड)',
  'automations.field.maxDelay': 'विराम ज़्यादा से ज़्यादा (सेकंड)',
  'automations.field.typing': 'हर संदेश से पहले टाइपिंग दिखाएँ',
  'automations.trigger.manual': 'हाथ से',
  'automations.trigger.chat-menu': 'चैट के मेनू से',
  'automations.trigger.schedule': 'हर',
  'automations.trigger.incoming': 'मेल खाते आने वाले संदेश पर',
  'automations.hint.schedule': '30m, 12h, 1d या 2w; ख़ाली: कोई शेड्यूल नहीं',
  'automations.hint.incoming': 'रेगुलर एक्सप्रेशन; ख़ाली: संदेशों पर नहीं',
  'automations.hint.audience':
    'personal, friends:vk, chat:vk:<id>, community:vk:<id>, list:<id>, audience:<id>, person:vk:<id>; | (या), & (और), - (छोड़कर) और कोष्ठक से जोड़ें',
  'automations.hint.template':
    '{name}, {days} और {network} हर व्यक्ति के लिए भरे जाते हैं',
  'automations.form.auto': 'ты/вы अपने आप पहचानें',
  'automations.form.informal': 'अनौपचारिक (ты)',
  'automations.form.formal': 'औपचारिक (вы)',
  'automations.lastFrom.any': 'कोई भी',
  'automations.lastFrom.me': 'मैं',
  'automations.lastFrom.contact': 'सामने वाला',
  'automations.status.sent': 'भेजा गया',
  'automations.status.failed': 'नहीं भेजा गया',
  'automations.status.skipped': 'छोड़ा गया',
  'automations.plan.title': '{count} को संदेश',
  'automations.plan.nothingSent':
    'यह पूर्वावलोकन है: कुछ भी भेजा या कतार में नहीं डाला गया।',
  'automations.plan.leftOut': 'छूटे हुए: {reasons}',
  'automations.notice.saved': '"{name}" सहेजा गया।',
  'automations.notice.deleted': '"{name}" हटाया गया।',
  'automations.notice.queued':
    '{count} ड्राफ़्ट अपनी चैट में इंतज़ार कर रहे हैं: देखने और भेजने के लिए चैट खोलें।',
  'automations.notice.listSaved': 'सूची "{name}" सहेजी गई ({count} लोग)।',
  'automations.notice.audienceSaved': 'दर्शक "{name}" सहेजा गया ({count} लोग)।',
  'automations.error.name': 'ऑटोमेशन को नाम दें',
  'automations.error.number': 'संख्याएँ शून्य या उससे ज़्यादा होनी चाहिए',
  'automations.error.audience': 'दर्शक समझ नहीं आया',
  'automations.error.trigger': 'चलाने का कम से कम एक तरीक़ा चुनें',
  'automations.error.invalid': 'ऑटोमेशन सही नहीं है',
  'automations.people.title': 'लोग',
  'automations.people.search': 'नाम, हैंडल या नेटवर्क से लोग खोजें',
  'automations.people.sameAs': '{count} और नेटवर्क पर भी',
  'automations.people.selected': '{count} चुने गए',
  'automations.people.test': 'परीक्षण: शर्तें अनदेखी करें',
  'automations.people.run': 'उन पर "{name}" चलाएँ',
  'automations.people.pickAutomation':
    'चुने गए लोगों पर चलाने के लिए कोई ऑटोमेशन खोलें।',
  'automations.people.listName': 'सूची का नाम',
  'automations.people.saveList': 'सूची के रूप में सहेजें',
  'automations.people.clear': 'चयन हटाएँ',
  'automations.audiences.title': 'दर्शक',
  'automations.audiences.use': 'इस्तेमाल करें',
  'automations.audiences.count': 'गिनें',
  'automations.audiences.resolved': '{count} लोग: {names}',
  'settings.operator.title': 'ऑपरेटर',
  'settings.operator.hint':
    'डिफ़ॉल्ट रूप से केवल लोगों के साथ निजी चैट चालू हैं। बॉट, समूह और चैनल बंद हैं; शामिल करने के प्रकार चुनें। मेनू बैज वही चयन उपयोग करता है।',
  'settings.operator.bot': 'बॉट',
  'settings.operator.private': 'लोगों के साथ निजी चैट',
  'settings.operator.group': 'समूह और समूह चैट',
  'settings.operator.channel': 'चैनल',
  'settings.stories.title': 'स्टोरी',
  'settings.birthdays.title': 'जन्मदिन के अनुस्मारक',
  'settings.birthdays.tomorrow': 'कल के जन्मदिन भी दिखाएँ',
  'settings.birthdays.hideGreeted': 'आज जिनको बधाई दे चुके हैं उन्हें छिपाएँ',
  'settings.birthdays.hint':
    'डिफ़ॉल्ट रूप से केवल आज के वे जन्मदिन दिखते हैं जिनकी बधाई अभी बाकी है। केवल भेजे जा चुके जन्मदिन संदेश गिने जाते हैं, ड्राफ़्ट या कतार के संदेश नहीं।',
  'settings.stories.show': 'स्टोरी दिखाएँ',
  'settings.stories.hint':
    'डिफ़ॉल्ट रूप से बंद। इस ब्राउज़र में स्टोरी पट्टी, अवतार रिंग और प्रोफ़ाइल स्टोरी चालू करें।',
  'settings.folderTabs.title': 'फ़ोल्डर टैब',
  'settings.folderTabs.placement': '“सभी” और “अपठित” का स्थान',
  'settings.folderTabs.end': 'अंत में (डिफ़ॉल्ट)',
  'settings.folderTabs.start': 'शुरुआत में',
  'settings.folderTabs.hint':
    'चुने हुए किनारे से “सभी” पहले और “अपठित” दूसरे स्थान पर हैं। अन्य फ़ोल्डरों का क्रम बना रहता है; Telegram नहीं बदलता।',
  'settings.appearance.title': 'रूप-रंग',
  'settings.appearance.intro':
    'थीम और स्किन हर स्क्रीन पर लागू होती हैं और इसी ब्राउज़र में सहेजी जाती हैं। हेडर का थीम बटन हल्की और गहरी थीम के बीच बदलता है।',
  'settings.appearance.theme': 'थीम',
  'settings.appearance.skin': 'स्किन',
  'settings.appearance.effects': 'दृश्य प्रभाव घटाएँ',
  'settings.effects.auto': 'स्वचालित: जब ब्राउज़र धीमा रेंडर करे',
  'settings.effects.on': 'हमेशा घटे हुए (बिना ब्लर)',
  'settings.effects.off': 'पूरे प्रभाव',
  'settings.theme.system': 'सिस्टम के अनुसार',
  'settings.theme.light': 'हल्की',
  'settings.theme.dark': 'गहरी',
  'settings.theme.auto': 'ऑटो: दिन में (7–19) हल्की, रात में गहरी',
  'settings.skin.t3': 't3.codes जैसा (डिफ़ॉल्ट)',
  'settings.skin.telegram': 'Telegram जैसा',
  'settings.skin.whatsapp': 'WhatsApp जैसा',
  'settings.skin.signal': 'Signal जैसा',
  'greetings.title': 'अभिवादन',
  'greetings.intro':
    'बातचीत शुरू करने के लिए स्टिकर और वाक्यांश चुनें, देखें कि किसका अभिवादन होगा, फिर भेजें। स्टिकर की तस्वीरें सीधे नेटवर्क से लोड होती हैं; ऐप में कुछ भी कॉपी नहीं होता।',
  'greetings.stickers': 'स्टिकर और वाक्यांश',
  'greetings.selected': '{total} में से {count} स्टिकर चुने गए',
  'greetings.pick': '{label} का उपयोग करें',
  'greetings.telegramDefault':
    'खाली चैट में Telegram जो स्टिकर सुझाता है, वे उसके यूज़र API ({method} "{emoticon}") से आते हैं, जिसे बॉट कॉल नहीं कर सकता। इसके बजाय नीचे दिए सेट से स्टिकर सूचीबद्ध करें, या अपने सेट जोड़ें।',
  'greetings.sets': 'सूचीबद्ध करने के लिए Telegram स्टिकर सेट',
  'greetings.language': 'अभिवादन की भाषा',
  'greetings.prefer': 'भेजें',
  'greetings.prefer.sticker': 'जहाँ संभव हो स्टिकर',
  'greetings.prefer.text': 'टेक्स्ट अभिवादन',
  'greetings.listLive': 'स्टिकर लाइव सूचीबद्ध करें',
  'greetings.save': 'चयन सहेजें',
  'greetings.saved': 'चयन सहेजा गया।',
  'greetings.planTitle': 'किसका अभिवादन करें',
  'greetings.mode': 'योजना',
  'greetings.mode.initiate': 'नई बातचीत शुरू करें',
  'greetings.mode.reply': 'अभिवादन का जवाब दें',
  'greetings.delay': 'भेजने के बीच विराम, सेकंड',
  'greetings.preview': 'योजना देखें',
  'greetings.send': 'अभिवादन भेजें',
  'greetings.busy': 'काम चल रहा है…',
  'greetings.noPlan':
    'अभी कोई योजना नहीं है। किसका अभिवादन होगा, यह देखने के लिए योजना देखें।',
  'greetings.emptyPlan':
    'अभिवादन के लिए कोई नहीं: हर ज्ञात चैट का पहले ही अभिवादन हो चुका है, जवाब दिया जा चुका है या उसे फ़िल्टर कर दिया गया है।',
  'greetings.chat': 'चैट',
  'greetings.lang': 'भाषा',
  'greetings.what': 'अभिवादन',
  'greetings.status': 'स्थिति',
  'greetings.ready': 'तैयार',
  'greetings.sent': 'भेजा गया',
  'greetings.skipped': 'छोड़ा गया: {reason}',
  'greetings.networks': 'हर नेटवर्क क्या अनुमति देता है',
  'greetings.network': 'नेटवर्क',
  'greetings.addressing': 'स्टिकर',
  'greetings.initiate': 'बातचीत शुरू कर सकते हैं',
  'greetings.note': 'टिप्पणी',
  'greetings.initiate.yes': 'हाँ',
  'greetings.initiate.window': 'उनके आख़िरी संदेश के {hours} घंटे के भीतर',
  'greetings.initiate.reply-only': 'केवल जवाब',
  'greetings.textOnly': 'केवल टेक्स्ट',

  /* ---- Telegram संदेश प्रदर्शन ---- */

  /* ---- R-Z14 ---- */
  'disk.banner': 'डिस्क लगभग भर चुकी है — नए संदेश सहेजे न जा सकें',
  'disk.dismiss': 'छिपाएँ',

  /* ---- R-Z17 ---- */
  'schema.tooNew':
    'ये डेटा ऐप के नए संस्करण ने सहेजा था। इनका उपयोग जारी रखने के लिए ऐप अपडेट करें।',
  /* ---- R-Z12 ---- */
  'error.load': 'यह सूची लोड नहीं हो सकी।',
  'error.retry': 'फिर कोशिश करें',
  'settings.saveFailed': 'सहेजा नहीं जा सका: {error}',
  'error.code.unknown': 'कुछ गड़बड़ हो गई',
  'error.code.bad-host': 'स्थानीय सर्वर ने इस पेज का पता अस्वीकार कर दिया',
  'error.code.too-large': 'भेजने के लिए यह बहुत बड़ा है',
  'error.code.bad-json': 'अनुरोध बिगड़ा हुआ था और लागू नहीं हुआ',
  'error.code.internal': 'स्थानीय सर्वर में आंतरिक त्रुटि हुई',
  'error.code.send-unknown':
    'पता नहीं कि यह भेजा गया या नहीं — दोबारा कोशिश से पहले चैट देखें',
  'error.code.unsupported': 'यहाँ समर्थित नहीं है',
  'error.code.unsupported-chat': 'इस चैट में समर्थित नहीं है',
  'error.code.captcha':
    'नेटवर्क कैप्चा माँग रहा है — पहले आधिकारिक ऐप में उसे पूरा करें',
  'error.code.LOW_DISK': 'डिस्क लगभग भरी है — कुछ सहेजा नहीं गया',
  'error.code.STORE_WRITE_FAILED':
    'स्टोर डिस्क पर नहीं लिख सका — कुछ सहेजा नहीं गया',
  'error.code.STORE_FULL': 'डिस्क भरी है — कुछ सहेजा नहीं गया',
  'error.code.STORE_LOCKED': 'स्टोर किसी दूसरी चल रही प्रति ने लॉक कर रखा है',
  'error.code.outbox-unavailable':
    'भेजने का लॉग उपलब्ध नहीं है, इसलिए कुछ नहीं भेजा गया',
  'error.code.send-in-doubt':
    'पिछला संदेश शायद जा चुका है — उसे दोहराया नहीं गया',
  'error.code.timeout': 'अनुरोध का समय समाप्त हो गया',
  'error.code.network': 'स्थानीय सर्वर से कोई उत्तर नहीं',
  'questions.title': 'सवाल और सहेजे गए जवाब',
  'questions.intro':
    'अलग-अलग चैट में जवाब फिर उपयोग करें। स्वीकृत सहेजे गए नियम स्वचालित भेज सकते हैं; अनुमानित, विरोधी और अधूरे मिलान समीक्षा में रहते हैं। प्रोफ़ाइल मान के लिए {{field}}, छोटे बदलते वाक्यांश के लिए … और शब्द के अंत के लिए word* उपयोग करें।',
  'questions.action': 'कार्रवाई',
  'questions.kind.send-template': 'टेम्पलेट भेजें',
  'questions.kind.answer-questions': 'सवालों के जवाब दें',
  'questions.actionHint':
    'सबसे हाल के अनुत्तरित सवाल और नीचे सहेजे गए जवाब इस्तेमाल होते हैं। अस्वीकृत, अनुमानित, विरोधी या अधूरे जवाब समीक्षा के लिए स्वचालित भेजना रोकते हैं।',
  'questions.ruleIds': 'जवाब नियम की आईडी',
  'questions.ruleIdsHint':
    'कॉमा से अलग करें; सभी चालू नियमों के लिए खाली छोड़ें।',
  'questions.approximate': 'समीक्षा के लिए अनुमानित मिलान दिखाएँ',
  'questions.contract': 'कॉन्फ़िगर किए मानों को प्लेसहोल्डर से बदलें',
  'questions.contractHint':
    'जवाब सहेजते या सीखते समय जवाब पूर्वावलोकन की प्रोफ़ाइल और वेतन सेटिंग इस्तेमाल करें। मंज़ूरी देने से पहले सुझाए टेम्प्लेट जाँचें।',
  'questions.salaryTemplateEvidence': 'वेतन प्लेसहोल्डर मान',
  'questions.profile': 'प्रोफ़ाइल मान',
  'questions.fieldName': 'फ़ील्ड नाम, जैसे city',
  'questions.addField': 'फ़ील्ड जोड़ें',
  'questions.removeField': 'फ़ील्ड हटाएँ',
  'questions.question': 'सवाल या पैटर्न',
  'questions.answer': 'जवाब',
  'questions.variant': 'विकल्प {count}',
  'questions.approved': 'इस सहेजे गए नियम से स्वचालित भेजने की स्वीकृति',
  'questions.frequency': 'देखे गए जवाब: {count}',
  'questions.evidence': 'स्रोत संदेश',
  'questions.addVariant': 'जवाब का विकल्प जोड़ें',
  'questions.removeVariant': 'विकल्प हटाएँ',
  'questions.sources': 'प्रदाता, कॉमा से अलग; खाली होने पर सभी',
  'questions.chats': 'चैट, जैसे hh:123, telegram:456; खाली होने पर सभी',
  'questions.new': 'नया जवाब नियम',
  'questions.refresh': 'जवाब ताज़ा करें',
  'questions.empty':
    'अभी कोई जवाब नहीं सहेजा है। नया जोड़ें या आयात की गई बातचीत से सुझाव सीखें।',
  'questions.saved': 'जवाब नियम सहेजा गया।',
  'questions.deleted': 'जवाब नियम हटाया गया।',
  'questions.createAutomation': 'सवालों का ऑटोमेशन बनाएँ',
  'questions.automationName': 'आने वाले सवालों के जवाब',
  'questions.learn': 'बातचीत से सीखें',
  'questions.learnHint':
    'इस डिवाइस पर सहेजे गए सभी संदेशों से सीखें। पूरी बातचीत में वास्तव में भेजे गए जवाब गिने जाते हैं; सारांश में उद्धरण उपयोग नहीं बढ़ाते। सुझाव स्वीकृत नहीं होते।',
  'questions.previewLearning': 'सीखे गए जवाब देखें',
  'questions.applyLearning': 'समीक्षा के लिए सुझाव सहेजें',
  'questions.learned':
    'सुझाव सहेजे गए। स्वीकृति से पहले हर जवाब की समीक्षा करें।',
  'questions.coverage': 'संग्रह के जाँचे गए संदेश: {seen} में से {retained}।',
  'questions.partialHistory':
    'विश्वसनीय समय न होने से कुछ बातचीत बाहर रखी गई हैं। सीखना सहेजे गए संदेशों तक सीमित है; सेवाओं से अनुपलब्ध इतिहास डाउनलोड नहीं होता।',
  'questions.preview': 'जवाब का पूर्वावलोकन',
  'questions.previewSource': 'पूर्वावलोकन का प्रदाता',
  'questions.previewChat': 'पूर्वावलोकन की चैट',
  'questions.match.exact': 'सटीक मिलान',
  'questions.match.template': 'पैटर्न मिलान',
  'questions.match.approximate': 'अनुमानित मिलान',
  'questions.match.assembled': 'अलग-अलग जवाबों से बनाया गया',
  'questions.match.unanswered': 'कोई मेल खाता जवाब नहीं',
  'questions.reviewRequired': 'स्वचालित भेजने से पहले समीक्षा ज़रूरी है।',
  'questions.ready':
    'स्वीकृत और पूरा है। इस पूर्वावलोकन में कुछ नहीं भेजा गया।',
  'questions.noAnswer': 'सहेजा गया जवाब जोड़ें या पूरा करें।',
  'questions.missing': 'प्रोफ़ाइल में मान गुम हैं: {fields}',
  'questions.enabled': 'इस जवाब नियम का उपयोग करें',
  'questions.approvedComplete': 'स्वीकृत और पूरा है।',
  'automations.form.neutral': 'सहेजा गया जवाब',
  'chat.form.neutral': 'सहेजा गया जवाब',
  'automations.reason.question-unanswered':
    'नए सवाल का कोई सहेजा गया जवाब नहीं',
  'automations.reason.question-already-answered':
    'आखिरी संदेश पहले ही भेजा जा चुका है',
  'automations.reason.question-turn-unavailable':
    'आखिरी संदेश को सवाल की तरह उपयोग नहीं किया जा सकता',
  'questions.aliases': 'समान अर्थ वाले प्रश्न, प्रत्येक पंक्ति में एक',
  'questions.canonical': 'पुराने विकल्पों की जगह इस सुधार का उपयोग करें',
  'questions.policy': 'उत्तर दोबारा उपयोग करने के नियम',
  'questions.policyHint':
    'अस्वीकृत वाक्यांश सहेजे और सीखे गए उत्तरों से हटाए जाते हैं, प्रोफ़ाइल से भरी गई जानकारी में भी। पुराने संदेश सुरक्षित रहते हैं। विराम चिह्न वाले विकल्प आपके चुने बिना नहीं जोड़े जाते।',
  'questions.rejected': 'अस्वीकृत वाक्यांश, प्रत्येक पंक्ति में एक',
  'questions.punctuationEquivalent':
    'केवल अंतिम विराम चिह्न में अलग उत्तरों की गिनती जोड़ें',
  'questions.policySaved': 'उत्तर दोबारा उपयोग करने के नियम सहेजे गए।',
  'questions.noReply': 'उत्तर सारांश पूरा है; जवाब आवश्यक नहीं।',
  'questions.match.summary': 'पूरी की गई प्रश्नावली का सारांश',
  'automations.reason.question-summary-complete':
    'प्रश्नावली पूरी है; जवाब आवश्यक नहीं',
  'questions.contexts': 'संदर्भ के मान',
  'questions.contextHint':
    'मुद्रा, काम करने के तरीके या अन्य संदर्भ के लिए प्रोफ़ाइल मान चुनने वाले शब्द सेट करें। प्राथमिकता: प्रश्न, हाल की बातचीत, नौकरी का वेतन, विवरण और आपका डिफ़ॉल्ट। अनुपलब्ध मान भरे नहीं जाते।',
  'questions.contextGroup': 'संदर्भ समूह',
  'questions.contextKey': 'संदर्भ फ़ील्ड, जैसे currency',
  'questions.contextChoice': 'संदर्भ विकल्प',
  'questions.contextChoiceId': 'विकल्प का मान, जैसे USD',
  'questions.contextKeywords':
    'यह विकल्प चुनने वाले शब्द, प्रत्येक पंक्ति में एक',
  'questions.contextDefault': 'संदर्भ न होने पर डिफ़ॉल्ट',
  'questions.contextNoDefault': 'संदर्भ आवश्यक है',
  'questions.contextAddGroup': 'संदर्भ समूह जोड़ें',
  'questions.contextRemoveGroup': 'संदर्भ समूह हटाएँ',
  'questions.contextAddChoice': 'संदर्भ विकल्प जोड़ें',
  'questions.contextRemoveChoice': 'संदर्भ विकल्प हटाएँ',
  'questions.contextPreview': 'पूर्वावलोकन के लिए बातचीत और नौकरी',
  'questions.contextPreviewHint':
    'ये फ़ील्ड केवल इस पूर्वावलोकन के लिए हैं। भेजते समय वास्तविक बातचीत और उससे जुड़ी नौकरी का संदर्भ उपयोग होता है।',
  'questions.contextRecent':
    'हाल के संदेश, सबसे नया पहले, प्रत्येक पंक्ति में एक',
  'questions.contextPay': 'नौकरी के वेतन का संदर्भ',
  'questions.contextDescription': 'नौकरी का विवरण',
  'questions.contextEvidence': 'ये मान क्यों चुने गए',
  'questions.contextSource.question': 'वर्तमान प्रश्न',
  'questions.contextSource.conversation': 'हाल की बातचीत',
  'questions.contextSource.vacancy-pay': 'नौकरी का वेतन',
  'questions.contextSource.vacancy-description': 'नौकरी का विवरण',
  'questions.contextSource.default': 'सेट किया गया डिफ़ॉल्ट',
  'questions.contextSource.missing': 'संदर्भ उपलब्ध नहीं है',
  'questions.contextSource.ambiguous': 'संदर्भ अस्पष्ट है',
  'questions.salaryGuidance':
    'रिक्ति/फ़ॉर्म के अनुसार न्यूनतम और सुविधाजनक दर का मसौदा बनाएँ (समीक्षा आवश्यक)',
  'questions.salary.hourlyNet': 'सुविधाजनक प्रति घंटे शुद्ध राशि (वैकल्पिक)',
  'questions.salary.hourlyGross': 'सुविधाजनक प्रति घंटे सकल राशि (वैकल्पिक)',
  'questions.contextSource.form-intro': 'फ़ॉर्म का परिचय',
  'questions.salaryMinimumSource': 'न्यूनतम भुगतान का स्रोत: {source}',
  'questions.contextSource.owner-target': 'स्वामी का लक्ष्य',
  'questions.salaryTitle': 'वेतन लक्ष्य',
  'questions.salaryHint':
    'हर मुद्रा के लिए अलग मासिक कर-पश्चात लक्ष्य दें। कर-पूर्व राशि भरें या अपनी कर दरों और दिनांकित विनिमय दरों से गणना चुनें। घंटे की दर आपके घंटों और चरण से ऊपर गोल होगी। अनुपलब्ध या पुरानी जानकारी की समीक्षा ज़रूरी है।',
  'questions.salaryEnabled': 'निर्धारित वेतन लक्ष्य उपयोग करें',
  'questions.salaryApproved':
    'पूर्ण वेतन उत्तरों को स्वतः भेजने की मंज़ूरी दें',
  'questions.salaryHours':
    'मासिक कार्य घंटे (खाली रखने पर प्रति घंटे उत्तर बंद)',
  'questions.salaryDefault': 'डिफ़ॉल्ट वेतन मुद्रा',
  'questions.salaryBasis': 'डिफ़ॉल्ट कर आधार',
  'questions.salaryCurrency': 'वेतन मुद्रा',
  'questions.salaryCode': 'मुद्रा कोड, जैसे USD',
  'questions.salaryKeywords': 'मुद्रा के शब्द, अल्पविराम से अलग',
  'questions.salary.net': 'मासिक कर के बाद की राशि',
  'questions.salary.gross': 'मासिक कर से पहले की राशि',
  'questions.salary.hourlyStep': 'प्रति घंटे पूर्णांकन चरण',
  'questions.salaryAdd': 'वेतन मुद्रा जोड़ें',
  'questions.salaryRemove': 'वेतन मुद्रा हटाएं',
  'questions.salaryClear': 'वेतन सेटिंग हटाएं',
  'questions.match.salary': 'निर्धारित वेतन लक्ष्य',
  'questions.salaryMethod': 'कर-पूर्व राशि का तरीका',
  'questions.salaryMethod.explicit': 'भरी हुई कर-पूर्व राशि',
  'questions.salaryMethod.personal': 'प्रगतिशील व्यक्तिगत कर',
  'questions.salaryMethod.company': 'कंपनी कर और वितरण कर',
  'questions.salary.grossStep':
    'गणना की गई कर-पूर्व मासिक राशि का पूर्णांकन चरण',
  'questions.salaryTaxHint.personal':
    'अपनी लागू वार्षिक कर-पूर्व आय की सीमाएं और दरें दें। हर दर केवल अपने दायरे पर लागू होती है; अंतिम दायरा असीमित है। क्षेत्र या कानूनी दरें पहले से तय नहीं हैं।',
  'questions.salaryTaxHint.company':
    'दायरा पूरी वार्षिक कर-पूर्व आय की एक दर चुनता है। वितरण कर कंपनी कर के बाद लगता है। ताज़ा विनिमय दर उपलब्ध हो तो सीमा की मुद्रा वेतन से अलग हो सकती है।',
  'questions.salaryTaxCurrency': 'व्यक्तिगत कर की मुद्रा',
  'questions.salaryBand': 'कर दायरा {number}',
  'questions.salaryBandLimit': 'वार्षिक कर-पूर्व आय की ऊपरी सीमा',
  'questions.salaryBandCurrency': 'सीमा की मुद्रा (खाली पर वेतन की मुद्रा)',
  'questions.salaryTaxRate': 'कर दर (%)',
  'questions.salaryPayout': 'अतिरिक्त वितरण कर (%)',
  'questions.salaryUnlimited': 'अंतिम दायरा: कोई ऊपरी सीमा नहीं',
  'questions.salaryAddBand': 'सीमित कर दायरा जोड़ें',
  'questions.salaryRemoveBand': 'कर दायरा हटाएं',
  'questions.salaryAddTax': 'कर दर तालिका बनाएं',
  'questions.salaryRemoveTax': 'कर दर तालिका हटाएं',
  'questions.salaryExchange': 'दिनांकित विनिमय दरें',
  'questions.salaryExchangeHint':
    'दर हर सूचीबद्ध मुद्रा की एक इकाई के लिए आधार मुद्रा की इकाइयां है। केवल कर सीमाओं का रूपांतरण होता है; अलग कर-पश्चात लक्ष्य नहीं बदलते। उत्तर के साथ स्रोत और तारीख दिखेंगे। अनुपलब्ध या पुरानी दरों की समीक्षा ज़रूरी है।',
  'questions.salaryExchangeBase': 'विनिमय की आधार मुद्रा',
  'questions.salaryExchangeDate': 'दर की तारीख',
  'questions.salaryExchangeSource': 'दर का स्रोत',
  'questions.salaryExchangeSource.manual': 'मालिक की दी हुई दरें',
  'questions.salaryExchangeSource.cbr': 'रूसी केंद्रीय बैंक की दरें',
  'questions.salaryExchangeAge': 'दर की अधिकतम आयु (दिन)',
  'questions.salaryExchangeRate': 'एक मुद्रा इकाई के लिए आधार इकाइयां',
  'questions.salaryAddRate': 'विनिमय दर जोड़ें',
  'questions.salaryRemoveRate': 'विनिमय दर हटाएं',
  'questions.salaryAddExchange': 'विनिमय दरें बनाएं',
  'questions.salaryRemoveExchange': 'विनिमय दरें हटाएं',
  'questions.salaryCalculationEvidence': 'वेतन गणना का विवरण',
  'questions.salaryFetchRates': 'रूस के केंद्रीय बैंक से ताज़ा करें',
  'questions.salaryUseCachedRates': 'सहेजी दरें इस्तेमाल करें',
  'questions.salaryRatesLoading': 'विनिमय दरें लोड हो रही हैं…',
  'questions.salaryRates.updated':
    'रूस के केंद्रीय बैंक की दरें लोड हुईं ({date})।',
  'questions.salaryRates.cached': 'सहेजी दरें लोड हुईं ({date})।',
  'questions.salaryRates.stale':
    '{date} की दरें पुरानी हैं। गणना वाले उत्तरों की समीक्षा ज़रूरी है।',
  'questions.salaryRates.unavailable':
    'कोई सहेजी दर उपलब्ध नहीं है। दरें भरें या दोबारा ताज़ा करें।',
  'questions.salaryRatesFallback':
    'ताज़ा करने से नई मान्य दरें नहीं मिलीं; उपलब्ध सहेजी दरें रखी गई हैं।',
  'questions.salaryRatesDraft': 'दरें इस मसौदे में लागू हुई हैं।',
  'questions.salaryRatesChanged':
    'दरें लोड होते समय सेटिंग बदली। आपके बदलाव रखे गए हैं; उन्हें बदलने के लिए फिर कोशिश करें।',
  'questions.salaryExchangeMode': 'विनिमय दर नीति',
  'questions.salaryExchangeMode.snapshot': 'इस सहेजी दर का उपयोग करें',
  'questions.salaryExchangeMode.cbr':
    'रूस के केंद्रीय बैंक से अपने आप ताज़ा करें',
  'questions.salaryExchangeModeHint':
    'स्वचालित मोड ताज़ी सहेजी दरें लेता है और योजना से पहले अनुपलब्ध या पुरानी दरें ताज़ा करता है। अनुरोध विफल होने पर कैश की तारीख़ रहती है और पाँच मिनट बाद फिर प्रयास होता है। सहेजी दरें केवल स्नैपशॉट मोड में इस्तेमाल होती हैं।',
};
import { hiFollowBacklink } from './hi-follow-backlink.js';
