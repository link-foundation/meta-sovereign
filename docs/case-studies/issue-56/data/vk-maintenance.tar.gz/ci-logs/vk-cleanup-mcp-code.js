async (page) => (async (page, fixture, check) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      language
    );
    await page.goto(`${fixture.base}/?vkLocale=${language}#conn-vk/manual`);
    const panel = page.locator(`[data-${fixture.feature}]`);
    const ready = () =>
      page.waitForFunction((feature) => {
        const input = document.querySelector(
          `[data-${feature}] input[type=checkbox]`
        );
        return input && !input.disabled;
      }, fixture.feature);
    // A mounted heading and an enabled control distinguish loading from absence.
    await panel
      .getByRole('heading', { name: words.title, exact: true })
      .waitFor();
    await ready();
    for (const key of fixture.keys) {
      if (!(await panel.innerText()).includes(words[key])) {
        throw Error(`Missing ${language}.${key}`);
      }
    }
    const { focus, ...checked } = await check(page, {
      panel,
      words,
      ready,
      feature: fixture.feature,
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await panel.locator(focus).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-${fixture.feature}/mcp-${language}-phone.png`,
    });
    result.push({ language, translated: true, ...checked });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:33405","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","feature":"vk-cleanup","keys":["hint","enabled","priorityIds","limit","plan","run"],"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"VK inactive friend cleanup","hint":"Remove only banned or deleted friends. Priority IDs in any VK friend policy are always protected. Automatic cleanup starts off; a reviewed confirmation is required for each manual batch.","enabled":"Run this saved policy automatically","priorityIds":"Priority user IDs, separated by commas","limit":"Batch limit (0–10000; zero disables effects)","plan":"Prepare review","run":"Confirm reviewed removals"},"ru":{"title":"Удаление неактивных друзей ВКонтакте","hint":"Удаляются только заблокированные или удалённые друзья. Приоритетные ID во всех правилах друзей ВКонтакте всегда защищены. Автоочистка изначально выключена; каждый ручной пакет требует просмотра и подтверждения.","enabled":"Автоматически выполнять сохранённые правила","priorityIds":"ID приоритетных пользователей через запятую","limit":"Предел за проход (0–10000; ноль запрещает действия)","plan":"Подготовить просмотр","run":"Подтвердить просмотренные удаления"},"hi":{"title":"VK निष्क्रिय मित्र सफाई","hint":"केवल प्रतिबंधित या हटाए गए मित्र हटाएँ। VK की किसी भी मित्र नीति में प्राथमिक ID हमेशा सुरक्षित हैं। स्वचालित सफाई शुरू में बंद है; हर मैनुअल बैच की समीक्षा और पुष्टि चाहिए।","enabled":"सहेजी नीति अपने आप चलाएँ","priorityIds":"प्राथमिक उपयोगकर्ता ID, अल्पविराम से अलग","limit":"बैच सीमा (0–10000; शून्य पर कार्रवाइयाँ बंद)","plan":"समीक्षा तैयार करें","run":"समीक्षित हटाने की पुष्टि करें"},"zh":{"title":"VK 停用好友清理","hint":"仅删除被封禁或已注销的好友。所有 VK 好友规则中的优先 ID 始终受到保护。自动清理默认关闭；每次手动处理均须审核确认。","enabled":"自动运行已保存的规则","priorityIds":"优先用户 ID，以逗号分隔","limit":"每批上限（0–10000；零禁用操作）","plan":"准备审核","run":"确认已审核的删除操作"}}}, (async (page, { panel, ready, feature }) => {
  const name = feature.slice(3);
  const enabled = panel.locator(`[data-action=vk-${name}-enabled]`);
  const previous = await enabled.isChecked();
  await enabled.click();
  await ready();
  const priority = panel.locator(`[data-${name}-field=priorityIds]`);
  const target = Number((await priority.inputValue()) || 99) + 1;
  await priority.fill(String(target));
  await panel.locator(`[data-${name}-field=limit]`).fill('1');
  await panel.locator(`[data-action=vk-${name}-save]`).click();
  await ready();
  await panel.locator(`[data-action=vk-${name}-plan]`).click();
  await ready();
  await panel.locator(`[data-vk-${name}-plan=review]`).waitFor();
  await panel.locator(`[data-action=vk-${name}-run]`).click();
  await ready();
  await panel.locator(`[data-vk-${name}-status=confirmed]`).waitFor();
  await page.reload();
  await ready();
  if (
    (await enabled.isChecked()) === previous ||
    (await priority.inputValue()) !== String(target)
  ) {
    throw new Error('Acknowledged policy lost');
  }
  await panel.locator(`[data-vk-${name}-status=confirmed]`).waitFor();
  return {
    focus: `[data-vk-${name}-status]`,
    reviewed: true,
    acknowledged: true,
    savedChoiceRetained: true,
  };
}))