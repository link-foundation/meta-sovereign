# 数据迁移：带版本的数据模式 (languages: [en](DATA-MIGRATIONS.md) • zh • [hi](DATA-MIGRATIONS.hi.md) • [ru](DATA-MIGRATIONS.ru.md))

当存储数据的形状发生变化（字段改名、标识符换了算法、日期改存为 ISO 文本）时，磁盘上已有的数据必须随之更新。meta-sovereign 在数据旁保存一个**模式版本**，并在数据以写入方式打开时按顺序自动执行**迁移**（R-Z17）。

## 版本如何工作

- 版本是存储中的一条链接 `meta:schema`：`{ version, applied: [{ id, at, ms, changed }], app }`。`applied` 是历史（哪个迁移、何时、耗时多久、改了多少条链接）；`app` 是写入它的应用版本。
- 没有这条链接的存储是**版本 0**：即有版本之前的数据形状。空存储视为最新。
- `CURRENT_SCHEMA`（在 `js/src/storage/migrations/index.js`）是本构建写入的版本。每个迁移是一个模块 `js/src/storage/migrations/<NNNN>-<slug>.js`，把数据从版本 `NNNN-1` 迁到 `NNNN`。
- 同样的模块同时用于**服务器存储**（`data.lino`）、**恢复的备份**以及网页 / GitHub Pages 模式的**浏览器存储**。

## 用户会看到什么

| 位置                                             | 发生什么                                                                                                                                                                                     |
| ------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `meta-sovereign serve` 或任何写入命令            | 若存储较旧，先迁移（服务器之后才开始监听）。日志显示 `migration_started`，每个迁移一条 `migration_step`（`id`、`scanned`、`changed`、`ms`；只有计数，从不含内容），然后是 `migration_done`。 |
| `meta-sovereign migrate --store=<dir>`           | 立即迁移并打印同样的行。                                                                                                                                                                     |
| `meta-sovereign migrate --store=<dir> --dry-run` | 统计每个迁移会改动什么；不写入，不加锁。                                                                                                                                                     |
| `meta-sovereign migrate --store=<dir> --status`  | 存储的版本、待执行的迁移数以及历史。                                                                                                                                                         |
| `/api/health`                                    | `schema: { version, current }`。                                                                                                                                                             |
| 只读命令（`export`、`backup`、`cv-read` 等）     | 从不迁移。较旧的存储按原样读取（一行 `schema_old_read_only` 说明）；读取代码接受旧形状。                                                                                                     |
| 备份                                             | 归档记录 `schema: { version }`。恢复较旧的归档时先在内存中迁移其链接，因此失败不会写入任何内容；较新的归档会被拒绝并报 `BACKUP_TOO_NEW`。                                                    |
| 对等同步（`/ws`、`sync-connect`、WebRTC）        | 对等方交换模式版本。若数字不同，则不交换任何数据，双方记录 `SCHEMA_MISMATCH` 并写明两个版本；较旧的一方必须更新应用。                                                                        |

### 来自较新版本的存储：`STORE_TOO_NEW`

若存储由较新的应用写入（版本高于 `CURRENT_SCHEMA`），应用**绝不写入**：服务器保持关闭，命令以“this store was written by a newer version; update the app”停止。只读打开同样被拒绝，以免误读数据。请更新应用（或用写入它的应用打开该存储）。

### 磁盘空间不足：`LOW_DISK`

迁移只向日志追加，但仍需要空间。开始前可用空间至少为 `data.lino` 的 10% 加 256 MB；否则不做任何改动，并告知需要多少、剩余多少。释放空间后重新启动即可。

## 回滚：失败的迁移如何不复制存储而被撤销

`data.lino` 只追加，因此迁移通过截断来撤销：

1. 第一个迁移之前，日志被刷新到磁盘，其字节长度被持久地写入 `migration.json`。
2. 迁移期间暂停压缩（日志只追加），也不写二进制快照 `data.bin`。
3. 每个迁移完成后，追加其 `meta:schema` 链接，`migration.json` 前移到新长度。两个迁移之间停止，则保留第一个。
4. 最后删除 `migration.json`。
5. 若迁移抛出错误，或进程死亡且下次打开发现 `migration.json`：`data.lino` 被截断到记录的长度（fsync），`data.bin` 被删除（由日志重建），日志文件被移除（`migration_rolled_back`）。同一次打开随后再试一次。若再次失败，应用报告带迁移 id 的 `MIGRATION_FAILED`，存储保持原样。

不会产生存储的第二份副本，内存也保持在存储本来占用的水平（迁移以每批 1000 份副本查看链接）。

**浏览器存储**是整体保存的快照，没有日志可截断：其迁移是幂等的，每个迁移后保存 `meta:schema`，中途关闭的标签页会重新执行该迁移并得到相同结果。来自较新构建的浏览器存储不会被触碰（页面使用临时副本并触发 `ms-schema-too-new` 事件）。

## 编写迁移

检查清单：

1. **模块** `js/src/storage/migrations/<NNNN>-<slug>.js`，导出 `id`（不含 `.js` 的文件名）、`from`（`NNNN-1`）、`to`（`NNNN`）、`description` 和 `async up(ctx)`。在 `index.js` 的 `MIGRATIONS` 中加入导入和条目，并把 `CURRENT_SCHEMA` 提到 `to`。不得导入 `node:`，不得联网：它是纯数据转换，必须也能在浏览器中运行。
2. **幂等且只向前。** 崩溃后再次运行 `up` 必须得到相同结果：从已存字段计算目标形状，只写入不同之处（`ctx.putMany` 会跳过已相等的链接，只统计真实改动）。
3. **旧形状存储的夹具测试**：按上一个版本存储的方式构造链接（参见 `js/tests/migrations-email.test.js`；最好由当前代码写入的内容推导），迁移后与当前代码会存储的内容比较。
4. **幂等测试**：运行两次（`runMigrations(store, { migrations, from: <旧版本> })`）；第二次改动 0 条。
5. **dry-run 计数**：同一夹具通过 `migrate --dry-run`（或 `runMigrations(..., { dryRun: true })`）报告改动的链接数且不写入。
6. **文档行**：在下表中加一行，并说明哪些无法由已存数据重新计算（以及旧记录仍可读取）。
7. 迁移发布并运行一段时间之前，读取代码继续接受旧形状（只读打开不迁移）。

`ctx` 提供：

- `ctx.scan({ prefix, where, batchSize }, async (batch) => ...)`：成批的匹配链接副本；`ctx.get(id)`。
- `ctx.putMany(links)` / `ctx.put(link)`：写入有变化的链接；`ctx.tombstone(id)`：删除一条。
- `ctx.rekey(oldId, newId, { patch })`：把链接写到新 id 下，保留指向它的 `alias:<oldId>` 链接，并把旧 id 标记删除。`newId` 下已有的不同链接不会被覆盖（计入 `ctx.stats.conflicts`）。`ctx.rekeyMany(pairs, { fields, children, refMap })` 对多对 id 执行，然后一次遍历，把 `children` 条目、列出的标量 `fields`（如 `replyTo`）以及 `refMap(text)` 映射的内容（嵌入更长 id 中的 id）指向新 id。`ctx.resolve(id)` 沿别名解析，因此仍引用旧 id 的回复、表情回应或聊天成员关系依然能找到目标。
- `ctx.log(name, counts)`：只含数字的日志行；`ctx.progress({ scanned, changed })`；`ctx.dryRun`。

## 迁移列表

| Id                            | 模式     | 作用                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| ----------------------------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `0001-email-threads`          | 0 -> 1   | 由原始 RFC 822（IMAP、POP3、`.eml`、`.mbox`）读取的邮件获得 R-Z5 使用的会话键（`References` 的第一个 id，否则 `In-Reply-To`，否则自身 `Message-ID`，否则去前缀的主题）、父邮件、`messageId` / `references` / `inReplyTo`，并把 `timestamp` 改为 ISO 时间；所有邮件的时间都改为 ISO。由已存的 `rawHeaders` 和 `subject` 重新计算。无法从已存数据恢复：encoded-word 主题的解码形式，以及没有 Message-ID 的邮件的 id；它们保持原样且仍可读取。                                                                                                                                                                                                |
| `0002-whatsapp-chat-ids`      | 1 -> 2   | WhatsApp 聊天改用 R-Z9 的稳定 id：E.164 号码、群组 JID、关联 id JID，或已保存联系人导出文件的 `name:<哈希>`。根据已存的 `chat`、`chatName` 和 `via` 重新计算；从页面读取的消息迁到 `msg:whatsapp:<新聊天>:<键>`（旧 id 仍可通过 `alias:` 找到），`chat`、tokens 和 `chat:whatsapp:<id>` 引用随之更新。已存数据无法恢复的：按页面标题读取的聊天（当时没有保存号码）、没有名称的 `unknown` 导出聊天、以参与者 JID 存储的群消息的真实 id，以及旧导出的计数 id；它们保留原 id（能计算时聊天仍会更新），依然可读。数量记录在日志行 `whatsapp_chat_ids_unresolved`。                                                                             |
| `0003-vk-reactions-docs`      | 2 -> 3   | VK 反应改为存储表情，数字保留在 `reactionId`（原先只是数字）；以 `file` 存储的 VK 图片 / gif 文档获得 `photo` / `gif` 类型和 `ext`。根据已存的 `reactions` 和保留的 `raw` 重新计算；VK 没有对应表情的反应保持为数字，没有 `raw` 的消息保留原附件。消息 id、聊天 id、发送者和时间均未改变（没有 id 迁移）。数量记录在日志行 `vk_reactions_docs`。                                                                                                                                                                                                                                                                                           |
| `0004-github-external-ids`    | 3 -> 4   | GitHub 条目获得 `externalId`（`kind`、REST `id`、`nodeId`、`owner`、`repo`、`number`）和 `messageId`，仅由已保存的字段回填：类型和编号来自链接 id，仓库来自 `raw.url`（或链接 id），REST id 和 node id 来自 `raw`，评论所属的 issue 编号来自其聊天。无法确定仓库或对象的条目保持不变，编辑 / 删除 / 反应仍以 `no-external-id` 拒绝；其数量记录在日志行 `github_external_ids`（`unresolved`）。不访问网络；没有 id 被移动。                                                                                                                                                                                                                 |
| `0005-archive-ids`            | 4 -> 5   | Facebook / Messenger 和 LinkedIn 归档消息获得不冲突的 id：`msg:facebook:<会话文件夹>:<毫秒>:<发送者摘要>:<n>`（原为 `msg:facebook:<毫秒>`）和 `msg:linkedin:<会话>:<ISO 时间>:<发送者摘要>:<n>`（原为 `<会话>-<日期文本>`）；Facebook 的数字 `timestamp` 变为 ISO 文本，发送者和正文中的 latin-1 乱码仅在可还原时才修复。由已保存的 `chat`、`sender`、`timestamp` 和 `raw` 计算；旧 id 通过 `alias:` 仍可解析，导入时也会检查它们，因此重新导入同一归档不会产生重复。无法恢复：没有 `timestamp_ms` 的 Facebook 消息和日期无法读取的 LinkedIn 消息保留原 id（日志行 `archive_ids`，`unresolved`）；旧 id 下已合并的消息本来就是同一条链接。 |
| `0006-tombstones`             | 5 -> 6   | `deleted: true`、`{ deleted: true, deletedAt }`（应用内删除消息）以及不完整的 `deleted` 对象统一为新代码写入的唯一形态 `deleted: { at, by, reason }`。只根据已存字段计算：单独的 `deleted: true` 变为 `{ at: null, by: 'unknown', reason: null }`（时间和原因从未保存），`deletedAt` 变为 `at`，并带 `by: 'user'`、`reason: 'deleted-in-app'`。`false` / `null` 保持不变；其他类型的值不动并被计数（日志行 `tombstones`、`unknown`）。读取方仍接受旧形态（`isTombstone`、`deletedAtOf`），所以只读打开旧存储可正常工作。                                                                                                                   |
| `0007-browser-policy`         | 6 -> 7   | 添加可移植的浏览器可见默认设置。保留已有记录、配置文件和恢复的设置。只读存储缺少设置时也默认可见。不读取账户数据。                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| `0008-salary-exchange`        | 7 -> 8   | 添加空的俄罗斯银行薪酬汇率日期缓存。迁移不虚构或下载汇率，保留现有答案及导入的汇率快照；只读存储中缺少缓存时显示汇率不可用。                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| `0009-salary-exchange-policy` | 8 -> 9   | 将现有薪酬自动化保留为保存快照模式。保留已明确选择的央行自动策略；迁移不联网，不修改批准状态或汇率。                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| `0010-hh-message-metadata`    | 9 -> 10  | 只从已保存的原始消息补全 HH 方向、发送者、申请屏障、回复和编辑元信息。保留明确已有值、ID、聊天和不可变版本；不访问网络。没有原始数据的记录仍可读，须显式重新导入才能补全。                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| `0021-hh-browser-delivery`    | 20 -> 21 | 将缺少已保存送达证据的旧 HH 浏览器发出消息标记为 unknown。重新读取原生状态后可更新为 sent、delivered 或 read。保留正文、ID、时间、版本、API 记录和明确状态；不访问网络或改写答案知识库。                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| `0022-unread-answers`         | 21 -> 22 | 为旧的未读遍历及轮询输入添加明确的 `answerChats: false`。不执行浏览器操作，不更改草稿或批准状态。保留已有 true 选择；只读旧记录仍默认为仅审核模式。仅新的明确启动会写入保留审核及选项回执。                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| `0023-answer-final-period`    | 22 -> 23 | 为现有复用策略记录默认 `answerFinalPeriod: with`，保留明确的 `without`。无效的已存偏好会阻止迁移。不更改答案、次数、聊天、批准状态，不操作浏览器或网络。                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| `0024-answer-equivalents`     | 23 -> 24 | 接受有界的明确等价答案声明，拒绝无效或歧义列表。保留旧答案、次数、批准状态和消息，不推测、不访问网络。                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| `0025-application-preview`    | 24 -> 25 | 为私有申请审核和批次预留可选职位预览时长。保留已确认签名、答案和发送预留；旧记录无此字段时，执行默认暂停 3 秒。发现意外字段则拒绝迁移。不执行浏览器或网络操作。JavaScript 和原生同步节点协商模式版本 25。                                                                                                                                                                                                                                                                                                                                                                                                                                  |

### 其他工作宣布的形状变化（各自按此约定添加迁移）

| 变化                                                                     | 如何适配                                                                               |
| ------------------------------------------------------------------------ | -------------------------------------------------------------------------------------- |
| R-Z7：删除标记统一为 `deleted: { at, by, reason }`                       | 扫描带 `deleted: true` 或 `deletedAt` 的链接；`ctx.putMany`。                          |
| R-Z10：Facebook / LinkedIn 消息 id；Facebook `timestamp_ms` 数字改为 ISO | id 用 `ctx.rekeyMany`（别名使回复和表情回应仍可解析）；时间用 `scan` + `putMany`。     |
| R-Z9：WhatsApp 聊天 id 由标题式改为稳定式                                | `ctx.rekeyMany`，配合 `fields: ['chat']` 与针对 `chat:whatsapp:<id>` 子项的 `refMap`。 |
| R-Z11：GitHub 条目新增 `externalId`                                      | `scan` + `putMany`，尽可能由已存的 URL / id 回填。                                     |

## Telegram 的 `SCHEMA_REV` 是另一回事

`telegram-layer.js` 中的 `SCHEMA_REV` 表示聊天上次是用哪一层 Telegram API 读取的；它变化时 `telegram-repair.js` 会从网络重新读取聊天。迁移不得使用网络，所以两者保持分离：迁移改变已存数据的形状，修复则重新向 Telegram 询问新一层能提供的内容。
