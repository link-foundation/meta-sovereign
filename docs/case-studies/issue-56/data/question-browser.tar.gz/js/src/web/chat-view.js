// The chat screen (issue #31 / PR #34), styled after t3.codes by default
// and re-skinnable (Telegram, WhatsApp, Signal — see app.css `data-skin`):
//
//   - a searchable conversation list with names, previews and date
//     sections;
//   - the conversation in a centred column, with "typing…" for the other
//     side and for an automation typing on the user's behalf;
//   - a floating composer that suggests whole replies we gave to the
//     last message before, then word by word from our own messages,
//     and shows our typing status while the user types;
//   - a menu that runs or tests an automation in this chat, and the
//     drafts automations left here: send (one click is the
//     confirmation), edit, switch "ты"/"вы", mark as sent by hand, skip.

import { PeerBar } from './chat-peer-actions.js';
import { AutomationRunButton } from './chat-automation-button.js';
import { BrowserAnswerControls } from './question-browser-controls.js';
import { useAutomationDismiss } from './chat-automation-dismiss.js';
import { TranslateBar } from './chat-translate-bar.js';
import { VoiceChatBar } from './chat-voice-chat.js';
import {
  CallButton,
  PrivateCallHost,
  usePrivateCall,
} from './chat-private-call.js';
import { PinnedBar } from './chat-pinned.js';
import { DeletedBar } from './chat-deleted.js';
import { EditedBar } from './chat-message-versions.js';
import { LiveLocationsBar } from './chat-live-locations.js';
import { RequestsBar } from './chat-join-requests.js';
import { NotifyButton } from './chat-notify-settings.js';
import { ExportMenu } from './chat-export.js';
import { TtlBadge } from './chat-ttl.js';
import { ChatReactionsScope } from './chat-reactions.js';
import { ChatWall } from './chat-wallpaper.js';
import { useChatTheme } from './chat-theme.js';
import { SavedChats, SavedToggle, useSavedView } from './chat-saved.js';
import {
  SavedTagBar,
  SavedTagResults,
  useSavedTags,
} from './chat-saved-tags.js';
import React, { useCallback, useRef, useState } from 'react';
import { LoadError } from './api-errors.js';
import { api as defaultApi } from './dom.js';
import { sentence, useDates, useLocaleContext, useT } from './i18n.js';
import { ConnectionGuide } from './connection-guide.js';
import { ChatAccountEmpty, ChatAccountNotice } from './chat-account.js';
import { networkName } from './connection-guides.js';
import { networkMessageId } from './chat-model.js';
import { presetName } from './automations-model.js';
import { useChatState, chatFromHash } from './chat-state.js';
import { Icon } from './icons.js';
import { Notice } from './notice.js';
import { useLeaving } from './chat-leaving.js';
import { infoLine } from './chat-info.js';
import { isBirthdayToday } from './profile-extras-model.js';
import { PersonPanel } from './person-panel.js';
import { UnreadMarks, useUnreadMarks } from './chat-marks.js';
import { MessageBubble, QuoteContext, ReplyQuote } from './chat-message.js';
import { ChatKindContext } from './auto-download.js';
import { ChatAvatar } from './chat-list.js';
import { EmojiStatus } from './emoji-status.js';
import { replyRefOf, useChatActions } from './chat-actions.js';
import { useMessageLinks } from './chat-link-open.js';
import { TagSearchHost } from './chat-tags.js';
import { InstantViewHost } from './chat-instant-view.js';
import { EmptyConversation } from './chat-empty.js';
import { Suggestions } from './chat-suggestions.js';
import { useComposerHeight } from './chat-composer-height.js';
import {
  accountDeleted,
  chatDisplayName,
  DeletedAccountBadge,
} from './chat-identity.js';
import { BotBar } from './chat-business-bots.js';
import { useBusinessLinks } from './chat-business-link-open.js';
import { useProfileRequest } from './contact-links.js';
import { ConversationHeader } from './chat-selection.js';
import { useDragSelect } from './chat-drag.js';
import { Busy, ChatListSkeleton } from './spinner.js';
import { useComposerText, useSuggestionsFor } from './chat-suggest.js';
import {
  appTarget,
  useBotCommands,
  useCommandBox,
} from './chat-bot-commands.js';
import { useInlineBox } from './chat-inline-bots.js';
import { useLinkPreview } from './chat-link-preview.js';
import { EditBar, hasMedia, useCaretAtEnd } from './chat-edit-mode.js';
import {
  AttachButton,
  AttachDialog,
  DropHint,
  pasteFiles,
  useAttach,
  useDropFiles,
} from './chat-attach.js';
import { PollDialog, usePollCreate } from './chat-poll-create.js';
import { TodoDialog, useTodoCreate } from './chat-todo-create.js';
import { ShareDialog, useShare } from './chat-share.js';
import { useAttachBots } from './chat-attach-bots.js';
import { TopicTabs } from './chat-topics.js';
import { ForumViewMenu, stripForum, useForumView } from './chat-forum-view.js';
import { TopicClosedBar, topicClosedFor } from './chat-topic-admin.js';
import {
  ScheduleDialog,
  ScheduledButton,
  ScheduledList,
  SendMenu,
  WHEN_ONLINE,
  sendMenuItems,
  useScheduled,
  useSendMenu,
} from './chat-schedule.js';
import { canEffect, EffectPanel } from './chat-effects.js';
import { formatShortcut } from './text-shortcuts.js';
import { useEmojiTools } from './chat-emoji-tools.js';
import { useVoice } from './chat-voice.js';
import { useRoundVideo } from './chat-round-record.js';
import { useFormatBar } from './chat-format-bar.js';
import {
  KeyboardToggle,
  ReplyKeyboard,
  useReplyKeyboard,
} from './chat-bots.js';
import { AutopilotBar, DraftCard, NextChatBar } from './chat-automation.js';
import { groupAlbums, rowIds } from './chat-album.js';
import { SearchBar, SearchButton, useChatSearch } from './chat-search.js';
import {
  DayPill,
  FloatingDay,
  dayBreaks,
  useDayJump,
  useNewer,
} from './chat-days.js';
import { goToMessage, useArrival, useStreamJumps } from './chat-jump.js';
import { NOTICE, Sidebar, noticeInWords } from './chat-sidebar.js';
import { useSendAs } from './chat-send-as.js';
import { usePaidSend } from './chat-paid-send.js';
import { useLiveWatch } from './live-watch.js';
// VK's captcha, asked of the user when scroll-back needs it (R-Z20).
import { VkCaptchaDialog } from './vk-captcha.js';
import {
  OlderRow,
  UnreadLine,
  useFollow,
  useKeepPlace,
  useOlder,
  useSeen,
} from './chat-follow.js';

// The list's paging helpers live in ./chat-follow.js; their tests read
// them here.
export { addedAfter, followMove } from './chat-follow.js';

export { failureText, waitingText } from './chat-failure.js';
export { autopilotText } from './chat-automation.js';
export { reasonText } from './notice.js';
export { noticeInWords } from './chat-sidebar.js';

import {
  ShortcutsHost,
  focusListSearch,
  useChatShortcuts,
} from './shortcuts.js';

const el = React.createElement;

const isTyping = (typing) =>
  Boolean(typing.automation) || typing.people.length > 0;

const TypingLine = ({ typing }) => {
  const t = useT();
  if (typing.automation) {
    return el(
      'span',
      { className: 'typing', 'data-typing': 'automation' },
      t('chat.typingAutomation', {
        name: presetName(t, typing.automation),
      })
    );
  }
  if (typing.people.length > 0) {
    return el(
      'span',
      { className: 'typing', 'data-typing': 'people' },
      t('chat.typing', { names: typing.people.join(', ') })
    );
  }
  return null;
};

const automationTriggerKey = (automation) => {
  const automatic = automation.triggers?.some((trigger) =>
    ['incoming', 'schedule'].includes(trigger.kind)
  );
  return automatic
    ? automation.enabled === false
      ? 'disabled'
      : 'enabled'
    : 'manual';
};

const AutomationMenuToggle = ({ menu, activeCount, t }) =>
  el(
    'button',
    {
      type: 'button',
      className: 'chat-menu-toggle',
      'aria-expanded': menu.open ? 'true' : 'false',
      'aria-busy': Boolean(menu.running),
      'data-action': 'chat-automations',
      'aria-label': t('chat.automations'),
      title: t('chat.automations'),
      onClick: menu.toggle,
    },
    [
      el(Icon, { key: 'i', name: 'automation', size: 16 }),
      el(
        'span',
        { key: 'l', className: 'chat-automation-label' },
        t('chat.automations')
      ),
      activeCount
        ? el(
            'span',
            {
              key: 'active',
              className: 'automation-active-count',
              'data-automation-active-count': activeCount,
            },
            String(activeCount)
          )
        : null,
    ]
  );

const AutomationMenu = ({ menu, autopilot, api, chat }) => {
  const box = useAutomationDismiss(menu.open, menu.close ?? menu.toggle);
  const t = useT();
  const activeCount = menu.automations.filter(
    (item) => autopilot?.stateFor?.(item.id)?.on
  ).length;
  return el('div', { className: 'chat-menu', ref: box }, [
    el(AutomationMenuToggle, { key: 'toggle', menu, activeCount, t }),
    menu.open
      ? el(
          'div',
          { key: 'list', className: 'chat-menu-list', role: 'menu' },
          menu.automations.length === 0
            ? [
                el(
                  'p',
                  { key: 'none', className: 'meta' },
                  t('chat.automation.none')
                ),
                el(BrowserAnswerControls, {
                  key: `browser:${chat.key}`,
                  api,
                  chat,
                }),
              ]
            : [
                el(
                  'p',
                  {
                    key: 'status',
                    className: 'meta',
                    'data-automation-summary': '',
                  },
                  t('chat.automation.summary', { count: activeCount })
                ),
                ...menu.automations.map((a) => {
                  const run = autopilot?.stateFor?.(a.id);
                  const apOn = run?.on;
                  return el('div', { key: a.id, className: 'chat-menu-item' }, [
                    el('span', { key: 'n', className: 'chat-menu-name' }, [
                      el('strong', { key: 'n' }, a.name),
                      el(
                        'small',
                        {
                          key: 'status',
                          className: 'automation-state',
                          'data-automation-state': apOn
                            ? 'active'
                            : run?.status === 'paused'
                              ? 'paused'
                              : 'off',
                        },
                        t(
                          apOn
                            ? 'chat.automation.active'
                            : run?.status === 'paused'
                              ? 'chat.automation.paused'
                              : 'chat.automation.off'
                        )
                      ),
                      el(
                        'small',
                        {
                          key: 'triggers',
                          className: 'meta',
                          'data-automation-triggers': automationTriggerKey(a),
                        },
                        t(`chat.automation.triggers.${automationTriggerKey(a)}`)
                      ),
                      el(
                        'small',
                        { key: 'm', className: 'meta' },
                        sentence(t(`automations.mode.${a.mode}`))
                      ),
                    ]),
                    el(AutomationRunButton, {
                      key: 'test',
                      menu,
                      automation: a,
                      test: true,
                    }),
                    el(AutomationRunButton, {
                      key: 'run',
                      menu,
                      automation: a,
                      test: false,
                    }),
                    el(AutomationRunButton, {
                      key: 'find',
                      menu,
                      automation: a,
                      find: true,
                    }),
                    apOn
                      ? el(
                          'button',
                          {
                            key: 'ap',
                            type: 'button',
                            role: 'menuitem',
                            'data-action': 'autopilot-stop',
                            'data-automation': a.id,
                            onClick: () => autopilot.stop(a.id),
                          },
                          t('chat.autopilot.stop')
                        )
                      : el(
                          'button',
                          {
                            key: 'ap',
                            type: 'button',
                            role: 'menuitem',
                            'data-action': 'autopilot-start',
                            'data-automation': a.id,
                            onClick: () => autopilot?.start(a.id),
                          },
                          t('chat.draft.autopilot')
                        ),
                  ]);
                }),
                el(BrowserAnswerControls, {
                  key: `browser:${chat.key}`,
                  api,
                  chat,
                }),
              ]
        )
      : null,
  ]);
};

// Under the name: who is typing, else Telegram's members and online, a
// person's last seen, else the network and how many wrote here.
const subtitleOf = (t, state, chatTime) => {
  if (accountDeleted(state.current, state.info)) {
    return t('chat.account.deleted');
  }
  const chat = state.current;
  const line = infoLine(t, state.info, { kind: chat.kind, chatTime });
  const source = networkName(t, chat.source);
  if (line) {
    return line;
  }
  // A group whose members are not known yet says only where it is.
  if (!chat.personal && chat.people.length === 0) {
    return source;
  }
  return t(chat.personal ? 'chat.subtitle.personal' : 'chat.subtitle.group', {
    source,
    count: chat.people.length,
  });
};

// Who this is: what the conversation tells about them (R-Y50).
// A personal chat's, and every Telegram chat's (its profile, R-Y111).
const hasAbout = (chat) =>
  Boolean(chat?.personal) || chat?.source === 'telegram';

const AboutButton = ({ about, onAbout, chat }) => {
  const t = useT();
  const label = t(chat?.personal ? 'chat.about.open' : 'chat.about.chatInfo');
  return el(
    'button',
    {
      type: 'button',
      className: about ? 'chat-about icon-btn active' : 'chat-about icon-btn',
      'data-action': 'chat-about',
      'aria-label': label,
      'aria-pressed': about,
      title: label,
      onClick: onAbout,
    },
    el(Icon, { name: 'user' })
  );
};

const Header = ({
  state,
  api,
  onBack,
  about,
  onAbout,
  find,
  saved,
  forumView,
  call,
}) => {
  const t = useT();
  const { chatTime } = useDates();
  const chat = state.current;
  return el('header', { className: 'chat-header' }, [
    el(
      'button',
      {
        key: 'back',
        type: 'button',
        className: 'chat-back icon-btn',
        'data-action': 'chat-back',
        'aria-label': t('chat.back'),
        title: t('chat.back'),
        onClick: onBack,
      },
      el(Icon, { name: 'back' })
    ),
    el(ChatAvatar, {
      key: 'a',
      api,
      chat: accountDeleted(chat, state.info)
        ? { ...chat, deletedAccount: true }
        : chat,
    }),
    el('div', { key: 't', className: 'chat-header-title' }, [
      el('div', { key: 'n', className: 'chat-title-row' }, [
        el('strong', { key: 'n' }, chatDisplayName(chat, t, state.info)),
        el(DeletedAccountBadge, { key: 'deleted', chat, info: state.info }),
        isBirthdayToday(state.info?.birthday)
          ? el(
              'span',
              {
                key: 'bd',
                className: 'birthday-mark',
                'data-birthday-today': 'true',
                title: t('chat.birthday.today'),
              },
              '\u{1F382}'
            )
          : null,
        chat.emojiStatus
          ? el(EmojiStatus, { key: 'es', status: chat.emojiStatus, api })
          : null,
        el(TtlBadge, { key: 'ttl', chat, info: state.info }),
      ]),
      el(
        'span',
        {
          key: 's',
          className:
            state.info?.online && state.info.kind === 'user'
              ? 'meta online'
              : 'meta',
        },
        el(ChatSubtitle, { state, t, chatTime })
      ),
    ]),
    el('div', { key: 'actions', className: 'chat-header-actions' }, [
      // "Call" in a private chat (R-Y196).
      el(CallButton, { key: 'call', state, call }),
      el(SearchButton, { key: 'find', find }),
      el(SavedToggle, { key: 'saved', saved }),
      // View as messages / View as topics in a forum (R-Y171).
      el(ForumViewMenu, { key: 'forum-view', view: forumView }),
      el(NotifyButton, { key: 'notify', api, chat }),
      // "Export chat history" in the header's ⋯ menu (R-Y186).
      el(ExportMenu, { key: 'more', api, chat, info: state.info }),
      hasAbout(chat)
        ? el(AboutButton, { key: 'about', about, onAbout, chat })
        : null,
      el(AutomationMenu, {
        key: 'm',
        menu: state.menu,
        autopilot: state.autopilot,
        api,
        chat,
      }),
    ]),
  ]);
};

// Telegram groups one sender's messages into a run when they follow
// each other within 10 minutes on the same day (telegram-tt
// `groupMessages`): the name shows on the first, the avatar by the
// last, and the bubbles' corners between them are rounded less.
const RUN_GAP_MS = 10 * 60_000;

const sameRun = (a, b) =>
  Boolean(a && b) &&
  !a.service &&
  !b.service &&
  String(a.sender) === String(b.sender) &&
  Math.abs(Date.parse(b.timestamp) - Date.parse(a.timestamp)) <= RUN_GAP_MS &&
  String(a.timestamp).slice(0, 10) === String(b.timestamp).slice(0, 10);

/** id → { first, last } of each message in its sender's run. */
export const messageRuns = (messages) => {
  const runs = new Map();
  for (let i = 0; i < messages.length; i += 1) {
    runs.set(messages[i].id, {
      first: !sameRun(messages[i - 1], messages[i]),
      last: !sameRun(messages[i], messages[i + 1]),
    });
  }
  return runs;
};

const Stream = ({ state, api, actions }) => {
  const { onAction, menuFor, selection } = actions;
  const follow = useFollow(state, api);
  const keep = useKeepPlace(follow.box, state);
  const older = useOlder(follow.box, state);
  const newer = useNewer(follow.box, state.history);
  useArrival(state);
  useSeen(follow.box, state.seen, state.messages);
  const onScroll = (event) => {
    follow.onScroll(event);
    keep();
    older();
    newer();
  };
  const days = useDayJump({
    history: state.history,
    api,
    chat: state.current,
    box: follow.box,
    toEnd: follow.toEnd,
    notify: () => state.notify?.({ kind: 'date-failed' }),
  });
  // What leaves the chat goes like in Telegram (./chat-leaving.js).
  // A window opened anew (a jump to a date) is not messages leaving.
  const view = `${state.current?.key ?? ''}:${state.history?.view ?? 0}`;
  const shown = useLeaving(state.messages, view);
  // Reply lookups: what is shown, then the originals fetched for it.
  const shownById = new Map(shown.map((m) => [m.id, m]));
  // An album is one row (./chat-album.js).
  const messages = groupAlbums(shown);
  const empty = messages.length === 0 && state.drafts.drafts.length === 0;
  const msgById = {
    get: (id) => shownById.get(id) ?? state.replyTargets?.get(id),
  };
  const runs = messageRuns(messages);
  const breaks = dayBreaks(messages);
  const order = messages.filter((m) => !m.service).map((m) => m.id);
  const onSelect = (id, { shift }) => selection.toggle(id, { shift, order });
  const column = useRef(null);
  const drag = useDragSelect({
    box: follow.box,
    column,
    selection,
    order: () => order,
  });
  const marks = useUnreadMarks(api, state.current, {
    scrollTo: (id) => onScrollTo(id),
    messages: shown,
  });
  const alone =
    Boolean(state.current.personal) || state.current.kind === 'channel';
  // Go to a message, back from replies, to the newest (R-Y107, R-Y109).
  const { onScrollTo, down, onDown } = useStreamJumps(state, follow);
  const scroll = el(
    'div',
    {
      key: 'scroll',
      className: `chat-scroll${empty ? ' is-empty' : ''}`,
      ref: follow.box,
      onScroll,
      onWheelCapture: follow.onReadGesture,
      onTouchStartCapture: follow.onReadGesture,
      onTouchMoveCapture: follow.onReadGesture,
      onPointerDownCapture: follow.onReadGesture,
      onPointerMoveCapture: follow.onReadGesture,
      onKeyDownCapture: follow.onReadGesture,
      ...drag,
    },
    [
      // The date of what is at the top, over it while scrolling.
      el(FloatingDay, { key: 'day', box: follow.box, onOpen: days.open }),
      el(
        'div',
        {
          key: 'col',
          ref: column,
          className: selection.active
            ? 'chat-column is-selecting'
            : 'chat-column',
        },
        [
          empty ? null : el(OlderRow, { key: 'older', history: state.history }),
          ...messages.flatMap((message) => [
            breaks.has(message.id)
              ? el(DayPill, {
                  key: `day-${breaks.get(message.id)}`,
                  day: breaks.get(message.id),
                  onOpen: days.open,
                })
              : null,
            rowIds(message).includes(state.unreadLine)
              ? el(UnreadLine, { key: 'unread-line', lineRef: follow.line })
              : null,
            el(MessageBubble, {
              key: message.id,
              message,
              run: runs.get(message.id),
              showAvatar: runs.get(message.id)?.last !== false,
              showName: !alone && runs.get(message.id)?.first !== false,
              // A private chat and a channel name no one: there is one voice.
              isPersonal: alone,
              msgById,
              composer: state.composer,
              api,
              onScrollTo,
              onAction,
              menuFor,
              selecting: selection.active,
              selected: selection.shows(message.id),
              onSelect,
              // Desktop's corner Reply shows in groups only.
              fastReply: !alone,
            }),
          ]),
          ...state.drafts.drafts.map((draft) =>
            el(DraftCard, {
              key: draft.id,
              draft,
              drafts: state.drafts,
              autopilot: state.autopilot,
            })
          ),
          empty
            ? el(EmptyConversation, {
                key: 'empty',
                api,
                chat: state.current,
                history: state.history,
              })
            : null,
          el('div', { key: 'end', ref: follow.end }),
        ]
      ),
    ]
  );
  return [
    // The background behind the messages is its own layer (R-Y155).
    el('div', { key: 'wall', className: 'chat-wall' }, [
      el(ChatWall, {
        key: 'layer',
        api,
        chat: state.current.chat,
        info: state.info,
      }),
      el(
        ChatReactionsScope,
        { key: 'scope', chat: state.current, info: state.info },
        scroll
      ),
    ]),
    days.calendar,
    el(UnreadMarks, {
      key: 'marks',
      current: state.current,
      marks,
      raised: down,
    }),
    el(ScrollDown, {
      key: 'down',
      shown: down,
      count: follow.unseen || (state.current.unread ?? 0),
      onClick: onDown,
    }),
  ];
};

// Telegram's round "down" button: shown once the end is out of sight,
// with how many messages wait below.
const ScrollDown = ({ shown, count, onClick }) => {
  const t = useT();
  if (!shown) {
    return null;
  }
  return el(
    'button',
    {
      type: 'button',
      className: 'chat-down',
      'data-action': 'scroll-new',
      'aria-label':
        count > 0
          ? `${t('chat.scrollDown')}: ${t('chat.newMessages', { count })}`
          : t('chat.scrollDown'),
      title: t('chat.scrollDown'),
      onClick,
    },
    [
      el(Icon, { key: 'i', name: 'arrow-down', size: 22 }),
      count > 0
        ? el(
            'span',
            { key: 'n', className: 'chat-down-count' },
            count > 999 ? '999+' : String(count)
          )
        : null,
    ]
  );
};

// Several messages not sent: deal with them at once (Element's bar).
const FailedBar = ({ composer }) => {
  const t = useT();
  if (composer.failed < 2) {
    return null;
  }
  return el('div', { className: 'chat-failed-bar', role: 'alert' }, [
    el('span', { key: 'n' }, t('chat.failedCount', { count: composer.failed })),
    el(
      'button',
      {
        key: 'resend',
        type: 'button',
        'data-action': 'resend-all',
        onClick: composer.resendAll,
      },
      t('chat.resendAll')
    ),
    el(
      'button',
      {
        key: 'delete',
        type: 'button',
        'data-action': 'delete-all',
        onClick: composer.deleteAll,
      },
      t('chat.deleteAll')
    ),
  ]);
};

// The chat screen before its chats come: the list's rows as shimmering
// shapes, as Telegram Web A draws them, and the conversation's side
// empty (R-Y84).
const ChatLoading = ({ t }) =>
  el('div', { className: 'chat-shell is-loading' }, [
    el('aside', { key: 'side', className: 'chat-sidebar' }, [
      el(
        'div',
        { key: 'h', className: 'chat-sidebar-head' },
        el(
          Busy,
          { as: 'span', className: 'chat-sidebar-title' },
          t('common.loading')
        )
      ),
      el(ChatListSkeleton, { key: 'rows' }),
    ]),
    el('section', { key: 'main', className: 'chat-main' }),
  ]);

// The skeleton while the list loads; why and a retry button if it cannot (R-Z12).
const ChatLoadingOrError = ({ t, state }) =>
  state.loadError
    ? el(LoadError, {
        error: state.loadError,
        retry: state.retryLoad,
        what: 'chat',
      })
    : el(ChatLoading, { t });

// Reply bar shown above the input when user chose to reply.
const ReplyBar = ({ replyTo, onClear }) => {
  const t = useT();
  if (!replyTo) {
    return null;
  }
  return el('div', { className: 'composer-reply-bar' }, [
    el(ReplyQuote, { key: 'q', replyRef: replyTo }),
    el(
      'button',
      {
        key: 'x',
        type: 'button',
        className: 'composer-reply-clear',
        'aria-label': t('chat.replyCancel'),
        onClick: onClear,
      },
      '✕'
    ),
  ]);
};

// "Send without sound" and "Schedule message" for the message box and
// the files' box, and the chat's scheduled messages (./chat-schedule.js).
const useSendLater = ({ state, api, composer, attach }) => {
  const scheduled = useScheduled({ state, api });
  // "Send with effect" in a private chat's text box (R-Y149).
  const effects = canEffect(state, api);
  const textMenu = useSendMenu(scheduled.enabled || effects);
  // The files' box offers it too (R-Y161).
  const filesMenu = useSendMenu(scheduled.enabled || effects);
  const [effecting, setEffecting] = useState(null); // 'text' | 'files'
  const [picking, setPicking] = useState(null); // 'text' | 'files'
  const [listing, setListing] = useState(false);
  const sendWith = (what, when) =>
    what === 'files' ? attach.send(when) : composer.send(when);
  const pick = (what) => (key) => {
    if (key === 'sendEffect') {
      setEffecting(what);
    } else if (key === 'sendSilent') {
      sendWith(what, { silent: true });
    } else if (key === 'sendWhenOnline') {
      // Held until the person is online (R-Y197).
      sendWith(what, { scheduleDate: WHEN_ONLINE });
    } else {
      setPicking(what);
    }
  };
  const menuItems = sendMenuItems({ state, api, effects });
  const closeList = useCallback(() => setListing(false), []);
  const parts = [
    el(SendMenu, {
      key: 'text-menu',
      menu: textMenu,
      onPick: pick('text'),
      items: menuItems,
    }),
    effecting
      ? el(EffectPanel, {
          key: 'effects',
          api,
          over: effecting === 'files',
          onClose: () => setEffecting(null),
          onPick: (effect) => {
            setEffecting(null);
            sendWith(effecting, { effect });
          },
        })
      : null,
    el(SendMenu, {
      key: 'files-menu',
      menu: filesMenu,
      onPick: pick('files'),
      items: menuItems,
    }),
    picking
      ? el(ScheduleDialog, {
          key: 'when',
          reminder: scheduled.reminder,
          onClose: () => setPicking(null),
          onPick: (at) =>
            sendWith(picking, { scheduleDate: Math.floor(at / 1000) }),
        })
      : null,
    listing
      ? el(ScheduledList, { key: 'scheduled', scheduled, onClose: closeList })
      : null,
  ];
  return {
    scheduled,
    textMenu,
    filesMenu,
    openList: () => setListing(true),
    parts,
  };
};

const unless = (hide, part) => (hide ? null : part);

// The switch between microphone and camera, while the box is empty (R-Y150).
const recordButtons = ({ voice, round, empty }) =>
  empty && !voice.recording && !round.recording && round.switcher
    ? [round.switcher]
    : [];

// The microphone or camera in Send's place while the box is empty or a
// recording is on; null when Send belongs there.
const recordControl = ({ voice, round, empty }) => {
  const shown = empty || voice.phase !== 'idle' || round.phase !== 'idle';
  if (!shown) {
    return null;
  }
  if (round.active) {
    return round.button;
  }
  return voice.enabled ? voice.button : null;
};

const composing = (event) =>
  Boolean(event.nativeEvent?.isComposing) || event.keyCode === 229;

// Recording or editing: the buttons that make no sense are gone.
const isBare = (recording, editing) => Boolean(recording || editing);

// The bar over the box: the message being edited, else the reply.
const barOver = (composer, editing) =>
  editing
    ? el(EditBar, {
        key: 'eb',
        message: editing.message,
        onCancel: composer.cancelEdit,
      })
    : el(ReplyBar, {
        key: 'rb',
        replyTo: composer.replyTo ?? null,
        onClear: composer.clearReplyTo,
      });

// The row's end: the bot keyboard, emoji, the microphone/camera switch,
// and the microphone or camera in Send's place (never while editing).
const endButtons = (parts) => {
  const { bare, recording, editing, voice, round, text, reply, emoji } = parts;
  // A forward waiting is sent without words, too (R-Y154).
  const empty = !text.trim() && !parts.forwarding;
  return [
    bare ? null : el(KeyboardToggle, { key: 'kb', reply }),
    recording ? null : emoji.button,
    ...(editing ? [] : recordButtons({ voice, round, empty })),
    (editing ? null : recordControl({ voice, round, empty })) ??
      el(SendButton, {
        key: 'send',
        composer: parts.composer,
        editing,
        text,
        forwarding: parts.forwarding,
        menu: parts.menu,
      }),
  ];
};

// The Send button (a check mark while a message is edited, R-Y146).
const SendButton = ({ composer, editing, text, menu, forwarding }) => {
  const t = useT();
  const empty =
    !text.trim() && !(editing && hasMedia(editing.message)) && !forwarding;
  return el(
    'button',
    {
      type: 'submit',
      className: 'primary send',
      disabled: empty,
      'aria-busy': composer.sending ? 'true' : undefined,
      'aria-label': editing ? t('common.save') : t('common.send'),
      'data-mode': editing ? 'edit' : undefined,
      ...(editing ? {} : menu.props),
    },
    el(Icon, { name: editing ? 'check' : 'send', size: 18 })
  );
};

// The paperclip menu's entry for a poll or checklist hook, when it is on.
const showOf = (hook) => (hook.enabled ? hook.show : null);

const Composer = ({ state, api, keys }) => {
  const t = useT();
  const { composer } = state;
  const text = useComposerText(composer);
  const suggest = useSuggestionsFor(state.suggester, text, state.suggest);
  // Files and photos: the paperclip, a paste, a drop (R-Y99).
  const attach = useAttach({ state, api });
  const dragging = useDropFiles(attach);
  // A new poll, from the paperclip's menu (R-Y121).
  const poll = usePollCreate({ state, api, composer });
  // A new checklist, from the same menu (R-Y195).
  const todo = useTodoCreate({ state, api, composer });
  // A place or a contact, from the same menu (R-Y142).
  const share = useShare({ state, api, composer });
  // Attachment-menu bots in the same menu, and adding one (R-Y201).
  const attachBots = useAttachBots({ state, api });
  // The Send buttons' menu; scheduled messages (R-Y102).
  const later = useSendLater({ state, api, composer, attach });
  // Who sends in a supergroup: the avatar button (R-Y141).
  const sendAs = useSendAs(api, state.current);
  // A chat that charges Stars per message: the price, and the question
  // before every send (R-Y184).
  const paid = usePaidSend(api, state.current);
  // Our live location follows us while it is shared (R-Y147).
  useLiveWatch({ api, state });
  // The emoji panel (R-Y104), with stickers and GIFs (R-Y105).
  const box = useRef(null);
  const typeText = (next) => composer.setText(next, { typed: true });
  // ":word" suggests emoji by Telegram's words (R-Y206).
  const tools = useEmojiTools({ state, api, composer, box, text, typeText });
  const { stickers, emoji } = tools;
  // With nothing typed, the microphone (R-Y108).
  const voice = useVoice({ state, api });
  // Or, switched over, the camera: a round video (R-Y150).
  const round = useRoundVideo({ state, api });
  const recording = voice.recording || round.recording;
  useComposerHeight(box, text, !recording);
  // Text selected in the box: the formatting bar (R-Y109).
  const format = useFormatBar({ box, setText: typeText });
  // A bot's keyboard under the box, and what it asks of it (R-Y110).
  const reply = useReplyKeyboard({ state, replyRefOf, api });
  // "/" lists a bot's commands; a bot chat's Menu button (R-Y135).
  const commands = useCommandBox({
    ...useBotCommands(api, state.current, state.info),
    api,
    text,
    composer,
    ...appTarget(state),
  });
  // "@gif cats": an inline bot's answers over the box (R-Y138).
  const inline = useInlineBox({ api, state, composer, text });
  // The link in the text, previewed above the box (R-Y145).
  const linkPreview = useLinkPreview({ api, state, text, composer });
  // Editing a message: the caret at the end, no files, no voice (R-Y146).
  const editing = composer.editing ?? null;
  const bare = isBare(recording, editing);
  useCaretAtEnd(box, editing?.message.id ?? null);
  const onKeyDown = (event) => {
    keys?.(event);
    // Ctrl/Cmd+B, I, K… format the selection (R-Y101).
    if (event.defaultPrevented || formatShortcut(event, typeText)) {
      return;
    }
    // Enter that confirms an input method's word (Chinese, Japanese…) is
    // not a Send.
    if (
      composing(event) ||
      [inline, commands, tools.suggest].some((part) => part.onKey(event))
    ) {
      return;
    }
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      composer.send();
    }
  };
  const form = el(
    'form',
    {
      key: 'form',
      className: 'chat-composer',
      onSubmit: (event) => {
        event.preventDefault();
        composer.send();
      },
    },
    [
      inline.panel,
      commands.list,
      tools.suggest.list,
      el(Suggestions, { key: 's', suggest, composer }),
      format.bar,
      emoji.panel,
      // The forward waiting for a comment (R-Y154).
      state.forwardBar ?? null,
      barOver(composer, editing),
      linkPreview.bar,
      paid.label,
      el('div', { key: 'row', className: 'chat-composer-row' }, [
        unless(bare, sendAs.button),
        voice.bar,
        round.overlay,
        unless(bare, commands.menuButton),
        bare
          ? null
          : el(AttachButton, {
              key: 'attach',
              attach,
              onPoll: showOf(poll),
              onTodo: showOf(todo),
              ...share.menu,
              bots: attachBots.menu,
            }),
        bare
          ? null
          : el(ScheduledButton, {
              key: 'scheduled',
              scheduled: later.scheduled,
              onOpen: later.openList,
            }),
        recording
          ? null
          : el('textarea', {
              key: 'input',
              ref: box,
              rows: 1,
              placeholder: reply.placeholder || t('chat.placeholder'),
              'aria-label': t('chat.placeholder'),
              value: text,
              onChange: (event) =>
                composer.setText(event.target.value, { typed: true }),
              onKeyDown,
              onPaste: editing ? undefined : pasteFiles(attach),
            }),
        ...endButtons({
          bare,
          recording,
          editing,
          voice,
          round,
          text,
          reply,
          emoji,
          composer,
          forwarding: Boolean(state.forwarding),
          menu: later.textMenu,
        }),
      ]),
      el(ReplyKeyboard, { key: 'reply-kb', reply }),
    ]
  );
  return el(React.Fragment, null, [
    el(DropHint, { key: 'drop', over: dragging }),
    form,
    reply.peerDialog,
    el(AttachDialog, {
      key: 'files',
      attach,
      sendProps: later.filesMenu.props,
    }),
    poll.shown ? el(PollDialog, { key: 'poll', poll }) : null,
    todo.shown ? el(TodoDialog, { key: 'todo', todo }) : null,
    el(ShareDialog, { key: 'share', share, api }),
    attachBots.dialog,
    sendAs.dialog,
    paid.dialog,
    ...later.parts,
    ...(stickers.parts ?? []),
  ]);
};

/** The screen itself, pure: everything comes from `state`. */
// The header, and beside the messages what the conversation tells about
// the person, open until closed (in every personal chat, as Telegram's
// profile column).
const ChatSubtitle = ({ state, t, chatTime }) =>
  isTyping(state.typing)
    ? el(TypingLine, { typing: state.typing })
    : el(React.Fragment, null, [
        subtitleOf(t, state, chatTime),
        state.history?.complete && !state.history.older
          ? el(
              'span',
              { key: 'complete', 'data-history-complete': true },
              ` · ${t('chat.history.complete')}`
            )
          : null,
      ]);

const ChatTop = ({ state, api, onBack, saved, forumView, call, actions }) => {
  const [about, setAbout] = useState(false);
  // A contact or phone link opens the person's column (R-Y217).
  useProfileRequest(state.current, () => setAbout(true));
  const chat = about && hasAbout(state.current) ? state.current : null;
  const find = useChatSearch({
    api,
    current: state.current,
    messages: state.messages,
    reach: state.history?.reach,
  });
  return [
    el(
      ConversationHeader,
      { key: 'h', actions },
      el(Header, {
        state,
        api,
        onBack,
        about: Boolean(chat),
        onAbout: () => setAbout((open) => !open),
        find,
        saved,
        forumView,
        call,
      })
    ),
    el(SearchBar, { key: 'find', find }),
    chat
      ? el(PersonPanel, {
          key: `about:${chat.key}`,
          api,
          chat,
          revision: JSON.stringify(
            state.messages.map((message) => [
              message.id,
              message.body,
              message.replyTo,
            ])
          ),
          info: state.info ?? null,
          username: state.info?.username ?? null,
          onOpenChat: (target) => state.openAt?.(target),
          hasChat: (key) => state.hasChat?.(key) ?? false,
          onGo: (id) => {
            // Narrow, the column covers the messages: it goes.
            if (!globalThis.matchMedia?.('(min-width: 900px)').matches) {
              setAbout(false);
            }
            return goToMessage(id, state.history?.reach);
          },
          lastId: networkMessageId(
            state.messages.findLast((m) => !m.pending && !m.ephemeral) ?? null
          ),
          onClose: () => setAbout(false),
        })
      : null,
  ];
};

// A closed topic has no composer for those who cannot manage topics (R-Y153).
const ComposerOrClosed = ({ state, api, keys }) =>
  topicClosedFor(state.forum?.open, state.info)
    ? el(TopicClosedBar)
    : el(Composer, { state, api, keys });

// The shortcuts of ./shortcuts.js on this screen's state.
const useScreenShortcuts = ({
  state,
  select,
  setPane,
  setHelp,
  enabled = true,
}) =>
  useChatShortcuts({
    enabled,
    chats: state.chats,
    current: state.current,
    select,
    tabs: state.tabs,
    setFilter: state.setFilter,
    selfId: state.telegram?.account?.id,
    focusSearch: () => {
      setPane('list');
      globalThis.setTimeout(focusListSearch, 0);
    },
    openHelp: () => setHelp(true),
  });

const Conversation = ({
  t,
  state,
  api,
  actions,
  theme,
  saved,
  forumView,
  privateCall,
  tags,
  setPane,
}) =>
  state.current
    ? el('section', { key: 'main', className: 'chat-main', ...theme }, [
        el(ChatTop, {
          key: 'header',
          actions,
          state,
          api,
          onBack: () => setPane('list'),
          saved,
          forumView,
          call: privateCall,
        }),
        // A forum's topics, as Telegram's tabs layout (R-Y122).
        el(TopicTabs, {
          key: 'topics',
          forum: stripForum(forumView, state.forum),
          api,
          chat: state.current,
          info: state.info,
        }),
        el(PinnedBar, {
          key: 'pin',
          state,
          api,
          onOpen: (id) => goToMessage(id, state.history?.reach),
        }),
        // Saved deletions and edits share one compact row in Chat and Operator.
        el('div', { key: 'history', className: 'chat-history-bar' }, [
          el(DeletedBar, { key: `deleted:${state.current.key}`, state, api }),
          el(EditedBar, { key: `edited:${state.current.key}`, state, api }),
        ]),
        // The live locations shared in the chat (R-Y197).
        el(LiveLocationsBar, {
          key: `live:${state.current.key}`,
          state,
          api,
          onGo: (id) => goToMessage(id, state.history?.reach),
        }),
        // The chat's voice chat or live stream (R-Y188).
        el(VoiceChatBar, {
          key: `voice:${state.current.key}`,
          api,
          chat: state.current,
          live: state.groupCall,
        }),
        // "Translate to <language>" over a foreign-language chat (R-Y213).
        el(TranslateBar, { key: 'translate-bar', api, state }),
        // Add contact, Block, Report spam over a stranger's chat (R-Y137).
        el(PeerBar, {
          key: `peer:${state.current.key}`,
          api,
          chat: state.current,
        }),
        // The bot a business connected to this chat (R-Y180).
        el(BotBar, {
          key: `bot:${state.current.key}`,
          api,
          chat: state.current,
        }),
        // "N requested to join" for those who may invite (R-Y152).
        el(RequestsBar, {
          key: `requests:${state.current.key}`,
          api,
          chat: state.current,
          info: state.info,
          live: state.joinRequests,
        }),
        el(ChatAccountNotice, { key: 'account', state }),
        el(FailedBar, { key: 'failed', composer: state.composer }),
        el(AutopilotBar, { key: 'ap', autopilot: state.autopilot }),
        el(NextChatBar, {
          key: 'next',
          drafts: state.drafts,
          autopilot: state.autopilot,
        }),
        el(Notice, {
          key: 'n',
          notice: noticeInWords(t, state.notice),
          labels: NOTICE,
          dismiss: state.dismiss,
        }),
        saved.on ? null : el(SavedTagBar, { key: 'tags', api, tags }),
        saved.on
          ? el(SavedChats, { key: 'saved', api, chat: state.current })
          : tags.active
            ? el(SavedTagResults, { key: 'tagged', api, tags })
            : el(Stream, { key: 's', state, api, actions }),
        // A closed topic has no composer for those who cannot manage
        // topics (R-Y153).
        saved.on
          ? null
          : el(ComposerOrClosed, {
              key: 'c',
              state: actions.withForward(state),
              api,
              keys: actions.keys,
            }),
        ...actions.dialogs,
      ])
    : null;

const initialChatPane = () =>
  chatFromHash(globalThis.location?.hash) ? 'chat' : 'list';

export const ChatScreen = ({ state, api, embedded = false }) => {
  const { t, locale } = useLocaleContext();
  const [pane, setPane] = useState(initialChatPane);
  const account = state.telegram?.account;
  const selfName =
    [account?.firstName, account?.lastName].filter(Boolean).join(' ') || null;
  const actions = useChatActions({ state, api, t, locale, selfName });
  // A link to a message opens in the app (R-Y154).
  useMessageLinks({ state, api });
  // A business chat link opens its chat with the text in the box (R-Y180).
  useBusinessLinks({ state, api });
  // Saved Messages as chats, or as messages (R-Y143).
  const saved = useSavedView(state.current, state.info);
  // A forum as its messages or as its topics (R-Y171).
  const forumView = useForumView({ api, state });
  // Its reaction tags and the filter they make (R-Y151).
  const tags = useSavedTags(api, state.current, state.info);
  // The chat's theme colours, scoped to its view (R-Y170).
  const theme = useChatTheme(api, state.current, state.info);
  // Phones show one pane at a time (list → conversation → back), as
  // Telegram and WhatsApp do; wider screens show both and ignore it.
  // One function for every render, so the list's rows stay as they are.
  const latest = useRef(null);
  latest.current = (key) => {
    state.select(key);
    setPane('chat');
  };
  const [select] = useState(() => (key) => latest.current(key));
  // A private call, placed from the header or rung in (R-Y196).
  const privateCall = usePrivateCall(api, state.privateCall, (user) =>
    state.chatName?.(`telegram:${user}`)
  );
  // Desktop's keyboard shortcuts and their list (R-Y183).
  const [help, setHelp] = useState(false);
  useScreenShortcuts({ state, select, setPane, setHelp, enabled: !embedded });
  if (state.loading) {
    return el(ChatLoadingOrError, { t, state });
  }
  if (state.total === 0) {
    // Connected but nothing synced yet: say so, never "connect" again.
    return state.telegram?.connected
      ? el(ChatAccountEmpty, { telegram: state.telegram })
      : el(ConnectionGuide, { section: 'chat' });
  }
  const quote = { selfName, api, chatName: state.chatName };

  return el(
    QuoteContext.Provider,
    { value: quote },
    el(
      ChatKindContext.Provider,
      { value: kindOf(state.current) },
      el(
        'div',
        {
          className: `chat-shell${embedded ? ' chat-embedded' : ''}`,
          'data-pane': embedded ? 'chat' : pane,
        },
        [
          embedded
            ? null
            : el(Sidebar, {
                key: 'side',
                state: { ...state, select, openShortcuts: () => setHelp(true) },
                api,
              }),
          el(ShortcutsHost, {
            key: 'shortcuts',
            open: help,
            close: () => setHelp(false),
          }),
          // The call window and an incoming call's notification (R-Y196).
          el(PrivateCallHost, { key: 'private-call', api, state: privateCall }),
          // A clicked #hashtag or $cashtag searches (R-Y182).
          el(TagSearchHost, { key: 'tag-search', api, state }),
          // The Instant View reader (R-Y205).
          el(InstantViewHost, { key: 'instant-view', api }),
          el(Conversation, {
            t,
            key: 'conversation',
            state,
            api,
            actions,
            theme,
            saved,
            forumView,
            privateCall,
            tags,
            setPane,
          }),
        ]
      )
    )
  );
};

// The kind of the open chat, for the media download settings (R-Y181).
const kindOf = (current) => current?.kind ?? 'private';

export const ChatView = ({ api = defaultApi, ...options }) => {
  const t = useT();
  return el(React.Fragment, null, [
    el(ChatScreen, {
      key: 'screen',
      state: useChatState(api, { t, ...options }),
      api,
    }),
    el(VkCaptchaDialog, { key: 'vk-captcha' }),
  ]);
};
