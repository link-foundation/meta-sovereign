/**
 * Local web server (R-F4) + universal links HTTP surface (R-F8) + UI (R-F1).
 *
 * Endpoints (full list lives in `routes-derived.js` and `routes-mutating.js`):
 *   GET  /                         -> GitHub Pages redirect (SPA with localUi=true)
 *   GET  /app.js, /app.min.js, /app.css -> optional SPA assets (localUi=true)
 *   GET  /links, /links/:id        -> read links
 *   PUT  /links                    -> upsert
 *   DEL  /links/:id                -> delete
 *   GET  /sources                  -> list message-source adapters
 *   GET  /api/contacts             -> contacts derived from messages
 *   GET  /api/status               -> service identity + store stats + verify diff count
 *   GET  /api/autocomplete?q=&me=  -> outgoing-history-driven completions
 *   GET  /api/suggest?source=&chat=&typed= -> reply-graph autocomplete
 *   GET  /api/audience?q=          -> set-algebra over store filters
 *   GET  /api/facts                -> question-answer pairs per partner
 *   GET  /api/search?q=            -> dice-similarity search
 *   GET  /api/patterns             -> persisted patterns
 *   PUT  /api/patterns             -> upsert pattern link
 *   POST /api/patterns/infer       -> { examples, mode } -> { regex, flags }
 *   GET  /api/graphs               -> persisted automation graphs
 *   PUT  /api/graphs               -> upsert graph
 *   POST /api/graphs/run           -> { id, message, mode } -> plan
 *   GET  /api/replies              -> persisted reply variation groups
 *   PUT  /api/replies              -> upsert reply variation group
 *   GET  /api/profile              -> read profile (R-D5)
 *   PUT  /api/profile              -> upsert + plan cross-network sync
 *   GET  /api/resume               -> read resume (R-D6)
 *   PUT  /api/resume               -> upsert + plan cross-network sync
 *   POST /api/broadcast            -> queue post for outbound networks
 *   POST /api/outreach             -> { query, text, networks, mode } -> plan
 *   /api/automations/*, POST /api/send, /api/typing -> routes-automations.js
 *   /api/message/* (edit, delete, react, read, forward) -> routes-messages.js
 *   /api/passcode/* -> the local passcode and its lock gate (routes-passcode.js)
 *   POST /api/client-log           -> the page's errors, in the log (routes-client-log.js)
 *   /api/people, /api/audiences, /api/lists -> routes-people.js
 *   GET  /api/people/learned?key=  -> what a conversation tells (routes-learned.js)
 *   GET  /api/greetings/*          -> greeting stickers/texts (routes-greetings.js)
 *   POST /api/email/pull           -> local-server email API/protocol proxy
 *   POST /api/email/send           -> local-server email send proxy
 *   GET  /api/email/attachment     -> a mail attachment from the media folder (routes-email.js)
 *   GET  /api/media/<network>/<sha256>[.ext] -> imported archive media (routes-media.js, R-Z15)
 *   POST /api/archive/upload?source=&name= -> import an export file (routes-archive-upload.js)
 *   GET  /api/backups              -> list archives (gated on archiveDir)
 *   POST /api/backups              -> { passphrase?, keep? } -> { file }
 *   POST /api/backups/restore      -> { file, passphrase? } -> { restored }
 *   GET  /api/auto-import          -> browser auto-import status + jobs
 *   POST /api/auto-import          -> { provider } -> job (see routes-auto-import.js)
 *
 * Implemented with Node's built-in `http` module to keep the dependency
 * footprint at zero. The Docker images in `docker/` simply run
 * `node js/bin/meta-sovereign serve`.
 */

import http from 'node:http';
import path from 'node:path';
import { promises as fs } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { openDualStore, wrapSecretStore } from '../storage/index.js';
import { CURRENT_SCHEMA } from '../storage/migrations/index.js';
import { createRequestGate } from './request-gate.js';
import { createRuntimeLifecycle } from './runtime-lifecycle.js';
import { listenFailure } from './listen-error.js';
import {
  getSource as getSourceDefault,
  liveOptionsFrom,
  listSources,
} from '../sources/index.js';
import { createTelegramAccount } from '../sources/telegram-account.js';
import { createExtraAccounts } from '../sources/telegram-accounts.js';
import { createExtraRuntime, telegramChats } from './telegram-extras.js';
import { accountScope } from './account-scope.js';
import { bodyFailure, fail, json } from './util.js';
import { bindWire, requestWireFailure } from './wire.js';
import { handleDerivedRoutes } from './routes-derived.js';
import { handleMutatingRoutes } from './routes-mutating.js';
import { handleCvRoutes } from './routes-cv.js';
import { handleBrowserRoutes } from './routes-browser.js';
import { handleFormRoutes } from './routes-forms.js';
import { createFormReader } from '../forms/reader.js';
import { createFormReportWriter } from '../forms/report-file.js';
import { handleGreetingRoutes } from './routes-greetings.js';
import { handleBackupRoutes } from './routes-backup.js';
import { handleSuggestRoutes } from './routes-suggest.js';
import { handleAutomationRoutes } from './routes-automations.js';
import { createFollowDiscovery } from '../follow/chat-discovery.js';
import { handlePeopleRoutes } from './routes-people.js';
import { handleContactsImport } from './routes-contacts-import.js';
import {
  createAutomationRunner,
  createAutomationScheduler,
} from '../automation/runner.js';
import { createDefaultSender } from '../sources/browser-sender.js';
import { createAutopilot } from '../automation/autopilot.js';
import { recoverOutbox } from '../automation/outbox.js';
import { backgroundJobs } from './background-jobs.js';
import { handleDeletedRoutes } from './routes-deleted.js';
import { handleVersionRoutes } from './routes-message-versions.js';
import { withMessageVersions } from '../storage/message-versions.js';
import { handleAudienceSyncRoute } from './audience-sync.js';
import { setTypingFor } from '../sources/live-links.js';
import { createReplyService } from '../replies/reply-service.js';
import { createChatIndex } from './chat-index.js';
import { handleChatRoutes } from './routes-chat.js';
import { handleFeedbackRoutes } from './routes-feedback.js';
import { handleStickerCollections } from './routes-sticker-collections.js';
import { createClinkReplyStore } from '../replies/reply-store-clink.js';
import { handleAutoImportRoutes } from './routes-auto-import.js';
import { handleWhatsAppRoutes } from './routes-whatsapp.js';
import { handleMarketplaceRoutes } from './routes-marketplaces.js';
import { profileDirIn } from '../sources/whatsapp-web-signin.js';
import { handleTelegramRoutes } from './routes-telegram.js';
import { handleMessageRoutes } from './routes-messages.js';
import { handleEmailGets } from './routes-email.js';
import { handleMediaGets } from './routes-media.js';
import {
  handleArchiveUpload,
  UPLOAD_TIMEOUT_MS,
} from './routes-archive-upload.js';
import { createAttachmentStore } from './email-attachments.js';
import {
  VK_CAPTCHA_HOSTS,
  VK_IMAGE_HOSTS,
  VK_MEDIA_HOSTS,
  cspSources,
} from '../sources/vk-hosts.js';
import { setAttachmentSink } from '../sources/email.js';
import { handleEventRoutes } from './routes-events.js';
import { createPasscodeLock } from './passcode.js';
import { gateLocked, handlePasscodeRoutes } from './routes-passcode.js';
import { createClientLogRoute } from './routes-client-log.js';
import { createLearnedRoute } from './routes-learned.js';
import { createConversationKnowledge } from './conversation-knowledge.js';
import { createGitHubCheck } from '../sources/github-check.js';
import { handleMetrics } from './metrics.js';
import { jsonLog } from './log.js';
import { defaultStoreDir } from '../storage/app-directory.js';
import { listenLocal } from './local-tls.js';
import { handlePullRoutes, pullContext } from './routes-pull.js';
import { createPeer, attachSyncWebSocket } from '../sync/index.js';
import { attachSignaling } from '../sync/webrtc-signaling.js';
import {
  classifyOrigin,
  corsContext,
  handleCors,
  hostAllowed,
  parseAllowedOrigins,
} from './cors.js';
import {
  hostedUiUrl,
  localUiEnabled,
  redirectToHosted,
  serveBeacon,
  serveTrust,
  withHostedOrigin,
} from './hosted-ui.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const webRoot = path.resolve(here, '..', 'web');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.wasm': 'application/wasm',
};

// Conservative Content-Security-Policy. The SPA loads no remote
// resources except VK greeting-sticker previews from https://vk.com
// (issue #35; Telegram thumbnails are proxied through
// /api/greetings/file) and ships no inline scripts/styles: only same-origin SPA
// modules/bundles and app.css. WebSockets connect to the same
// origin (/ws + /rtc); discovery may also attempt 127.0.0.1 / localhost
// on alternate ports. Browser-first provider API calls (JMAP, Gmail,
// Graph, etc.) use HTTPS directly when CORS allows them.
// `frame-src https:` is for a bot's mini app (R-Y168), shown in a sandboxed
// iframe of the bot's own https origin; nothing else may be framed.
export const CSP =
  "default-src 'self'; " +
  "script-src 'self' 'wasm-unsafe-eval'; " +
  "style-src 'self'; " +
  "img-src 'self' data: blob: https://vk.com " +
  // VK's picture CDNs, for photos and stickers in VK chats (R-Z8).
  `${cspSources(VK_IMAGE_HOSTS)} ${cspSources(VK_CAPTCHA_HOSTS)}; ` +
  // Direct VK audio and video files (R-Z20); a VK video page is a link.
  `media-src 'self' ${cspSources(VK_MEDIA_HOSTS)}; ` +
  'frame-src https:; ' +
  "connect-src 'self' https: ws: wss: http://127.0.0.1:* http://localhost:*; " +
  "worker-src 'self'; " +
  "font-src 'self' data:; " +
  "object-src 'none'; " +
  "base-uri 'self'; " +
  "frame-ancestors 'none'";

const SECURITY_HEADERS = {
  'content-security-policy': CSP,
  'x-content-type-options': 'nosniff',
  'referrer-policy': 'no-referrer',
  'x-frame-options': 'DENY',
};

// SPA assets keep their names across releases, so browsers must
// revalidate them (`no-cache`) instead of guessing a lifetime — Safari
// otherwise kept running an old bundle after an update. The ETag makes
// the revalidation a cheap 304 when nothing changed.
const serveStatic = async (req, res, filePath) => {
  try {
    const stat = await fs.stat(filePath);
    const etag = `"${stat.size.toString(16)}-${Math.floor(stat.mtimeMs).toString(16)}"`;
    const headers = { 'cache-control': 'no-cache', etag };
    if (req.headers['if-none-match'] === etag) {
      res.writeHead(304, headers);
      res.end();
      return true;
    }
    const buf = await fs.readFile(filePath);
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      ...headers,
      'content-type': MIME[ext] ?? 'application/octet-stream',
    });
    res.end(buf);
    return true;
  } catch {
    return false;
  }
};

// Browser-safe modules outside js/src/web that the SPA imports directly.
// Each entry maps a URL prefix to the directory under src/ that holds
// the matching file. Only files whose name matches the allow-list
// regex are served, and the resolved path must stay under the mapped
// directory (no `..`).
const SRC_ROOT = path.resolve(here, '..');
const BROWSER_MOUNTS = [
  ['/storage/', path.join(SRC_ROOT, 'storage')],
  ['/handlers/', path.join(SRC_ROOT, 'handlers')],
  ['/sync/', path.join(SRC_ROOT, 'sync')],
];

const handleStatic = async (req, res, p) => {
  if (req.method !== 'GET') {
    return false;
  }
  if (p === '/' || p === '/index.html') {
    return serveStatic(req, res, path.join(webRoot, 'index.html'));
  }
  if (/^\/[a-zA-Z0-9._-]+\.(js|css|svg|wasm)$/.test(p)) {
    return serveStatic(req, res, path.join(webRoot, p.slice(1)));
  }
  for (const [prefix, dir] of BROWSER_MOUNTS) {
    if (!p.startsWith(prefix)) {
      continue;
    }
    const tail = p.slice(prefix.length);
    if (!/^[a-zA-Z0-9._-]+\.js$/.test(tail)) {
      continue;
    }
    const resolved = path.join(dir, tail);
    if (!resolved.startsWith(dir + path.sep) && resolved !== dir) {
      continue;
    }
    return serveStatic(req, res, resolved);
  }
  return false;
};

// The hosted app may use the server; the local copy is optional.
const uiContext = (allowOrigins, uiUrl, localUi) => {
  const hosted = hostedUiUrl(uiUrl);
  const allowed = parseAllowedOrigins(allowOrigins);
  // A hosted copy named by hand may use the server too — unless
  // cross-origin use is off (`--allow-origin=none`).
  const custom = uiUrl ?? process.env.MS_UI_URL;
  return {
    allowOrigins:
      custom && allowed.length > 0
        ? withHostedOrigin(allowed, hosted)
        : allowed,
    uiUrl: hosted,
    localUi: localUiEnabled(localUi),
  };
};

/**
 * CV routes accept an injected browser so tests — and any embedder
 * that already owns a session — never open a second one.
 * @param {{commander?: object, sessionFactory?: Function, artifactDir?: string}} cv
 */
const cvContext = (cv = {}) => ({
  cvCommander: cv.commander ?? null,
  cvSessionFactory: cv.sessionFactory ?? null,
  cvArtifactDir: cv.artifactDir ?? null,
});

/**
 * The reply service behind /api/suggest. `replies.clink` (or
 * `MS_REPLY_CLINK=1`) mirrors the reply graph into a link-cli database
 * next to the store.
 */
const replyService = (store, storeDir, replies = {}) => {
  const option = replies.clink ?? process.env.MS_REPLY_CLINK === '1';
  const clink =
    option === true
      ? createClinkReplyStore({ db: path.join(storeDir, 'replies.links') })
      : option || null;
  return createReplyService({ store, self: replies.self ?? [], clink });
};

/**
 * Sending, typing and automations. `automations.send` and `.setTyping`
 * replace the adapters (tests); by default a message goes through the
 * network's API and falls back to its official web UI. The scheduler
 * fires schedule and incoming triggers unless `scheduler: false`.
 */
const automationContext = (
  store,
  automations = {},
  log = null,
  getSource = getSourceDefault,
  later = []
) => {
  const say = (event) => log?.(event);
  // The saved connection's token and ids, so the API is really tried
  // before the web app.
  const optionsFor = (source) =>
    liveOptionsFrom(store, source).catch(() => ({}));
  const send =
    automations.send ??
    createDefaultSender({
      getSource,
      options: automations.options,
      optionsFor,
      browser: { store, ...automations.browser },
      log: say,
    });
  const setTyping =
    automations.setTyping ??
    (async ({ source, chat, cancel }) =>
      setTypingFor(getSource, {
        source,
        chat,
        cancel,
        options: await optionsFor(source),
      }).catch((error) => ({
        supported: false,
        source,
        error: error.message,
      })));
  const self = (automations.self ?? []).map(String);
  const runner = createAutomationRunner({
    store,
    send,
    setTyping,
    resolveAudience: automations.resolveAudience,
    self,
    log: say,
  });
  const scheduler = createAutomationScheduler({
    store,
    runner,
    isSelf: (sender) => sender === 'me' || self.includes(String(sender)),
    tickMs: automations.tickMs,
    log: say,
  });
  const autopilot = createAutopilot({ store, runner, log: say });
  // A send the last run never finished may have gone out: it becomes
  // `unknown` and is never retried by itself (R-Z3).
  const recover = () =>
    recoverOutbox(store).catch((error) =>
      say({
        level: 'warn',
        event: 'outbox_recover_failed',
        error: error.message,
      })
    );
  const recovered = automations.deferRecovery ? null : recover();
  if (automations.scheduler !== false) {
    // Started once the port is really ours (R-Z1): a second `serve` on a
    // busy port must not run automation on the same store.
    later.push(() => {
      scheduler.start();
      // An autopilot left on stays paused after a restart until the user
      // resumes it (or it was set to resume on start) (R-Z3).
      (recovered ?? recover())
        .then(() => autopilot.resume())
        .catch((error) =>
          say({
            level: 'warn',
            event: 'autopilot_resume_failed',
            error: error.message,
          })
        );
    });
  }
  return {
    send,
    setTyping,
    automations: { runner, scheduler, autopilot },
    closeAutomations: async () => {
      autopilot.stopAll();
      scheduler.stop();
      await send.close?.();
    },
  };
};

/**
 * Greeting routes accept injected sources (and a sleep) so tests send
 * nothing to a real network.
 * @param {{resolveSource?: Function, sleep?: Function}} greetings
 */
// Whether GitHub accounts link back (R-Y53): the given one, or GitHub's.
const githubCheckOf = (store, log, given) =>
  given ?? createGitHubCheck({ store, log });

// Pictures shown in Chat are kept next to the store.
const mediaDirOf = (storeDir) =>
  storeDir ? path.join(storeDir, 'media', 'telegram') : null;

// Mail (R-Z5): where attachments are kept next to the store, and the
// periodic pull of a connected mailbox (`emailPoll: false` turns it off).
const emailContext = (storeDir) => {
  const emailFiles = storeDir
    ? createAttachmentStore(path.join(storeDir, 'media', 'email'))
    : null;
  setAttachmentSink(emailFiles ? (bytes) => emailFiles.save(bytes) : null);
  return { emailFiles };
};

// Listen (with HTTPS beside HTTP when asked, ./local-tls.js) and track
// the front server's sockets as well, so close() ends them all.
const listenTracked = async (server, sockets, options) => {
  const { listener, tls } = await listenLocal(server, options);
  if (listener === server) {
    return { listener, tls, closeFront: () => {} };
  }
  listener.on('connection', (socket) => {
    sockets.add(socket);
    socket.on('close', () => sockets.delete(socket));
  });
  return { listener, tls, closeFront: () => listener.close() };
};
/**
 * The connected Telegram account (sync, history, sending). Tests that
 * inject a fake login (`telegramMtproto`/`telegramCreds`) get no real
 * account unless they pass one, so nothing ever dials Telegram.
 */
const telegramAccountFor = (store, log, options, later = []) => {
  if (options.telegramAccount !== undefined) {
    return options.telegramAccount || null;
  }
  if (options.telegramMtproto || options.telegramCreds) {
    return null;
  }
  const account = createTelegramAccount({
    store,
    log: (e) => log?.(e),
    chats: options.chats,
    mediaDir: options.mediaDir ?? null,
  });
  later.push(() => account.start());
  return account;
};

// The extra accounts' live side (R-Y198): lazy, it dials nothing until an
// extra account exists in the store and is asked for. None without an
// account 1.
// R-Y202: each signed-in extra account also runs on its own store, in a
// subdirectory of the store dir (a memory store when the server was given
// a store of its own, as tests do, so nothing is made on disk).
const telegramContext = (store, log, account, extra = {}, later = []) => {
  const say = (e) => log?.(e);
  const runtime = account
    ? createExtraRuntime({
        home: store,
        storeDir: extra.providedStore ? null : extra.storeDir,
        openStore: extra.telegramExtraStore ?? null,
        build: extra.telegramExtraBuild ?? undefined,
        log: say,
      })
    : null;
  // Signed-in extra accounts start with the server.
  later.push(() => runtime?.startAll().catch(() => {}));
  return {
    telegramAccount: account,
    telegramStore: store,
    telegramAccounts: account ? createExtraAccounts({ store, log: say }) : null,
    telegramExtras: runtime,
  };
};

// `telegram` sends and types through the connected account; every other
// network keeps its adapter.
const accountSources = (account) => (name) => {
  const adapter = getSourceDefault(name);
  return name === 'telegram' && account && adapter
    ? { ...adapter, live: { ...adapter.live, ...account.live } }
    : adapter;
};

const greetingContext = (greetings = {}) => ({
  greetingSources: greetings.resolveSource ?? null,
  greetingSleep: greetings.sleep ?? null,
  greetingRandom: greetings.random ?? null,
});

const applySecurityHeaders = (res) => {
  for (const [k, v] of Object.entries(SECURITY_HEADERS)) {
    if (!res.hasHeader(k)) {
      res.setHeader(k, v);
    }
  }
};

// The app's own files, or — with the local copy off — the way to the
// hosted one (R-Y59).
const handlePage = (req, res, p, ctx) =>
  serveBeacon(req, res, p, ctx) ||
  serveTrust(req, res, p, ctx) ||
  (ctx.localUi
    ? handleStatic(req, res, p)
    : redirectToHosted(req, res, p, ctx.uiUrl));

// Same rule as HTTP: no sockets for pages on other websites, none while
// locked (R-Y183).
// Nor for a Host that is not this server's own (DNS rebinding, R-Z1).
const socketAllowed = (ctx) => (req) =>
  hostAllowed(req, ctx.port) &&
  classifyOrigin(req, ctx.allowOrigins) !== 'denied' &&
  (!ctx.tls ||
    req.socket?.encrypted ||
    classifyOrigin(req, ctx.allowOrigins) === 'allowed') &&
  !ctx.passcode.locked();

// With TLS enabled, direct local access uses the trusted certificate.
// The public bootstrap routes stay usable before trust; an allow-listed
// hosted page may still use HTTP where its browser supports loopback.
const redirectLocalTls = (req, res, url, ctx) => {
  if (
    !ctx.tls ||
    req.socket?.encrypted ||
    classifyOrigin(req, ctx.allowOrigins) === 'allowed'
  ) {
    return false;
  }
  const p = url.pathname;
  if (
    p === '/trust' ||
    p === '/api/beacon.svg' ||
    (!ctx.localUi && (p === '/' || p === '/index.html'))
  ) {
    return false;
  }
  res.writeHead(307, {
    location: `https://${req.headers.host}${url.pathname}${url.search}`,
    'content-length': '0',
  });
  res.end();
  return true;
};

// The local passcode (R-Y183): its own routes, then the gate that refuses
// everything else while the server is locked.
const passcodeHandled = async (req, res, p, ctx) =>
  (await handlePasscodeRoutes(req, res, p, ctx)) || gateLocked(res, p, ctx);

const handlePageOrLock = async (req, res, p, ctx) =>
  (await handlePage(req, res, p, ctx)) || passcodeHandled(req, res, p, ctx);

const route = async (store, req, res, ctx) => {
  applySecurityHeaders(res);
  // First of all, on every route: only a loopback Host with this server's
  // port may use it. A rebound DNS name sends its own name (R-Z1).
  if (!hostAllowed(req, ctx.port)) {
    return fail(res, 421, 'bad-host', 'unexpected Host header');
  }
  if (handleCors(req, res, ctx.allowOrigins)) {
    return;
  }
  const url = new URL(req.url, 'http://localhost');
  const p = url.pathname;
  if (redirectLocalTls(req, res, url, ctx)) {
    return;
  }
  const wireFailure = requestWireFailure(req);
  if (wireFailure) {
    return fail(res, ...wireFailure);
  }
  if (await handlePageOrLock(req, res, p, ctx)) {
    return;
  }
  // A request for an extra Telegram account runs on that account's own
  // store and service; none for account 1 (R-Y202).
  const scope = await accountScope(req, url, p, ctx);
  if (scope.refuse) {
    return json(res, scope.refuse[0], scope.refuse[1]);
  }
  return routeOn(scope.store ?? store, req, res, scope.ctx ?? ctx, url, p);
};

const routeOn = async (store, req, res, ctx, url, p) => {
  if (p === '/sources' && req.method === 'GET') {
    return json(res, 200, listSources());
  }
  if (await handleMetrics(store, req, res, p, ctx)) {
    return;
  }
  if (await handleCvRoutes(store, req, res, p, url, ctx)) {
    return;
  }
  if (await handleSuggestRoutes(req, res, p, url, ctx)) {
    return;
  }
  if (await handleAutomationRoutes(store, req, res, p, url, ctx)) {
    return;
  }
  if (await handlePeopleRoutes(store, req, res, p, url)) {
    return;
  }
  if (await handleStickerCollections(store, req, res, p, url, ctx)) {
    return;
  }
  if (await handleGreetingRoutes(store, req, res, p, url, ctx)) {
    return;
  }
  if (await handleMutatingRoutes(store, req, res, p, url, ctx)) {
    return;
  }
  if (
    await handleBackupRoutes(store, req, res, p, ctx.archiveDir, {
      fallbackPassphrase: ctx.secretPassphrase,
      recovery: ctx.recovery,
    })
  ) {
    return;
  }
  for (const handle of [
    () => handleContactsImport(store, req, res, p, ctx),
    () => handleEventRoutes(store, req, res, p, ctx),
    () => handleBrowserRoutes(store, req, res, p, url, ctx),
    () => handleFormRoutes(store, req, res, p, ctx),
    () => ctx.clientLog?.(req, res, p, ctx) ?? false,
    () => handleAutoImportRoutes(store, req, res, p, ctx),
    () => handleWhatsAppRoutes(store, req, res, p, ctx),
    () => handleMarketplaceRoutes(store, req, res, p, ctx),
    () => handleArchiveUpload(store, req, res, p, ctx),
    () => handlePullRoutes(store, req, res, p, ctx),
    () => handleTelegramRoutes(req, res, p, ctx),
    () => handleMessageRoutes(store, req, res, p, url, ctx),
    () => handleEmailGets(store, req, res, p, url, ctx),
    () => handleMediaGets(req, res, p, ctx),
    () => handleDeletedRoutes(store, req, res, p, url, ctx),
    () => handleVersionRoutes(store, req, res, p, url, ctx),
    () => handleAudienceSyncRoute(store, req, res, p, ctx),
    () => handleChatRoutes(req, res, p, url, ctx),
    () => handleFeedbackRoutes(store, req, res, p, url, ctx),
    () => ctx.learned?.(store, req, res, p, url, ctx) ?? false,
    () => handleDerivedRoutes(store, req, res, p, url, ctx),
  ]) {
    if (await handle()) {
      return;
    }
  }
  return fail(res, 404, 'unknown-route', 'unknown route');
};

const initStore = async ({
  providedStore,
  storeDir,
  archiveDir,
  secretPassphrase,
  log,
}) => {
  let store = providedStore;
  let resolvedArchiveDir = archiveDir;
  if (!store) {
    store = await openDualStore(storeDir, {
      // How many lines could not be read, never what they said (R-Z2).
      onCorrupt: ({ count, file, quarantined }) =>
        log?.({
          level: 'warn',
          event: quarantined ? 'store_corrupt_quarantined' : 'store_corrupt',
          count,
          file,
        }),
      onError: (error) =>
        log?.({
          level: 'warn',
          event: 'store_snapshot_failed',
          error: error.message,
        }),
      // A full disk: degraded, recovered, *_skipped (R-Z14).
      onEvent: (event) => log?.(event),
    });
    // The binary snapshot may have missed the last writes (a crash).
    await store.reconcile();
    if (!resolvedArchiveDir) {
      resolvedArchiveDir = path.join(storeDir, 'archives');
      await fs.mkdir(resolvedArchiveDir, { recursive: true });
    }
  }
  // Kept before wrapping: the secret wrapper does not pass `flush` on.
  store = withMessageVersions(store);
  const unwrapped = store;
  const flush = async () => {
    await unwrapped.flush?.();
  };
  // An injected store belongs to its caller (including the rolling host).
  const releaseStore = async () => {
    if (!providedStore) {
      await unwrapped.close?.();
    }
  };
  if (secretPassphrase) {
    store = wrapSecretStore({ inner: store, passphrase: secretPassphrase });
  }
  // The unwritten-changes state for /api/health (R-Z14).
  // ... and the data schema it was opened at (R-Z17).
  const storeHealth = () => ({
    ...(unwrapped.health?.() ?? { degraded: false, queuedBytes: 0 }),
    schema: unwrapped.schema ?? null,
  });
  return { store, resolvedArchiveDir, flush, releaseStore, storeHealth };
};

// The HTTP server: each request is logged, and routed (./account-scope.js
// picks the Telegram account it is for).
const createHttpServer = (store, ctx, log) => {
  // A big export uploaded over Wi-Fi takes longer than Node's default 5
  // minutes to arrive (R-Z23); headers still time out at Node's 60 s.
  const dispatch = (req, res) => {
    const start = Date.now();
    const pathname = (req.url ?? '').split('?')[0];
    if (
      /^\/api\/(people|audience|facts|search|autocomplete|greetings\/plan)(\/|$)/.test(
        pathname
      )
    ) {
      log?.({
        level: 'debug',
        event: 'http_analysis_started',
        method: req.method,
        path: pathname,
      });
    }
    res.on('finish', () => {
      log?.({
        event: 'http',
        method: req.method,
        path: (req.url ?? '').split('?')[0],
        status: res.statusCode,
        ...(res.statusCode === 403 ? corsContext(req) : {}),
        duration_ms: Date.now() - start,
      });
    });
    return route(store, req, res, ctx).catch((err) => {
      log?.({
        level: 'error',
        event: 'http_error',
        method: req.method,
        path: (req.url ?? '').split('?')[0],
        error: err.message,
        stack: err.stack ?? null,
      });
      // A body the client sent badly is its own error (400/413); any other
      // failure is told in the log, not to the page (paths, internals).
      const [status, body] = bodyFailure(err) ?? [
        500,
        { ok: false, error: 'internal server error', code: 'internal' },
      ];
      json(res, status, body);
    });
  };
  const gate = createRequestGate(dispatch, ctx.front);
  const server = http.createServer(
    { requestTimeout: UPLOAD_TIMEOUT_MS },
    (req, res) => {
      bindWire(req, res, ctx.jsonCompatibility);
      return gate.handle(req, res);
    }
  );
  server.requestGate = gate;
  server.prependListener('upgrade', (req, socket) => {
    if (!gate.authorize(req)) {
      socket.destroy();
    }
  });
  return server;
};

// Listen; when the port cannot be had, let go of what was opened (nothing
// background was started) and fail with a message a person can act on.
const listenOrRelease = async (server, sockets, options, release) => {
  try {
    return await listenTracked(server, sockets, options);
  } catch (error) {
    await release();
    throw listenFailure(error, options.port);
  }
};

// The page's live sockets: sync and WebRTC signalling (same rules as HTTP).
const attachSockets = (server, ctx, store, { enableSync, node }) => {
  if (!enableSync) {
    return { wsHandle: null, signaling: null };
  }
  const originAllowed = socketAllowed(ctx);
  const verifyOrigin = (req) =>
    server.requestGate.authorize(req) && originAllowed(req);
  const wsHandle = attachSyncWebSocket(server, {
    path: '/ws',
    verifyOrigin,
    jsonCompatibility: ctx.jsonCompatibility,
  });
  // Peers of another data schema are refused, with a log line (R-Z17).
  createPeer(store, {
    node,
    schemaVersion: CURRENT_SCHEMA,
    hub: true,
    onMismatch: (error) =>
      ctx.log?.({
        level: 'warn',
        event: 'schema_mismatch',
        local: error.local,
        remote: error.remote,
        message: error.message,
      }),
  }).connect(wsHandle.transport);
  const signaling = attachSignaling(server, {
    path: '/rtc',
    verifyOrigin,
    jsonCompatibility: ctx.jsonCompatibility,
  });
  ctx.sync = wsHandle;
  ctx.signaling = signaling;
  return { wsHandle, signaling };
};

// The browser sender signs in to the web apps in profiles inside the store
// (owner only), the same ones "Sign in to WhatsApp Web" opens (R-Z9).
const withStoreProfiles = (automations = {}, storeDir, front) => ({
  ...automations,
  ...(front?.warming ? { deferRecovery: true } : {}),
  browser: {
    profileDirFor: (source) => profileDirIn(storeDir, source),
    ...automations.browser,
  },
});

// The open connections of `server`, so a shutdown can end them.
const trackSockets = (server) => {
  const sockets = new Set();
  server.on('connection', (socket) => {
    sockets.add(socket);
    socket.on('close', () => sockets.delete(socket));
  });
  return sockets;
};

// The automations' part of the context, fed by the Telegram account.
const automationFor = (store, automations, log, telegramAccount, later) =>
  automationContext(
    store,
    automations,
    log,
    accountSources(telegramAccount),
    later
  );

const logFlusher = (store) => store?.flushLog;
const applyServerAddress = (ctx, listening, front, activate) => {
  ctx.tls = front?.tls ?? listening.tls;
  ctx.port = front?.port ?? listening.listener.address().port;
  if (!front?.warming) {
    activate();
  }
};

const releaseBeforeListen =
  ({ wsHandle, signaling, lifecycle, flush, releaseStore }) =>
  async () => {
    wsHandle?.close();
    signaling?.close();
    await lifecycle.stopRuntime();
    try {
      await flush().catch(() => {});
    } finally {
      await releaseStore();
    }
  };

const serverForms = (store, options) =>
  createFormReader({
    store,
    reportWriter: createFormReportWriter(),
    ...options,
  });

export const startServer = async ({
  port = 0,
  storeDir = defaultStoreDir(),
  archiveDir,
  store: providedStore,
  enableHandlers = true,
  enableSync = true,
  log = process.env.MS_LOG_FORMAT === 'json' ? jsonLog() : null,
  node = 'server',
  secretPassphrase = process.env.MS_SECRET_PASSPHRASE ?? null,
  emailLiveFactory = null,
  emailPoll,
  cv = {},
  forms,
  // replies: `{ self?, clink? }` for /api/suggest; automations: `{ send?,
  // setTyping?, resolveAudience?, self?, scheduler?, tickMs? }`.
  replies,
  automations,
  greetings,
  broadcasting,
  allowOrigins,
  follow,
  autoImportLauncher,
  // Tests inject a fake `createSignIns()` and a fake MTProto (no real browsers
  // or network are used).
  autoImportSignIns,
  telegramMtproto,
  telegramCreds,
  // A `createTelegramAccount()` (or `false` for none); see telegramAccountFor.
  telegramAccount: telegramAccountOption,
  // Tests: the extra accounts' stores and services (R-Y202), see
  // ./telegram-extras.js `createExtraRuntime`.
  telegramExtraStore,
  telegramExtraBuild,
  // Tests and demos pass a fake, so GitHub is never asked (R-Y53).
  githubCheck,
  systemContactsReader,
  // The hosted app, and whether this serves its own copy (./hosted-ui.js).
  uiUrl,
  localUi,
  // Legacy JSON is an explicit opt-in. Normal servers speak text/binary LINO.
  jsonCompatibility = process.env.MS_JSON_COMPATIBILITY === '1',
  // HTTPS on the same port for Safari (./local-tls.js, R-Y64); `serve` sets it.
  tls,
  // diskFree: a test fake `(dir) => bytes|null` (R-Z14); backups:
  // `{ intervalHours?, keep? }` for the automatic backup (R-Z7).
  diskFree,
  pulls,
  backups,
  // Private rolling-worker options; the public listener remains in its host.
  front,
} = {}) => {
  const { store, resolvedArchiveDir, flush, releaseStore, storeHealth } =
    await initStore({
      providedStore,
      storeDir,
      archiveDir,
      secretPassphrase,
      log,
    });
  // Services that run in the background start only after the port is ours.
  const later = [];
  automations = withStoreProfiles(automations, storeDir, front);
  const chatIndex = createChatIndex(store, { log });
  const telegramAccount = telegramAccountFor(
    store,
    log,
    {
      telegramAccount: telegramAccountOption,
      telegramMtproto,
      telegramCreds,
      chats: () => telegramChats(chatIndex),
      mediaDir: mediaDirOf(storeDir),
    },
    later
  );
  const ctx = {
    front,
    jsonCompatibility: jsonCompatibility === true,
    archiveDir: resolvedArchiveDir,
    sync: null,
    signaling: null,
    secretPassphrase,
    emailLiveFactory,
    ...emailContext(storeDir),
    ...uiContext(allowOrigins, uiUrl, localUi),
    ...cvContext(cv),
    forms: serverForms(store, forms),
    replies: replyService(store, storeDir, replies),
    ...automationFor(store, automations, log, telegramAccount, later),
    ...greetingContext(greetings),
    broadcasting,
    storeDir,
    followDiscovery: createFollowDiscovery({ store, ...follow }),
    followBacklinkOptions: follow?.backlinks,
    storeHealth,
    systemContactsReader,
    diskFree,
    passcode: createPasscodeLock({ dir: storeDir }),
    log,
    clientLog: createClientLogRoute(),
    learned: createLearnedRoute(),
    githubCheck: githubCheckOf(store, log, githubCheck),
    autoImport: null,
    autoImportLauncher,
    autoImportSignIns,
    telegramMtproto,
    telegramCreds,
    ...telegramContext(
      store,
      log,
      telegramAccount,
      { providedStore, storeDir, telegramExtraStore, telegramExtraBuild },
      later
    ),
    chatIndex,
    knowledge: createConversationKnowledge({ store, index: chatIndex, log }),
    ...pullContext(store, log, pulls, later, emailPoll),
  };
  Object.assign(ctx, backgroundJobs({ ctx, store, log, later, backups }));
  const server = createHttpServer(store, ctx, log);
  const sockets = trackSockets(server);
  const lifecycle = createRuntimeLifecycle({
    server,
    ctx,
    store,
    later,
    enableHandlers,
    sockets,
    flush,
    releaseStore,
    flushLog: logFlusher(providedStore),
  });
  const { wsHandle, signaling } = attachSockets(server, ctx, store, {
    enableSync,
    node,
  });
  const listening = await listenOrRelease(
    server,
    sockets,
    { port, storeDir, tls, log },
    releaseBeforeListen({ wsHandle, signaling, lifecycle, flush, releaseStore })
  );
  applyServerAddress(ctx, listening, front, lifecycle.activate);
  return {
    port: listening.listener.address().port,
    tls: ctx.tls,
    store,
    bus: lifecycle.bus,
    sync: wsHandle,
    signaling,
    archiveDir: resolvedArchiveDir,
    allowOrigins: ctx.allowOrigins,
    uiUrl: ctx.uiUrl,
    localUi: ctx.localUi,
    activate: lifecycle.activate,
    drain: server.requestGate.drain,
    passcodeState: () => ctx.passcode.status(),
    inheritUnlock: () => ctx.passcode.inheritUnlock(),
    close: (options) =>
      lifecycle.close(listening, { wsHandle, signaling }, options),
  };
};
