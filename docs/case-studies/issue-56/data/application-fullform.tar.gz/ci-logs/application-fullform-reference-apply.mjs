#!/usr/bin/env bun

/**
 * Universal job application automation for hh.ru
 * Works with both Playwright and Puppeteer through browser-commander
 *
 * This is the main entry point that:
 * 1. Parses CLI arguments
 * 2. Starts (or reuses) the automation browser and starts tracing
 * 3. Creates and starts the orchestrator (login, resume selection, applications)
 */

import path from 'path';
import { spawn } from 'child_process';
import { isNavigationError, isTimeoutError, makeBrowserCommander } from 'browser-commander';
import { createQADatabase } from './qa-database.mjs';
import { enableDebugLevel } from './logging.mjs';
import { createConfig, getUserDataDir } from './config.mjs';
import { createOrchestrator } from './orchestrator.mjs';
import { createDailyLimitPriority } from './application-limits.mjs';
import { saveQAPairs } from './vacancy-response.mjs';
import { markVacancyAsProcessed } from './vacancies.mjs';
import { connectOrLaunchBrowser } from './browser-session.mjs';
import { recordBrowserLifecycle } from './browser-lifecycle.mjs';
import { startTracing, stopTracing } from './tracing.mjs';
import { enableConfirmations, withConfirmations } from './confirmations.mjs';
import { withCaptchaGuard } from './captcha.mjs';
import { createCaptchaPrefill } from './captcha-solver.mjs';
import { createDeferredQuestions, formatQuestions } from './deferred-questions.mjs';
import { createVacancyFilters } from './vacancy-filters.mjs';
import { createSkippedVacancies } from './skipped-vacancies.mjs';
import { expandContacts, loadContacts, withContacts } from './contacts.mjs';
import { createInstantChat } from './instant-chat.mjs';
import { blockHangingHosts } from './hanging-hosts.mjs';
import { closeChatPanel } from './helpers/page-helpers.mjs';
import { todayLine } from './stats.mjs';
import { prepareAlerts } from './notify.mjs';
import { createChatHistory } from './chat-history.mjs';
import { learnChatQuestions, withChatHistoryAnswers } from './chat-learning.mjs';
import { answerCorrections } from './answer-corrections.mjs';
import { watchChats } from './chat-recording.mjs';
import { createVacancyInsights } from './vacancy-insights.mjs';
import { vacancyContextTexts } from './vacancy-context.mjs';
import { createResumeAliasUpdater } from './resume-aliases.mjs';
import { submissionRetries } from './submission-retries.mjs';
import { watchVacancyFeedback } from './vacancy-feedback.mjs';
import { questionnaireMode } from './questionnaire-mode.mjs';
import { traceRetentionDays } from './trace-storage.mjs';

const qaDatabase = createQADatabase(path.join(process.cwd(), 'data', 'qa.lino'), { resolveVariants: true });

let session = null;
let commander = null;
let chatProcess = null;
let chatRecording = null;
let shuttingDown = false;

/**
 * Finish the trace, release browser-commander resources and the browser, then exit
 */
async function shutdown(reason, exitCode = 0) {
  if (shuttingDown) {
    return;
  }
  shuttingDown = true;
  recordBrowserLifecycle('worker_shutdown', { reason, exitCode });
  console.log(`\n${reason}, shutting down...`);
  try {
    await chatRecording?.flush();
    if (chatProcess) {
      chatProcess.kill('SIGTERM');
      chatProcess = null;
    }
    await stopTracing();
    await commander?.destroy();
    await session?.release();
  } catch (error) {
    console.error('Error during shutdown:', error.message);
  }
  process.exit(exitCode);
}

process.on('SIGINT', () => shutdown('Received SIGINT'));
process.on('SIGTERM', () => shutdown('Received SIGTERM'));
process.on('SIGUSR1', () => questionnaireMode.setEnabled(true));
process.on('SIGUSR2', () => questionnaireMode.setEnabled(false));

(async () => {
  const argv = createConfig();
  process.env.TRACE_RETENTION_DAYS = String(traceRetentionDays(argv.traceRetentionDays));
  questionnaireMode.setEnabled(!argv.questions);
  if (process.env.HH_QUESTIONNAIRE_MODE_HANDOFF) {
    const handoff = process.env.HH_QUESTIONNAIRE_MODE_HANDOFF;
    delete process.env.HH_QUESTIONNAIRE_MODE_HANDOFF;
    questionnaireMode.restore(JSON.parse(handoff));
    console.log(`♻️  Preserved ${questionnaireMode.ids().length} RAM questionnaire(s) during controlled code reload`);
  }
  process.env.ANSWER_FINAL_PERIOD = argv.answerFinalPeriod;
  // Also pass the CLI preference to chat/form workers that post their own alerts.
  process.env.NOTIFY_SOUND = String(argv.notificationSound);
  if (!argv.notificationSound) console.log('🔕 Notification sounds disabled; visual alerts remain enabled.');
  if (process.env.HH_SUBMISSION_RETRIES_HANDOFF) {
    const handoff = process.env.HH_SUBMISSION_RETRIES_HANDOFF;
    delete process.env.HH_SUBMISSION_RETRIES_HANDOFF;
    submissionRetries.restore(JSON.parse(handoff));
    console.log(`♻️  Preserved ${submissionRetries.ids().length} in-memory submission cooldown(s) during code reload`);
  }
  argv.userDataDir ||= getUserDataDir();

  if (argv.verbose) {
    enableDebugLevel();
  }

  // Vacancies whose questions are answered later are not opened until then
  const deferredQuestions = createDeferredQuestions(path.join(process.cwd(), 'data', 'deferred-questions.lino'), {
    skipQuestions: argv.skipQuestions,
  });
  if (argv.skipQuestions.length > 0) {
    console.log(`⏭️  Skipping vacancies that ask:\n${formatQuestions(argv.skipQuestions)}`);
  }
  // Answers and the cover letter use {{telegram}}-style placeholders for data/contacts.lino
  await qaDatabase.backfillQuestionAnswers();
  let salaryRates = {};
  const contacts = await loadContacts(path.join(process.cwd(), 'data', 'contacts.lino'), {
    onRates: value => { salaryRates = value.rubPer ?? {}; },
  });
  const chatHistory = createChatHistory();
  const chatQa = withContacts(withChatHistoryAnswers(qaDatabase, { history: chatHistory, contacts, corrections: answerCorrections }), contacts);
  const { readQADatabase, addOrUpdateQA, addQAIfMissing } = chatQa;
  argv.message = expandContacts(argv.message, contacts);
  argv.messageEn = expandContacts(argv.messageEn ?? '', contacts);
  const deferredVacancyIds = await deferredQuestions.pendingVacancyIds(await readQADatabase());
  deferredVacancyIds.forEach(markVacancyAsProcessed);
  if (deferredVacancyIds.size > 0) {
    console.log(`Loaded ${deferredVacancyIds.size} vacancy ID(s) that wait for answers in data/deferred-questions.lino`);
  }

  // Vacancies that are not programming jobs, or cannot be applied to, are not opened
  const vacancyFilters = createVacancyFilters({
    rulesPath: path.join(process.cwd(), 'data', 'vacancy-filters.lino'),
    filteredPath: path.join(process.cwd(), 'data', 'filtered-vacancies.lino'),
  });
  const filteredVacancyIds = await vacancyFilters.filteredVacancyIds();
  filteredVacancyIds.forEach(markVacancyAsProcessed);
  if (filteredVacancyIds.size > 0) {
    console.log(`Loaded ${filteredVacancyIds.size} vacancy ID(s) filtered out before (data/filtered-vacancies.lino)`);
  }

  // Every other skip is kept with its reason; final ones (and transient ones skipped twice) are not opened
  const skippedVacancies = createSkippedVacancies(path.join(process.cwd(), 'data', 'skipped-vacancies.lino'));
  const migrated = await skippedVacancies.importIgnoredVacancyIds(path.join(process.cwd(), 'data', 'ignored-vacancy-ids.txt'));
  if (migrated > 0) {
    console.log(`Moved ${migrated} questionnaire vacancy ID(s) from data/ignored-vacancy-ids.txt to data/skipped-vacancies.lino`);
  }
  const skippedVacancyIds = await skippedVacancies.skippedVacancyIds({
    ignoreQuestionnaires: argv.ignoreVacanciesWithQuestionnaire,
  });
  skippedVacancyIds.forEach(markVacancyAsProcessed);
  const externalSite = [...(await skippedVacancies.read()).values()].filter(({ reason }) => reason === 'external_site');
  if (skippedVacancyIds.size > 0) {
    console.log(`Loaded ${skippedVacancyIds.size} vacancy ID(s) skipped before (data/skipped-vacancies.lino; ` +
      `${externalSite.length} to apply on the employer's site, see bun run skipped)`);
  }

  session = await connectOrLaunchBrowser({
    engine: argv.engine,
    userDataDir: argv.userDataDir,
    port: argv.browserPort,
    keepOpen: argv.keepBrowserOpen,
    idleTimeoutMinutes: argv.browserIdleTimeout,
    singleTab: argv.singleTab,
  });
  await watchVacancyFeedback(session.page, { enabled: argv.autoAnswerViewedVacancy });
  chatRecording = await watchChats(session.page, {
    onChat: (chat) => learnChatQuestions(chat, { history: chatHistory, qaDatabase: chatQa }),
    onError: (error) => console.log(`⚠️  Chat recording failed: ${error.message}`),
  });

  // Someone answers on stdin when steps are confirmed, so missing answers can be asked for too
  if (argv.confirmSteps.length > 0) {
    enableConfirmations({ steps: argv.confirmSteps, onStop: () => shutdown('Stopped by the user') });
    console.log(`🧪 Confirming on stdin: ${argv.confirmSteps.join(', ')}`);
  }
  if (argv.maxApplications > 0) {
    console.log(`🧪 Stopping after ${argv.maxApplications} application(s)`);
  }
  console.log(todayLine());
  // The notification app is built in the background, the first time only
  prepareAlerts();
  let applicationsSent = 0;

  // browser-commander waits for 30 s without requests by default before a click counts the page as
  // ready; hh.ru's anti-bot request repeats every 30 s, so every click waited half a minute
  commander = makeBrowserCommander({ page: session.page, verbose: argv.verbose, networkIdleForMs: argv.networkIdleMs });
  console.log(`Using ${commander.engine} automation engine`);
  // Ad and tracker requests that hang kept every page from being ready for half a minute
  await blockHangingHosts(session.page)
    .catch((error) => console.log(`⚠️  Could not block the hanging ad hosts: ${error.message}`));

  if (argv.trace) {
    await startTracing({ commander, page: session.page });
  }

  const vacancyInsights = createVacancyInsights({
    enabled: argv.vacancyInsights, collect: argv.collectVacancies, compare: argv.compareResume,
    update: argv.updateResumeAliases, directory: argv.vacancyCacheDir,
    updateAliases: createResumeAliasUpdater({ fromPort: argv.browserPort }),
  });
  console.log(`🗃️  Private vacancy archive: ${vacancyInsights.cache.directory}`);
  console.log(argv.applyFromVacancyPage
    ? `📖 Application route: vacancy page (${argv.vacancyPreviewSeconds} s preview) → application form`
    : '📖 Application route: collected vacancy → search → application form');
  const orchestrator = createOrchestrator({
    // Nothing touches the page while hh.ru shows a captcha, except its answer: Haiku's reading is sent
    // once (--captcha-auto-send), after that it is only prefilled and the user sends it
    commander: withConfirmations(withCaptchaGuard(commander, {
      ...createDailyLimitPriority({ port: argv.browserPort,
        saveAnswers: raw => saveQAPairs({ commander: raw, addOrUpdateQA, strict: true }) }),
      onCaptcha: argv.captchaPrefill
        ? createCaptchaPrefill({ page: session.page, sendOnce: argv.captchaAutoSend })
        : undefined,
    })),
    page: session.page,
    argv,
    qaDB: { readQADatabase, addOrUpdateQA },
    contacts,
    salaryRates,
    deferredQuestions,
    vacancyFilters,
    skippedVacancies,
    vacancyInsights,
    onPageClosed: () => shutdown('Tab close detected'),
    // Recruiter bots ask in the chat panel right after the application
    answerInstantChat: argv.answerInstantChats ? createInstantChat({
      page: session.page,
      readQADatabase,
      addOrUpdateQA,
      addQAIfMissing,
      chatHistory,
      contacts,
      readTemplates: withContacts(createQADatabase(path.join(process.cwd(), 'data', 'chat-templates.lino')), contacts).readQADatabase,
      autoSend: argv.autoSendExactAnswers,
      autoReuse: argv.autoReuseAnswers,
      closePanel: () => closeChatPanel(commander),
      vacancyContext: async (vacancyId) => [...vacancyContextTexts(await vacancyInsights.read(vacancyId)),
        vacancyFilters.card?.(vacancyId) ?? '', vacancyFilters.description?.(vacancyId) ?? ''],
    }) : undefined,
    onApplicationSent: () => ++applicationsSent === argv.maxApplications &&
      shutdown(`Sent ${applicationsSent} application(s), the --max-applications limit`),
  });

  if (argv.processChats || argv.clearRejections) {
    const intervalSeconds = argv.chatsIntervalMinutes * 60;
    const chatScriptPath = new URL('./answer-chats.mjs', import.meta.url).pathname;
    // Answering clears the rejections first; without it the rejections alone are cleared
    const mode = argv.processChats
      ? ['--auto', ...(argv.autoSendExactAnswers ? ['--auto-send'] : []), ...(argv.autoReuseAnswers ? ['--auto-reuse'] : [])]
      : ['--clear-rejections', ...(argv.autoSendExactAnswers ? ['--auto-send'] : [])];
    chatProcess = spawn(process.execPath, [chatScriptPath, ...mode, `--poll=${intervalSeconds}`,
      argv.askRejectionReason ? '--ask-rejection-reason' : '--no-ask-rejection-reason', `--rejection-reason-reply=${argv.rejectionReasonReply}`], {
      // Its own output straight into this log: through a pipe it came only when it exited
      stdio: ['ignore', 'inherit', 'inherit'],
      env: { ...process.env, VACANCY_CACHE_DIR: argv.vacancyCacheDir },
    });
    chatProcess.on('exit', (code) => {
      chatProcess = null;
      if (code !== 0 && !shuttingDown) {
        console.log(`⚠️  Chat processor exited with code ${code}`);
      }
    });
    console.log(argv.processChats
      ? `💬 Chat processor started (rejections cleared, then unread chats answered, every ${argv.chatsIntervalMinutes} min)`
      : `📭 Rejection clearing started (unread rejections opened every ${argv.chatsIntervalMinutes} min, and as they show in the chat window)`);
  }

  await orchestrator.start();
})().catch((error) => {
  if (isNavigationError(error)) {
    return shutdown('Navigation interrupted the automation; please restart the script if needed');
  }
  if (isTimeoutError(error)) {
    return shutdown(`Timeout while waiting for page elements: ${error.message}`);
  }
  recordBrowserLifecycle('worker_error', { code: error.code, name: error.name,
    expectedNavigation: Boolean(error.expectedNavigation), stack: error.stack ?? error.message });
  console.error('Error occurred:', error.stack ?? error.message);
  return shutdown('Unexpected error', 1);
});
