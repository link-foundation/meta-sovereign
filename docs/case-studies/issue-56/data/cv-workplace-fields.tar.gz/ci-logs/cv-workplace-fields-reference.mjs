/**
 * The browser side of the experience sync: reading the LinkedIn experience page, and prefilling
 * the experience forms of LinkedIn and hh.ru in a browser slot. Saving is a separate step the
 * caller takes only after the user typed `y`.
 *
 * @module experience-sites
 */

import { formatMonthYear } from './experience.mjs';
import { alertUser } from './notify.mjs';
import { waitForCaptcha } from './form-slots.mjs';
import { pageLanguage } from './hh-words.mjs';
import { importUserSession } from './user-sessions.mjs';

export const LINKEDIN_PROFILE = 'https://www.linkedin.com/in/konard';
const LOGIN_URL = /linkedin\.com\/(authwall|login|uas\/login|checkpoint|signup|start\/join)/i;
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Whether a LinkedIn URL is a login or sign-up wall
 * @param {string} url
 * @returns {boolean}
 */
export const isLinkedInLoginPage = (url) => LOGIN_URL.test(String(url));

/**
 * Whether the slot has a LinkedIn session: its li_at cookie is set. Only the cookie's presence
 * is checked; its value is never read out
 * @param {Object} page - Playwright page of the slot
 * @returns {Promise<boolean>}
 */
export async function hasLinkedInSession(page) {
  const cookies = await page.context().cookies('https://www.linkedin.com').catch(() => []);
  return cookies.some((cookie) => cookie.name === 'li_at' && cookie.value !== '');
}

/**
 * The "show all experiences" page of a profile
 * @param {string} profileUrl - https://www.linkedin.com/in/<name>
 * @returns {string}
 */
export const linkedInExperienceUrl = (profileUrl) => `${profileUrl.replace(/\/+$/, '')}/details/experience/`;

/**
 * Runs in the page: the positions on LinkedIn's experience page as the text lines of each item
 * (the visible spans, in order), with nested roles for a company with several positions and the
 * edit link of each when the profile is the user's own
 * @returns {{items: Array<{lines: string[], editUrl: string|null, roles: Array<{lines: string[], editUrl: string|null}>}>, text: string, edits: Array<{label: string, url: string}>}}
 */
export function readLinkedInExperienceItems() {
  const ENTITY = '[data-view-name="profile-component-entity"]';
  const main = document.querySelector('main') ?? document.body;
  let entities = [...main.querySelectorAll(ENTITY)];
  // Older or newer markup without the entity mark: list items of the main list
  const isEntity = (element) => (entities.length > 0 ? element.matches(ENTITY) : element.matches('li'));
  if (entities.length === 0) {
    entities = [...main.querySelectorAll('li')].filter((li) => /\b\d{4}\b/.test(li.innerText));
  }
  const nestedIn = (element, root) => {
    for (let node = element.parentElement; node && node !== root; node = node.parentElement) {
      if (isEntity(node)) {
        return true;
      }
    }
    return false;
  };
  const linesOf = (root) => {
    const spans = [...root.querySelectorAll('span[aria-hidden="true"]')].filter((span) => !nestedIn(span, root));
    const raw = spans.length > 0
      ? spans.map((span) => span.innerText)
      : root.innerText.split('\n');
    const lines = [];
    for (const line of raw.map((text) => text.replace(/\s+/g, ' ').trim()).filter(Boolean)) {
      // Screen reader copies repeat the visible text
      if (lines[lines.length - 1] !== line) {
        lines.push(line);
      }
    }
    return lines;
  };
  const editUrlOf = (root) => {
    const link = [...root.querySelectorAll('a[href*="/edit/forms/"], a[href*="add-edit"], a[href*="/edit/"]')].find((a) => !nestedIn(a, root));
    return link ? new URL(link.getAttribute('href'), window.location.href).href : null;
  };
  const top = entities.filter((entity) => !entities.some((other) => other !== entity && other.contains(entity)));
  const items = top.map((entity) => {
    const roles = entities.filter((other) => other !== entity && entity.contains(other));
    return {
      lines: linesOf(entity),
      editUrl: editUrlOf(entity),
      roles: roles.map((role) => ({ lines: linesOf(role), editUrl: editUrlOf(role) })),
    };
  });
  // «Edit Senior Software Engineer at Kaiten.ru»: the edit link of each position, also when the
  // items are not recognized and the positions are read from the text
  const edits = [...new Map([...main.querySelectorAll('a[href*="/edit/forms/"][aria-label]')]
    .map((link) => [link.getAttribute('aria-label'), new URL(link.getAttribute('href'), window.location.href).href])).entries()]
    .map(([label, url]) => ({ label, url }));
  // Lines of the text that are not the description: a position's skills line («iOS and Android»,
  // a link to its skills) and its media (links out of LinkedIn with a thumbnail)
  const textOf = (link) => link.innerText.trim();
  const marks = {
    skills: [...new Set([...main.querySelectorAll('a[href*="skill-associations-details"]')].map(textOf).filter(Boolean))],
    media: [...new Set([...main.querySelectorAll('a[href]')]
      .filter((link) => !/linkedin\.com/.test(link.href) && link.querySelector('svg, img'))
      .flatMap((link) => textOf(link).split('\n')).map((line) => line.trim()).filter(Boolean))],
  };
  return { items, text: main.innerText, edits, marks };
}

/**
 * Open the experience page in the slot, waiting while LinkedIn asks to log in (the user logs in
 * in the slot's window; nothing here reads or types a password), then load every position
 * @param {Object} page - Playwright page of the slot
 * @param {Object} [options]
 * @param {string} [options.profileUrl=LINKEDIN_PROFILE]
 * @param {number} [options.waitMinutes=30] - How long to wait for the login
 * @returns {Promise<{items: Object[], text: string, edits: Array<{label: string, url: string}>, url: string}>}
 */
export async function readLinkedInExperience(page, { profileUrl = LINKEDIN_PROFILE, waitMinutes = 30, port = 9350 } = {}) {
  const url = linkedInExperienceUrl(profileUrl);
  if (!page.url().startsWith(url)) {
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
  }
  await waitForLinkedInLogin(page, { url, port, waitMinutes });
  await page.waitForSelector('main', { timeout: 30000 }).catch(() => {});
  // Positions load as the page scrolls; "Show more results" loads the rest
  for (let i = 0; i < 15; i++) {
    const more = await page.evaluate(() => {
      window.scrollTo(0, document.body.scrollHeight);
      const button = [...document.querySelectorAll('main button')].find((element) => /show more results|показать больше/i.test(element.innerText));
      button?.click();
      return Boolean(button);
    });
    await sleep(more ? 2500 : 1200);
    if (!more && i >= 2) {
      break;
    }
  }
  const { items, text, edits, marks } = await page.evaluate(readLinkedInExperienceItems);
  return { items, text, edits, marks, url: page.url() };
}

/**
 * When the slot has no LinkedIn session (no li_at cookie) or shows a login wall: take the LinkedIn
 * session of a browser you use (user-sessions), or else wait until the user logs in in the slot's
 * window, then open `url`. Nothing here reads, types or copies a password
 * @param {Object} page
 * @param {Object} options
 * @param {string} options.url - The page to be on afterwards
 * @param {number} [options.port=9350] - Shown in the message, to find the window
 * @param {number} [options.waitMinutes=30]
 * @param {boolean} [options.importSession=true] - Try the sessions of your browsers first
 */
export async function waitForLinkedInLogin(page, { url, port = 9350, waitMinutes = 30, importSession = true }) {
  if (await hasLinkedInSession(page) && !isLinkedInLoginPage(page.url())) {
    return;
  }
  // The LinkedIn session of a browser you use, before asking you to log in
  const signedIn = async () => {
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => {});
    return await hasLinkedInSession(page) && !isLinkedInLoginPage(page.url());
  };
  if (importSession && await importUserSession({ page, domain: 'linkedin.com', signedIn })) {
    return;
  }
  console.log(`🔐 Not logged in to LinkedIn: log in to LinkedIn in the slot window (port ${port}). The run goes on by itself`);
  console.log('   once you are logged in. This script never reads, types or stores your password.');
  // The sign-in form rather than the sign-up wall, coming back to `url` after the login
  await page.goto(`https://www.linkedin.com/login?session_redirect=${encodeURIComponent(url)}`, { waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => {});
  const deadline = Date.now() + waitMinutes * 60000;
  let reported = Date.now();
  const endAlert = alertUser({ port });
  try {
    while (!(await hasLinkedInSession(page) && page.url().startsWith(url))) {
      if (Date.now() > deadline) {
        throw new Error(`Not logged in to LinkedIn after ${waitMinutes} minutes`);
      }
      // Logged in (the session cookie is there) but landed elsewhere, e.g. the feed: open `url`
      if (await hasLinkedInSession(page) && !isLinkedInLoginPage(page.url()) && !page.url().startsWith(url)) {
        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 }).catch(() => {});
      }
      if (Date.now() - reported > 60000) {
        console.log('⏳ Still waiting for the LinkedIn login in the slot window...');
        reported = Date.now();
      }
      await sleep(3000);
    }
  } finally {
    endAlert();
  }
  console.log('✅ Logged in to LinkedIn');
}

/**
 * Runs in the page: set a form control by its label (label element, aria-label, or the text of
 * its group), firing the events frameworks listen to
 * @param {{label: string, value: string|boolean, kind: 'text'|'checkbox'|'select', group?: string}} field -
 *   label and group are regular expression sources, matched case-insensitively
 * @returns {string|null} Why it was not set, or null
 */
export function setFieldByLabel({ label, value, kind, group }) {
  const pattern = new RegExp(label, 'i');
  const groupPattern = group ? new RegExp(group, 'i') : null;
  // A checkbox without a label is named by the short text next to it («I am currently working in this role»)
  const nearText = (element) => {
    for (let node = element.parentElement, depth = 0; node && depth < 3; node = node.parentElement, depth++) {
      const text = node.innerText?.trim();
      if (text) {
        return text.length <= 120 ? text : '';
      }
    }
    return '';
  };
  const labelOf = (element) => {
    const own = [
      element.getAttribute('aria-label'),
      ...[...(element.labels ?? [])].map((item) => item.innerText),
      (element.getAttribute('aria-labelledby') ?? '').split(/\s+/).map((id) => document.getElementById(id)?.innerText ?? '').join(' '),
      element.getAttribute('placeholder'),
    ].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
    return own || (kind === 'checkbox' ? nearText(element).replace(/\s+/g, ' ').trim() : '');
  };
  const groupOf = (element) => element.closest('fieldset')?.innerText ?? element.parentElement?.parentElement?.innerText ?? '';
  // A rich text box (LinkedIn's description) is a contenteditable with role=textbox
  const selector = kind === 'select' ? 'select' : kind === 'checkbox' ? 'input[type="checkbox"]'
    : 'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]), textarea, [contenteditable="true"][role="textbox"]';
  const control = [...document.querySelectorAll(selector)].find((element) => element.getClientRects().length > 0 &&
    pattern.test(labelOf(element)) && (!groupPattern || groupPattern.test(groupOf(element))));
  if (!control) {
    return `no field labelled ${label}${group ? ` in ${group}` : ''}`;
  }
  if (kind === 'checkbox') {
    // A styled checkbox is toggled by a real click on its label (the caller does it): a click
    // from the page script leaves the box and the form's state apart
    if (control.checked !== Boolean(value)) {
      control.setAttribute('data-hh-automation-toggle', '');
      return 'toggle';
    }
    return null;
  }
  if (kind === 'select') {
    const option = [...control.options].find((item) => item.text.trim().toLowerCase() === String(value).toLowerCase() || item.value === String(value));
    if (!option) {
      return `no option ${value} in ${label}`;
    }
    control.value = option.value;
  } else if (control.isContentEditable) {
    control.focus();
    document.execCommand('selectAll', false);
    document.execCommand('insertText', false, String(value));
    return null;
  } else {
    const prototype = control.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(prototype, 'value').set.call(control, String(value));
  }
  control.dispatchEvent(new Event('input', { bubbles: true }));
  control.dispatchEvent(new Event('change', { bubbles: true }));
  // Closes a suggestion list the typing opened
  control.blur();
  return null;
}

const fieldsOfLinkedIn = (fields) => {
  const list = [];
  const month = (date) => (date?.includes('-') ? formatMonthYear(date).split(' ')[0] : null);
  // Labels of the position form: «Job title*», «Organization*», «Location», «Description, maximum
  // 2,000 characters», «I am currently working in this role», «Start month», «Start year*»
  if (fields.title) {
    list.push({ label: '^(job )?title|^должность', value: fields.title, kind: 'text' });
  }
  if (fields.company) {
    list.push({ label: 'company|organization|компани|организаци', value: fields.company, kind: 'text' });
  }
  if (fields.location) {
    list.push({ label: '^location|^местоположение', value: fields.location, kind: 'text' });
  }
  if (fields.description) {
    list.push({ label: '^description|^описание', value: fields.description, kind: 'text' });
  }
  if ('current' in fields) {
    list.push({ label: 'currently work|сейчас работаю|в настоящее время', value: fields.current, kind: 'checkbox' });
  }
  if (fields.start) {
    if (month(fields.start)) {
      list.push({ label: '^start month|^месяц начала', value: month(fields.start), kind: 'select' });
    }
    list.push({ label: '^start year|^год начала', value: fields.start.slice(0, 4), kind: 'select' });
  }
  if (fields.end && !fields.current) {
    if (month(fields.end)) {
      list.push({ label: '^end month|^месяц окончания', value: month(fields.end), kind: 'select' });
    }
    list.push({ label: '^end year|^год окончания', value: fields.end.slice(0, 4), kind: 'select' });
  }
  return list;
};

/**
 * Toggle the checkbox setFieldByLabel marked, with a real click on its label (or on the box)
 * @param {Object} page
 * @returns {Promise<string|null>} Why it was not toggled, or null
 */
async function toggleMarked(page) {
  const marked = page.locator('[data-hh-automation-toggle]').first();
  const id = await marked.getAttribute('id').catch(() => null);
  // Found by its id: the marker is removed below, and the box is checked again after that
  const box = id ? page.locator(`[id="${id}"]`).first() : marked;
  const label = id ? page.locator(`label[for="${id}"]`).first() : null;
  const before = await box.isChecked().catch(() => null);
  if (label && await label.isVisible().catch(() => false)) {
    await label.click().catch(() => {});
  } else {
    await box.click({ force: true }).catch(() => {});
  }
  await sleep(300);
  const after = await box.isChecked().catch(() => before);
  await box.evaluate((element) => element.removeAttribute('data-hh-automation-toggle')).catch(() => {});
  return after === before ? 'the checkbox did not change' : null;
}

/**
 * Add skills to the open position form from the skill picker: each skill is typed and the
 * suggestion that is exactly it is chosen. A profile at LinkedIn's 100-skill limit only takes
 * skills already in its Skills section; the others are left for the user
 * @param {Object} page
 * @param {string[]} skills
 * @returns {Promise<{added: string[], missing: string[]}>}
 */
export async function addLinkedInSkills(page, skills) {
  const added = [];
  const missing = [];
  const input = page.locator('input[placeholder^="Skill"], input[placeholder^="Навык"]').first();
  for (const skill of skills) {
    if (!await input.isVisible().catch(() => false)) {
      await page.getByRole('button', { name: /^(Add skill|Добавить навык)$/ }).first().click().catch(() => {});
    }
    if (!await input.isVisible().catch(() => false)) {
      missing.push(skill);
      continue;
    }
    await input.fill(skill);
    await sleep(2000);
    // The skill itself, or LinkedIn's longer name of it: «Rust» is «Rust (Programming Language)»
    const escaped = skill.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    let option = page.getByRole('option', { name: skill, exact: true }).first();
    if (!await option.isVisible().catch(() => false)) {
      option = page.getByRole('option', { name: new RegExp(`^${escaped} \\(`, 'i') }).first();
    }
    const offered = await option.isVisible().catch(() => false);
    const name = offered ? (await option.innerText().catch(() => skill)).trim().split('\n')[0] : skill;
    if (offered) {
      await option.click().catch(() => {});
      await sleep(800);
    }
    // A chosen skill shows as a checked chip; a skill outside the profile's Skills section is not taken
    const chosen = await page.evaluate((label) => [...document.querySelectorAll('input[type="checkbox"]')]
      .some((box) => box.checked && box.labels?.[0]?.innerText.trim().toLowerCase() === label.toLowerCase()), name).catch(() => false);
    if (chosen) {
      added.push(name);
    } else {
      if (await input.isVisible().catch(() => false)) {
        await input.fill('');
      }
      missing.push(skill);
    }
  }
  await page.evaluate(() => document.activeElement?.blur?.()).catch(() => {});
  return { added, missing };
}

/**
 * A media link's title: the link itself as people write it (github.com/deep-foundation). The
 * company name read as another site (Deep.Foundation is also a domain)
 * @param {string} url
 * @returns {string}
 */
export function mediaTitle(url) {
  return url.replace(/^https?:\/\//i, '').replace(/^www\./i, '').replace(/\/+$/, '');
}

/**
 * Add a link to the open position form's Media (e.g. the company website), titled with the link
 * itself. Typed like a person: LinkedIn's form breaks on a pasted link or title. Skipped when the
 * form already has it; an item titled with the company name earlier is renamed instead
 * @param {Object} page
 * @param {{url: string, oldTitle?: string}} link - oldTitle: the company name earlier items took
 * @returns {Promise<{added: boolean, problem: string, broken?: boolean, title: string}>} problem:
 *   '' when added or already there; broken: the form broke and has to be opened again
 */
export async function addLinkedInMedia(page, { url, oldTitle = '' }) {
  const title = mediaTitle(url);
  // Only the form's Media list counts: the company name is also elsewhere in the form
  const mediaList = page.locator('[data-testid$="position-mediaUiCollection"]').first();
  const titled = async (name) => (await mediaList.innerText().catch(() => '')).split('\n')
    .some((line) => line.trim().toLowerCase() === name.toLowerCase());
  const titleInput = page.getByLabel(/^(Title|Название)\*?$/).first();
  const typeTitle = async () => {
    await sleep(1000);
    await titleInput.click();
    await page.keyboard.press(process.platform === 'darwin' ? 'Meta+A' : 'Control+A');
    await page.keyboard.type(title, { delay: 30 });
    await sleep(1500);
    await page.getByRole('button', { name: /^(Save|Сохранить)$/ }).last().click();
    await sleep(3000);
  };
  if (await titled(title)) {
    return { added: false, problem: '', title };
  }
  if (oldTitle && await titled(oldTitle)) {
    // Its edit link is labelled «Edit media, <title>»
    await mediaList.locator('a').filter({ hasText: `, ${oldTitle}` }).first().click();
    if (!await titleInput.waitFor({ timeout: 10000 }).then(() => true, () => false)) {
      return { added: false, problem: `the media item «${oldTitle}» did not open to be renamed to ${title}`, title };
    }
    await typeTitle();
    const renamed = await titled(title);
    return { added: renamed, problem: renamed ? '' : `the media item «${oldTitle}» was not renamed to ${title}`, title };
  }
  const linkItem = page.getByRole('menuitem', { name: /^(Add a link|Добавить ссылку)$/ });
  for (let attempt = 0; attempt < 5 && !await linkItem.isVisible().catch(() => false); attempt++) {
    await page.getByRole('button', { name: /^(Add media|Добавить медиа\p{L}*)$/u }).first().click().catch(() => {});
    await sleep(1500);
  }
  if (!await linkItem.isVisible().catch(() => false)) {
    return { added: false, problem: 'no «Add media» → «Add a link» in the form', title };
  }
  await linkItem.click();
  // Paced like a person: LinkedIn's form broke on back-to-back clicks
  await sleep(1500);
  const input = page.locator('input[aria-label^="Paste or type a link"], input[aria-label*="ссылк"]').first();
  // LinkedIn's preview of a link fails now and then: it is tried again; a site's root also with «/»
  // (https://kaiten.ru/), a page only as written (https://github.com/deep-foundation)
  const root = /^https?:\/\/[^/]+\/?$/.test(url);
  const withSlash = root && !url.endsWith('/') ? `${url}/` : url;
  for (const link of [url, withSlash, url, withSlash]) {
    await input.fill('');
    await input.pressSequentially(link, { delay: 30 });
    await sleep(800);
    await page.getByRole('button', { name: /^(Add|Добавить)$/ }).first().click();
    if (await titleInput.waitFor({ timeout: 20000 }).then(() => true, () => false)) {
      break;
    }
  }
  if (!await titleInput.isVisible().catch(() => false)) {
    // «Add media» is a step of the position form: its ✕ discards the whole form and its Back works
    // only with a preview, so the window is left for the user
    return { added: false, problem: `LinkedIn could not preview ${url}: the «Add media» window is left open, use Try again or another link, then Back or Save`, title };
  }
  await typeTitle();
  // LinkedIn's form now and then breaks on saving a link («Something went wrong on our end»)
  if (await page.getByText(/Something went wrong|Что-то пошло не так/).first().isVisible().catch(() => false)) {
    return { added: false, broken: true, problem: `LinkedIn's form broke on adding ${url}`, title };
  }
  const added = await titled(title);
  return { added, problem: added ? '' : `the link ${url} did not show in Media`, title };
}

/**
 * Close the suggestion list a typed field opened, the way a person does: the suggestion that is
 * exactly the typed value is chosen, else the form's heading is clicked; no field is left focused
 * @param {Object} page
 * @param {string} [value] - The value just typed
 */
export async function closeSuggestions(page, value) {
  const listbox = page.locator('[role="listbox"]:visible').first();
  if (value && await listbox.isVisible().catch(() => false)) {
    const option = listbox.getByRole('option', { name: String(value), exact: true }).first();
    if (await option.isVisible().catch(() => false)) {
      await option.click().catch(() => {});
    }
  }
  if (await listbox.isVisible().catch(() => false)) {
    await page.locator('h2:visible').first().click().catch(() => {});
  }
  await page.evaluate(() => document.activeElement?.blur?.()).catch(() => {});
}

/**
 * Open LinkedIn's position form (the position's edit form, or a new one) and prefill it.
 * Skills are picked from the profile's skills, and the company website is added as a media link
 * @param {Object} page
 * @param {Object} change - Of planSync
 * @param {Object} [options]
 * @param {string} [options.profileUrl=LINKEDIN_PROFILE]
 * @returns {Promise<string[]>} Notes: fields that could not be set
 */
export async function prefillLinkedInPosition(page, change, { profileUrl = LINKEDIN_PROFILE, port = 9350 } = {}) {
  const url = change.target?.editUrl ?? `${profileUrl.replace(/\/+$/, '')}/add-edit/POSITION/`;
  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
  await waitForLinkedInLogin(page, { url, port });
  await page.waitForSelector('dialog[open] input, [role="dialog"] input, form input, input[placeholder="Role title"]', { timeout: 30000 }).catch(() => {});
  await sleep(1500);
  const notes = [];
  // Saving a change is not news for the network: «Notify network» is switched off
  const notifyOff = await page.evaluate(() => {
    const toggle = [...document.querySelectorAll('[role="switch"]')].find((element) => /notify your network|уведом/i.test(element.getAttribute('aria-label') ?? element.parentElement?.innerText ?? ''));
    if (toggle?.getAttribute('aria-checked') === 'true') {
      toggle.click();
      return true;
    }
    return false;
  }).catch(() => false);
  if (notifyOff) {
    notes.push('LinkedIn: «Notify network» switched off');
  }
  for (const field of fieldsOfLinkedIn(change.fields)) {
    let problem = await page.evaluate(setFieldByLabel, field).catch((error) => error.message.split('\n')[0]);
    if (problem === 'toggle') {
      problem = await toggleMarked(page);
    }
    if (problem) {
      notes.push(`LinkedIn: ${problem}`);
    }
    // Unchecking «currently working» shows the end date fields
    if (field.kind === 'checkbox') {
      await sleep(700);
    }
    // A typed title, company or place opens LinkedIn's suggestions
    if (field.kind === 'text' && !problem) {
      await sleep(800);
      await closeSuggestions(page, field.value);
    }
  }
  await closeSuggestions(page);
  // Whether anything in the form changed: a change of only skills the profile lacks changes nothing
  let changed = fieldsOfLinkedIn(change.fields).length > 0;
  if (change.fields.skills?.length) {
    const { added, missing } = await addLinkedInSkills(page, change.fields.skills);
    changed ||= added.length > 0;
    if (added.length) {
      notes.push(`LinkedIn: skills added: ${added.join(', ')}`);
    }
    if (missing.length) {
      notes.push(`LinkedIn: not among the profile's skills (LinkedIn allows 100), add them yourself if needed: ${missing.join(', ')}`);
    }
  }
  if (change.fields.website) {
    const oldTitle = change.target?.company ?? change.fields.company ?? change.source?.company ?? '';
    const { added, problem, broken, title } = await addLinkedInMedia(page, { url: change.fields.website, oldTitle });
    if (broken) {
      // Prefilled again from the start, without the link
      const { website, ...fields } = change.fields;
      const again = await prefillLinkedInPosition(page, { ...change, fields }, { profileUrl, port });
      change.unchanged = false;
      return [...again, `LinkedIn: ${problem}, so the form was prefilled again without it: add ${website} yourself in Media if you want it`];
    }
    changed ||= added;
    if (problem || added) {
      notes.push(problem ? `LinkedIn: ${problem}` : `LinkedIn: media link ${change.fields.website} («${title}»)`);
    }
  }
  change.unchanged = !changed;
  return notes;
}

/** Fields each site's form takes from a change; the rest (e.g. hh.ru per-job skills) are notes */
const FILLABLE = {
  linkedin: ['title', 'company', 'location', 'description', 'start', 'end', 'current', 'skills'],
  hh: ['title', 'company', 'description', 'start', 'end', 'current'],
};

/**
 * Whether a change sets anything in the target site's form (else it is only notes for the user)
 * @param {Object} change - Of planSync
 * @param {'linkedin'|'hh'} site
 * @returns {boolean}
 */
export const hasFillableFields = (change, site) => Object.keys(change.fields).some((field) => FILLABLE[site].includes(field));

/**
 * Save LinkedIn's open position form (only after the user's `y`), then wait for the dialog to close
 * @param {Object} page
 */
export async function saveLinkedInPosition(page) {
  const form = page.locator('dialog[open], [role="dialog"]').filter({ has: page.locator('input[placeholder="Role title"], input') }).first();
  const saveBtn = form.getByRole('button', { name: /^(Save|Сохранить)$/ }).last();
  await saveBtn.waitFor({ state: 'visible', timeout: 10000 });
  await saveBtn.click();
  // A saved position shows «Your experience is saved» (then people to connect with)
  await page.waitForFunction(() => /\/edit\/forms\/next-action\//.test(window.location.href) || /Your experience is saved|Опыт работы сохран/i.test(document.body.innerText), null, { timeout: 15000 }).catch(() => {});
  await closeLinkedInFollowUp(page);
}

/**
 * Notice the user's Save of the position form in the browser: an edited position closes without
 * «Your experience is saved», so the click itself is what tells saved from closed. Only the form's
 * own Save counts (its dialog has the «Notify network» switch), not the Save of a media step
 */
export async function watchLinkedInSave(page) {
  await page.evaluate(() => {
    window.__positionSaveClicked = false;
    if (!window.__positionSaveWatch) {
      window.__positionSaveWatch = true;
      document.addEventListener('click', (event) => {
        const button = event.target.closest?.('button');
        const dialog = button?.closest('dialog, [role="dialog"]');
        if (button && dialog?.querySelector('[role="switch"]') && /^(Save|Сохранить)$/.test(button.innerText.trim())) {
          window.__positionSaveClicked = true;
        }
      }, true);
    }
  }).catch(() => {});
}

/**
 * What became of the position form in the browser: 'saved', 'closed', 'broken' (LinkedIn's
 * «Something went wrong», nothing saved) or null (still open)
 */
export async function linkedInFormOutcome(page) {
  const state = await page.evaluate(() => ({
    broken: /Something went wrong on our end|Что-то пошло не так/i.test(document.querySelector('dialog[open]')?.innerText ?? ''),
    saved: /\/edit\/forms\/next-action\//.test(window.location.href) || /Your experience is saved|Опыт работы сохран/i.test(document.body?.innerText ?? '')
      || (window.__positionSaveClicked === true && !document.querySelector('dialog[open] [role="switch"]')),
    open: /\/edit\/forms\//.test(window.location.href) || /\/add-edit\//.test(window.location.href),
  })).catch(() => null);
  if (!state) {
    return null;
  }
  // A form that broke on Save saved nothing
  return state.broken ? 'broken' : state.saved ? 'saved' : state.open ? null : 'closed';
}

/**
 * Close LinkedIn's «Your experience is saved / connect with people you may know» window with
 * Skip: nobody is invited
 */
export async function closeLinkedInFollowUp(page) {
  const skip = page.getByRole('button', { name: /^(Skip|Пропустить)$/ }).first();
  if (await skip.isVisible().catch(() => false)) {
    await skip.click().catch(() => {});
    await sleep(1500);
  }
  const dismiss = page.locator('button[aria-label="Dismiss"], button[aria-label="Закрыть"]').first();
  if (/\/edit\/forms\/next-action\//.test(page.url()) && await dismiss.isVisible().catch(() => false)) {
    await dismiss.click().catch(() => {});
  }
}

const HH = {
  experienceCard: '[data-qa="profile-experience-company-card"]',
  editButton: '[data-qa^="edit-experience-button-"]',
  // The resume page without edit buttons on its cards: «Редактировать» opens the list of jobs,
  // where a card opens its form
  viewAll: '[data-qa="profile-experience-viewAll"]',
  company: 'input[name="company"]',
  position: 'input[name="position"]',
  startYear: '[data-qa="resume-editor-experience-start-year-input"]',
  endYear: '[data-qa="resume-editor-experience-end-year-input"]',
  present: '[data-qa="resume-editor-experience-present-checkbox"]',
  description: '[data-qa="resume-editor-experience-description-input"]',
  monthSelect: '[data-qa="magritte-select-activator"]',
  save: '[data-qa="profile-layout-save-button"]',
  cancel: '[data-qa="profile-layout-cancel-button"]',
  /** Followed by a resume's hash */
  resumeCheckbox: 'profile-resumes-list-checkbox-',
};

/**
 * Runs in the page: click the edit button of the hh.ru experience card of a company and title
 * (cards hold "company / duration / title / period"), after expanding the list; a card without
 * one opens its form itself
 * @param {{company: string, title: string, editButton: string, card: string}} target
 * @returns {boolean}
 */
export function clickHhExperienceEdit({ company, title, description = '', editButton, card, markOnly = false }) {
  const norm = (text) => String(text).toLowerCase().replace(/\s+/g, ' ').trim();
  const pick = (element) => {
    if (markOnly) {
      document.querySelectorAll('[data-hh-experience-edit-target]').forEach((previous) => previous.removeAttribute('data-hh-experience-edit-target'));
      element.setAttribute('data-hh-experience-edit-target', 'true');
    } else element.click();
  };
  const controls = [...new Set([...document.querySelectorAll(`${editButton}, main button, main a`)])]
    .filter((element) => element.matches(editButton) || /^(edit|редактировать)$/i.test(element.innerText.trim()));
  const matches = controls.filter((button) => {
    // A company card can group several positions: the company name is shared, but the
    // description and Edit control must belong to the same individual position.
    const companyCard = button.closest(card);
    const companyMatches = companyCard && norm(companyCard.innerText).includes(norm(company));
    for (let element = button.parentElement; element && element !== document.body; element = element.parentElement) {
      // Never borrow the first button of an ancestor containing neighbouring workplaces.
      if (controls.filter((control) => element.contains(control)).length > 1) {
        return false;
      }
      const text = norm(element.innerText);
      if ((companyMatches || text.includes(norm(company))) && (!title || text.includes(norm(title))) && (!description || text.includes(norm(description)))) {
        return true;
      }
    }
    return false;
  });
  if (matches.length === 1) {
    pick(matches[0]);
    return true;
  }
  if (controls.length > 0) {
    return false;
  }
  const cards = [...document.querySelectorAll(card)].filter((element) => element.matches('a[href]') &&
    norm(element.innerText).includes(norm(company)) && (!description || norm(element.innerText).includes(norm(description))));
  if (cards.length === 1) {
    pick(cards[0]);
    return true;
  }
  return false;
}

/**
 * Open hh.ru's form for a job of the resume: the edit form of a company's job (with its title, when
 * given), or a new one when no company is given
 * @param {Object} page
 * @param {Object} options
 * @param {string} options.resumeHash
 * @param {{company: string, title?: string}|null} options.job - null opens a new job's form
 * @param {number} [options.port=9351] - The slot's port, which a captcha alert brings forward
 * @returns {Promise<string[]>} Notes: what went wrong; empty when the form is open
 */
export async function openHhExperienceForm(page, { resumeHash, job, port = 9351 }) {
  if (await hhCvFormOpen(page)) {
    return ['hh.ru: an experience form is open; finish or close it before another edit'];
  }
  if (job?.entryId && !/^\d+$/.test(String(job.entryId))) {
    return ['hh.ru: invalid workplace record ID'];
  }
  const url = job?.entryId
    ? `https://hh.ru/profile/edit/experience/${job.entryId}?resumeFrom=${encodeURIComponent(resumeHash)}&hhtmFrom=resume`
    : `https://hh.ru/profile/edit/experience?resumeFrom=${encodeURIComponent(resumeHash)}&hhtmFrom=resume`;
  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
  // While hh.ru shows a captcha nothing is touched: the user solves it in the slot
  if (!await waitForCaptcha(page, console.log, 'slot', port)) {
    return ['hh.ru: the captcha was not solved, nothing prefilled'];
  }
  if (job?.entryId) {
    return page.waitForSelector(HH.position, { timeout: 30000 }).then(() => [], () => ['hh.ru: the requested workplace form did not open']);
  }
  if (!job) {
    // The resume page also has Add controls for other sections. Only use the workplace
    // list's Add new button, even when the resume has inline workplace Edit controls.
    const add = page.locator('main [data-qa="list-add"]:visible').filter({ hasText: /^(add|добавить)/i });
    if (!await add.first().waitFor({ timeout: 15000 }).then(() => true, () => false) || await add.count() !== 1) {
      return ['hh.ru: the workplace list has no unique Add new button'];
    }
    await add.click();
    return page.waitForSelector(HH.position, { timeout: 30000 }).then(() => [], () => ['hh.ru: the new workplace form did not open']);
  }
  // Resume summaries can hide older jobs and omit the View all control entirely.
  // The full workplace list exposes each language copy; identity is verified again in the form.
  await page.waitForSelector(`${HH.experienceCard}, [data-qa="position-title"]`, { timeout: 30000 }).catch(() => {});
  const found = await page.evaluate(clickHhExperienceEdit, {
    company: job.company, title: job.title ?? '', description: job.description ?? '', editButton: HH.editButton, card: HH.experienceCard, markOnly: true,
  });
  if (!found) {
    return [`hh.ru: no unique workplace record of ${job.company} found in the experience list`];
  }
  await page.waitForFunction(() => {
    const edit = document.querySelector('[data-hh-experience-edit-target="true"]');
    if (!edit) return false;
    return edit.matches('a[href]') || typeof edit.onclick === 'function' || Object.keys(edit).some((key) =>
      key.startsWith('__reactProps$') && typeof edit[key]?.onClick === 'function');
  }, null, { timeout: 20000 });
  await page.locator('[data-hh-experience-edit-target="true"]').click();
  return page.waitForSelector(HH.position, { timeout: 30000 }).then(() => sleep(1000).then(() => []), () => ['hh.ru: the experience form did not open']);
}

/**
 * Open hh.ru's form for a job of the resume (its edit form, or a new one) and prefill it
 * @param {Object} page
 * @param {Object} change - Of planSync
 * @param {Object} options
 * @param {string} options.resumeHash
 * @param {number} [options.port=9351] - The slot's port, which a captcha alert brings forward
 * @returns {Promise<string[]>} Notes: fields that could not be set
 */
export async function prefillHhExperience(page, change, { resumeHash, port = 9351 }) {
  const { prepareHhCvChange } = await import('./hh-cv-editor.mjs');
  return (await prepareHhCvChange(page, change, { resumeHash, port })).notes;
}

/** Fill an already open form. Opening, copying, selecting resumes and saving stay separate. */
export async function fillHhExperience(page, fields, { notes = [] } = {}) {
  if (!await hhExperienceFormOpen(page)) {
    throw new Error('hh.ru: no experience form is open');
  }
  const fill = async (selector, value) => {
    const field = page.locator(selector).first();
    if (await field.count() === 0) {
      notes.push(`hh.ru: no field ${selector}`);
      return;
    }
    await field.fill(String(value));
  };
  if ('company' in fields) {
    await fill(HH.company, fields.company);
  }
  if (fields.title) {
    await fill(HH.position, fields.title);
  }
  if ('description' in fields) {
    await fill(HH.description, fields.description);
  }
  if (fields.start) {
    await fill(HH.startYear, fields.start.slice(0, 4));
    await chooseHhMonth(page, 0, fields.start, notes);
  }
  if ('current' in fields) {
    const present = page.locator(HH.present).first();
    if (await present.count() > 0 && await present.isChecked() !== Boolean(fields.current)) {
      await present.click({ force: true });
    }
  }
  if (fields.end && !fields.current) {
    await fill(HH.endYear, fields.end.slice(0, 4));
    await chooseHhMonth(page, 1, fields.end, notes);
  }
  if (fields.skills?.length) {
    notes.push(`hh.ru: skills are kept for the whole resume («Навыки»), check that it has: ${fields.skills.join(', ')}`);
  }
  return notes;
}

/** Choose the month of hh.ru's start (0) or end (1) date in its custom select */
export async function chooseHhMonth(page, index, date, notes) {
  if (!date.includes('-')) {
    return;
  }
  // An English page can still offer Russian months. HH.ru also replaces the trigger with a
  // searchable input while it is focused, including after Escape closed its option list.
  const language = pageLanguage(await page.evaluate(() => document.documentElement.lang).catch(() => ''));
  const names = [...new Set([language, 'ru', 'en'].map((lang) => formatMonthYear(date, lang).split(' ')[0]))];
  const field = page.locator(`[data-qa="resume-editor-experience-${index === 0 ? 'start' : 'end'}-month-input"]`).first();
  const scoped = await field.count() > 0;
  const trigger = scoped ? field.locator(`${HH.monthSelect}:visible`).first()
    : page.locator(`${HH.monthSelect}:visible`).filter({ hasText: /^\s*(Месяц|Month)/ }).nth(index);
  const value = scoped ? field.locator('[data-qa="trigger-values-wrapper"]').first() : trigger.locator('[data-qa="trigger-values-wrapper"]');
  const current = await value.textContent({ timeout: 1000 }).catch(() => '');
  if (names.some((name) => current?.trim().toLowerCase() === name.toLowerCase())) {
    return;
  }
  const input = scoped ? field.locator('input[role="combobox"]:visible').first() : null;
  if (!input || await input.count() === 0) {
    if (await trigger.count() === 0) {
      notes.push(`hh.ru: set the ${index === 0 ? 'start' : 'end'} month (${names[0]}) yourself`);
      return;
    }
    await trigger.click();
  }
  if (input && await input.count() > 0) {
    await input.fill('');
    await input.press('ArrowDown');
  }
  const option = page.getByRole('option', { name: new RegExp(`^(?:${names.join('|')})$`, 'iu') }).first();
  if (await option.waitFor({ timeout: 5000 }).then(() => true, () => false)) {
    await option.click();
  } else {
    await page.keyboard.press('Escape');
    notes.push(`hh.ru: set the ${index === 0 ? 'start' : 'end'} month (${names[0]}) yourself`);
  }
}

/** The description in hh.ru's open experience form; null when it is not open */
export const hhExperienceDescription = (page) => page.locator(HH.description).first().inputValue({ timeout: 1000 }).catch(() => null);

/** Whether hh.ru's experience form is open in the page */
export const hhExperienceFormOpen = (page) => page.locator(HH.position).count().then((count) => count > 0, () => false);

/** Any owner-reviewed CV draft, including the inline About editor. */
export const hhCvFormOpen = (page) => page.locator(`${HH.position}, textarea[data-qa="resume-editor-about"]`).count().then((count) => count > 0, () => false);

/**
 * The resumes of the profile that show the job of hh.ru's open experience form (its checkboxes):
 * hh.ru keeps jobs for the whole profile, each resume picks the ones it shows
 * @param {Object} page
 * @returns {Promise<Array<{hash: string, checked: boolean}>>}
 */
export const hhExperienceResumes = (page) => page.evaluate((prefix) => [...document.querySelectorAll(`[data-qa^="${prefix}"]`)].map((element) => {
  const input = element.matches('input') ? element : element.querySelector('input[type="checkbox"]');
  return { hash: element.getAttribute('data-qa').slice(prefix.length), checked: Boolean(input?.checked ?? element.getAttribute('aria-checked') === 'true') };
}), HH.resumeCheckbox).catch(() => []);

/**
 * Show the job of hh.ru's open experience form in these resumes only
 * @param {Object} page
 * @param {string[]} hashes
 */
export async function setHhExperienceResumes(page, hashes) {
  const available = await hhExperienceResumes(page);
  if (available.length === 0 || hashes.some((hash) => !available.some((resume) => resume.hash === hash))) {
    throw new Error('hh.ru: requested resume selection is unavailable');
  }
  for (const { hash, checked } of available) {
    if (checked !== hashes.includes(hash)) {
      await page.locator(`[data-qa="${HH.resumeCheckbox}${hash}"]`).first().click({ force: true });
    }
  }
  const selected = (await hhExperienceResumes(page)).filter((resume) => resume.checked).map((resume) => resume.hash).sort();
  if (JSON.stringify(selected) !== JSON.stringify([...hashes].sort())) {
    throw new Error('hh.ru: resume selection did not match the requested checkboxes');
  }
}

/**
 * Save hh.ru's open experience form (only after the user's `y`), then wait for it to close
 * @param {Object} page
 */
export async function saveHhExperience(page) {
  const saveBtn = page.locator(HH.save).first();
  await saveBtn.waitFor({ state: 'visible', timeout: 10000 });
  await saveBtn.click();
  // Wait for the form to close: the position input disappears after a successful save
  await page.waitForSelector(HH.position, { state: 'detached', timeout: 15000 }).catch(() => {});
}

/**
 * Leave hh.ru's experience form without saving: «Отменить», then «Не надо» in hh.ru's
 * «Сохранить изменения?» question
 * @param {Object} page
 */
export async function discardHhExperience(page) {
  // The caller explicitly chose to discard this draft. HH.ru can use beforeunload instead
  // of a page dialog; dismissing that browser prompt would leave the form open.
  const onDialog = (dialog) => dialog.type() === 'beforeunload' ? dialog.accept() : dialog.dismiss();
  page.on('dialog', onDialog);
  try {
    const discard = page.getByRole('button', { name: /^(не надо|don['’]?t(?: save)?|discard)$/i });
    if (!await discard.isVisible()) await page.locator(HH.cancel).first().click();
    if (await discard.waitFor({ timeout: 1500 }).then(() => true, () => false)) {
      await discard.click();
    }
    await page.locator(HH.position).waitFor({ state: 'detached', timeout: 15000 });
  } finally {
    page.off('dialog', onDialog);
  }
}

/**
 * Close LinkedIn's position form without saving (Escape, then "Discard" when it asks)
 * @param {Object} page
 */
export async function discardLinkedInPosition(page) {
  await page.keyboard.press('Escape').catch(() => {});
  // The form opened as its own page does not close on Escape: its close button does
  const close = page.locator('button[aria-label="Dismiss"], button[aria-label="Закрыть"]').first();
  if (await close.isVisible().catch(() => false)) {
    await close.click().catch(() => {});
  }
  const discard = page.locator('button:has-text("Discard"), button:has-text("Отменить изменения")').first();
  if (await discard.waitFor({ timeout: 3000 }).then(() => true, () => false)) {
    await discard.click();
  }
}

/**
 * Prefill the technology list of a job in hh.ru's edit form (withStack): the rest of its
 * description is kept as the form has it
 * @param {Object} page
 * @param {Object} options
 * @param {string} options.resumeHash
 * @param {{company: string, title?: string}} options.job
 * @param {string} options.stack - Comma-separated
 * @param {boolean} [options.add=false] - Append to the job's list instead of replacing it
 * @param {number} [options.port=9351]
 * @returns {Promise<{notes: string[], before: string|null, after: string|null}>}
 */
export async function prefillHhStack(page, { resumeHash, job, stack, add = false, port = 9351 }) {
  const { prepareHhCvChange } = await import('./hh-cv-editor.mjs');
  const result = await prepareHhCvChange(page, { kind: 'update', target: job, fields: { stack, addStack: add } }, { resumeHash, port });
  return { notes: result.notes, before: result.before.description, after: result.draft.description };
}
