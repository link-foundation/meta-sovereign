async (page) => { const session = await page.context().newCDPSession(page); await session.send('Network.enable'); await session.send('Network.setCacheDisabled', {cacheDisabled: true}); try { return await (async (page) => (async (page, fixture, check) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      language
    );
    await page.goto(`${fixture.base}/?vkLocale=${language}#conn-vk/manual`);
    const panel = page.locator(`[data-${fixture.feature}]`);
    const ready = () =>
      page.waitForFunction((feature) => {
        const input = document.querySelector(
          `[data-${feature}] input[type=checkbox]`
        );
        return input && !input.disabled;
      }, fixture.feature);
    // A mounted heading and an enabled control distinguish loading from absence.
    await panel
      .getByRole('heading', { name: words.title, exact: true })
      .waitFor();
    await ready();
    for (const key of fixture.keys) {
      if (!(await panel.innerText()).includes(words[key])) {
        throw Error(`Missing ${language}.${key}`);
      }
    }
    const { focus, ...checked } = await check(page, {
      panel,
      words,
      ready,
      feature: fixture.feature,
      action: async (name) => {
        await panel.locator(`[data-action=${fixture.feature}-${name}]`).click();
        await ready();
      },
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await panel.locator(focus).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-${fixture.evidenceName}/mcp-${language}-phone.png`,
    });
    result.push({ language, translated: true, ...checked });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:34669","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","feature":"vk-suggestions","evidenceName":"vk-discovery","keys":["hint","scanLimit","maxFriends","run"],"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"VK best suggestions","hint":"Scheduling starts off. Rank the reviewed suggestions by mutual friends, with stable ID ties. Only current accessible accounts with posting, viewing, messaging and friend-request permission qualify. New discovery requests share a durable allowance of 40 attempts per UTC day. Unknown outcomes never replay.","scanLimit":"Maximum profiles to inspect","maxFriends":"Friend capacity (0 holds requests)","run":"Confirm reviewed relationship actions"},"ru":{"title":"Лучшие рекомендации друзей ВКонтакте","hint":"Расписание выключено. Рекомендации сортируются по общим друзьям, затем по ID. Нужны доступный аккаунт и разрешения публиковать, просматривать, писать и отправлять заявку. Новые заявки этих политик используют общий сохраняемый лимит 40 попыток за сутки UTC. Неизвестный результат не повторяется.","scanLimit":"Максимум проверяемых профилей","maxFriends":"Предел друзей (0 запрещает заявки)","run":"Подтвердить проверенные действия с заявками"},"hi":{"title":"VK के श्रेष्ठ मित्र सुझाव","hint":"शेड्यूल बंद है। समीक्षित सुझाव साझा मित्रों की संख्या, फिर ID के क्रम में हैं। केवल सुलभ खाते और पोस्ट, देखने, संदेश तथा मित्र अनुरोध की मौजूदा अनुमति मान्य हैं। इन खोज नीतियों में नए अनुरोधों की साझा स्थायी सीमा प्रति UTC दिन 40 प्रयास है। अज्ञात परिणाम दोहराए नहीं जाते।","scanLimit":"जाँचने के लिए अधिकतम प्रोफ़ाइल","maxFriends":"मित्र सीमा (0 से अनुरोध रुकते हैं)","run":"समीक्षित मित्रता कार्रवाइयाँ पुष्ट करें"},"zh":{"title":"VK 最佳好友建议","hint":"自动计划默认关闭。按共同好友数量排序审核的建议，数量相同时按 ID 排序。账号须可访问，且当前允许发帖、查看、私信及好友请求。这些发现策略共享持久配额：每个 UTC 日最多尝试 40 次新请求。结果未知时绝不重试。","scanLimit":"最多检查的资料数","maxFriends":"好友容量（0 暂缓请求）","run":"确认已审核的好友关系操作"}}}, (async (page, { panel, ready, action }) => {
  await action('plan');
  if (
    !(await panel.locator('[data-vk-suggestions-status=confirmed]').count())
  ) {
    if (
      (await panel
        .locator('[data-suggestions-id="11"][data-suggestions-reason=eligible]')
        .count()) !== 1
    ) {
      throw Error('Best mutually ranked suggestion is missing');
    }
    await action('run');
  }
  for (const kind of ['community', 'rejections']) {
    const section = page.locator(`[data-vk-${kind}]`);
    if (await section.locator(`[data-action=vk-${kind}-enabled]`).isChecked()) {
      throw Error('Independent discovery scheduling unexpectedly enabled');
    }
    await section.locator(`[data-action=vk-${kind}-plan]`).click();
    await section
      .locator(`[data-action=vk-${kind}-enabled]`)
      .waitFor({ state: 'attached' });
    await section.locator('[data-discovery-summary]').waitFor();
  }
  await page.reload();
  await ready();
  await action('plan');
  if (
    (await panel.locator('[data-vk-suggestions-status=confirmed]').count()) !==
      1 ||
    (await panel
      .locator('[data-suggestions-id="11"][data-suggestions-reason=eligible]')
      .count())
  ) {
    throw Error('Confirmed suggestion was not retained after reload');
  }
  return {
    focus: '[data-vk-suggestions-plan]',
    rankedSuggestion: 11,
    noReplay: true,
    independentPolicies: 3,
  };
})))(page); } finally { await session.detach(); } }