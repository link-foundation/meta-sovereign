"""Replay the real stale channel and TCP-end regressions on published sources."""
import os
from pathlib import Path
import subprocess
from parent_replay import replay_parent

parent = 'd4c7fb8122d3e708e584749a25a8ed5d63449bc0'
root = Path(__file__).resolve().parents[2]
paths = ['js/src/web/app.min.js', 'js/src/sync/webrtc-signaling.js',
         'js/src/sync/bun-server.js']
saved = {name: (root / name).read_bytes() for name in paths}
try:
    for name in paths:
        (root / name).write_bytes(subprocess.check_output(
            ['git', 'show', f'{parent}:{name}'], cwd=root))
    env = dict(os.environ, NODE_OPTIONS='--max-old-space-size=384',
               RUN_BROWSER_E2E='1', E2E_BROWSER='webkit', CI_LINO_SYNC_DEBUG='1')
    with (root / 'ci-logs/rtc-lifecycle-connected-before.log').open('w') as log:
        result = subprocess.run(['node', 'js/tests/e2e-lino-sync.mjs'],
            cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    assert result.returncode == 1
    assert 'timed out: reconnected WebRTC deletion' in (
        root / 'ci-logs/rtc-lifecycle-connected-before.log').read_text()
    print('connected peer: expected actual-parent stale-channel failure', flush=True)
finally:
    for name, content in saved.items():
        (root / name).write_bytes(content)
replay_parent(__file__, 'rtc-lifecycle', parent, [
    ('tcp-end', 'js/src/sync/ws-transport.js', ['node', '--test',
     '--test-concurrency=1', '--test-timeout=5000',
     '--test-name-pattern=a disconnected socket leaves', 'js/tests/sync-ws.test.js']),
])
