import { createWebRtcTransport, signalingChannel } from './webrtc-transport.js';

const peerIdentity = (id) =>
  typeof id === 'string' && /^[a-zA-Z\d-]{1,100}$/u.test(id);

/** A fresh signaling identity owns a fresh PC; unrelated live peers survive. */
export const createWebRtcMesh = ({
  signaling,
  connect,
  makeTransport = createWebRtcTransport,
  onError = (error) =>
    globalThis.console?.warn?.('WebRTC negotiation failed', error),
  trace = () => {},
  ...options
}) => {
  const peers = new Map();
  let nextConnection = 0;
  let closed = false;
  const remove = (id) => {
    const entry = peers.get(id);
    if (!entry) {
      return;
    }
    peers.delete(id);
    entry.detach();
    entry.transport.close();
    trace('peer-left', { peers: peers.size });
  };
  const ensure = (id) => {
    if (!peers.has(id)) {
      const listeners = new Set();
      const scoped = signalingChannel({
        send: (message) => signaling.raw.send({ ...message, to: id }),
        onMessage(handler) {
          listeners.add(handler);
          return () => listeners.delete(handler);
        },
      });
      const transport = makeTransport({
        ...options,
        onError,
        signaling: scoped,
        trace: (
          (connection) => (event, fields) =>
            trace(event, { connection, ...fields })
        )(++nextConnection),
      });
      peers.set(id, { transport, listeners, detach: connect(transport) });
      trace('peer-created', { peers: peers.size });
    }
    return peers.get(id);
  };
  const off = signaling.on('*', (message) => {
    if (closed) {
      return;
    }
    if (message.type === 'peer-left' && peerIdentity(message.peerId)) {
      remove(message.peerId);
    } else if (message.type === 'peer-joined' && peerIdentity(message.peerId)) {
      ensure(message.peerId).transport.startAsInitiator().catch(onError);
    } else if (
      peerIdentity(message.from) &&
      ['offer', 'answer', 'ice'].includes(message.type)
    ) {
      const entry =
        message.type === 'offer'
          ? ensure(message.from)
          : peers.get(message.from);
      for (const handler of entry?.listeners ?? []) {
        handler(message);
      }
    }
  });
  return {
    peers,
    close() {
      if (closed) {
        return;
      }
      closed = true;
      off();
      for (const id of peers.keys()) {
        remove(id);
      }
    },
  };
};
