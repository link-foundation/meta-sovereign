/** Broker-owned identities route negotiation to exactly one current socket. */
export const createSignalingRooms = (send) => {
  const rooms = new Map();
  const relayTypes = new Set(['offer', 'answer', 'ice']);
  return {
    rooms,
    join(room, socket) {
      if (!rooms.has(room)) {
        rooms.set(room, new Map());
      }
      const peers = rooms.get(room);
      const peerId = globalThis.crypto.randomUUID();
      peers.set(socket, peerId);
      for (const other of peers.keys()) {
        if (other !== socket) {
          send(other, { type: 'peer-joined', peerId });
        }
      }
    },
    leave(room, socket) {
      const peers = rooms.get(room);
      const peerId = peers?.get(socket);
      if (!peerId) {
        return;
      }
      peers.delete(socket);
      if (!peers.size) {
        rooms.delete(room);
        return;
      }
      for (const other of peers.keys()) {
        send(other, { type: 'peer-left', peerId });
      }
    },
    relay(room, socket, event) {
      const peers = rooms.get(room);
      const from = peers?.get(socket);
      if (
        !from ||
        !relayTypes.has(event?.type) ||
        (event.to === undefined && event.from !== undefined)
      ) {
        return;
      }
      for (const [other, peerId] of peers) {
        if (
          other !== socket &&
          (event.to === undefined || event.to === peerId)
        ) {
          // Unaddressed legacy frames retain their exact shape. Addressed
          // frames always get their actual sender from this connection.
          send(other, event.to === undefined ? event : { ...event, from });
        }
      }
    },
  };
};
