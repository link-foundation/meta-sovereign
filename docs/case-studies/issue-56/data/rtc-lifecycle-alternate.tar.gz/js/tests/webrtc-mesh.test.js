import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createSignalingRooms } from '../src/sync/signaling-rooms.js';
import { createWebRtcMesh } from '../src/sync/webrtc-mesh.js';
import { signalingChannel } from '../src/sync/webrtc-transport.js';

test('broker assigns connection identities and announces one departure without removing survivors', () => {
  const sent = [];
  const broker = createSignalingRooms((socket, event) =>
    sent.push({ socket, event })
  );
  broker.join('room', 'a');
  broker.join('room', 'b');
  broker.join('room', 'c');
  const id = broker.rooms.get('room').get('b');
  assert.equal(sent.length, 3);
  assert.equal(sent[0].event.peerId, id);
  assert.equal(sent[0].socket, 'a');
  broker.leave('room', 'b');
  broker.leave('room', 'b');
  assert.deepEqual(
    sent.slice(3),
    ['a', 'c'].map((socket) => ({
      socket,
      event: { type: 'peer-left', peerId: id },
    }))
  );
  assert.equal(broker.rooms.get('room').size, 2);
  broker.leave('room', 'a');
  broker.leave('room', 'c');
  assert.equal(broker.rooms.size, 0);
});

test('addressed SDP and ICE reach only their target with the real broker-owned sender', () => {
  const sent = [];
  const broker = createSignalingRooms((socket, event) =>
    sent.push({ socket, event })
  );
  for (const socket of ['a', 'b', 'c']) {
    broker.join('room', socket);
  }
  broker.join('other', 'd');
  const ids = broker.rooms.get('room');
  const message = {
    type: 'offer',
    sdp: '你好\r\n',
    empty: [],
    single: [true],
    to: ids.get('b'),
    from: ids.get('c'),
  };
  sent.length = 0;
  broker.relay('room', 'a', message);
  assert.deepEqual(sent, [
    { socket: 'b', event: { ...message, from: ids.get('a') } },
  ]);
  broker.relay('room', 'a', {
    type: 'ice',
    to: broker.rooms.get('other').get('d'),
    candidate: {},
  });
  broker.relay('room', 'a', { type: 'peer-left', peerId: ids.get('b') });
  broker.relay('room', 'a', {
    type: 'offer',
    from: ids.get('c'),
    sdp: 'forged',
  });
  broker.relay('room', 'd', message);
  assert.equal(
    sent.length,
    1,
    'unknown sender, cross-room target and forged membership never relay'
  );
  broker.leave('room', 'b');
  sent.length = 0;
  broker.relay('room', 'a', message);
  assert.deepEqual(sent, [], 'departed identity cannot receive late answers');
});

test('legacy unaddressed signaling retains exact fields and room isolation', () => {
  const sent = [];
  const broker = createSignalingRooms((socket, event) =>
    sent.push({ socket, event })
  );
  for (const socket of ['a', 'b', 'c']) {
    broker.join('room', socket);
  }
  broker.join('other', 'd');
  sent.length = 0;
  const message = { type: 'answer', sdp: 'v=0', empty: [], value: false };
  broker.relay('room', 'a', message);
  assert.deepEqual(
    sent,
    ['b', 'c'].map((socket) => ({ socket, event: message }))
  );
});

const fixture = () => {
  let receive;
  const sent = [];
  const connections = [];
  const errors = [];
  const signaling = signalingChannel({
    send: (message) => sent.push(message),
    onMessage: (handler) => {
      receive = handler;
    },
  });
  const mesh = createWebRtcMesh({
    signaling,
    onError: (error) => errors.push(error.message),
    makeTransport({ signaling: scoped }) {
      const entry = {
        received: [],
        started: 0,
        closed: 0,
        detached: 0,
        scoped,
      };
      scoped.on('*', (message) => entry.received.push(message));
      const transport = {
        async startAsInitiator() {
          entry.started++;
        },
        close() {
          entry.closed++;
        },
      };
      connections.push(entry);
      return { ...transport, entry };
    },
    connect: (transport) => () => {
      transport.entry.detached++;
    },
  });
  return {
    mesh,
    receive: (message) => receive(message),
    connections,
    sent,
    errors,
  };
};

test('each current peer owns its signaling; duplicate joins and late answers do not replace channels', async () => {
  const { mesh, receive, connections, sent, errors } = fixture();
  try {
    receive({ type: 'peer-joined', peerId: 'b' });
    receive({ type: 'peer-joined', peerId: 'c' });
    assert.equal(mesh.peers.size, 2);
    receive({ type: 'answer', from: 'b', sdp: 'answer-b' });
    assert.equal(connections[0].received.length, 1);
    assert.equal(connections[1].received.length, 0);
    connections[0].scoped.sendIce({ candidate: 'bounded fixture' });
    assert.equal(sent[0].to, 'b');
    receive({ type: 'peer-joined', peerId: 'b' });
    assert.equal(
      connections.length,
      2,
      'transport itself guards repeated initiation'
    );
    receive({ type: 'answer', from: 'late', sdp: 'old' });
    receive({ type: 'peer-joined', peerId: 'invalid/id' });
    assert.equal(mesh.peers.size, 2);
    await Promise.resolve();
    assert.deepEqual(errors, []);
  } finally {
    mesh.close();
  }
});

test('rejoining identity creates a fresh connection while departure drains only the old peer', () => {
  const { mesh, receive, connections } = fixture();
  try {
    receive({ type: 'peer-joined', peerId: 'b' });
    receive({ type: 'peer-joined', peerId: 'c' });
    receive({ type: 'peer-left', peerId: 'b' });
    receive({ type: 'peer-left', peerId: 'b' });
    receive({ type: 'answer', from: 'b', sdp: 'late' });
    receive({ type: 'ice', from: 'b', candidate: {} });
    receive({ type: 'offer', from: 'b-new', sdp: 'fresh' });
    assert.equal(connections.length, 3);
    assert.equal(connections[0].closed, 1);
    assert.equal(connections[0].detached, 1);
    assert.equal(connections[0].received.length, 0);
    assert.equal(
      connections[1].closed,
      0,
      'unrelated survivor stays connected'
    );
    assert.equal(connections[2].received[0].sdp, 'fresh');
    assert.deepEqual([...mesh.peers.keys()], ['c', 'b-new']);
  } finally {
    mesh.close();
  }
});

test('close drains every connection exactly once and ignores all later signaling', () => {
  const { mesh, receive, connections } = fixture();
  receive({ type: 'peer-joined', peerId: 'b' });
  receive({ type: 'peer-joined', peerId: 'c' });
  mesh.close();
  mesh.close();
  receive({ type: 'peer-joined', peerId: 'new' });
  receive({ type: 'offer', from: 'new', sdp: 'late' });
  assert.equal(mesh.peers.size, 0);
  assert.equal(connections.length, 2);
  assert.ok(
    connections.every((entry) => entry.closed === 1 && entry.detached === 1)
  );
});
