import { assert } from './e2e-chat.mjs';
import { readSyncPeer } from './e2e-lino-sync-read.mjs';
import { prepareSyncPeer, stopSyncPeer } from './e2e-sync-peer.mjs';
import { watchChatPages } from './e2e-page-errors.mjs';
import { traceSyncPeer } from './e2e-lino-sync-trace.mjs';

/** Three finite isolated stores exercise actual rejoining and room routing. */
export const verifySyncLifecycle = async ({
  page,
  other,
  base,
  engine,
  until,
  store,
  id,
  errors,
}) => {
  await page.evaluate(
    (key) => globalThis.__msApi.put({ id: key, body: 'before reload' }),
    id
  );
  await until(
    async () =>
      (await readSyncPeer(other, id))?.record?.body === 'before reload',
    'record before reload'
  );
  const previous = await other.evaluate(
    () => globalThis.performance.timeOrigin
  );
  await other.reload();
  await other.waitForFunction(
    () =>
      globalThis.__msApi && globalThis.__syncWire?.some((frame) => frame.rtc)
  );
  assert(
    (await other.evaluate(() => globalThis.performance.timeOrigin)) !==
      previous,
    'connected peer really reloaded'
  );
  await page.evaluate((key) => globalThis.__msApi.del(key), id);
  await until(async () => {
    const value = await readSyncPeer(other, id);
    return value && !value.record;
  }, 'reconnected WebRTC deletion');
  const context = await page.context().browser().newContext();
  watchChatPages(context, { errors, engine, base });
  const third = await context.newPage();
  const trace = await traceSyncPeer(third, 2);
  try {
    await prepareSyncPeer(third, base, engine);
    const targets = [page, other, third];
    for (const [index, sender] of targets.entries()) {
      const link = {
        id: `l:rtc-rejoined-${index}`,
        body: `peer ${index}: 你好 🚀`,
        single: [true],
        empty: [],
      };
      await sender.evaluate((value) => globalThis.__msApi.put(value), link);
      for (const receiver of targets.filter((target) => target !== sender)) {
        try {
          await until(
            async () => {
              const value = await readSyncPeer(receiver, link.id);
              return (
                value?.record?.body === link.body &&
                value.record.single[0] === true &&
                value.record.empty.length === 0 &&
                (receiver === page || !value.secret)
              );
            },
            `three-peer convergence from ${index}`,
            20000
          );
        } catch (error) {
          const value = await readSyncPeer(receiver, link.id);
          console.error(
            '[sync-lifecycle-observation]',
            JSON.stringify({
              source: index,
              target: targets.indexOf(receiver),
              recordPresent: Boolean(value?.record),
              bodyMatches: value?.record?.body === link.body,
              secretPresent: Boolean(value?.secret),
            })
          );
          throw error;
        }
      }
      assert(
        !(await store.get(link.id)),
        'mesh writes never reach the server store'
      );
      await sender.evaluate((key) => globalThis.__msApi.del(key), link.id);
      for (const receiver of targets.filter((target) => target !== sender)) {
        await until(async () => {
          const value = await readSyncPeer(receiver, link.id);
          return value && !value.record;
        }, `three-peer deletion from ${index}`);
      }
    }
    await stopSyncPeer(third);
    await context.close();
    const after = { id: 'l:rtc-after-third-left', body: 'surviving pair' };
    await other.evaluate((value) => globalThis.__msApi.put(value), after);
    await until(
      async () =>
        (await readSyncPeer(page, after.id))?.record?.body === after.body,
      'surviving pair convergence'
    );
    console.log(
      '[sync-lifecycle]',
      JSON.stringify({
        reloaded: true,
        peers: 3,
        sources: 3,
        secrets: 0,
        serverWrites: 0,
        departed: true,
      })
    );
  } finally {
    if (!third.isClosed()) {
      await trace('closing');
      await stopSyncPeer(third);
    }
    await context.close();
  }
};
