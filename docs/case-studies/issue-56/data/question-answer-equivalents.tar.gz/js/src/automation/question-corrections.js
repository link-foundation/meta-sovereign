// An explicit correction limits reuse for that question. It does not rewrite
// the transcript, extract new facts or turn corrected text into observed sends.
import { matchContextualQuestion } from './question-context-match.js';
import { questionCore } from './question-turns.js';
import { renderAnswer } from './question-profile.js';
import { rejectedAnswer } from './question-policy.js';
import { matchNotice } from './question-notices.js';
import { answerSpellings } from './question-equivalents.js';

export const answerRuleEligible = (rule, { source, chat } = {}) =>
  rule.enabled !== false &&
  (!rule.sources?.length || rule.sources.includes(source)) &&
  (!rule.chats?.length || rule.chats.includes(`${source}:${chat}`));

export const createAnswerCorrectionGuard = (
  rules = [],
  {
    policy = {},
    profile = {},
    contract = (text) => text,
    matching,
    contexts,
  } = {}
) => {
  const core = (text) =>
    questionCore(text, { preserveCase: matching?.caseSensitive === true });
  const identity = (text) => {
    const value = contract(text).trim();
    return policy.punctuationEquivalent
      ? value.replace(/[.!。！]+$/u, '')
      : value;
  };
  const corrections = rules
    .filter((rule) => rule.answers.some((answer) => answer.canonical))
    .map((rule) => ({
      rule,
      questions: [rule.question, ...(rule.questions ?? [])].map((text) =>
        rule.kind === 'notice' ? text : core(text)
      ),
      answers: new Set(
        rule.answers
          .filter((answer) => answer.canonical)
          .flatMap(answerSpellings)
          .flatMap((text) => {
            const rendered = renderAnswer(text, profile).text;
            return rejectedAnswer(text, policy) ||
              rejectedAnswer(rendered, policy)
              ? []
              : [identity(text), identity(rendered)];
          })
      ),
    }));
  return (question, text, context = {}) => {
    const normalized = core(question);
    const applicable = corrections.filter(
      (entry) =>
        (entry.rule.kind === 'notice') === (context.notice === true) &&
        answerRuleEligible(entry.rule, context) &&
        entry.questions.some((pattern) =>
          entry.rule.kind === 'notice'
            ? matchNotice(pattern, question, matching)
            : matchContextualQuestion(pattern, normalized, entry.rule, {
                matching,
                contexts,
              })
        )
    );
    return (
      !applicable.length ||
      applicable.some((entry) => entry.answers.has(identity(text)))
    );
  };
};
