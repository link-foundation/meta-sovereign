await (async (page) => {
  const base = 'http://127.0.0.1:39873';
  const pageErrors = [];
  const requests = [];
  page.on('pageerror', (error) => pageErrors.push(error.message));
  page.on('request', (request) => {
    if (request.method() === 'POST') requests.push(new URL(request.url()).pathname);
  });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript(() => {
    localStorage.setItem('metaSovereignLocale','en');
    localStorage.setItem('metaSovereignTutorial',JSON.stringify({off:true,v:5}));
  });
  await page.goto(base + '/?browser-review=mcp#/automation');
  const open = async (details) => {
    if (!(await details.evaluate((node) => node.open))) await details.locator(':scope > summary').click();
  };
  const panel = page.locator('[data-question-controls]');
  await open(panel);
  const editor = panel.locator('[data-answer-rule]');
  await editor.getByLabel('Question or pattern',{exact:true}).fill('Do you have experience? …');
  await editor.getByLabel('Answer',{exact:true}).fill('Five years.');
  await editor.getByLabel('Approved for automatic sending with this saved rule',{exact:true}).check();
  const saved = page.waitForResponse((response) => response.url().endsWith('/api/automations/answers/save'));
  await editor.getByRole('button',{name:'Save',exact:true}).click();
  const savedStatus = (await saved).status();
  await panel.getByText('Answer rule saved.',{exact:true}).waitFor();
  const controls = panel.locator('[data-browser-answer-controls]');
  await open(controls);
  await controls.getByLabel('Web-chat reference',{exact:true}).fill('7');
  const reviewed = page.waitForResponse((response) => response.url().endsWith('/api/automations/answers/browser/inspect'));
  await controls.locator('[data-browser-answer-inspect]').click();
  const reviewStatus = (await reviewed).status();
  await controls.getByText('No matching answer',{exact:true}).waitFor();
  await controls.getByText('Review required before automatic sending.',{exact:true}).waitFor();
  await controls.getByText('Do you have experience? Please book a time.',{exact:true}).waitFor();
  const reply = await controls.locator('[data-browser-text-draft]').inputValue();
  const sendDisabled = await controls.locator('[data-browser-text-send]').isDisabled();
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth);
  if (savedStatus !== 200 || reviewStatus !== 200 || reply || !sendDisabled || overflow || pageErrors.length) {
    throw new Error(JSON.stringify({savedStatus,reviewStatus,reply,sendDisabled,overflow,pageErrors}));
  }
  return {viewport:[390,844], savedStatus, reviewStatus, match:'unanswered', requests, reply, sendDisabled, overflow, pageErrors};
})(page);
