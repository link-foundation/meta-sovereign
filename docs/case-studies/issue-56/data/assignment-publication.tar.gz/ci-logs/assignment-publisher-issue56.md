We should make it in such a way that automatic questions and answers a configurable across systems using UI and unified automation data model and APIs.

https://github.com/konard/hh-job-application-automation (full support of automation of applications + full support for messaging via web version of hh, so it looks like our chat, but we can see messages also in chat, and some way to see messages from all systems combined, or only from telegram or hh and so on).

Also in operator mode, we should support handling of unread messages in hh and so on.

Automations of question and answers should be fully supported across the systems, meaning we should use implement all features of hh-job-application-automation but not only in hh chat, in all chats, so the same mechisms like patterns substitution, question recognition and so on.

We must support exactly all features of
- https://github.com/konard/hh-job-application-automation (job applications and forms filling and questions answering automation and all other features we have there like advanced CV sync)
- https://github.com/konard/broadcast (ability to use broadcast for channels and public chats and so on, so we can send the same message across social systems all at once).
- https://github.com/konard/telegram-bot (all features)
- https://github.com/konard/follow (automation of handling PR chats inside same social system and cross systems)
- https://github.com/konard/vk-bot (all kinds of example scripts for messaging automation and VK integration via API + browser)
- https://github.com/konard/vk-bot-desktop (support desktop app)

In this issue/pull request we must ensure we provide all the features via cli, api server, and UI, so everything is controllable in convenient way.

By default we should start with visible browser windows (headed) to build trust with a user on how our system operates, and it should be possible to configure each case and slot of browser to be headless if needed.

We should use https://github.com/link-foundation/browser-commander extensively for all systems, so even if official API does not support something or API token is not available and for user it is more convenient to use browser it can (as that requires no server or to complex configuration).

We should also use full potential of new (latest versions) https://github.com/link-assistant/formal-ai/blob/main/docs/associative-tech-stack.md, and update exactly all our dependencies, if some of them have missing features or bugs we report them.

For example we should support latest link-cli for data storage fully, and also support both binary and text links notation protocols for communication between web version and the server (no json API, and use https://github.com/link-foundation/lino-rest-api by default). We can keep json/rest api as compatibility layer, but it should be disabled by default.

We should also use not only link-cli as database, but also regularly make text and binary based links notation dumps, so if something is failed we have a way to recover.

In addition to all that, we should use experience of github.com/link-assistant/formal-ai to fully support universal react.js application, that is working on GitHub Pages (landing + /app) + local web-server (by default turned off) + iOS app (with all instructions on how to configure deploy with real Apple Developer account,  yet it must not fail if no such account specified), electron desktop app (also should work just fine without developer account on mac), android app and so on.

So we can prepare to publish it to iOS.

We should also support multiserver sync, for example it should be possible to detect the meta-sovereign in local network and connect to it from desktop to mobile (full support of all features we can in mobile).

And also we should be able to use mobile to connect to desktop server.

We should also be able to make sync between these servers, and decide where we store data, for example on iPhone I have lots of space, so I can deside to migrate all caches and loaded data to my iPhone in local network, I can decide to keep it on both systems or partially and so on.

We should be able do sync or just connect in all directions.

We also need to think of ways to have full browsers on iPhone, like for example have docker or other emulation being able to configure on iPhone directly, but we should be able to use everything on iPhone, and yet use desktop server in sync for only browsers and other missing features.

We should carefully think about UI, so it displays the context carefully and does not show unsupported features if run only on iPhone with no desktop and so on.

We need to download all logs and data related about the issue to this repository, make sure we compile that data to `./docs/case-studies/issue-{id}` folder, and use it to do deep case study analysis (also make sure to search online for additional facts and data), in which we will reconstruct timeline/sequence of events, list of each and all requirements from the issue, find root causes of the each problem, and propose possible solutions and solution plans for each requirement (we should also check known existing components/libraries, that solve similar problem or can help in solutions).

If there is not enough data to find actual root cause, add debug output and verbose mode if not present, that will allow us to find root cause on next iteration.

If issue related to any other repository/project, where we can report issues on GitHub, please do so. Each issue must contain reproducible examples, workarounds and suggestions for fix the issue in code. Also double check to fully apply requirements to entire codebase, so if we have issue in multiple places, it should be fixed in all them.

Please plan and execute everything in this single pull request, you have unlimited time and context, as context auto-compacts and you can continue indefinitely, until it is each and every requirement fully addressed, and everything is totally done.

Please plan and execute everything in this single pull request, you have unlimited time and context, as context auto-compacts and you can continue indefinitely, until each and every requirement fully addressed, and everything is totally done.