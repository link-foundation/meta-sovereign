export const enAssignment = {
  'assignment.standalone': 'Draft from assignment instructions',
  'assignment.standalone-hint':
    'Paste the instructions or enter a document URL, then review the English issue before publishing.',
  'assignment.instructions-text': 'Assignment instructions',
  'assignment.instructions-pasted': 'Instructions used: pasted text',
  'assignment.title': 'Publish an assignment repository',
  'assignment.hint':
    'Use the configured local model to draft an English issue without employer names. Review its requirements, stack, template and visibility before publishing. A vacancy link opens a separate browser; saved HH chat links can supply it automatically.',
  'assignment.instructions': 'Instruction document URL (optional)',
  'assignment.instructions-detected': 'Instruction links in the form',
  'assignment.instructions-select': 'Choose a link or enter a URL',
  'assignment.instructions-required': 'Instruction document URL',
  'assignment.instructions-hint':
    'Read visible text from an HTML or plain-text page in a separate browser. Login, verification, PDF and canvas documents need a readable text version.',
  'assignment.instructions-used': 'Instructions used: {title}',
  'assignment.target': 'GitHub owner/repository',
  'assignment.visibility': 'Repository visibility',
  'assignment.visibility.private': 'Private',
  'assignment.visibility.public': 'Public',
  'assignment.vacancy': 'HH vacancy URL or ID (optional)',
  'assignment.language': 'Template language',
  'assignment.language-auto': 'Use the vacancy or assignment',
  'assignment.language-owner': 'Selected by you: {language}',
  'assignment.language-reviewed': 'Template language: {language}',
  'assignment.refresh':
    'Read the vacancy again instead of using its saved snapshot',
  'assignment.employers':
    'Additional employer names or aliases to remove (one per line)',
  'assignment.restore': 'Restore saved draft after reopening',
  'assignment.draft': 'Draft issue and repository plan',
  'assignment.drafting': 'Drafting…',
  'assignment.publish': 'Publish reviewed repository and issue',
  'assignment.publishing': 'Publishing and checking receipts…',
  'assignment.recover': 'Recover the same publication',
  'assignment.template': 'Template: {repository} · {source}',
  'assignment.source.live': 'current Hive Mind table',
  'assignment.source.fallback':
    'built-in fallback; live recommendation unavailable',
  'assignment.template.create': 'Create a repository from this template.',
  'assignment.template.merge':
    'Add template history and missing workflows while preserving existing files.',
  'assignment.template.keep': 'Keep the existing repository and pipeline.',
  'assignment.vacancy-used': 'Vacancy used: {title}',
  'assignment.verified':
    'Repository, pipeline and issue were confirmed. The assignment implementation still needs to be completed and reviewed.',
  'assignment.uncertain':
    'Publication is unconfirmed ({code}; stage {stage}). Recover the same publication to inspect receipts; an uncertain creation is not repeated.',
  'assignment.review-changed':
    'The form has changed. Read and plan the current page before drafting again.',
  'assignment.error':
    'No confirmed result ({code}). Your inputs and any attempted publication are retained.',
};
