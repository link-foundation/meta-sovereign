import { ruApplication } from './ru-application.js';
export const ruVacancy = {
  'vacancySelection.retry-wait':
    'Ожидание повтора после общей ошибки (пять часов); ответы сохранены',
  ...ruApplication,
  'vacancySelection.searchAt': 'Последний успешный поиск: {date}.',
  'vacancySelection.skipResponded':
    'Исключать карточки с отметкой об отправленном отклике',
  'vacancySelection.excludeText':
    'Исключать точный текст, одна фраза на строку',
  'vacancySelection.hint':
    'До 32 фраз по 120 символов. Проверяются название, работодатель и до 100 сохранённых описаний без учёта регистра и ё/е. Непрочитанные описания остаются непроверенными. Все карточки видны; отклики не отправляются.',
  'vacancySelection.unavailable': 'Сервер не поддерживает проверку отбора.',
  'vacancySelection.stale':
    'Отбор устарел. Повторите поиск с текущими настройками и сохранёнными решениями.',
  'vacancySelection.summary':
    'Исключено: {excluded} · Отложено: {deferred} · Нужно описание: {unread} · На проверку: {review}',
  'vacancySelection.owner-skipped': 'Исключено вашим сохранённым решением',
  'vacancySelection.owner-deferred': 'Отложено вашим сохранённым решением',
  'vacancySelection.responded': 'Исключено: карточка уже отмечена как отклик',
  'vacancySelection.configured-text': 'Исключено по настроенному тексту',
  'vacancySelection.needs-description':
    'Сохраните описание и повторите поиск для проверки текста',
  'vacancySelection.review':
    'Доступно для ручной проверки; отклик не отправлен',
  'vacancySelection.match': 'Совпадение «{term}»: {field}',
  'vacancySelection.title': 'название',
  'vacancySelection.company': 'работодатель',
  'vacancySelection.description': 'сохранённое описание',
  'vacancySelection.cachedAt':
    'Описание сохранено {date}; вакансия на сайте могла измениться.',
  'technology.working': 'Обработка сохранённых данных…',
  'technology.title': 'Анализ технологий вакансий',
  'technology.hint':
    'Сравните до 100 сохранённых описаний с явно выбранным проверенным экспортом резюме. Упоминания — текстовые свидетельства, а не подтверждение навыка. Распознаются только названия из справочника; неизвестные теги видны отдельно. Счётчики учитывают уникальные вакансии. Резюме не изменяется, отклики не отправляются.',
  'technology.catalog': 'Локальные названия и варианты технологий',
  'technology.catalogEdit':
    'Правка справочника (до 256 названий, по 8 вариантов)',
  'technology.entry': 'Запись справочника',
  'technology.new': 'Добавить название',
  'technology.canonical': 'Название технологии',
  'technology.aliases': 'Варианты названия, по одному в строке',
  'technology.caseSensitive': 'Учитывать регистр (для Go, BASIC и NPM)',
  'technology.updateDraft': 'Обновить черновик справочника',
  'technology.remove': 'Удалить из черновика',
  'technology.defaults': 'Загрузить исходные названия в черновик',
  'technology.save': 'Сохранить справочник',
  'technology.unsaved':
    'В черновике есть несохранённые изменения. Сохраните его перед анализом.',
  'technology.invalid':
    'Используйте уникальные названия до 80 символов и не более 8 вариантов на название.',
  'technology.resume': 'Проверенный экспорт резюме для сравнения',
  'technology.choose': 'Выберите экспортированное резюме',
  'technology.analyze': 'Проанализировать сохранённые вакансии',
  'technology.reload':
    'Загрузить сохранённые справочник и отчёт; сбросить черновик',
  'technology.loadError':
    'Часть сохранённых данных не загрузилась. Подключитесь к локальному серверу и загрузите снова.',
  'technology.failed':
    'Анализ или сохранение справочника не подтверждены. Предыдущие свидетельства и черновик сохранены. При конфликте справочника загрузите его снова перед сохранением.',
  'technology.saved': 'Сохранённый анализ',
  'technology.provenance': 'Проверенный источник резюме',
  'technology.stale':
    'В отчёте использована другая версия справочника. Повторите анализ с сохранённым справочником.',
  'technology.statistics': 'Статистика корпуса (уникальные вакансии)',
  'technology.evidence': 'Упоминания в резюме (20 на странице)',
  'technology.vacancy': 'Сохранённая вакансия для просмотра',
  'technology.mentioned': 'Упомянуто в резюме',
  'technology.missing': 'Не найдено в тексте резюме',
  'technology.requiredMissing':
    'Обязательные названия, отсутствующие в тексте резюме',
  'technology.preferredMissing':
    'Желательные названия, отсутствующие в тексте резюме',
  'technology.unrecognized':
    'Нераспознанные теги навыков (добавьте в справочник)',
  'technology.aliasSuggestions':
    'Наблюдаемые варианты уже упомянутых в резюме названий',
  'technology.spellingSuggestions':
    'Похожие написания для проверки (не совпадение)',
  'technology.vacancyEvidence': 'Упоминания в вакансии',
  'technology.prose': 'Исходное сохранённое описание работодателя',
  'technology.required': 'Обязательно',
  'technology.preferred': 'Желательно',
  'technology.unspecified': 'Обязательность не указана',
  'technology.ambiguous': 'Неоднозначный вариант',
  'technology.metadata.location': 'Местоположения',
  'technology.metadata.employment': 'Занятость',
  'technology.metadata.experience': 'Опыт',
  'technology.metadata.workFormat': 'Форматы работы',
  'vacancy.exports': 'Экспорт резюме HH',
  'vacancy.exportHint':
    'Прочитать последнее, выбранное или все резюме этого аккаунта HH. Исходные файлы могут содержать личные данные. Производные Markdown, текст, структурированные данные и Lino исключают контакты, зарплату и дату рождения; удалённые строки с личными данными подсчитываются. HTML нужен для проверенного извлечения. DOC содержит RTF.',
  'vacancy.exportSettings': 'Настройки экспорта',
  'vacancy.exportScope': 'Какие резюме экспортировать',
  'vacancy.exportScope.latest': 'Последнее наблюдаемое обновление',
  'vacancy.exportScope.selected': 'Резюме, выбранное для поиска',
  'vacancy.exportScope.all': 'Все наблюдаемые резюме (до 100)',
  'vacancy.exportStart': 'Прочитать и экспортировать резюме',
  'vacancy.exportRecover': 'Восстановить статус экспорта',
  'vacancy.exportUnknown':
    'Статус экспорта неизвестен. Восстановите или остановите сохранённый запрос перед новым экспортом.',
  'vacancy.exportProgress': 'Проверено резюме: {count} из {total}',
  'vacancy.exportState.running': 'Выполняется экспорт',
  'vacancy.exportState.completed': 'Экспорт завершён',
  'vacancy.exportState.failed':
    'Экспорт остановлен из-за ошибки; проверенные файлы сохранены',
  'vacancy.exportState.stopped':
    'Экспорт остановлен; проверенные файлы сохранены',
  'vacancy.exportState.interrupted':
    'Экспорт прерван; восстановление статуса его не перезапустит',
  'vacancy.exportRemoved':
    'Строк с личными данными удалено из производных файлов: {count}',
  'vacancy.exportNative': 'исходный · возможны личные данные',
  'vacancy.exportSanitized': 'без личных данных',
  'vacancy.title': 'Вакансии HH',
  'vacancy.hint':
    'Ищите вакансии и собирайте полные описания в своём браузере HH. Отдельные элементы проверки ниже могут отправлять отклики. Описания доступны при подготовке тестового задания.',
  'vacancy.settings': 'Настройки поиска и браузера',
  'vacancy.query': 'Слова для поиска',
  'vacancy.resume': 'Хеш выбранного резюме (необязательно)',
  'vacancy.area': 'ID региона HH (необязательно)',
  'vacancy.salary': 'Минимальная зарплата (необязательно)',
  'vacancy.currency': 'Валюта',
  'vacancy.order': 'Порядок',
  'vacancy.browserSlot': 'Слот браузера',
  'vacancy.mode': 'Видимость браузера',
  'vacancy.remote': 'Удалённая работа',
  'vacancy.inherit': 'Сохранённая политика браузера',
  'vacancy.visible': 'Видимый браузер',
  'vacancy.headless': 'Фоновый браузер',
  'vacancy.salary_desc': 'Сначала высокая зарплата',
  'vacancy.publication_time': 'Сначала новые',
  'vacancy.relevance': 'Сначала подходящие',
  'vacancy.search': 'Найти вакансии',
  'vacancy.stop': 'Остановить операцию браузера',
  'vacancy.loading': 'Загружаем сохранённые вакансии…',
  'vacancy.unavailable':
    'Для чтения HH нужен подключённый сервер с поддержкой браузера. Сохранённые описания доступны.',
  'vacancy.working': 'Читаем в выделенном браузере…',
  'vacancy.failed':
    'Чтение не подтверждено. Проверьте вход или проверку в выделенном браузере. Предыдущие результаты сохранены.',
  'vacancy.page': 'Страница {page} · вакансий: {count}',
  'vacancy.collect': 'Сохранить полное описание',
  'vacancy.previous': 'Предыдущая страница',
  'vacancy.next': 'Следующая страница',
  'vacancy.responded': 'Уже откликнулись',
  'vacancy.cached': 'Сохранённые описания (последние 100)',
  'vacancy.empty':
    'Сохраните вакансию, чтобы её полное описание появилось здесь.',
  'vacancy.refresh': 'Прочитать описание заново',
  'vacancy.salaryValue': 'Зарплата',
  'vacancy.location': 'Местоположение',
  'vacancy.experience': 'Опыт',
  'vacancy.employment': 'Занятость',
  'vacancy.workFormat': 'Формат работы',
  'vacancy.published': 'Опубликовано',
  'vacancy.resumeLanguage': 'Предпочтительный язык резюме',
  'vacancy.ru': 'Сначала русский',
  'vacancy.en': 'Сначала английский',
  'vacancy.any': 'Любой язык',
  'vacancy.resumes': 'Резюме в этом слоте браузера',
  'vacancy.readResumes': 'Прочитать список резюме',
  'vacancy.resumesHint':
    'Список только для чтения. Совпадающий проверенный экспорт подтверждает язык сохранённого резюме; иначе название служит подсказкой. Выбор меняет настройки поиска.',
  'vacancy.resumesCaptured':
    'Список сохранён {date}; прочитайте заново, чтобы проверить изменения аккаунта.',
  'vacancy.resumeSuggested': 'Выбрать {title} · {reason}',
  'vacancy.resumesEmpty': 'В этом списке резюме не обнаружены.',
  'vacancy.resumeUnknownDate': 'Дата обновления неизвестна',
  'vacancy.resumeUse': 'Использовать для поиска',
  'vacancy.resumeSelected': 'Выбрано для поиска',
  'vacancy.resumeProof.ru': 'Русский экспорт · сохранён {date}',
  'vacancy.resumeProof.en': 'Английский экспорт · сохранён {date}',
  'vacancy.resumeReason.updated': 'последнее наблюдаемое обновление',
  'vacancy.resumeReason.latest': 'пометка HH «последнее»',
  'vacancy.resumeReason.list-order': 'порядок в списке HH',
  'cvTechnology.title': 'Двуязычная проверка технологий в резюме',
  'cvTechnology.hint':
    'Выберите проверенные экспорты на русском и английском. Проверьте предложения для каждого поля и сохраните выбранные изменения как локальную проверку. Резюме у провайдера останется прежним.',
  'cvTechnology.ru': 'Русский экспорт',
  'cvTechnology.en': 'Английский экспорт',
  'cvTechnology.generate': 'Подготовить локальную проверку',
  'cvTechnology.reload': 'Загрузить сохранённую проверку',
  'cvTechnology.loadError':
    'Не удалось загрузить проверку. Текущая проверка сохранена на экране.',
  'cvTechnology.before': 'Исходный текст',
  'cvTechnology.after': 'Предлагаемый текст',
  'cvTechnology.draft': 'Черновик локальной проверки',
  'cvTechnology.saved':
    'Выбранные изменения сохранены как локальная проверка. Резюме у провайдера не изменено.',
  'cvTechnology.complete':
    'Оба сохранённых экспорта уже содержат проверенные технологии.',
  'cvTechnology.blocked':
    'Устраните неоднозначность данных перед сохранением проверки.',
  'cvTechnology.coverage': 'Покрытие по полям',
  'cvTechnology.raw': 'Исходные списки и повторы',
  'cvTechnology.duplicates': 'Повторы',
  'cvTechnology.save': 'Сохранить выбранное локально',
  'cvTechnology.counterpart-ambiguous':
    'Этой позиции соответствуют несколько мест работы',
  'cvTechnology.counterpart-missing':
    'Для этой позиции не найдено место работы',
  'cvTechnology.counterpart-unresolved':
    'Соответствие места работы не установлено',
  'cvTechnology.about-layout':
    'Структура раздела «О себе» требует проверки; исходный текст сохранён',
  'cvTechnology.alias-ambiguous':
    'Название технологии имеет несколько значений',
  'cvTechnology.moreChanges': 'Показать ещё изменения',
  'cvTechnology.moreEvidence': 'Показать ещё исходные данные',
  'cvTechnology.about': 'О себе',
  'cvTechnology.skills': 'Навыки',
  'cvTechnology.position': 'Место работы',
  'cvTechnology.current': 'настоящее время',
  'cvWatch.title': 'Наблюдение за сохранением резюме',
  'cvWatch.hint':
    'Подключение к существующей вкладке резюме HH в этом слоте. Сохраняйте или отменяйте изменения сами на HH. Наблюдение не открывает, не меняет и не переключает страницы. Снимок обновляется только после проверки сохранённого экспорта.',
  'cvWatch.duration': 'Длительность (минуты)',
  'cvWatch.start': 'Начать наблюдение',
  'cvWatch.stop': 'Остановить наблюдение',
  'cvWatch.reload': 'Загрузить состояние',
  'cvWatch.none': 'Наблюдение не запущено.',
  'cvWatch.starting': 'Подключение к существующей вкладке…',
  'cvWatch.watching': 'Ожидание сохранения владельцем.',
  'cvWatch.verifying': 'Проверка окончательных полей по сохранённым экспортам…',
  'cvWatch.saved': 'Сохранение владельцем подтверждено.',
  'cvWatch.not-saved':
    'Сохранение не подтверждено. Предыдущий снимок сохранён.',
  'cvWatch.cancelled': 'Владелец отменил изменения. Снимок не изменён.',
  'cvWatch.edited':
    'После сохранения владелец изменил поля. Проверка отменена.',
  'cvWatch.failed':
    'Ошибка наблюдения. Загрузите состояние перед новым запуском.',
  'cvWatch.stopped': 'Наблюдение остановлено.',
  'cvWatch.expired': 'Время наблюдения истекло.',
  'cvWatch.interrupted':
    'Наблюдение прервано. Для продолжения запустите его явно.',
  'cvWatch.verified': 'Подтверждённые сохранения',
  'cvWatch.until': 'До',
  'cvWatch.snapshots': 'Сохранённые снимки резюме',
  'cvWatch.choose': 'Выберите снимок',
  'cvWatch.native': 'Проверка экспорта HH',
  'cvWatch.workplace': 'Проверенная запись о работе',
  'cvWatch.included': 'Включена в это резюме',
  'cvWatch.excluded': 'Исключена из этого резюме',
  'cvWatch.inspect': 'Просмотреть очищенные поля',
  'cvWatch.empty': 'Подтверждённых сохранений пока нет.',
  'cvWatch.loadError':
    'Не удалось подтвердить соединение или состояние. Снимки сохранены; загрузите состояние перед новым запуском.',
  'cvPrepare.title': 'Подготовить черновик резюме',
  'cvPrepare.hint':
    'Выберите сохранённое изменение «О себе» и откройте это резюме в существующем слоте HH. Сначала остановите наблюдение. Подготовка отклоняет открытый редактор; Сохранить или Отмена остаются за вами. Для проверенных снимков начните наблюдение перед сохранением.',
  'cvPrepare.choose':
    'Сначала сохраните выбранное изменение «О себе» или описания места работы в локальном плане.',
  'cvPrepare.prepare': 'Подготовить «О себе»',
  'cvPrepare.recordId': 'ID существующего места работы',
  'cvPrepare.description': 'Подготовить описание',
  'cvPrepare.workplaceHint':
    'Для описания места работы самостоятельно откройте неизменённую существующую запись и введите её числовой ID. Она должна относиться только к выбранному резюме; для общей записи нужна отдельная копия. Подготовка меняет только описание, а сохранение или отмена остаются за вами.',
  'cvPrepare.reload': 'Обновить состояние подготовки',
  'cvPrepare.cancel': 'Отменить запрос без ответа',
  'cvPrepare.cancelHint':
    'Перед новой попыткой отмените этот запрос. Черновики HH сохраняются; для уже начатой подготовки будет показано её фактическое состояние.',
  'cvPrepare.cancelled':
    'Неполученный запрос надёжно отменён. Его поздняя копия не подготовит черновик. Сохранение на HH не подтверждено.',
  'cvPrepare.recovery':
    'Перед новой попыткой восстановите состояние. Неизвестный запрос блокирует подготовку; проверьте существующую вкладку.',
  'cvPrepare.starting': 'Подключение к существующей вкладке резюме…',
  'cvPrepare.opening': 'Открытие редактора «О себе»…',
  'cvPrepare.preparing': 'Подготовка проверенного текста…',
  'cvPrepare.prepared':
    'Черновик подготовлен. Проверьте его во вкладке HH и выберите «Сохранить» или «Отменить». Эта квитанция не подтверждает сохранение на сервисе.',
  'cvPrepare.failed':
    'Подготовка остановлена до изменения полей. Существующий черновик сохранён.',
  'cvPrepare.uncertain':
    'Результат подготовки неизвестен. Проверьте черновик во вкладке HH; автоматического повтора не было.',
  'cvPrepare.interrupted':
    'Подготовка прервана. Проверьте существующий черновик HH перед продолжением.',
  'cvTranslation.title': 'Сравнить переводы опыта работы',
  'cvTranslation.hint':
    'Выбранным локальным командам перевода передаётся только этот текст. Результаты приватны. Пустые поля модели используют текущий псевдоним Haiku и новейшую доступную Luna; точная модель позволяет повторно использовать кэш.',
  'cvTranslation.source': 'Исходный текст',
  'cvTranslation.direction': 'Направление перевода',
  'cvTranslation.text': 'Текст опыта работы',
  'cvTranslation.model': 'Точная модель (необязательно)',
  'cvTranslation.compare': 'Сравнить переводы',
  'cvTranslation.reload': 'Загрузить сохранённое сравнение',
  'cvTranslation.pending':
    'Запрос мог быть получен. Загрузите его состояние перед новым запуском. Отмена неполученного запроса блокирует запоздалые копии.',
  'cvTranslation.loadError':
    'Не удалось загрузить сравнение. Повторите загрузку.',
  'cvTranslation.review':
    'Проверьте переводы. Поля на сайте не заполнялись и не сохранялись.',
  'cvTranslation.cached': 'Из кэша этой модели/версии',
  'cvTranslation.fresh': 'Новый ответ',
  'cvTranslation.refused': 'Корректного перевода нет',
  'cvTranslation.output': 'Посмотреть отклонённый ответ',
  'cvTranslation.preferred': 'Предпочтительный вариант',
  'cvTranslation.none':
    'Корректных вариантов нет; исходный текст не является переводом.',
  'cvTranslation.running': 'Выполняется сравнение переводов.',
  'cvTranslation.completed': 'Сравнение завершено. Проверьте каждый вариант.',
  'cvTranslation.interrupted': 'Прервано; этот запрос не будет запущен заново.',
  'cvTranslation.stopped': 'Остановлено; завершённые варианты доступны.',
  'cvTranslation.failed':
    'Ошибка сравнения; ранее сохранённый приватный кэш доступен.',
  'cvTranslation.cancel': 'Отменить неполученный запрос',
  'cvTranslation.stop': 'Остановить сравнение',
  'cvTranslation.noAnswer': 'Ответ не получен',
  'cvWorkplace.title': 'Проверить поля места работы',
  'cvWorkplace.hint':
    'Выберите сохранённый экспорт резюме и место работы. Введите числовой ID из адреса открытого редактора места работы. Проверьте и одобрите изменения, затем откройте эту запись с выбранным только этим резюме. Подготовка заполняет нативный черновик; сохранить или отменить его нужно на HH.',
  'cvWorkplace.export': 'Сохранённый экспорт резюме',
  'cvWorkplace.job': 'Место работы в экспорте',
  'cvWorkplace.fields': 'Предлагаемые поля',
  'cvWorkplace.company': 'Компания',
  'cvWorkplace.position': 'Должность',
  'cvWorkplace.description': 'Описание',
  'cvWorkplace.website': 'Сайт компании',
  'cvWorkplace.current': 'Я работаю здесь сейчас',
  'cvWorkplace.start': 'Месяц начала',
  'cvWorkplace.end': 'Месяц окончания',
  'cvWorkplace.areaId': 'Город или регион',
  'cvWorkplace.industryIds': 'Отрасли компании (до пяти)',
  'cvWorkplace.areaSearch': 'Поиск городов и регионов',
  'cvWorkplace.industrySearch': 'Поиск отраслей компании',
  'cvWorkplace.boundedChoices':
    'Поиск показывает до 50 совпадений и сохраняет выбранные значения видимыми.',
  'cvWorkplace.empty': 'Пусто',
  'cvWorkplace.yes': 'Да',
  'cvWorkplace.no': 'Нет',
  'cvWorkplace.draft': 'Предлагаемые изменения — ожидают вашего одобрения',
  'cvWorkplace.reviewed': 'Изменения одобрены — можно подготовить черновик',
  'cvWorkplace.before': 'Сохранённый экспорт',
  'cvWorkplace.after': 'Предлагаемое значение',
  'cvWorkplace.loadSource': 'Загрузить место работы и справочники',
  'cvWorkplace.propose': 'Проверить предлагаемые изменения',
  'cvWorkplace.approve': 'Одобрить эти изменения',
  'cvWorkplace.prepare': 'Подготовить нативный черновик места работы',
  'cvWorkplace.reload': 'Обновить сохранённую проверку',
  'cvWorkplace.status': 'Проверить статус подготовки',
  'cvWorkplace.cancel': 'Остановить подготовку',
  'cvWorkplace.loadError':
    'Не удалось загрузить сохранённую проверку места работы.',
  'cvWorkplace.operation': 'Действие с местом работы',
  'cvWorkplace.update': 'Изменить поля места работы',
  'cvWorkplace.detach': 'Убрать из этого резюме',
  'cvWorkplace.loadMembership': 'Прочитать сохранённый выбор резюме',
  'cvWorkplace.resumes': 'Выбор резюме',
  'cvWorkplace.detachHint':
    'Будет подготовлено только снятие выбора текущего резюме в существующей записи. Выбор других резюме и все поля останутся согласованными. Сохраняете вы. Для замены общего места работы сначала сохраните и проверьте отдельную копию.',
  'cvWorkplace.membershipBefore': 'Сохранённый выбор в HH',
  'vacancyChoice.title': 'Локальные решения по вакансиям',
  'vacancyChoice.hint':
    'Сохраняйте исключения и напоминания для этого слота браузера. Они сохраняются после перезапуска. Отклики пока отправляются вручную.',
  'vacancyChoice.note': 'Личная заметка или вопрос на потом',
  'vacancyChoice.skipped': 'Исключено из вашего плана',
  'vacancyChoice.deferred': 'Отложено для просмотра',
  'vacancyChoice.skippedAction': 'Исключить',
  'vacancyChoice.deferredAction': 'Посмотреть позже',
  'vacancyChoice.clear': 'Вернуть в план',
  'vacancyChoice.reload': 'Загрузить сохранённые решения',
  'vacancyChoice.failed':
    'Сохранённые решения не подтверждены. Загрузите их перед изменением; заметки остаются видимыми.',
  'vacancyChoice.empty': 'Нет сохранённых исключений или напоминаний.',
  'vacancyChoice.more': 'Показать ещё',
};
