import { describe, it, expect } from 'test-anywhere';
import { promises as fs } from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { setTimeout, clearTimeout } from 'node:timers';
import { startServer } from './helpers/legacy-server.js';
import { createMemoryStore } from '../src/storage/index.js';
import { waitFor } from './helpers/wait-for.js';

const fetchJson = async (url, init) => {
  const r = await fetch(url, init);
  return { status: r.status, body: r.status === 204 ? null : await r.json() };
};

// Send a literal HTTP request line over a raw TCP socket so URL
// normalisation in `fetch` (Bun, Deno, Node all collapse `..`) can't
// rewrite the path before it reaches the server.
const rawRequestStatus = (port, rawPath) =>
  new Promise((resolve, reject) => {
    const sock = net.createConnection({ host: '127.0.0.1', port }, () => {
      sock.write(
        `GET ${rawPath} HTTP/1.1\r\nHost: 127.0.0.1:${port}\r\nConnection: close\r\n\r\n`
      );
    });
    let buf = '';
    sock.setEncoding('utf8');
    sock.on('data', (chunk) => {
      buf += chunk;
    });
    sock.on('end', () => {
      const m = /^HTTP\/1\.\d (\d{3})/.exec(buf);
      resolve(m ? Number(m[1]) : 0);
    });
    sock.on('error', reject);
  });

const rawKeepAliveSocket = (port, rawPath = '/sources') =>
  new Promise((resolve, reject) => {
    const sock = net.createConnection({ host: '127.0.0.1', port }, () => {
      sock.write(
        `GET ${rawPath} HTTP/1.1\r\nHost: 127.0.0.1:${port}\r\nConnection: keep-alive\r\n\r\n`
      );
    });
    let buf = '';
    let settled = false;
    sock.setEncoding('utf8');
    sock.on('data', (chunk) => {
      buf += chunk;
      if (!settled && buf.includes('\r\n\r\n')) {
        settled = true;
        resolve(sock);
      }
    });
    sock.on('error', (err) => {
      if (!settled) {
        reject(err);
      }
    });
  });

const withDeadline = (promise, ms, message) =>
  new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(message)), ms);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (err) => {
        clearTimeout(timer);
        reject(err);
      }
    );
  });

describe('http server lifecycle', () => {
  it('tears down idle keep-alive sockets before a pending flush completes', async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'ms-keepalive-'));
    let releaseFlush;
    const pendingFlush = new Promise((resolve) => {
      releaseFlush = resolve;
    });
    const trace = (stage) => {
      if (process.env.CI_FIXTURE_DEBUG === '1') {
        console.error(`[fixture:http-lifecycle] ${stage}`);
      }
    };
    let flushing = false;
    const store = createMemoryStore();
    store.flush = () => {
      flushing = true;
      trace('flush_pending');
      return pendingFlush;
    };
    const handle = await startServer({
      localUi: true,
      port: 0,
      storeDir: dir,
      store,
      enableHandlers: false,
      enableSync: false,
      telegramAccount: false,
      automations: { scheduler: false },
      emailPoll: false,
      backups: { intervalHours: 0 },
    });
    let sock = null;
    let closePromise = null;
    let closedHandle = false;
    try {
      sock = await rawKeepAliveSocket(handle.port);
      const socketClosed = new Promise((resolve) =>
        sock.once('close', () => {
          trace('socket_closed');
          resolve();
        })
      );
      closePromise = handle.close().then(() => {
        closedHandle = true;
      });
      // HTTP shutdown must not wait for unrelated persistence. Hold a flush
      // open deliberately instead of timing real disk/background services.
      await withDeadline(
        socketClosed,
        2000,
        'idle keep-alive socket stayed open after server close'
      );
      await waitFor(() => flushing, { timeoutMs: 2000 });
      expect(closedHandle).toBe(false);
      releaseFlush();
      await withDeadline(
        closePromise,
        2000,
        'server close did not finish after its flush was released'
      );
    } finally {
      releaseFlush();
      sock?.destroy();
      if (closePromise) {
        await closePromise;
      } else if (!closePromise) {
        await handle.close();
      }
      await fs.rm(dir, { recursive: true, force: true });
    }
  });
});

describe('http server', () => {
  it('round-trips a link via HTTP', async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'ms-srv-'));
    // No Telegram account: it would add its own repair marker link.
    const handle = await startServer({
      localUi: true,
      port: 0,
      storeDir: dir,
      telegramAccount: false,
    });
    const base = `http://127.0.0.1:${handle.port}`;
    try {
      await fetchJson(`${base}/links`, {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ id: 'a', tokens: ['hi'] }),
      });
      const got = await fetchJson(`${base}/links/a`);
      expect(got.body.tokens[0]).toBe('hi');
      const list = await fetchJson(`${base}/links`);
      expect(list.body.length).toBe(1);
    } finally {
      await handle.close();
    }
  });
  it('exposes /sources', async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'ms-srv2-'));
    const handle = await startServer({ localUi: true, port: 0, storeDir: dir });
    try {
      const r = await fetchJson(`http://127.0.0.1:${handle.port}/sources`);
      expect(r.body.includes('telegram')).toBe(true);
    } finally {
      await handle.close();
    }
  });

  it('serves the SPA shell at /', async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'ms-srv3-'));
    const handle = await startServer({ localUi: true, port: 0, storeDir: dir });
    try {
      const r = await fetch(`http://127.0.0.1:${handle.port}/`);
      const text = await r.text();
      expect(r.status).toBe(200);
      expect(text.includes('meta-sovereign')).toBe(true);
      const js = await fetch(`http://127.0.0.1:${handle.port}/app.js`);
      expect(js.status).toBe(200);
      await js.text();
      const bundle = await fetch(`http://127.0.0.1:${handle.port}/app.min.js`);
      expect(bundle.status).toBe(200);
      await bundle.text();
      const discovery = await fetch(
        `http://127.0.0.1:${handle.port}/discovery-shell.js`
      );
      expect(discovery.status).toBe(200);
      await discovery.text();
      const css = await fetch(`http://127.0.0.1:${handle.port}/app.css`);
      expect(css.status).toBe(200);
      await css.text();
    } finally {
      await handle.close();
    }
  });

  it('exposes derived API routes', async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'ms-srv4-'));
    const handle = await startServer({ localUi: true, port: 0, storeDir: dir });
    const base = `http://127.0.0.1:${handle.port}`;
    try {
      await fetchJson(`${base}/links`, {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          id: 'msg:telegram:1',
          tokens: ['message', 'telegram', '1'],
          sender: 'alice',
          chat: 'general',
          source: 'telegram',
          body: 'hi',
        }),
      });
      // Our own message does not make us a contact.
      await fetchJson(`${base}/links`, {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          id: 'msg:telegram:2',
          tokens: ['message', 'telegram', '2'],
          sender: 'me',
          chat: 'general',
          source: 'telegram',
          body: 'hello',
        }),
      });
      const contacts = await fetchJson(`${base}/api/contacts`);
      expect(contacts.body.length).toBe(1);
      expect(contacts.body[0].id).toBe('alice');

      const infer = await fetchJson(`${base}/api/patterns/infer`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ examples: ['hi alice', 'hi bob'] }),
      });
      expect(typeof infer.body.regex).toBe('string');

      await fetchJson(`${base}/api/graphs`, {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          id: 'graph:greet',
          tokens: ['graph', 'greet'],
          nodes: [],
          edges: [],
        }),
      });
      const graphs = await fetchJson(`${base}/api/graphs`);
      expect(graphs.body.find((g) => g.id === 'graph:greet')).toBeTruthy();

      const status = await fetchJson(`${base}/api/status`);
      expect(typeof status.body.links).toBe('number');
      expect(status.body.messages).toBe(2);
      expect(status.body.contacts).toBe(1);
      expect(status.body.graphs).toBe(1);
    } finally {
      await handle.close();
    }
  });

  it('mounts browser-safe sibling modules under /storage and /handlers', async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'ms-srv5-'));
    const handle = await startServer({ localUi: true, port: 0, storeDir: dir });
    const base = `http://127.0.0.1:${handle.port}`;
    try {
      const browserStore = await fetch(`${base}/storage/browser-store.js`);
      expect(browserStore.status).toBe(200);
      await browserStore.text();

      const handlers = await fetch(`${base}/handlers/index.js`);
      expect(handlers.status).toBe(200);
      await handlers.text();

      // Traversal stays inside the mount dir. We send a raw HTTP
      // request so the runtime's fetch URL-normaliser doesn't collapse
      // `/storage/../etc/passwd` to `/etc/passwd` before it leaves the
      // client (Bun, Deno, and Node all do this in `fetch`).
      const traversalStatus = await rawRequestStatus(
        handle.port,
        '/storage/../etc/passwd'
      );
      expect([403, 404]).toContain(traversalStatus);

      // Only `.js` files are served from a mount.
      const txt = await fetch(`${base}/storage/notes.txt`);
      expect(txt.status).toBe(404);
      await txt.text();

      // Subdirectories inside a mount are not exposed.
      const nested = await fetch(`${base}/storage/sub/inner.js`);
      expect(nested.status).toBe(404);
      await nested.text();
    } finally {
      await handle.close();
    }
  });
});

describe('email server routes', () => {
  it('proxies email pull/send through local server fallback routes', async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'ms-email-'));
    const handle = await startServer({
      localUi: true,
      port: 0,
      storeDir: dir,
      emailLiveFactory: ({ protocol }) => {
        expect(protocol).toBe('gmail');
        return {
          async pullMessages() {
            return {
              links: [
                {
                  id: 'msg:email:local-1',
                  tokens: ['message', 'email', 'local-1'],
                  source: 'email',
                  sender: 'alice@example.com',
                  chat: 'thread-1',
                  body: 'local server mail',
                },
              ],
              rawCount: 1,
              nextOffset: null,
            };
          },
          async post(message) {
            return { id: 'sent-local', subject: message.subject };
          },
        };
      },
    });
    const base = `http://127.0.0.1:${handle.port}`;
    try {
      const pulled = await fetchJson(`${base}/api/email/pull`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ protocol: 'gmail', provider: 'gmail' }),
      });
      expect(pulled.status).toBe(200);
      expect(pulled.body.imported).toBe(1);
      const stored = await fetchJson(`${base}/links/msg%3Aemail%3Alocal-1`);
      expect(stored.body.body).toBe('local server mail');

      // Sending needs the user's confirmation: a preview and a token
      // first, then the same request with the token.
      const mail = {
        protocol: 'gmail',
        message: { to: 'bob@example.com', subject: 'Hi', text: 'hello' },
      };
      const post = (body) =>
        fetchJson(`${base}/api/email/send`, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(body),
        });
      const asked = await post(mail);
      expect(asked.status).toBe(428);
      expect(asked.body.preview.to).toBe('bob@example.com');
      expect(asked.body.preview.subject).toBe('Hi');
      const token = asked.body.confirm.token;
      const changed = await post({
        ...mail,
        message: { ...mail.message, to: 'eve@example.com' },
        confirmToken: token,
      });
      expect(changed.status).toBe(428);
      const again = await post(mail);
      const sent = await post({
        ...mail,
        confirmToken: again.body.confirm.token,
      });
      expect(sent.status).toBe(200);
      expect(sent.body.result.id).toBe('sent-local');
      const reused = await post({
        ...mail,
        confirmToken: again.body.confirm.token,
      });
      expect(reused.status).toBe(428);
    } finally {
      await handle.close();
    }
  });
});

describe('http server observability', () => {
  it('exposes /metrics in Prometheus exposition format', async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'ms-mtr-'));
    const handle = await startServer({ localUi: true, port: 0, storeDir: dir });
    const base = `http://127.0.0.1:${handle.port}`;
    try {
      await fetch(`${base}/links`, {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ id: 'msg:m1', tokens: ['m'] }),
      }).then((r) => r.text());
      const r = await fetch(`${base}/metrics`);
      expect(r.status).toBe(200);
      const body = await r.text();
      expect(body).toContain('# HELP meta_sovereign_links_total');
      expect(body).toContain('# TYPE meta_sovereign_links_total gauge');
      expect(body).toMatch(/meta_sovereign_links_by_kind\{kind="message"\} 1/);
      expect(body).toMatch(/meta_sovereign_ws_peers \d+/);
    } finally {
      await handle.close();
    }
  });
  it('writes JSON access logs when log option is provided', async () => {
    const { jsonLog } = await import('../src/server/log.js');
    const lines = [];
    const log = jsonLog({ write: (line) => lines.push(line) });
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'ms-log-'));
    const handle = await startServer({
      localUi: true,
      port: 0,
      storeDir: dir,
      log,
    });
    const base = `http://127.0.0.1:${handle.port}`;
    try {
      await fetch(`${base}/sources`).then((r) => r.text());
      // wait for `finish` event to flush
      await waitFor(() => lines.length > 0, { what: 'the http log line' });
      const httpLines = lines
        .map((l) => JSON.parse(l))
        .filter((e) => e.event === 'http');
      expect(httpLines.length).toBeGreaterThan(0);
      expect(httpLines.at(-1).path).toBe('/sources');
      expect(httpLines.at(-1).status).toBe(200);
      expect(typeof httpLines.at(-1).duration_ms).toBe('number');
    } finally {
      await handle.close();
    }
  });
  it('emits Content-Security-Policy + hardening headers on every response', async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'ms-csp-'));
    const handle = await startServer({ localUi: true, port: 0, storeDir: dir });
    const base = `http://127.0.0.1:${handle.port}`;
    try {
      const html = await fetch(`${base}/`);
      await html.text();
      expect(html.headers.get('content-security-policy')).toMatch(
        /default-src 'self'/
      );
      expect(html.headers.get('x-content-type-options')).toBe('nosniff');
      expect(html.headers.get('x-frame-options')).toBe('DENY');
      expect(html.headers.get('referrer-policy')).toBe('no-referrer');
      const api = await fetch(`${base}/sources`);
      await api.json();
      expect(api.headers.get('content-security-policy')).toMatch(
        /default-src 'self'/
      );
      const wasm = await fetch(`${base}/pattern-matcher.wasm`);
      await wasm.arrayBuffer();
      expect(wasm.status).toBe(200);
      expect(wasm.headers.get('content-type')).toBe('application/wasm');
    } finally {
      await handle.close();
    }
  });
});

describe('static asset caching', () => {
  it('makes browsers revalidate SPA assets so updates are never stale', async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'ms-srv-cache-'));
    const handle = await startServer({ localUi: true, port: 0, storeDir: dir });
    const base = `http://127.0.0.1:${handle.port}`;
    try {
      for (const asset of ['/', '/app.min.js', '/app.css']) {
        const r = await fetch(`${base}${asset}`);
        await r.text();
        expect(r.headers.get('cache-control')).toBe('no-cache');
        const etag = r.headers.get('etag');
        expect(Boolean(etag)).toBe(true);
        const again = await fetch(`${base}${asset}`, {
          headers: { 'if-none-match': etag },
        });
        await again.text();
        expect(again.status).toBe(304);
      }
    } finally {
      await handle.close();
    }
  });
});
