async (page) => {
  const process = {env:{}};
  var inactiveContract = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    openBrowserAnswerWatch: () => openBrowserAnswerWatch
  });

  // mcp-reader:node:crypto
  var randomUUID = () => "independent-inactive-history";
  var randomBytes = () => {
    throw new Error("Unexpected write");
  };

  // js/src/sources/browser-inactive-view.js
  var browserInactiveView = ({ operation, token }) => {
    const key = /* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1");
    const current = (state2) => state2.interrupted || document.hasFocus() ? "owner-active" : "ready";
    if (operation === "open" && !window[key]) {
      if (document.hasFocus()) {
        return { state: "owner-active" };
      }
      const state2 = { token, interrupted: false };
      state2.events = [
        "pointerdown",
        "keydown",
        "wheel",
        "touchstart",
        "touchmove",
        "input"
      ];
      state2.mark = (event) => {
        if (event.isTrusted || event.type === "input") {
          state2.interrupted = true;
        }
      };
      state2.focus = () => {
        if (document.hasFocus()) {
          state2.interrupted = true;
        }
      };
      for (const type of state2.events) {
        document.addEventListener(type, state2.mark, {
          capture: true,
          passive: true
        });
      }
      window.addEventListener("focus", state2.focus, true);
      document.addEventListener("visibilitychange", state2.focus, true);
      window[key] = state2;
    }
    const state = window[key];
    if (!state || state.token !== token) {
      return { state: state ? "busy" : "unavailable" };
    }
    const status = current(state);
    if (operation === "release") {
      for (const type of state.events) {
        document.removeEventListener(type, state.mark, true);
      }
      window.removeEventListener("focus", state.focus, true);
      document.removeEventListener("visibilitychange", state.focus, true);
      delete window[key];
    }
    return { state: status };
  };
  var failure = (state) => {
    if (process.env.MS_BROWSER_HISTORY_DEBUG === "1") {
      console.error("[browser-inactive-view]", { state });
    }
    return Object.assign(
      new Error("The inactive provider view is no longer owned."),
      {
        code: `browser-background-${state}`,
        historyReason: state === "owner-active" ? state : "document-changed",
        fallback: false
      }
    );
  };
  var prepareBrowserInactiveView = async (page2) => {
    const context = page2.context();
    if (context.browser()?.browserType().name() !== "chromium") {
      throw failure("focus-unavailable");
    }
    let session;
    try {
      session = await context.newCDPSession(page2);
      await session.send("Emulation.setFocusEmulationEnabled", {
        enabled: false
      });
    } catch {
      throw failure("focus-unavailable");
    } finally {
      await session?.detach().catch(() => {
      });
    }
  };
  var withInactiveBrowserView = async (document2, read) => {
    if (["evaluateOwner", "evaluate"].some(
      (method) => typeof document2?.[method] !== "function"
    )) {
      throw failure("unavailable");
    }
    const token = randomUUID();
    const control = async (operation) => {
      for (const method of ["evaluateOwner", "evaluate"]) {
        const result = await document2[method]({
          fn: browserInactiveView,
          args: [{ operation, token }]
        });
        if (result.state !== "ready") {
          throw failure(result.state);
        }
      }
    };
    try {
      await document2.prepareInactiveView?.();
      await control("open");
      const result = await read(() => control("status"), token);
      await control("status");
      return result;
    } finally {
      await Promise.allSettled(
        ["evaluate", "evaluateOwner"].map(
          (method) => document2[method]({
            fn: browserInactiveView,
            args: [{ operation: "release", token }]
          })
        )
      );
    }
  };

  // js/src/sources/browser-choice-document.js
  var failure2 = () => Object.assign(
    new Error("The visible provider chat document changed or is ambiguous"),
    {
      code: "answer-chat-unverified",
      fallback: false
    }
  );
  var browserDocumentIdentity = (selector) => {
    const key = /* @__PURE__ */ Symbol.for("meta-sovereign.browser-choice-document.v1");
    window[key] ??= crypto.randomUUID();
    return { key: window[key], rows: document.querySelectorAll(selector).length };
  };
  var browserFrameVisible = (node) => {
    if (!node.isConnected || !node.getClientRects().length) {
      return false;
    }
    for (let parent = node; parent; parent = parent.parentElement) {
      const style = getComputedStyle(parent);
      if (parent.hidden || parent.getAttribute("aria-hidden") === "true" || style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) {
        return false;
      }
    }
    return true;
  };
  var trusted = (address, origins) => {
    const url = new URL(address);
    return origins.includes(url.origin) && !url.username && !url.password;
  };
  var inChat = (frame, ui, target) => {
    const url = new URL(frame.url());
    return trusted(url.href, ui.location.origins) && new RegExp(ui.location.pathPattern).exec(url.pathname)?.[1] === String(target);
  };
  var visibleFrame = async (frame, main, ui) => {
    for (let current = frame; current && current !== main; current = current.parentFrame()) {
      if (!trusted(current.url(), ui.documents.ancestorOrigins)) {
        return false;
      }
      const element = await current.frameElement();
      try {
        if (!await element.evaluate(browserFrameVisible)) {
          return false;
        }
      } finally {
        await element.dispose();
      }
    }
    return true;
  };
  var inList = (frame, ui) => trusted(frame.url(), ui.location.origins) && new RegExp(ui.chatScan.pathPattern).test(new URL(frame.url()).pathname);
  var chooseDocument = async (page2, ui, target, list = false) => {
    if (!page2 || !trusted(page2.url(), ui.documents.ownerOrigins)) {
      throw failure2();
    }
    const main = page2.mainFrame();
    const ownerRoute = new RegExp(ui.location.pathPattern).exec(
      new URL(page2.url()).pathname
    );
    if (list ? !new RegExp(ui.chatScan.pathPattern).test(new URL(page2.url()).pathname) : ownerRoute && ownerRoute[1] !== String(target)) {
      throw failure2();
    }
    const frames = page2.frames();
    if (frames.length > ui.documents.maxFrames) {
      throw failure2();
    }
    const candidates = [];
    const selector = list ? ui.chats.item : ui.messages.item;
    for (const frame of frames) {
      const matching = list ? inList(frame, ui) : inChat(frame, ui, target);
      if (matching && await visibleFrame(frame, main, ui)) {
        const identity = await frame.evaluate(browserDocumentIdentity, selector);
        if (identity.rows) {
          candidates.push({ frame, identity, frameUrl: frame.url() });
        }
      }
    }
    if (candidates.length !== 1) {
      throw failure2();
    }
    const owner = await main.evaluate(browserDocumentIdentity, selector);
    return { ...candidates[0], owner: owner.key, url: page2.url() };
  };
  var resolveBrowserDocument = async (commander, page2, ui, target, list = false) => {
    if (!ui.documents) {
      return commander;
    }
    let selected;
    try {
      selected = await chooseDocument(page2, ui, target, list);
    } catch {
      throw failure2();
    }
    const assertCurrent = async () => {
      try {
        const current = await chooseDocument(page2, ui, target, list);
        if (current.frame !== selected.frame || current.frameUrl !== selected.frameUrl || current.identity.key !== selected.identity.key || current.owner !== selected.owner || current.url !== selected.url) {
          throw failure2();
        }
      } catch {
        throw failure2();
      }
    };
    const ownerFrame = page2.mainFrame();
    return {
      async prepareInactiveView() {
        await assertCurrent();
        await prepareBrowserInactiveView(page2);
        await assertCurrent();
      },
      async evaluateOwner({ fn, args = [] }) {
        if (args.length > 1) {
          throw failure2();
        }
        if (args[0]?.operation === "release") {
          return ownerFrame.evaluate(fn, args[0]);
        }
        await assertCurrent();
        const result = await ownerFrame.evaluate(fn, args[0]);
        await assertCurrent();
        return result;
      },
      async evaluate({ fn, args = [] }) {
        if (args.length > 1) {
          throw failure2();
        }
        if (args[0]?.operation === "release") {
          return selected.frame.evaluate(fn, args[0]);
        }
        await assertCurrent();
        const value = selected.frame === page2.mainFrame() ? await commander.evaluate({ fn, args }) : await selected.frame.evaluate(fn, args[0]);
        await assertCurrent();
        return value;
      },
      async clickButton({ selector }) {
        await assertCurrent();
        if (selected.frame === page2.mainFrame()) {
          await commander.clickButton({
            selector,
            scrollIntoView: true,
            waitForNavigation: false,
            waitAfterClick: 0,
            verify: false
          });
        } else {
          await selected.frame.locator(selector).click({ timeout: 5e3 });
        }
      }
    };
  };
  var resolveBrowserChoiceDocument = (commander, page2, ui, target) => resolveBrowserDocument(commander, page2, ui, target);

  // js/src/sources/browser-choice-visibility.js
  var watchChoiceView = (attempt, stop = false) => {
    if (!stop) {
      attempt.viewChanged = (event) => {
        if (event.type !== "pointerdown" || event.target !== attempt.node && !attempt.node.contains(event.target)) {
          attempt.preserveView = true;
        }
      };
    }
    for (const type of [
      "wheel",
      "touchmove",
      "keydown",
      "input",
      "pointerdown"
    ]) {
      document[stop ? "removeEventListener" : "addEventListener"](
        type,
        attempt.viewChanged,
        true
      );
    }
  };
  var revealChoiceReply = (spec, attempt, current, message) => {
    if (attempt.preserveView) {
      return "owner-activity";
    }
    const composer = current.composer;
    if (composer && String(composer.value ?? composer.textContent ?? "")) {
      return "owner-draft";
    }
    const pattern = new RegExp(spec.messages.idPattern);
    const nodes = [...document.querySelectorAll(spec.messages.item)].filter(
      (node) => pattern.exec(node.getAttribute(spec.messages.idAttribute) ?? "")?.[1] === message.id
    );
    if (nodes.length !== 1) {
      return "unavailable";
    }
    try {
      nodes[0].scrollIntoView({
        block: "nearest",
        inline: "nearest",
        behavior: "instant"
      });
      return "revealed";
    } catch {
      return "unavailable";
    }
  };

  // mcp-reader:node:timers/promises
  var setTimeout = (ms) => page.waitForTimeout(ms);

  // js/src/sources/browser-pending-turn.js
  var browserPendingTurn = (rows) => {
    const validText = (value, limit, empty = false) => typeof value === "string" && value.length <= limit && (empty || Boolean(value.trim()));
    const end = rows.findLastIndex((row) => row.outgoing || row.service);
    const last = rows[end];
    const messages = rows.slice(end + 1).map(({ id, body }) => ({ id, body }));
    const boundary = last ? {
      kind: last.service ? "service" : "outgoing",
      id: last.id,
      body: last.body
    } : { kind: "rendered-start" };
    if (messages.length > 20 || messages.reduce((size, row) => size + String(row.body ?? "").length, 0) > 24e3) {
      return { code: "answer-history-limited" };
    }
    const relevant = last ? [last, ...messages] : messages;
    if (relevant.some(
      (row) => !validText(row.id, 480) || !validText(row.body, 6e3, row === last)
    ) || new Set(relevant.map((row) => row.id)).size !== relevant.length) {
      return { code: "answer-history-unverified" };
    }
    return { boundary, messages };
  };
  var checkedBrowserPendingTurn = (turn, question) => {
    if (turn === void 0) {
      return void 0;
    }
    const boundary = turn?.boundary;
    if (!Array.isArray(turn?.messages) || turn.messages.length > 20 || !["rendered-start", "outgoing", "service"].includes(boundary?.kind)) {
      return null;
    }
    const rows = turn.messages.map((row) => ({ id: row?.id, body: row?.body }));
    if (boundary.kind !== "rendered-start") {
      rows.unshift({
        id: boundary.id,
        body: boundary.body,
        outgoing: boundary.kind === "outgoing",
        service: boundary.kind === "service"
      });
    }
    const value = browserPendingTurn(rows);
    const latest = rows.at(-1);
    return !value.code && latest?.id === question.id && latest.body === question.body && Boolean(latest.outgoing) === question.outgoing && !latest.service ? value : null;
  };

  // js/src/sources/browser-choice-reader.js
  var browserChoiceSuggestions = (spec, group, all, visible, text) => {
    if (!spec.choices.genericGroup || !group.matches(spec.choices.genericGroup) || group.closest(spec.messages.item)) {
      return false;
    }
    const offered = all.filter((node) => group.contains(node) && visible(node));
    const pattern = new RegExp(spec.choices.genericPattern, "iu");
    return offered.length > 0 && offered.some((node) => pattern.test(text(node)));
  };
  var browserChoiceHistory = (spec, visible, text, historyOnly = false) => {
    const unavailable = (code) => ({ code });
    const validLocation = (url2, match2) => spec.location.origins.includes(url2.origin) && Boolean(match2?.[1]);
    const validRows = (rows2) => !rows2.some((row) => !row.id || row.body.length > 6e3) && new Set(rows2.map((row) => row.id)).size === rows2.length;
    const bodyOf = (node) => String(node.querySelector(spec.messages.body)?.innerText ?? "").trim();
    const url = new URL(location.href);
    const match = new RegExp(spec.location.pathPattern).exec(url.pathname);
    if (!validLocation(url, match)) {
      return unavailable("answer-chat-unverified");
    }
    const chat = match[1];
    const candidates = [...document.querySelectorAll(spec.messages.item)];
    if (candidates.length > 500) {
      return unavailable("answer-history-limited");
    }
    const idPattern = new RegExp(spec.messages.idPattern);
    const serviceTitle = spec.messages.serviceTitlePattern ? new RegExp(spec.messages.serviceTitlePattern, "iu") : null;
    const rows = candidates.filter(visible).map((node) => ({
      node,
      id: idPattern.exec(node.getAttribute(spec.messages.idAttribute) ?? "")?.[1],
      body: bodyOf(node),
      outgoing: node.matches(spec.messages.outgoing) || Boolean(node.querySelector(spec.messages.outgoing)),
      ...serviceTitle?.test(text(node.querySelector(spec.messages.serviceTitle))) ? { service: true } : {}
    }));
    if (!validRows(rows)) {
      return unavailable("answer-history-unverified");
    }
    const messages = rows.map(({ node, ...row }) => ({
      ...row,
      timestamp: spec.messages.timestampAttribute ? node.getAttribute(spec.messages.timestampAttribute) : null
    }));
    const latest = rows.at(-1);
    const pendingTurn = historyOnly ? void 0 : browserPendingTurn(messages);
    if (pendingTurn?.code) {
      return pendingTurn;
    }
    return {
      chat,
      latest,
      messages,
      pendingTurn,
      questionAvailable: Boolean(latest?.body) && !latest.service
    };
  };
  var readBrowserChoices = (spec, internal = false, historyOnly = false) => {
    const text = (node) => String(node?.textContent ?? "").replace(/\s+/gu, " ").trim();
    const visible = (node) => {
      if (!node?.isConnected || !node.getClientRects().length) {
        return false;
      }
      for (let parent = node; parent; parent = parent.parentElement) {
        const style = getComputedStyle(parent);
        if (parent.hidden || parent.getAttribute("aria-hidden") === "true" || style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) {
          return false;
        }
      }
      return true;
    };
    const unavailable = (code) => ({ code });
    const validControls = (controls2) => controls2.length <= 100 && !controls2.some((node) => !text(node) || text(node).length > 6e3);
    const history = browserChoiceHistory(spec, visible, text, historyOnly);
    if (history.code) {
      return history;
    }
    const { chat, latest, messages, pendingTurn, questionAvailable } = history;
    if (!questionAvailable) {
      return historyOnly ? { chat, messages } : unavailable("answer-question-unavailable");
    }
    const all = [...document.querySelectorAll(spec.choices.button)];
    if (all.length > 1e3) {
      return unavailable("answer-options-limited");
    }
    const groups = [...document.querySelectorAll(spec.choices.group)].filter(
      (group) => visible(group) && !browserChoiceSuggestions(spec, group, all, visible, text)
    );
    const attached = groups.filter((group) => {
      const dialog = group.closest('[role="dialog"]');
      if (dialog && !dialog.contains(latest.node)) {
        return false;
      }
      const parent = group.closest(spec.messages.item);
      if (parent) {
        return parent === latest.node;
      }
      const bound = group.getAttribute(
        spec.choices.questionAttribute ?? "data-question-id"
      );
      return bound ? bound === latest.id : Boolean(latest.node.compareDocumentPosition(group) & 4);
    }).filter(
      (group, _index, selected) => !selected.some((other) => other !== group && group.contains(other))
    );
    if (groups.length > 100 || attached.length > 1) {
      return unavailable("answer-options-ambiguous");
    }
    const shown = all.filter(visible);
    const yes = /^(?:yes|да|हाँ|是)[.!]?$/iu;
    const no = /^(?:no|нет|नहीं|否)[.!]?$/iu;
    const unscoped = shown.filter((node) => {
      const owner = node.closest(spec.messages.item);
      const dialog = node.closest('[role="dialog"]');
      return (!owner || owner === latest.node) && (!dialog || dialog.contains(latest.node)) && !groups.some((group) => group.contains(node)) && (yes.test(text(node)) || no.test(text(node)));
    });
    const pair = unscoped.length === 2 && unscoped.some((node) => yes.test(text(node))) && unscoped.some((node) => no.test(text(node)));
    const controls = shown.filter(
      (node) => attached.some((group) => group.contains(node)) || spec.choices.attachedButtons && latest.node.contains(node) || pair && unscoped.includes(node)
    );
    if (!validControls(controls)) {
      return unavailable("answer-options-unverified");
    }
    const enabled = controls.filter(
      (node) => !node.matches(':disabled,[disabled],[aria-disabled="true"]') && !node.closest('[inert],[aria-disabled="true"]')
    );
    const strictOptions = [attached.length, pair, controls.length].some(Boolean);
    const answerOptions = enabled.map(text);
    if (historyOnly) {
      return {
        chat,
        messages: messages.map(
          (row) => row.id === latest.id ? { ...row, strictOptions, answerOptions } : row
        )
      };
    }
    const composers = [...document.querySelectorAll(spec.composer)].filter(
      visible
    );
    if (composers.length > 1) {
      return unavailable("answer-composer-ambiguous");
    }
    const result = {
      chat,
      question: { id: latest.id, body: latest.body, outgoing: latest.outgoing },
      strictOptions,
      answerOptions,
      optionsShown: controls.map(text),
      messages,
      pendingTurn
    };
    return internal ? { ...result, controls: enabled, composer: composers[0] } : result;
  };

  // js/src/sources/browser-reply-guard.js
  var browserReplyAdmission = (state, reservation) => {
    if (state.attempts.has(reservation)) {
      return "send-in-doubt";
    }
    if (state.attempts.size >= 32) {
      const completed = [...state.attempts].find(
        ([_key, attempt]) => attempt.confirmed
      );
      if (!completed) {
        return "answer-choice-capacity";
      }
      state.attempts.delete(completed[0]);
    }
    return null;
  };
  var armBrowserReply = (input, context, current, node, valid) => {
    const { state, identity, snapshot } = context;
    const reservation = identity(current);
    const code = browserReplyAdmission(state, reservation);
    if (code) {
      return { code };
    }
    const attempt = {
      node,
      token: input.token,
      reservation,
      before: current.messages.map((row) => row.id),
      allowed: false,
      clicked: false
    };
    const selector = `[data-meta-answer-choice="${input.token}"]`;
    attempt.guard = (event) => {
      const tagged = event.target.closest?.(selector);
      if (!tagged && event.target !== attempt.node && !attempt.node.contains(event.target)) {
        return;
      }
      if (tagged !== attempt.node || !valid(snapshot(), attempt) || attempt.clicked) {
        event.preventDefault();
        event.stopImmediatePropagation();
        attempt.blocked = true;
        return;
      }
      attempt.allowed = true;
      attempt.clicked ||= event.type === "click";
    };
    node.setAttribute("data-meta-answer-choice", input.token);
    watchChoiceView(attempt);
    for (const type of ["pointerdown", "mousedown", "click"]) {
      document.addEventListener(type, attempt.guard, true);
    }
    state.attempts.set(reservation, attempt);
    return { armed: true, selector };
  };

  // js/src/sources/browser-choice-controller.js
  var createChoiceContext = (input, read) => {
    const { spec, expected } = input;
    const key = /* @__PURE__ */ Symbol.for("meta-sovereign.browser-answer-choice.v1");
    const state = window[key] ??= {
      owners: /* @__PURE__ */ new WeakMap(),
      observed: /* @__PURE__ */ new WeakSet(),
      attempts: /* @__PURE__ */ new Map()
    };
    const snapshot = (historyOnly = false) => read(spec, true, historyOnly);
    const identity = (value) => JSON.stringify([value.chat, value.question?.id, value.question?.body]);
    const ownershipIdentity = (value) => JSON.stringify([identity(value), value.pendingTurn]);
    const samePending = (value) => expected.pendingTurn ? JSON.stringify(value.pendingTurn) === JSON.stringify(expected.pendingTurn) : expected.pendingMessages ? JSON.stringify(value.pendingTurn?.messages) === JSON.stringify(expected.pendingMessages) : value.pendingTurn?.messages.length === 1;
    const same = (value) => !value.code && !value.question.outgoing && identity(value) === identity(expected) && samePending(value) && JSON.stringify(value.answerOptions) === JSON.stringify(expected.answerOptions);
    const valueOf = (node) => node ? String("value" in node ? node.value : node.textContent ?? "") : "";
    const writable = (node) => Boolean(node) && !node.matches(
      ':disabled,[disabled],[readonly],[inert],[aria-disabled="true"],[aria-readonly="true"]'
    ) && !node.closest('[inert],[aria-disabled="true"]');
    const write = (node, value) => {
      if (!writable(node)) {
        return false;
      }
      const prototype = node instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
      if (!setter || !("value" in node)) {
        return false;
      }
      state.writing = true;
      try {
        setter.call(node, value);
        node.dispatchEvent(new Event("input", { bubbles: true }));
        node.dispatchEvent(new Event("change", { bubbles: true }));
        return valueOf(node) === value;
      } finally {
        state.writing = false;
      }
    };
    const clearOwned = (current) => {
      const node = current.composer;
      const owner = node && state.owners.get(node);
      if (owner && owner.identity === ownershipIdentity(current) && valueOf(node) === owner.text) {
        const attempt = state.attempts.get(identity(current));
        if (attempt?.allowed && !attempt.confirmed) {
          return false;
        }
        state.owners.delete(node);
        return write(node, "");
      }
      return !valueOf(node);
    };
    const own = (current, text) => {
      const node = current.composer;
      const owner = { identity: ownershipIdentity(current), text };
      state.owners.set(node, owner);
      if (!state.observed.has(node)) {
        state.observed.add(node);
        node.addEventListener("input", () => {
          if (!state.writing) {
            state.owners.delete(node);
          }
        });
      }
      return owner;
    };
    const clean = (attempt) => {
      attempt.clearDraft?.();
      watchChoiceView(attempt, true);
      attempt.node.removeAttribute("data-meta-answer-choice");
      for (const node of document.querySelectorAll("[data-meta-answer-choice]")) {
        if (node.getAttribute("data-meta-answer-choice") === attempt.token) {
          node.removeAttribute("data-meta-answer-choice");
        }
      }
      for (const type of ["pointerdown", "mousedown", "click"]) {
        document.removeEventListener(type, attempt.guard, true);
      }
    };
    return {
      state,
      snapshot,
      identity,
      ownershipIdentity,
      same,
      valueOf,
      writable,
      own,
      write,
      clearOwned,
      clean
    };
  };
  var readChoiceHistory = (_input, { snapshot }) => snapshot(true);
  var readChoicePublic = (_input, context) => {
    const { snapshot, clearOwned, valueOf } = context;
    const current = snapshot();
    if (current.code) {
      return current;
    }
    if (current.optionsShown.length) {
      clearOwned(current);
    }
    const { controls: _controls, composer, ...result } = current;
    return { ...result, hasDraft: Boolean(valueOf(composer)) };
  };
  var prefillChoiceDraft = (input, context) => {
    const { snapshot, same, valueOf, write, own } = context;
    const current = snapshot();
    if (!same(current) || current.strictOptions || !current.composer || valueOf(current.composer)) {
      return { code: "answer-draft-preserved" };
    }
    const node = current.composer;
    if (!write(node, input.text)) {
      return { code: "answer-prefill-unverified" };
    }
    own(current, input.text);
    return same(snapshot()) ? { prefilled: true } : { code: "answer-prefill-unverified" };
  };
  var armChoiceClick = (input, context) => {
    const { option } = input;
    const { snapshot, same, clearOwned, valueOf } = context;
    const current = snapshot();
    const candidates = current.controls?.filter(
      (node) => String(node.textContent).replace(/\s+/gu, " ").trim() === option
    ) ?? [];
    if (!same(current) || !current.strictOptions || candidates.length !== 1) {
      return { code: "answer-choice-changed" };
    }
    if (!clearOwned(current)) {
      return { code: "answer-draft-preserved" };
    }
    return armBrowserReply(
      input,
      context,
      current,
      candidates[0],
      (fresh, attempt) => same(fresh) && fresh.controls.includes(attempt.node) && !valueOf(fresh.composer)
    );
  };
  var matchingChoiceReplies = (input, current, attempt) => {
    const { expected, option } = input;
    const questionIndex = current.messages?.findIndex((row) => row.id === expected.question.id) ?? -1;
    const matchesReply = (row) => row.outgoing && !row.service && !attempt.before.includes(row.id) && row.body === (option ?? input.text);
    return !current.code && current.chat === expected.chat && questionIndex >= 0 ? current.messages.slice(questionIndex + 1).filter(matchesReply) : [];
  };
  var readChoiceReceipt = (input, context) => {
    const { state, snapshot, clean } = context;
    const attempt = [...state.attempts.values()].find(
      (entry) => entry.token === input.token
    );
    if (!attempt) {
      return { code: "send-unknown" };
    }
    const current = snapshot();
    const matches = matchingChoiceReplies(input, current, attempt);
    const confirmed = (input.text === void 0 ? attempt.allowed : attempt.clicked) && matches.length === 1;
    if (confirmed || input.finish) {
      clean(attempt);
    }
    if (confirmed) {
      if (!attempt.confirmed) {
        attempt.reveal = revealChoiceReply(
          input.spec,
          attempt,
          current,
          matches[0]
        );
      }
      attempt.confirmed = true;
      return { sent: true, messageId: matches[0].id, reveal: attempt.reveal };
    }
    if (input.finish && !attempt.allowed && attempt.blocked) {
      state.attempts.delete(attempt.reservation);
      return {
        code: input.text === void 0 ? "answer-choice-changed" : "answer-text-changed",
        dispatched: false
      };
    }
    return { code: "send-unknown", blocked: Boolean(attempt.blocked) };
  };
  var releaseChoiceClick = ({ token }, { state, clean }) => {
    const attempt = [...state.attempts.values()].find(
      (entry) => entry.token === token
    );
    if (attempt) {
      clean(attempt);
    }
    return { released: true };
  };

  // js/src/crm/question-recognition.js
  var W = "[\\p{L}\\p{M}\\p{N}_]";
  var start = (source2) => new RegExp(`^(?:${source2})(?!${W})`, "iu");
  var QUESTION_START = start(
    "\u043A\u0430\u043A|\u0447\u0442\u043E|\u0447\u0435\u043C|\u0433\u0434\u0435|\u043A\u0443\u0434\u0430|\u043E\u0442\u043A\u0443\u0434\u0430|\u043A\u043E\u0433\u0434\u0430|\u043F\u043E\u0447\u0435\u043C\u0443|\u0437\u0430\u0447\u0435\u043C|\u043A\u0442\u043E|\u043A\u0435\u043C|\u043A\u0430\u043A\u043E\u0439|\u043A\u0430\u043A\u0430\u044F|\u043A\u0430\u043A\u043E\u0435|\u043A\u0430\u043A\u0438\u0435|\u0441\u043A\u043E\u043B\u044C\u043A\u043E|\u043C\u043E\u0436\u043D\u043E|\u043D\u0435\u043B\u044C\u0437\u044F \u043B\u0438|\u043D\u0435 \u043F\u043E\u0434\u0441\u043A\u0430\u0436\u0435\u0442\u0435|\u043F\u043E\u0434\u0441\u043A\u0430\u0436\u0438|\u043F\u043E\u0434\u0441\u043A\u0430\u0436\u0438\u0442\u0435|\u0435\u0441\u0442\u044C \u043B\u0438|\u0431\u044B\u043B \u043B\u0438|\u0431\u044B\u043B\u0430 \u043B\u0438|\u0431\u044B\u043B\u0438 \u043B\u0438|how|what|where|when|why|who|which|do you|did you|are you|can you|could you|would you|is there|have you"
  );
  var REQUEST = start(
    "please\\s+(?:tell|share|describe|provide|send)|tell\\s+(?:me|us)|describe\\s+your|share\\s+your|\u0440\u0430\u0441\u0441\u043A\u0430\u0436\u0438\u0442\u0435|\u0440\u0430\u0441\u0441\u043A\u0430\u0436\u0438|\u0443\u043A\u0430\u0436\u0438\u0442\u0435|\u0443\u043A\u0430\u0436\u0438|\u043D\u0430\u043F\u0438\u0448\u0438\u0442\u0435|\u043D\u0430\u043F\u0438\u0448\u0438|\u043F\u0440\u0438\u0448\u043B\u0438\u0442\u0435|\u043F\u0440\u0438\u0448\u043B\u0438|\u0443\u0442\u043E\u0447\u043D\u0438\u0442\u0435|\u0443\u0442\u043E\u0447\u043D\u0438|\u0441\u043E\u043E\u0431\u0449\u0438\u0442\u0435|\u0441\u043E\u043E\u0431\u0449\u0438|\u043E\u043F\u0438\u0448\u0438\u0442\u0435|\u043E\u043F\u0438\u0448\u0438|\u043F\u043E\u0434\u0435\u043B\u0438\u0442\u0435\u0441\u044C|\u043F\u043E\u0434\u0435\u043B\u0438\u0441\u044C|\u043F\u0440\u0438\u0432\u0435\u0434\u0438(?:\u0442\u0435)?\\s+\u043F\u0440\u0438\u043C\u0435\u0440"
  );
  var HINDI_WORD = "\u0915\u094D\u092F\u093E|\u0915\u0939\u093E\u0901|\u0915\u0939\u093E\u0902|\u0915\u092C|\u0915\u094D\u092F\u094B\u0902|\u0915\u0948\u0938\u0947|\u0915\u094C\u0928|\u0915\u093F\u0938(?:\u0915\u093E|\u0915\u0940|\u0915\u0947|\u0947)?|\u0915\u093F\u0924\u0928(?:\u093E|\u0940|\u0947)";
  var HINDI_START = start(HINDI_WORD);
  var HINDI_SUBJECT = new RegExp(
    `^(?:\u0906\u092A|\u0924\u0941\u092E|\u0906\u092A\u0915\u093E|\u0906\u092A\u0915\u0940|\u0906\u092A\u0915\u0947|\u0924\u0941\u092E\u094D\u0939\u093E\u0930\u093E|\u0924\u0941\u092E\u094D\u0939\u093E\u0930\u0940|\u0924\u0941\u092E\u094D\u0939\u093E\u0930\u0947)(?!${W})[^\u0964.!?\\r\\n]{0,100}?(?<!${W})(?:${HINDI_WORD})(?!${W})`,
    "u"
  );
  var HINDI_REQUEST = new RegExp(
    `^(?:\u0915\u0943\u092A\u092F\u093E(?!${W})[^\u0964.!?\\r\\n]{0,160}?(?<!${W}))?(?:\u092C\u0924\u093E\u0907\u090F|\u092C\u0924\u093E\u090F\u0902|\u092C\u0924\u093E\u092F\u0947\u0902|\u092C\u0924\u093E\u0913|\u0938\u093E\u091D\u093E \u0915\u0930\u0947\u0902|\u092D\u0947\u091C\u0947\u0902|\u092A\u094D\u0930\u0926\u093E\u0928 \u0915\u0930\u0947\u0902|\u0909\u0932\u094D\u0932\u0947\u0916 \u0915\u0930\u0947\u0902|\u0932\u093F\u0916\u0947\u0902)(?!${W})`,
    "u"
  );

  // js/src/automation/question-subjects.js
  var names = [
    ["go", ["go", "golang"]],
    ["csharp", ["c#", "\u0441#", "csharp", "c-sharp"]],
    ["cpp", ["c++", "\u0441++", "cpp"]],
    ["c", ["c", "\u0441\u0438"]],
    ["javascript", ["javascript", "js", "\u0434\u0436\u0430\u0432\u0430\u0441\u043A\u0440\u0438\u043F\u0442"]],
    ["typescript", ["typescript", "ts"]],
    ["java", ["java", "\u0434\u0436\u0430\u0432\u0430"]],
    ["python", ["python", "\u043F\u0438\u0442\u043E\u043D"]],
    ["rust", ["rust"]],
    ["ruby", ["ruby"]],
    ["php", ["php"]],
    ["swift", ["swift"]],
    ["kotlin", ["kotlin"]],
    ["scala", ["scala"]],
    ["docker", ["docker", "\u0434\u043E\u043A\u0435\u0440"]],
    ["kubernetes", ["kubernetes", "k8s"]],
    ["mongodb", ["mongodb", "mongo"]],
    ["postgresql", ["postgresql", "postgres"]],
    ["mysql", ["mysql"]],
    ["redis", ["redis"]],
    ["aws", ["aws"]],
    ["azure", ["azure"]],
    ["gcp", ["gcp"]],
    ["react", ["react", "reactjs"]],
    ["angular", ["angular"]],
    ["vue", ["vue", "vuejs"]],
    ["git", ["git", "\u0433\u0438\u0442"]],
    ["github", ["github"]],
    ["linkedin", ["linkedin"]],
    ["telegram", ["telegram", "\u0442\u0435\u043B\u0435\u0433\u0440\u0430\u043C"]],
    ["lead", ["lead", "\u0442\u0438\u043C\u043B\u0438\u0434", "\u0442\u0435\u0445\u043B\u0438\u0434"]],
    ["junior", ["junior"]],
    ["senior", ["senior"]],
    ["usd", ["usd", "\u0434\u043E\u043B\u043B\u0430\u0440", "\u0434\u043E\u043B\u043B\u0430\u0440\u043E\u0432", "dollar", "dollars"]],
    [
      "rub",
      [
        "rub",
        "rur",
        "\u0440\u0443\u0431",
        "\u0440\u0443\u0431\u043B\u0435\u0439",
        "\u0440\u0443\u0431\u043B\u044F\u0445",
        "\u0440\u0443\u0431\u043B\u0438",
        "\u0440\u0443\u0431\u043B\u044C",
        "rubles",
        "roubles"
      ]
    ],
    ["eur", ["eur", "euro", "euros", "\u0435\u0432\u0440\u043E"]],
    ["gbp", ["gbp"]],
    ["inr", ["inr"]],
    ["cny", ["cny", "rmb"]],
    ["vnd", ["vnd"]],
    ["jpy", ["jpy"]],
    ["employment:ip", ["\u0438\u043F"]],
    ["employment:gph", ["\u0433\u043F\u0445"]],
    ["employment:self", ["\u0441\u0430\u043C\u043E\u0437\u0430\u043D\u044F\u0442\u044B\u0439", "\u0441\u0430\u043C\u043E\u0437\u0430\u043D\u044F\u0442\u044B\u043C\u0438", "\u0441\u0430\u043C\u043E\u0437\u0430\u043D\u044F\u0442\u043E\u0441\u0442\u044C"]]
  ];
  var aliases = new Map(
    names.flatMap(([key, values]) => values.map((name) => [name, key]))
  );

  // js/src/automation/question-options.js
  var explicitChoice = /\b(?:choose|select|pick)\s+(?:one|an?\s+option|from)\b|выбер(?:и|ите)\s+(?:один|одну|вариант|из)|(?:एक|कोई)\s+विकल्प\s+चुन|请(?:选择|选取)(?:一个|一项)|选择一个/iu;
  var answerChoiceState = (question, input = {}) => {
    const options = input.options === void 0 ? [] : input.options;
    if (!Array.isArray(options) || options.length > 100 || options.some(
      (option) => typeof option !== "string" || !option.trim() || option.length > 6e3
    ) || input.strictOptions !== void 0 && typeof input.strictOptions !== "boolean") {
      throw new Error(
        "Answer choices require bounded text and a boolean strictOptions"
      );
    }
    return {
      options,
      strictOptions: input.strictOptions === true || options.length > 0 || input.questionMode !== "field" && explicitChoice.test(question)
    };
  };

  // js/src/automation/question-turns.js
  var ACK_WORDS = new Set(
    "\u043E\u043A \u043E\u043A\u0435\u0439 \u0445\u043E\u0440\u043E\u0448\u043E \u043F\u043E\u043D\u044F\u043B \u043F\u043E\u043D\u044F\u043B\u0430 \u0441\u043F\u0430\u0441\u0438\u0431\u043E \u0431\u043B\u0430\u0433\u043E\u0434\u0430\u0440\u044E \u043F\u0440\u0438\u043D\u044F\u0442\u043E \u043E\u0442\u043B\u0438\u0447\u043D\u043E \u044F\u0441\u043D\u043E \u0437\u0430 \u0432\u0430\u0448 \u0432\u0430\u0448\u0438 \u043E\u0442\u0432\u0435\u0442 \u043E\u0442\u0432\u0435\u0442\u044B \u043E\u0442\u043A\u043B\u0438\u043A \u043F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0441\u0442\u0438 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044E \u0443\u0447\u0442\u0443 \u043E\u043F\u044B\u0442 hello hi thanks thank you for the your answer answers details information understood noted okay ok got it \u0928\u092E\u0938\u094D\u0924\u0947 \u0927\u0928\u094D\u092F\u0935\u093E\u0926 \u8C22\u8C22 \u597D\u7684".split(
      " "
    )
  );
  var CONSENT_WORDS = new Set(
    "yes no yeah yep sure okay ok yes of course let s lets continue please thanks thank you maybe perhaps da \u0434\u0430 \u043D\u0435\u0442 \u043A\u043E\u043D\u0435\u0447\u043D\u043E \u0430\u0433\u0430 \u0443\u0433\u0443 \u0445\u043E\u0440\u043E\u0448\u043E \u043E\u043A \u0434\u0430\u0432\u0430\u0439\u0442\u0435 \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u043C \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0430\u0442\u044C \u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0441\u043F\u0430\u0441\u0438\u0431\u043E \u0431\u043B\u0430\u0433\u043E\u0434\u0430\u0440\u044E \u043D\u0435 \u0443\u0432\u0435\u0440\u0435\u043D \u0443\u0432\u0435\u0440\u0435\u043D\u0430 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E \u0939\u093E\u0901 \u0939\u093E\u0902 \u091C\u0940 \u0928\u0939\u0940\u0902 \u0920\u0940\u0915 \u091C\u093E\u0930\u0940 \u0930\u0916\u0947\u0902 \u0927\u0928\u094D\u092F\u0935\u093E\u0926 \u662F \u597D\u7684 \u7EE7\u7EED \u662F\u7684 \u4E0D \u8C22\u8C22".split(
      " "
    )
  );

  // js/src/automation/question-pending-plan.js
  var validPendingMessage = (message) => message && typeof message.id === "string" && Boolean(message.id.trim()) && message.id.length <= 600 && typeof message.body === "string" && Boolean(message.body.trim()) && message.body.length <= 6e3;
  var checkedPendingMessages = (messages, question) => {
    if (!Array.isArray(messages) || !messages.length || messages.length > 20 || !messages.every(validPendingMessage) || new Set(messages.map((message) => message.id)).size !== messages.length || messages.reduce((size, message) => size + message.body.length, 0) > 24e3 || messages.at(-1).body !== question) {
      throw new Error("Pending messages must be a complete bounded turn.");
    }
    return messages.map(({ id, body }) => ({ id, body }));
  };

  // js/src/sources/browser-text-controller.js
  var textReplyOpen = (spec) => {
    const nodes = [
      ...document.querySelectorAll('p,span,div,[role="status"],[role="alert"]')
    ];
    if (nodes.length > 5e3) {
      return false;
    }
    const pattern = new RegExp(spec.textReply.closedText, "iu");
    return !nodes.some(
      (node) => !node.children.length && browserFrameVisible(node) && pattern.test(node.textContent)
    );
  };
  var textReplyButtons = (spec) => [...document.querySelectorAll(spec.textReply.send)].filter(
    (node) => browserFrameVisible(node) && !node.matches(':disabled,[disabled],[aria-disabled="true"]') && !node.closest('[inert],[aria-disabled="true"]')
  );
  var armTextReply = (input, context) => {
    const {
      snapshot,
      same,
      state,
      identity,
      own,
      valueOf,
      write,
      writable,
      clearOwned
    } = context;
    const current = snapshot();
    if (!same(current) || current.strictOptions || !writable(current.composer) || !textReplyOpen(input.spec)) {
      return { code: "answer-text-changed" };
    }
    if (valueOf(current.composer)) {
      return { code: "answer-draft-preserved" };
    }
    const code = browserReplyAdmission(state, identity(current));
    if (code) {
      return { code };
    }
    const composer = current.composer;
    if (!write(composer, input.text)) {
      return { code: "answer-prefill-unverified" };
    }
    const owner = own(current, input.text);
    const valid = (fresh2, attempt2) => same(fresh2) && !fresh2.strictOptions && textReplyOpen(input.spec) && fresh2.composer === composer && writable(composer) && state.owners.get(composer) === owner && valueOf(composer) === input.text && !attempt2.preserveView && textReplyButtons(input.spec).length === 1 && textReplyButtons(input.spec)[0] === attempt2.node;
    const buttons = textReplyButtons(input.spec);
    const fresh = snapshot();
    if (buttons.length !== 1 || !valid(fresh, { node: buttons[0] })) {
      clearOwned(current);
      return { code: "answer-text-changed" };
    }
    const armed = armBrowserReply(input, context, fresh, buttons[0], valid);
    const attempt = state.attempts.get(identity(current));
    if (armed.armed) {
      attempt.clearDraft = () => {
        if (!attempt.allowed && state.owners.get(composer) === owner) {
          clearOwned(current);
        }
      };
    } else {
      clearOwned(current);
    }
    return armed;
  };

  // js/src/sources/browser-choices.js
  var methods = {
    read: readChoicePublic,
    history: readChoiceHistory,
    prefill: prefillChoiceDraft,
    arm: armChoiceClick,
    armText: armTextReply,
    receipt: readChoiceReceipt,
    release: releaseChoiceClick
  };
  var source = `(input) => {
  const watchChoiceView = (${watchChoiceView.toString()});
  const revealChoiceReply = (${revealChoiceReply.toString()});
  const browserFrameVisible = (${browserFrameVisible.toString()});
  const browserReplyAdmission = (${browserReplyAdmission.toString()});
  const matchingChoiceReplies = (${matchingChoiceReplies.toString()});
  const armBrowserReply = (${armBrowserReply.toString()});
  const textReplyButtons = (${textReplyButtons.toString()});
  const textReplyOpen = (${textReplyOpen.toString()});
  const browserPendingTurn = (${browserPendingTurn.toString()});
  const browserChoiceSuggestions = (${browserChoiceSuggestions.toString()});
  const browserChoiceHistory = (${browserChoiceHistory.toString()});
  const context = (${createChoiceContext.toString()})(input, ${readBrowserChoices.toString()});
  const methods = {${Object.entries(methods).map(([name, method]) => `${name}: ${method.toString()}`).join(",")}};
  return methods[input.operation](input, context);
}`;
  var browserChoicePage = new Function(`return (${source})`)();
  var failure3 = (code) => Object.assign(
    new Error(
      {
        "answer-draft-preserved": "The provider composer contains an owner draft; review it before selecting an answer",
        "send-unknown": "The option may have been selected; inspect the provider chat before trying again",
        "send-in-doubt": "This question already has a selection attempt; inspect the provider chat before trying again"
      }[code] ?? "The current provider question or answer controls could not be verified"
    ),
    {
      code,
      fallback: false,
      ...["send-unknown", "send-in-doubt"].includes(code) ? { ambiguous: true, outcome: "unknown" } : {}
    }
  );
  var browserChoiceSpec = (ui) => {
    if (!ui.choices || !ui.location || !ui.messages.idPattern || !ui.messages.outgoing) {
      throw failure3("answer-choice-required");
    }
    return {
      choices: ui.choices,
      location: ui.location,
      messages: ui.messages,
      composer: ui.composer,
      ...ui.textReply ? { textReply: ui.textReply } : {}
    };
  };
  var evaluate = (commander, input) => commander.evaluate({ fn: browserChoicePage, args: [input] });
  var readBrowserHistory = async (commander, ui, target) => {
    const value = await evaluate(commander, {
      spec: browserChoiceSpec(ui),
      operation: "history"
    });
    if (value.code || value.chat !== String(target)) {
      throw failure3(value.code ?? "answer-chat-unverified");
    }
    return value.messages;
  };
  var readBrowserAnswerChoices = async (commander, ui, target) => {
    const value = await evaluate(commander, {
      spec: browserChoiceSpec(ui),
      operation: "read"
    });
    if (value.code || value.chat !== String(target)) {
      throw failure3(value.code ?? "answer-chat-unverified");
    }
    const choices = answerChoiceState(value.question.body, {
      options: value.answerOptions,
      strictOptions: value.strictOptions
    });
    return { ...value, ...choices, answerOptions: choices.options };
  };
  var prefillBrowserAnswer = async (commander, ui, expected, text) => {
    if (typeof text !== "string" || !text.trim() || text.length > 12e3 || answerChoiceState(expected.question.body, {
      options: expected.answerOptions
    }).strictOptions) {
      throw failure3("bad-draft");
    }
    const result = await evaluate(commander, {
      spec: browserChoiceSpec(ui),
      operation: "prefill",
      expected,
      text
    });
    if (!result.prefilled) {
      throw failure3(result.code);
    }
    return result;
  };
  var expectedPendingTurn = (draft, question, prefix) => {
    const pendingTurn = checkedBrowserPendingTurn(draft.answer.pendingTurn, {
      id: question.id.slice(prefix.length),
      body: question.body,
      outgoing: false
    });
    if (pendingTurn === null) {
      throw failure3("answer-choice-required");
    }
    return pendingTurn;
  };
  var expectedPendingMessages = (messages, prefix, question) => {
    if (messages.length === 1) {
      return void 0;
    }
    try {
      if (messages.some((message) => !message.id?.startsWith(prefix))) {
        throw failure3("answer-choice-required");
      }
      return checkedPendingMessages(
        messages.map((message) => ({
          id: message.id.slice(prefix.length),
          body: message.body
        })),
        question.body
      );
    } catch {
      throw failure3("answer-choice-required");
    }
  };
  var expectedQuestion = (draft, target) => {
    const messages = draft.answer?.turn?.messages;
    const question = Array.isArray(messages) && messages.at(-1);
    const prefix = `msg:${draft.source}:${target}:`;
    if (!question || question.id !== draft.answer.message || typeof question.id !== "string" || !question.id.startsWith(prefix) || typeof question.body !== "string" || question.body.length > 6e3 || draft.text !== draft.answer.option || !draft.answer.strictOptions) {
      throw failure3("answer-choice-required");
    }
    let answerOptions;
    try {
      answerOptions = JSON.parse(question.options);
      answerChoiceState(question.body, {
        options: answerOptions,
        strictOptions: true
      });
    } catch {
      throw failure3("answer-choice-required");
    }
    const pendingTurn = expectedPendingTurn(draft, question, prefix);
    const pendingMessages = expectedPendingMessages(messages, prefix, question);
    return {
      chat: String(target),
      question: { id: question.id.slice(prefix.length), body: question.body },
      answerOptions,
      ...pendingTurn ? { pendingTurn } : {},
      ...pendingMessages ? { pendingMessages } : {}
    };
  };
  var validWait = (receiptMs, pollMs) => Number.isSafeInteger(receiptMs) && receiptMs >= 0 && receiptMs <= 3e4 && Number.isSafeInteger(pollMs) && pollMs >= 1 && pollMs <= 1e3;
  var selectBrowserAnswer = async (commander, ui, draft, target, { receiptMs = 1e4, pollMs = 100 } = {}) => {
    if (!validWait(receiptMs, pollMs)) {
      throw failure3("bad-draft");
    }
    const expected = expectedQuestion(draft, target);
    const spec = browserChoiceSpec(ui);
    const result = await dispatchBrowserReply(
      commander,
      {
        spec,
        expected,
        option: draft.answer.option
      },
      { receiptMs, pollMs }
    );
    return {
      via: "browser",
      source: draft.source,
      chat: String(target),
      messageId: result.messageId,
      option: draft.answer.option
    };
  };
  var dispatchBrowserReply = async (commander, request, { receiptMs, pollMs }) => {
    if (!validWait(receiptMs, pollMs)) {
      throw failure3("bad-draft");
    }
    const input = { ...request, token: randomBytes(16).toString("hex") };
    try {
      const armed = await evaluate(commander, {
        ...input,
        operation: input.text === void 0 ? "arm" : "armText"
      });
      if (!armed.armed) {
        throw failure3(armed.code);
      }
      try {
        await commander.clickButton({
          selector: armed.selector,
          scrollIntoView: true,
          waitForNavigation: false,
          waitAfterClick: 0,
          verify: false
        });
      } catch {
      }
      const deadline = Date.now() + receiptMs;
      for (; ; ) {
        let result;
        const finish = Date.now() >= deadline;
        try {
          result = await evaluate(commander, {
            ...input,
            operation: "receipt",
            finish
          });
        } catch {
          throw failure3("send-unknown");
        }
        if (result.sent) {
          return result;
        }
        if (finish) {
          throw failure3(result.code);
        }
        await setTimeout(pollMs);
      }
    } finally {
      try {
        await evaluate(commander, { ...input, operation: "release" });
      } catch {
      }
    }
  };

  // js/src/sources/browser-text-reply.js
  var failure4 = (code) => Object.assign(
    new Error("The frozen provider text reply could not be verified."),
    { code, fallback: false }
  );
  var checkedTextSnapshot = (target, expected) => {
    const question = expected?.question;
    const pendingTurn = question && checkedBrowserPendingTurn(expected.pendingTurn, question);
    if (expected?.chat !== String(target) || expected.strictOptions !== false || !Array.isArray(expected.answerOptions) || expected.answerOptions.length || !question || question.outgoing !== false || !pendingTurn || answerChoiceState(question.body, { options: [] }).strictOptions) {
      throw failure4("bad-draft");
    }
    return {
      chat: String(target),
      strictOptions: false,
      question: { id: question.id, body: question.body, outgoing: false },
      pendingTurn,
      answerOptions: []
    };
  };
  var checkedTextReply = (ui, target, expected, text) => {
    if (!ui.documents || !ui.textReply?.send || !ui.textReply.closedText) {
      throw failure4("answer-text-unavailable");
    }
    if (typeof text !== "string" || !text.trim() || text.length > 12e3) {
      throw failure4("bad-draft");
    }
    return checkedTextSnapshot(target, expected);
  };
  var sendBrowserTextReply = async (commander, ui, target, expected, text, options = {}) => {
    const frozen = checkedTextReply(ui, target, expected, text);
    const result = await dispatchBrowserReply(
      commander,
      { spec: browserChoiceSpec(ui), expected: frozen, text },
      {
        receiptMs: options.receiptMs ?? 1e4,
        pollMs: options.pollMs ?? 100
      }
    );
    return {
      via: "browser",
      source: ui.id,
      chat: String(target),
      messageId: result.messageId,
      text
    };
  };

  // js/src/sources/browser-chat-list-state.js
  var scrollOwnerActive = (state) => state.interrupted || state.inactiveToken && (window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")]?.token !== state.inactiveToken || window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")].interrupted || document.hasFocus()) || (state.drafts ?? []).some(
    ([node, value]) => !node.isConnected || node.value !== value
  ) || state.composer && document.querySelectorAll(state.composer).length !== state.drafts.length;
  var restoreScroll = (state, { restore, history, item, idAttribute }) => {
    if (!restore || scrollOwnerActive(state) || !state.visible(state.root)) {
      return false;
    }
    if (!history) {
      state.root.scrollTop = state.original;
      return true;
    }
    const anchor = [...state.root.querySelectorAll(item)].find(
      (node) => node.getAttribute(idAttribute) === state.anchor?.id
    );
    if (anchor) {
      state.root.scrollTop += anchor.getBoundingClientRect().top - state.root.getBoundingClientRect().top - state.anchor.offset;
      state.restoring = true;
      return true;
    }
    if (!state.restoring) {
      state.root.scrollTop = state.original + (state.reversed ? 0 : state.root.scrollHeight - state.originalHeight);
      state.restoring = true;
    }
    return false;
  };
  var historyAnchor = (root, cells, idAttribute) => {
    const bounds = root.getBoundingClientRect();
    const anchor = cells.find((node) => {
      const rect = node.getBoundingClientRect();
      return rect.bottom > bounds.top && rect.top < bounds.bottom;
    });
    return anchor && {
      id: anchor.getAttribute(idAttribute),
      offset: anchor.getBoundingClientRect().top - bounds.top
    };
  };
  var scrollRoot = (cell) => {
    let root = cell?.parentElement;
    while (root && !/^(?:auto|scroll)$/.test(getComputedStyle(root).overflowY)) {
      root = root.parentElement;
    }
    return root ?? document.scrollingElement;
  };
  var openScroll = ({ token, item, composer, idAttribute, scope, inactiveToken }, visible) => {
    const history = scope === "history";
    const cell = [...document.querySelectorAll(item)].find(visible);
    const root = scrollRoot(cell);
    if (!root || !cell) {
      return { refused: "unavailable" };
    }
    const cells = history ? [...document.querySelectorAll(item)].filter(visible) : [];
    if (history && (cells.length > 500 || cells.some((node) => !root.contains(node)))) {
      return { refused: "unavailable" };
    }
    const state = {
      token,
      inactiveToken,
      root,
      visible,
      original: root.scrollTop,
      originalHeight: root.scrollHeight,
      anchor: history ? historyAnchor(root, cells, idAttribute) : void 0,
      reversed: getComputedStyle(root).flexDirection === "column-reverse",
      composer,
      interrupted: false,
      drafts: composer ? [...document.querySelectorAll(composer)].map((node) => [
        node,
        node.value
      ]) : []
    };
    state.events = [
      "pointerdown",
      "keydown",
      "wheel",
      "touchstart",
      "touchmove",
      "input"
    ];
    state.mark = (event) => {
      if (event.isTrusted || history) {
        state.interrupted = true;
      }
    };
    for (const type of state.events) {
      document.addEventListener(type, state.mark, {
        capture: true,
        passive: true
      });
    }
    state.scroll = (event) => {
      if (event.target === root || root === document.scrollingElement && event.target === document) {
        state.pendingScroll = false;
      }
    };
    document.addEventListener("scroll", state.scroll, {
      capture: true,
      passive: true
    });
    const previous = root.scrollTop;
    root.scrollTop = history && !state.reversed ? root.scrollHeight : 0;
    state.pendingScroll = previous !== root.scrollTop;
    return state;
  };
  var browserScrollState = (input, visible, openScroll2, restoreScroll2, scrollOwnerActive2) => {
    const {
      operation,
      token,
      item,
      top,
      restore,
      scope = "list",
      idAttribute
    } = input;
    const history = scope === "history";
    const key = /* @__PURE__ */ Symbol.for(
      history ? "meta-sovereign.browser-conversation-history.v1" : "meta-sovereign.browser-chat-list.v1"
    );
    const release = (state2) => {
      document.removeEventListener("scroll", state2.scroll, true);
      for (const type of state2.events) {
        document.removeEventListener(type, state2.mark, true);
      }
      const restored = restoreScroll2(state2, {
        restore,
        history,
        item,
        idAttribute
      });
      delete window[key];
      return { state: "released", restored };
    };
    const read = (state2) => {
      if (scrollOwnerActive2(state2)) {
        return { state: "owner-active" };
      }
      if (!visible(state2.root)) {
        return { state: "changed" };
      }
      if (operation === "move") {
        const previous = state2.root.scrollTop;
        state2.root.scrollTop = top;
        state2.pendingScroll = previous !== state2.root.scrollTop;
      }
      const { scrollTop, scrollHeight, clientHeight } = state2.root;
      if (clientHeight <= 0 || !Number.isFinite(scrollHeight)) {
        return { state: "unavailable" };
      }
      return {
        state: "ready",
        top: scrollTop,
        height: scrollHeight,
        view: clientHeight,
        bottom: scrollTop + clientHeight >= scrollHeight - 2,
        loading: Boolean(
          state2.pendingScroll || state2.root.querySelector('[aria-busy="true"], [role="progressbar"]')
        ),
        ...history ? {
          reversed: state2.reversed,
          oldest: state2.reversed ? scrollTop <= -(scrollHeight - clientHeight) + 2 : scrollTop <= 2
        } : {}
      };
    };
    if (operation === "open") {
      if (window[key]) {
        return { state: "busy" };
      }
      if (scrollOwnerActive2({ inactiveToken: input.inactiveToken })) {
        return { state: "owner-active" };
      }
      const state2 = openScroll2(input, visible);
      if (state2.refused) {
        return { state: state2.refused };
      }
      window[key] = state2;
    }
    const state = window[key];
    if (!state || state.token !== token) {
      return { state: "unavailable" };
    }
    if (operation === "restore") {
      restoreScroll2(state, { restore, history, item, idAttribute });
    }
    return operation === "release" ? release(state) : read(state);
  };
  var browserChatListState = new Function(`return (input) => {
  const visible = (${browserFrameVisible.toString()});
  const scrollOwnerActive = (${scrollOwnerActive.toString()});
  const restoreScroll = (${restoreScroll.toString()});
  const historyAnchor = (${historyAnchor.toString()});
  const scrollRoot = (${scrollRoot.toString()});
  const openScroll = (${openScroll.toString()});
  return (${browserScrollState.toString()})(input, visible, openScroll, restoreScroll, scrollOwnerActive);
}`)();

  // js/src/sources/browser-scan-control.js
  var createBrowserScanControl = (document2, spec) => {
    const token = randomUUID();
    return {
      token,
      control: (operation, extra = {}) => document2.evaluate({
        fn: browserChatListState,
        args: [{ ...spec, operation, token, ...extra }]
      })
    };
  };

  // js/src/sources/browser-scan-options.js
  var bounded = (value, fallback, minimum, maximum) => {
    const result = value ?? fallback;
    if (!Number.isInteger(result) || result < minimum || result > maximum) {
      throw Object.assign(new Error("Invalid bounded browser scan setting"), {
        code: "bad-chat-scan",
        fallback: false
      });
    }
    return result;
  };
  var normalizeChatScanOptions = (options = {}) => ({
    limit: bounded(options.limit, 500, 1, 5e3),
    maxPasses: bounded(options.maxPasses, 100, 1, 500),
    budgetMs: bounded(options.budgetMs, 3e4, 100, 12e4),
    waitMs: bounded(options.waitMs, 150, 10, 1e3),
    endWaitMs: bounded(options.endWaitMs, 2e3, 100, 1e4)
  });

  // js/src/sources/browser-conversation-history.js
  var stopped = (historyReason) => {
    throw Object.assign(new Error("Conversation history traversal stopped"), {
      historyReason
    });
  };
  var mergeConversationWindow = (known, incoming) => {
    if (!known.length) {
      return incoming.slice();
    }
    const positions = new Map(known.map((row, index) => [row.id, index]));
    const shared = incoming.findIndex((row) => positions.has(row.id));
    if (shared < 0) {
      stopped("history-gap");
    }
    const offset = positions.get(incoming[shared].id);
    if (shared > 0 && offset !== 0) {
      stopped("history-gap");
    }
    for (let index = shared; index < incoming.length; index++) {
      if (JSON.stringify(incoming[index]) !== JSON.stringify(known[offset + index - shared])) {
        stopped("conversation-changed");
      }
    }
    return [...incoming.slice(0, shared), ...known];
  };
  var releaseConversation = async (control, pause, waitMs, verifyCurrent) => {
    let restored = false;
    let restore;
    try {
      await verifyCurrent?.();
      restore = (await control("status")).state === "ready";
      if (restore) {
        await control("restore", { restore: true });
        await pause(waitMs);
        await verifyCurrent?.();
        restore = (await control("status")).state === "ready";
      }
    } catch {
      restore = false;
    }
    try {
      restored = Boolean((await control("release", { restore })).restored);
    } catch {
    }
    return restored;
  };
  var conversationTracker = (settings, ui, now) => {
    let rows = [];
    let passes = 0;
    let previous;
    let stableSince;
    return {
      get passes() {
        return passes;
      },
      loading() {
        passes++;
      },
      accept(found, state) {
        const merged = mergeConversationWindow(rows, found);
        if (merged.length > settings.limit || merged.reduce((sum, row) => sum + row.body.length, 0) > 1e6) {
          stopped("history-limit");
        }
        rows = merged;
        passes++;
        if (state.oldest && !state.loading && rows[0]?.service && ui.historyScan?.startAtService) {
          return "provider-start";
        }
        const signature = JSON.stringify([state.top, state.height, found]);
        if (state.oldest && !state.loading && signature === previous) {
          stableSince ??= now();
          if (now() - stableSince >= settings.endWaitMs) {
            return "rendered-start";
          }
        } else {
          stableSince = void 0;
        }
        previous = signature;
        return null;
      },
      result(reason, restored) {
        return {
          rows,
          coverage: {
            complete: reason === "provider-start",
            scope: "conversation",
            reason,
            passes
          },
          restored
        };
      }
    };
  };
  var scanBrowserConversation = async (document2, ui, target, options = {}, { now = () => Date.now(), pause = setTimeout } = {}) => {
    const settings = normalizeChatScanOptions(options);
    const { control } = createBrowserScanControl(document2, {
      item: ui.messages.item,
      idAttribute: ui.messages.idAttribute,
      composer: ui.composer,
      scope: "history",
      inactiveToken: options.inactiveToken
    });
    const started = now();
    const observed = conversationTracker(settings, ui, now);
    let reason = "pass-limit";
    let restored;
    const check = async (operation = "status", extra) => {
      if (options.signal?.aborted) {
        stopped("cancelled");
      }
      if (now() - started >= settings.budgetMs) {
        stopped("time-limit");
      }
      await options.verifyCurrent?.();
      const state = await control(operation, extra);
      if (state.state !== "ready") {
        stopped(state.state);
      }
      return state;
    };
    try {
      await check("open");
      while (observed.passes < settings.maxPasses) {
        await pause(settings.waitMs);
        if ((await check()).loading) {
          observed.loading();
          continue;
        }
        const found = (await readBrowserHistory(document2, ui, target)).map(
          ({ strictOptions: _strict, answerOptions: _options, ...row }) => row
        );
        const state = await check();
        const completed = observed.accept(found, state);
        if (completed) {
          reason = completed;
          break;
        }
        await check("move", {
          top: state.top - Math.max(1, Math.floor(state.view * 0.7))
        });
      }
    } catch (error) {
      reason = error.historyReason ?? (error.code === "answer-chat-unverified" ? "document-changed" : "read-failed");
    } finally {
      restored = await releaseConversation(
        control,
        pause,
        settings.waitMs,
        options.verifyRestore ?? options.verifyCurrent
      );
    }
    const result = observed.result(reason, restored);
    if (process.env.MS_BROWSER_HISTORY_DEBUG === "1") {
      console.error("[browser-conversation-history]", {
        ...result.coverage,
        rows: result.rows.length,
        restored
      });
    }
    return result;
  };

  // js/src/sources/browser-answer-watch.js
  var failure5 = () => Object.assign(new Error("The watched provider page changed or closed."), {
    code: "question-watch-page-changed",
    fallback: false
  });
  var openBrowserAnswerWatch = async ({
    commander,
    page: page2,
    ui,
    target,
    queue,
    receiptMs,
    pollMs,
    released
  }) => {
    if (!ui.documents || !page2?.on || !page2?.off) {
      throw failure5();
    }
    const document2 = await resolveBrowserChoiceDocument(
      commander,
      page2,
      ui,
      target
    );
    let changed = false;
    let closed = false;
    let closing;
    const invalidate = () => {
      changed = true;
    };
    const events = ["framenavigated", "framedetached", "close"];
    for (const event of events) {
      page2.on(event, invalidate);
    }
    const pending = /* @__PURE__ */ new Set();
    const verifyCurrent = async (verify) => {
      await verify?.();
      if (closed || changed) {
        throw Object.assign(failure5(), {
          historyReason: closed ? "cancelled" : "document-changed"
        });
      }
    };
    const run = (work) => {
      if (closed || changed) {
        return Promise.reject(failure5());
      }
      const result = queue(async () => {
        if (closed || changed) {
          throw failure5();
        }
        return work();
      });
      pending.add(result);
      result.then(
        () => pending.delete(result),
        () => pending.delete(result)
      );
      return result;
    };
    return {
      read: () => run(() => readBrowserAnswerChoices(document2, ui, target)),
      readInactiveHistory: (options = {}) => {
        normalizeChatScanOptions(options);
        if (!ui.historyScan) {
          throw Object.assign(new Error("Conversation history is unavailable."), {
            code: "unsupported-action",
            fallback: false
          });
        }
        return run(
          () => withInactiveBrowserView(
            document2,
            async (inactive, token) => scanBrowserConversation(document2, ui, target, {
              ...options,
              inactiveToken: token,
              verifyRestore: inactive,
              verifyCurrent: async () => {
                await verifyCurrent();
                await inactive();
              }
            })
          )
        );
      },
      prefill: (expected, text, verify) => run(async () => {
        await verifyCurrent(verify);
        return prefillBrowserAnswer(document2, ui, expected, text);
      }),
      select: (draft, verify) => run(async () => {
        await verifyCurrent(verify);
        return selectBrowserAnswer(document2, ui, draft, target, {
          receiptMs,
          pollMs
        });
      }),
      replyText: (expected, text, verify) => {
        const frozen = checkedTextReply(ui, target, expected, text);
        return run(async () => {
          await verifyCurrent(verify);
          return sendBrowserTextReply(document2, ui, target, frozen, text, {
            receiptMs,
            pollMs
          });
        });
      },
      close() {
        closing ??= (async () => {
          closed = true;
          for (const event of events) {
            page2.off(event, invalidate);
          }
          await Promise.allSettled([...pending]);
          released();
        })();
        return closing;
      }
    };
  };
  return __toCommonJS(stdin_exports);
})();

  const ui={"id":"hh","name":"HeadHunter","loginUrl":"https://hh.ru/account/login","listUrl":"https://hh.ru/chat","loggedIn":"[data-qa^=\"chatik-chat-message-\"], textarea[data-qa=\"text-input\"], iframe[src^=\"https://chatik.hh.ru/\"], [data-qa=\"mainmenu_applicantProfile\"]","loggedOut":"[data-qa=\"account-login-submit\"], form[action*=\"account/login\"]","composer":"textarea[data-qa=\"text-input\"]","location":{"origins":["https://hh.ru","https://www.hh.ru","https://chatik.hh.ru"],"pathPattern":"^/chat/(\\d{1,30})/?$"},"documents":{"ownerOrigins":["https://hh.ru","https://www.hh.ru","https://chatik.hh.ru"],"ancestorOrigins":["https://hh.ru","https://www.hh.ru","https://chatik.hh.ru"],"maxFrames":32},"chatScan":{"pathPattern":"^/chat/?$"},"historyScan":{"startAtService":true},"textReply":{"send":"button[data-qa*=\"send\"]","closedText":"работодатель отключил переписку|переписка будет доступна после приглашения|(?:chat|conversation) (?:is |has been )?closed|(?:messaging|correspondence) (?:is |has been )?disabled"},"choices":{"group":"[class*=\"buttons-wrapper\"], [class*=\"reply-options\"], [data-qa*=\"answer-options\"], [data-qa*=\"question-options\"]","attachedButtons":true,"genericGroup":"[class*=\"buttons-wrapper\"]:not([class*=\"reply-options\"]):not([data-qa*=\"answer-options\"]):not([data-qa*=\"question-options\"])","genericPattern":"^(?:здравствуйте|какая схема оплаты|где находится место работы|можно без опыта|какой график работы|могу работать в гибком графике|у меня есть профильный опыт|hello|नमस्ते|你好)[.!?]*$","button":"button, [role=\"button\"], [role=\"option\"]"},"messages":{"item":"[data-qa^=\"chatik-chat-message-\"]","idAttribute":"data-qa","idPattern":"^chatik-chat-message-(\\d+)$","body":"[data-qa=\"chat-bubble-text\"]","outgoing":"[data-qa=\"status-icon-delivered\"], [data-qa=\"status-icon-read\"], [data-qa=\"status-icon-sent\"]","timestampAttribute":"data-time","serviceTitle":"[data-qa=\"chat-bubble-title\"], [data-qa=\"chat-bubble-author-name\"]","serviceTitlePattern":"^(?:отклик на вакансию|vacancy application|(?:application for|response to) (?:the|a) vacancy|bewerbung)$"},"chats":{"item":"[data-qa^=\"chatik-open-chat-\"], a[href^=\"/chat/\"]","idAttribute":"data-qa","idPattern":"^chatik-open-chat-(\\d{1,30})$","requireId":true,"uniqueIds":true,"link":"a[href^=\"/chat/\"]","linkPattern":"^/chat/(\\d{1,30})(?:[/?#]|$)","title":"[data-qa=\"chat-cell-title\"], [data-qa=\"chat-title\"]","preview":"[class*=\"last-message-color_\"], [data-qa=\"chat-last-message\"]","unread":"[data-qa=\"chat-unread-count\"], [data-qa*=\"badge\"], [data-qa*=\"counter\"]"},"actions":{}}, html="<!doctype html><html lang=\"en\">\n<meta charset=\"utf-8\"><title>Conversation history · isolated fixture</title><style>\nbody{font:16px system-ui;margin:24px;background:#eef2f7;color:#172333}#history{height:220px;width:650px;overflow-y:auto;overflow-anchor:none;background:white;border:1px solid #adb9c9;}#rows{height:1200px;width:100%;position:relative;flex-shrink:0}article{box-sizing:border-box;position:absolute;height:100px;width:100%;padding:12px;border-bottom:1px solid #ddd}p{margin:5px 0}.outgoing{background:#e3f7ea}textarea{width:640px;height:65px;margin-top:12px}pre{white-space:pre-wrap;max-width:760px}\n</style><nav data-qa=\"mainmenu_applicantProfile\">Synthetic applicant profile</nav>\n<h1>Conversation with an earlier manual reply</h1><p>12 records, overlapping mounted windows. Ordinary scroll pane. No real account or messages.</p>\n<div id=\"history\"><div id=\"rows\"></div></div>\n<textarea data-qa=\"text-input\">Owner unfinished draft</textarea><pre id=\"result\">Only the current window is mounted.</pre>\n<script>\nconst ids=[13,8,92,4,73,2,61,9,47,3,38,1], reversed=false, marker=true;\nconst history=document.querySelector('#history'),rows=document.querySelector('#rows'),composer=document.querySelector('textarea');\nconst records=ids.map((id,index)=>({id,index,body:index===0?'':index===2?'I already replied manually.':index===11?'Thank you, we selected another candidate.':'Conversation record '+index,outgoing:index===2}));\nwindow.fixture={records,reads:0,clicks:0,sends:0,jump:false,render};\nfunction render(){const position=reversed?1200-history.clientHeight+history.scrollTop:history.scrollTop;const first=window.fixture.jump?0:Math.max(0,Math.floor(position/100)),last=Math.min(12,first+4);rows.innerHTML=records.slice(first,last).map(record=>'<article class=\"'+(record.outgoing?'outgoing':'')+'\" style=\"top:'+(record.index*100)+'px\" data-qa=\"chatik-chat-message-'+record.id+'\" data-time=\"2026-11-11T10:00:00Z\">'+(record.index===0&&marker?'<strong data-qa=\"chat-bubble-title\">Vacancy application</strong>':'')+'<p data-qa=\"chat-bubble-text\">'+record.body+'</p>'+(record.outgoing?'<span data-qa=\"status-icon-delivered\">Sent</span>':'')+'</article>').join('');}\nhistory.addEventListener('scroll',render);history.scrollTop=reversed?-300:300;render();composer.setSelectionRange(6,16);\n</script></html>";
  const errors=[];page.on('pageerror',error=>errors.push(error.message));
  await page.route('**/*',route=>route.fulfill({contentType:'text/html',body:html}));
  await page.goto('https://hh.ru/chat/7');
  await page.bringToFront();
  let released=0,interrupt=false,owner;
  const snapshot=()=>page.evaluate(()=>({
    top:document.querySelector('#history').scrollTop,
    draft:document.querySelector('textarea').value,
    selection:[document.querySelector('textarea').selectionStart,document.querySelector('textarea').selectionEnd],
    lease:Boolean(window[Symbol.for('meta-sovereign.browser-inactive-view.v1')]),
    history:Boolean(window[Symbol.for('meta-sovereign.browser-conversation-history.v1')]),
    sends:window.fixture.sends,
  }));
  const commander={evaluate:async ({fn,args})=>{
    const value=await page.evaluate(fn,args[0]);
    if(interrupt&&args[0]?.operation==='history'){
      interrupt=false;await page.bringToFront();owner=await snapshot();
    }
    return value;
  }};
  const handle=await inactiveContract.openBrowserAnswerWatch({
    commander,page,ui,target:'7',queue:work=>work(),released:()=>released++,
  });
  const outcomes=[];
  let other;
  try{
    const before=await snapshot();
    let refusal;
    try{await handle.readInactiveHistory({endWaitMs:100});}catch(error){refusal=error.code;}
    if(refusal!=='browser-background-owner-active'||JSON.stringify(before)!==JSON.stringify(await snapshot())) throw new Error('Focused view must remain unchanged');
    outcomes.push({name:'focused-refusal',refusal});
    await page.locator('#result').evaluate((node,value)=>node.textContent=JSON.stringify(value,null,2),outcomes[0]);
    await page.screenshot({path:"/tmp/gh-issue-solver-1794216540735/docs/screenshots/issue-56-inactive-history/mcp-focused-refusal.png",fullPage:true});
    other=await page.context().newPage();await other.bringToFront();
    const receipt=await handle.readInactiveHistory({endWaitMs:100});
    const after=await snapshot();
    if(!receipt.coverage.complete||receipt.rows.length!==12||!receipt.restored||JSON.stringify(after)!==JSON.stringify(before)) throw new Error('Inactive history must preserve the exact owner view');
    outcomes.push({name:'inactive-complete',coverage:receipt.coverage,restored:receipt.restored,owner:after});
    await page.locator('#result').evaluate((node,value)=>node.textContent=JSON.stringify(value,null,2),outcomes[1]);
    await page.screenshot({path:"/tmp/gh-issue-solver-1794216540735/docs/screenshots/issue-56-inactive-history/mcp-restored.png",fullPage:true});
    await other.bringToFront();interrupt=true;refusal=null;
    try{await handle.readInactiveHistory({endWaitMs:100});}catch(error){refusal=error.code;}
    const preserved=await snapshot();
    if(refusal!=='browser-background-owner-active'||JSON.stringify(preserved)!==JSON.stringify({...owner,lease:false,history:false})||preserved.sends) throw new Error('Returning owner must retain the current view');
    outcomes.push({name:'owner-return',refusal,owner:preserved});
    await page.locator('#result').evaluate((node,value)=>node.textContent=JSON.stringify(value,null,2),outcomes[2]);
    await page.screenshot({path:"/tmp/gh-issue-solver-1794216540735/docs/screenshots/issue-56-inactive-history/mcp-owner-return.png",fullPage:true});
  }finally{await handle.close();await other?.close();}
  if(released!==1||errors.length) throw new Error('Owned reader must close without browser errors');
  return {cases:outcomes.length,outcomes,released,pageErrors:errors,liveProvider:false};
}