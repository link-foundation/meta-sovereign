async (page) => {
  const session = await page.context().newCDPSession(page);
  const consoleErrors = [];
  const requestFailures = [];
  page.on('console', (entry) => { if (entry.type() === 'error') consoleErrors.push(entry.text()); });
  page.on('requestfailed', (request) => requestFailures.push({ url: request.url(), error: request.failure()?.errorText }));
  try {
    await session.send('Network.enable');
    await session.send('Network.setCacheDisabled', { cacheDisabled: true });
    return { ...await (async (page) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(String(error)));
  await page.context().grantPermissions(['clipboard-read', 'clipboard-write']);
  await page.addInitScript(({ key, version }) => {
    localStorage.setItem(key, JSON.stringify({ off: true, v: version }));
  }, {"key":"metaSovereignTutorial","version":5});
  await page.goto("http://127.0.0.1:34415");
  const result = [];
  for (const [language, words] of Object.entries({"en":{"diagnostics.title":"Live activity log","diagnostics.hint":"Recent redacted diagnostics from the connected server. Messages and account actions keep their own delivery states. The view keeps at most 300 entries and pauses when closed.","diagnostics.show":"Show activity log","diagnostics.loading":"Loading server diagnostics…","diagnostics.live":"Receiving server activity.","diagnostics.unavailable":"Server diagnostics are unavailable. Retained entries stay visible; reconnection is automatic.","diagnostics.gap":"Older entries have left the bounded server log.","diagnostics.copy":"Copy visible log","diagnostics.copied":"Visible log copied.","diagnostics.copyFailed":"Could not copy. Select the visible text to copy it manually.","diagnostics.empty":"No entries received in this view."},"ru":{"diagnostics.title":"Журнал текущей активности","diagnostics.hint":"Недавняя диагностика подключённого сервера со скрытыми секретами. У сообщений и действий остаются собственные состояния доставки. Здесь хранится не более 300 записей; закрытие приостанавливает обновления.","diagnostics.show":"Показать журнал активности","diagnostics.loading":"Загрузка диагностики сервера…","diagnostics.live":"Получаем события сервера.","diagnostics.unavailable":"Диагностика сервера недоступна. Полученные записи сохранены; подключение восстановится автоматически.","diagnostics.gap":"Старые записи вышли за пределы ограниченного журнала сервера.","diagnostics.copy":"Скопировать видимый журнал","diagnostics.copied":"Видимый журнал скопирован.","diagnostics.copyFailed":"Не удалось скопировать. Выделите видимый текст и скопируйте вручную.","diagnostics.empty":"В этом представлении пока нет записей."},"zh":{"diagnostics.title":"实时活动日志","diagnostics.hint":"查看已连接服务器的近期脱敏诊断信息。消息和账户操作保留各自的投递状态。此视图最多保留 300 条记录，关闭后暂停更新。","diagnostics.show":"显示活动日志","diagnostics.loading":"正在加载服务器诊断信息…","diagnostics.live":"正在接收服务器活动。","diagnostics.unavailable":"服务器诊断信息暂不可用。已有记录仍然显示，系统会自动重新连接。","diagnostics.gap":"较早的记录已超出服务器日志的容量限制。","diagnostics.copy":"复制可见日志","diagnostics.copied":"已复制可见日志。","diagnostics.copyFailed":"无法复制。请选择可见文本并手动复制。","diagnostics.empty":"此视图尚未收到记录。"},"hi":{"diagnostics.title":"लाइव गतिविधि लॉग","diagnostics.hint":"जुड़े सर्वर की हाल की जाँच जानकारी, जिसमें गोपनीय मान छिपे हैं। संदेशों और खाता कार्रवाइयों की डिलीवरी स्थिति अलग रहती है। यहाँ अधिकतम 300 प्रविष्टियाँ रहती हैं और बंद करने पर अपडेट रुकते हैं।","diagnostics.show":"गतिविधि लॉग दिखाएँ","diagnostics.loading":"सर्वर की जाँच जानकारी लोड हो रही है…","diagnostics.live":"सर्वर की गतिविधि मिल रही है।","diagnostics.unavailable":"सर्वर की जाँच जानकारी उपलब्ध नहीं है। पिछली प्रविष्टियाँ दिखती रहेंगी; कनेक्शन अपने आप फिर जुड़ेगा।","diagnostics.gap":"पुरानी प्रविष्टियाँ सर्वर लॉग की सीमा से बाहर हो गई हैं।","diagnostics.copy":"दिख रहा लॉग कॉपी करें","diagnostics.copied":"दिख रहा लॉग कॉपी हो गया।","diagnostics.copyFailed":"कॉपी नहीं हुआ। दिख रहा पाठ चुनकर स्वयं कॉपी करें।","diagnostics.empty":"इस दृश्य में अभी कोई प्रविष्टि नहीं मिली।"}})) {
    await page.evaluate((language) => localStorage.setItem('metaSovereignLocale', language), language);
    await page.setViewportSize({ width: 1180, height: 950 });
    await page.goto("http://127.0.0.1:34415" + '/?diagnostic-review=' + language + '#settings');
    const panel = page.locator('.diagnostics-settings');
    await panel.locator('[data-action=diagnostics-open]').click();
    await panel.getByText(words['diagnostics.live'], { exact: true }).waitFor();
    const text = await panel.locator('pre').textContent();
    if (!text.includes('/synthetic-activity') || text.includes('diagnostics.')) throw Error('Missing redacted live log');
    await panel.locator('[data-action=diagnostics-copy]').click();
    await panel.getByText(words['diagnostics.copied'], { exact: true }).waitFor();
    const copied = await page.evaluate(() => navigator.clipboard.readText());
    if (copied !== text) throw Error('Clipboard receipt mismatch');
    for (const phone of [false, true]) {
      await page.setViewportSize(phone ? { width: 390, height: 844 } : { width: 1180, height: 950 });
      await panel.scrollIntoViewIfNeeded();
      const fits = await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth);
      if (!fits) throw Error(language + ': horizontal overflow');
      await page.screenshot({ path: 'docs/screenshots/issue-56-diagnostics/mcp-' + language + (phone ? '-phone' : '') + '.png' });
    }
    await panel.locator('[data-action=diagnostics-open]').click();
    await panel.locator('[data-diagnostic-logs]').waitFor({ state: 'detached' });
    result.push({ language, copiedVisibleRedactedLog: true, desktopAndPhoneFit: true, collapsedViewDisposed: true });
  }
  if (errors.length) throw Error(JSON.stringify(errors));
  return { result, pageErrors: errors.length, liveProvider: false };
})(page), consoleErrors, requestFailures };
  } finally { await session.detach(); }
}