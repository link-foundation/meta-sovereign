/**
 * Automations (issue #31, PR #34): user-configurable rules of the form
 * "trigger → audience → conditions → action", after the triggers of
 * https://github.com/konard/vk-bot (`{ name, condition, action }` run on
 * new messages or on a schedule) and the daily caps, de-duplication
 * ledger and confirm-before-send habits of
 * https://github.com/konard/hh-job-application-automation.
 *
 * An automation is stored as an `automation:<id>` link:
 *
 *   triggers    [{ kind: 'manual' }]               run on demand (selected
 *                                                  people, an audience)
 *               [{ kind: 'chat-menu' }]            offered in every chat's menu
 *               [{ kind: 'schedule', every: '1d' }]
 *               [{ kind: 'incoming', pattern, flags }]
 *   audience    a people.js audience spec or its text form; defaults to
 *               everyone we have a personal chat with
 *   conditions  { silentDays, mutual, personal, lastFrom, networks,
 *                 cooldownDays }
 *   action      { kind: 'send-template', templates: { informal, formal,
 *                 neutral? }, form: 'auto' | 'informal' | 'formal' }
 *   mode        'safe' — every message is a draft the user confirms in the
 *               chat; 'auto' — sent with typing and human-like pauses
 *   pacing      { minDelayMs, maxDelayMs, typing, charsPerMinute,
 *                 maxTypingMs, dailyCap }
 *   limit       most messages per run
 *
 * Re-engaging dormant contacts (the original ask of issue #31) is just the
 * `reengage-dormant` preset. Everything here is pure over a list of links;
 * sending lives in `./runner.js`.
 */

import { acceptedSummariesFromLinks } from './question-summary-choice.js';
import {
  addressRulesFromPatterns,
  defaultAddressRules,
} from '../crm/address-form.js';
import { addressFormOf } from '../crm/person-learn.js';
import {
  safeRegExp,
  safeRegExpOrNull,
  safeTest,
} from '../patterns/safe-regex.js';
import {
  DAY_MS,
  defaultReengageTemplates,
  findDormantContacts,
  firstName,
  prefillLinkFor,
  renderReengageText,
  templateFor,
} from '../crm/reengage.js';

import { OUTBOX_PREFIX } from './outbox.js';
import {
  normalizeAnswerAction,
  planAnswer,
  QA_RULE_PREFIX,
} from './question-answers.js';
import { QA_POLICY_ID } from './question-policy.js';
import { resolveAnswerProfile } from './question-profiles.js';
import { answerEnvironmentFromMessages } from './question-context.js';
import { chatQuestionTurn, chatAnswerAction } from './question-chat-turn.js';
import { asksQuestion } from './question-match.js';
import { historyOrder } from '../replies/history-order.js';
import {
  SETTINGS_ID,
  normalizeSettings,
  optOutEntry,
  unreachableReason,
} from './safety.js';

/** No automation messages the same chat again within this many days. */
export const DEFAULT_COOLDOWN_DAYS = 7;

export const AUTOMATION_PREFIX = 'automation:';
export const DRAFT_PREFIX = 'automation-draft:';
export const RUN_PREFIX = 'automation-run:';
export const STATE_PREFIX = 'automation-state:';
export const EDIT_PREFIX = 'automation-edit:';
export const AUTOPILOT_PREFIX = 'automation-autopilot:';
export const TRIGGER_KINDS = Object.freeze([
  'manual',
  'chat-menu',
  'schedule',
  'incoming',
]);
export const AUTOMATION_MODES = Object.freeze(['safe', 'auto']);
export const ADDRESS_CHOICES = Object.freeze(['auto', 'informal', 'formal']);

export const DEFAULT_PACING = Object.freeze({
  minDelayMs: 20_000,
  maxDelayMs: 60_000,
  typing: true,
  // vk-bot types at 450 characters per minute.
  charsPerMinute: 450,
  maxTypingMs: 8_000,
  dailyCap: 50,
});

const DEFAULT_CONDITIONS = Object.freeze({
  silentDays: 0,
  mutual: true,
  personal: true,
  lastFrom: 'any',
  networks: null,
  cooldownDays: null,
});

const UNITS = { s: 1000, m: 60_000, h: 3_600_000, d: DAY_MS, w: 7 * DAY_MS };

/** `'90m'`, `'12h'`, `'1d'`, `'2w'` or a number of milliseconds. */
export const parseDuration = (value) => {
  if (typeof value === 'number' && value > 0) {
    return value;
  }
  const match = String(value ?? '')
    .trim()
    .match(/^(\d+(?:\.\d+)?)\s*([smhdw])$/i);
  if (!match) {
    throw new Error(`bad duration "${value}"; use e.g. 30m, 12h, 1d, 2w`);
  }
  return Number(match[1]) * UNITS[match[2].toLowerCase()];
};

const slug = (text) =>
  String(text ?? '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^\p{L}\p{N}]+/gu, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48) || 'automation';

const normalizeTrigger = (trigger) => {
  const kind = String(trigger?.kind ?? 'manual');
  if (!TRIGGER_KINDS.includes(kind)) {
    throw new Error(
      `unknown trigger "${kind}"; known: ${TRIGGER_KINDS.join(', ')}`
    );
  }
  if (kind === 'schedule') {
    parseDuration(trigger.every);
    return { kind, every: trigger.every };
  }
  if (kind === 'incoming') {
    const pattern = String(trigger.pattern ?? '');
    const flags = String(trigger.flags ?? 'iu');
    safeRegExp(pattern, flags);
    return { kind, pattern, flags };
  }
  return { kind };
};

const normalizeAction = (action = {}) => {
  const kind = action.kind ?? 'send-template';
  if (kind === 'answer-questions') {
    return normalizeAnswerAction(action);
  }
  if (kind !== 'send-template') {
    throw new Error(
      `unknown action "${kind}"; known: send-template, answer-questions`
    );
  }
  const form = action.form ?? 'auto';
  if (!ADDRESS_CHOICES.includes(form)) {
    throw new Error(`unknown address form "${form}"`);
  }
  const templates = Object.fromEntries(
    Object.entries(action.templates ?? defaultReengageTemplates).filter(
      ([key, text]) =>
        ['informal', 'formal', 'neutral'].includes(key) &&
        String(text ?? '').trim()
    )
  );
  if (Object.keys(templates).length === 0) {
    throw new Error('the send-template action needs at least one template');
  }
  return {
    kind,
    templates,
    form,
    fallbackForm: action.fallbackForm ?? 'formal',
  };
};

// Issue #31 calls safe mode "safe or debug mode"; both names work.
const normalizeMode = (input = 'safe') => {
  const mode = input === 'debug' ? 'safe' : input;
  if (!AUTOMATION_MODES.includes(mode)) {
    throw new Error(
      `unknown mode "${mode}"; known: ${AUTOMATION_MODES.join(', ')}`
    );
  }
  return mode;
};

const triggersOf = (input) =>
  (
    input.triggers ?? (input.trigger ? [input.trigger] : [{ kind: 'manual' }])
  ).map(normalizeTrigger);

/** Fill defaults and validate; throws a readable Error on bad input. */
export const normalizeAutomation = (input = {}) => {
  const name = String(input.name ?? '').trim() || 'Automation';
  const id =
    String(input.id ?? '').replace(AUTOMATION_PREFIX, '') || slug(name);
  return {
    id: `${AUTOMATION_PREFIX}${id}`,
    tokens: ['automation', id],
    name,
    description: String(input.description ?? ''),
    enabled: input.enabled !== false,
    preset: input.preset ?? null,
    triggers: triggersOf(input),
    audience: input.audience ?? { kind: 'personal' },
    conditions: { ...DEFAULT_CONDITIONS, ...input.conditions },
    action: normalizeAction(input.action),
    mode: normalizeMode(input.mode),
    pacing: { ...DEFAULT_PACING, ...input.pacing },
    limit: Number(input.limit ?? 20),
  };
};

export const automationKey = (automation) =>
  String(automation?.id ?? automation).replace(AUTOMATION_PREFIX, '');

export const hasTrigger = (automation, kind) =>
  automation.triggers.some((t) => t.kind === kind);

/** The `incoming` trigger whose pattern matches `text`, if any. */
export const incomingTrigger = (automation, text) =>
  automation.triggers.find((t) => {
    // A stored pattern that cannot be used (too long, invalid) never fires;
    // one that runs too long counts as no match (R-Z1, ReDoS).
    const regex = t.kind === 'incoming' && safeRegExpOrNull(t.pattern, t.flags);
    return regex ? safeTest(regex, text) : false;
  }) ?? null;

const PRESET_TEXTS = {
  jobs: {
    informal:
      'Привет!\n\nЯ сейчас открыт к новым проектам и вакансиям в автоматизации и разработке. Если у тебя или твоих друзей есть что-то подходящее — буду рад подробностям.',
    formal:
      'Здравствуйте!\n\nЯ сейчас открыт к новым проектам и вакансиям в автоматизации и разработке. Если у Вас или Ваших коллег есть что-то подходящее — буду рад подробностям.',
  },
  contracts: {
    informal:
      'Привет!\n\nБеру проекты на контракт: автоматизация процессов, боты, интеграции. Если тебе или знакомым это может пригодиться — напиши, обсудим.',
    formal:
      'Здравствуйте!\n\nБеру проекты на контракт: автоматизация процессов, боты, интеграции. Если Вам или Вашим коллегам это может пригодиться — напишите, обсудим.',
  },
  greeting: {
    informal: 'Привет! Рад тебя слышать, как дела?',
    formal: 'Здравствуйте! Рад Вас слышать, чем могу помочь?',
  },
};

/**
 * Ready-made automations the user starts from and changes freely. The
 * first one is issue #31's request: say hi to every personal contact we
 * have not talked to for 90 days, "ты" or "вы" detected, one confirmed
 * message at a time.
 */
export const automationPresets = () =>
  [
    {
      id: 'reengage-dormant',
      preset: 'reengage-dormant',
      name: 'Say hi to contacts silent for 90 days',
      description:
        'Personal chats with no messages for 90 days get a hello asking whether they or their friends need help with automation.',
      triggers: [{ kind: 'manual' }, { kind: 'chat-menu' }],
      conditions: { silentDays: 90, mutual: true },
      action: { templates: defaultReengageTemplates },
    },
    {
      id: 'job-search',
      preset: 'job-search',
      name: 'Ask about open positions',
      description:
        'Tell contacts you are open to new roles; pair with an audience of colleagues or recruiters.',
      triggers: [{ kind: 'manual' }, { kind: 'chat-menu' }],
      conditions: { silentDays: 30, mutual: true },
      action: { templates: PRESET_TEXTS.jobs },
      pacing: { dailyCap: 30 },
    },
    {
      id: 'contract-search',
      preset: 'contract-search',
      name: 'Offer contract work',
      description:
        'Let contacts know you take contract projects; intersect lists to reach exactly the right people.',
      triggers: [{ kind: 'manual' }, { kind: 'chat-menu' }],
      conditions: { silentDays: 30, mutual: true },
      action: { templates: PRESET_TEXTS.contracts },
      pacing: { dailyCap: 30 },
    },
    {
      id: 'greet-back',
      preset: 'greet-back',
      name: 'Greet back',
      description:
        'When someone says hi in a personal chat, draft a greeting in the right form (at most once a day).',
      enabled: false,
      triggers: [
        // `\b` only knows ASCII letters, so end the word explicitly.
        {
          kind: 'incoming',
          pattern: '^(привет|здравствуй\\p{L}*|hi|hello)(?![\\p{L}\\p{N}])',
        },
        { kind: 'chat-menu' },
      ],
      conditions: { mutual: false, cooldownDays: 1 },
      action: { templates: PRESET_TEXTS.greeting },
    },
  ].map(normalizeAutomation);

// ---- planning --------------------------------------------------------

const toMs = (value) => {
  const ms = Date.parse(String(value ?? ''));
  return Number.isNaN(ms) ? null : ms;
};

/** `automation-run:<automation>:<source>:<chat>`. */
export const runRecordId = (automation, { source, chat }) =>
  `${RUN_PREFIX}${automationKey(automation)}:${source}:${chat}`;

/** `automation-draft:<automation>:<source>:<chat>`. */
export const draftId = (automation, { source, chat }) =>
  `${DRAFT_PREFIX}${automationKey(automation)}:${source}:${chat}`;

const byId = (links, prefix) =>
  new Map(links.filter((l) => l?.id?.startsWith(prefix)).map((l) => [l.id, l]));

/** A conversation that is not 1:1 — offered from a group chat's menu. */
const groupCandidate = (links, { source, chat }, { isSelf, now }) => {
  const messages = links.filter(
    (l) =>
      l?.id?.startsWith('msg:') &&
      l.source === source &&
      String(l.chat) === String(chat)
  );
  const lastMs = Math.max(...messages.map((m) => toMs(m.timestamp) ?? 0), 0);
  const mine = messages.filter((m) => isSelf(m.sender)).length;
  return {
    key: `${source}:${chat}`,
    source,
    chat: String(chat),
    contact: null,
    name: messages.find((m) => m.chatName)?.chatName ?? null,
    personal: false,
    lastAt: lastMs ? new Date(lastMs).toISOString() : null,
    lastFrom: null,
    daysSilent: lastMs ? Math.floor((now - lastMs) / DAY_MS) : Infinity,
    messageCount: messages.length,
    mine,
    theirs: messages.length - mine,
    messages,
  };
};

/** Someone known only from an audience (a friend we never wrote to). */
const personCandidate = (person) => ({
  key: `${person.source}:${person.personalChat ?? person.user}`,
  source: person.source,
  chat: String(person.personalChat ?? person.user),
  contact: String(person.user),
  name: person.name ?? null,
  personal: true,
  lastAt: null,
  lastFrom: null,
  daysSilent: Infinity,
  messageCount: 0,
  mine: 0,
  theirs: 0,
  messages: [],
});

const pickCandidates = (links, automation, ctx) => {
  const personal = new Map(ctx.contacts.map((c) => [c.key, c]));
  if (ctx.targets) {
    return ctx.targets.map(
      (t) =>
        personal.get(`${t.source}:${t.chat}`) ?? groupCandidate(links, t, ctx)
    );
  }
  if (!ctx.resolveAudience) {
    return ctx.contacts;
  }
  const people = ctx.resolveAudience(links, automation.audience, {
    self: ctx.self,
  });
  return people.map(
    (p) =>
      personal.get(`${p.source}:${p.personalChat ?? p.user}`) ??
      personCandidate(p)
  );
};

const conditionReason = (candidate, c) => {
  if (c.networks?.length && !c.networks.includes(candidate.source)) {
    return 'network';
  }
  if (c.personal && candidate.personal === false) {
    return 'not-personal';
  }
  if (c.mutual && candidate.mine === 0) {
    return 'not-mutual';
  }
  if (candidate.daysSilent < Number(c.silentDays ?? 0)) {
    return 'talked-recently';
  }
  if (c.lastFrom !== 'any' && candidate.lastFrom !== c.lastFrom) {
    return `last-from-${candidate.lastFrom ?? 'nobody'}`;
  }
  return null;
};

// The cooldown in days (R-Z3): the automation's own, else its silence
// condition, else a week: an automation with default conditions never
// writes to the same chat on every run.
const cooldownDaysOf = (automation, settings) => {
  const c = automation.conditions;
  if (c.cooldownDays !== null && c.cooldownDays !== undefined) {
    return Number(c.cooldownDays);
  }
  return Math.max(
    Number(c.silentDays ?? 0),
    settings.cooldownDays ?? DEFAULT_COOLDOWN_DAYS
  );
};

// The outbox knows what really went out, even when the run record was
// not written: a send in doubt blocks until the user decides.
const outboxReason = (candidate, automation, ctx) => {
  const mine = ctx.outbox.get(`${candidate.source}:${candidate.chat}`) ?? [];
  if (mine.some((r) => ['sending', 'unknown'].includes(r.status))) {
    return 'send-unconfirmed';
  }
  const cooldownMs = cooldownDaysOf(automation, ctx.settings) * DAY_MS;
  return mine.some(
    (r) => r.status === 'sent' && ctx.now - (toMs(r.at) ?? 0) < cooldownMs
  )
    ? 'already-sent'
    : null;
};

/** A draft waiting, or a send/skip still inside the cooldown. */
const ledgerReason = (candidate, automation, ctx) => {
  if (ctx.drafts.has(draftId(automation, candidate))) {
    return 'draft-pending';
  }
  const record = ctx.records.get(runRecordId(automation, candidate));
  const cooldownMs = cooldownDaysOf(automation, ctx.settings) * DAY_MS;
  const recordMs = toMs(record?.at);
  const cooling =
    recordMs !== null &&
    ['sent', 'skipped'].includes(record.status) &&
    ctx.now - recordMs < cooldownMs;
  return cooling
    ? `already-${record.status}`
    : outboxReason(candidate, automation, ctx);
};

// Never to be written to: the opt-out list, blocked, left, a deleted
// account, a bot, a channel (R-Z3).
const unreachable = (candidate, ctx) =>
  optOutEntry(ctx.settings, candidate)
    ? 'opted-out'
    : unreachableReason(candidate.messages ?? []);

// A test from a chat's menu skips the conditions (it is *this* chat
// the user wants to try), never the ledger: a waiting draft stays one.
const exclusionReason = (candidate, automation, ctx) =>
  unreachable(candidate, ctx) ??
  (ctx.test ? null : conditionReason(candidate, automation.conditions)) ??
  ledgerReason(candidate, automation, ctx);

// The automation's outbox records, by `source:chat`.
const outboxByChat = (links, automation) => {
  const byChat = new Map();
  for (const l of links) {
    if (l?.id?.startsWith(OUTBOX_PREFIX) && l.owner === automation.id) {
      const key = `${l.source}:${l.chat}`;
      byChat.set(key, [...(byChat.get(key) ?? []), l]);
    }
  }
  return byChat;
};

/** Render the action's text for one candidate, "ты"/"вы" detected. */
export const draftFor = (automation, candidate, { isSelf, rules }) => {
  const { action } = automation;
  const addressForm =
    action.form === 'auto'
      ? addressFormOf(candidate.messages, {
          isSelf,
          rules,
          fallback: action.fallbackForm,
        })
      : { form: action.form, reason: 'chosen' };
  const { messages: _messages, ...summary } = candidate;
  const text = renderReengageText(
    templateFor(action.templates, addressForm.form),
    candidate
  );
  return {
    ...summary,
    id: draftId(automation, candidate),
    automation: automation.id,
    automationName: automation.name,
    form: addressForm.form,
    addressForm,
    text,
    // Written from the user's edited text (R-Y86).
    edited: Boolean(automation.edited?.includes(addressForm.form)),
    prefill: prefillLinkFor({ ...candidate, text }),
  };
};

/** Re-render a draft in the other form when the user overrides it. */
export const redraftWithForm = (automation, draft, form) => {
  if (automation.action.kind === 'answer-questions') {
    return { ...draft, form };
  }
  const text = renderReengageText(
    templateFor(automation.action.templates, form),
    draft
  );
  return {
    ...draft,
    form,
    text,
    edited: Boolean(automation.edited?.includes(form)),
    prefill: prefillLinkFor({ ...draft, text }),
  };
};

/**
 * Who the automation would message now, and why everyone else is left
 * out. `targets` (`[{ source, chat }]`) narrows it to chosen chats — the
 * chat menu and "run on selected people"; otherwise the audience is
 * resolved with `resolveAudience(links, spec)` (people.js). `test: true`
 * with targets ignores the conditions, so a chat menu can try any chat.
 */
// Normalized, with the forms the user's edit stands for (R-Y86).
const plannedAutomation = (input) => ({
  ...normalizeAutomation(input),
  ...(input?.edited ? { edited: input.edited } : {}),
});

// What was drafted, run and sent before, and the safety settings.
const ledgerContext = (links, automation) => ({
  drafts: byId(links, DRAFT_PREFIX),
  records: byId(links, RUN_PREFIX),
  outbox: outboxByChat(links, automation),
  settings: normalizeSettings(links.find((l) => l?.id === SETTINGS_ID) ?? {}),
});

const answerDraft = (
  automation,
  candidate,
  {
    self,
    answerRules,
    answerPolicy,
    acceptedSummaries,
    savedAutomation,
    now,
    modelCandidates,
  }
) => {
  const messages = candidate.messages.toSorted(historyOrder);
  const selected = chatQuestionTurn(
    messages,
    self,
    automation.action.modelDraft
  );
  if (selected.reason) {
    return selected;
  }
  const { latest, question, turn } = selected;
  const answer = planAnswer(question, {
    now,
    rules: answerRules,
    acceptedSummaries,
    policy: answerPolicy,
    ...chatAnswerAction(automation.action),
    ...answerEnvironmentFromMessages(messages, latest),
    source: candidate.source,
    chat: String(candidate.chat),
    options: latest.answerOptions,
    strictOptions: latest.strictOptions,
  });
  if (
    !answer.text &&
    !(
      modelCandidates &&
      automation.action.modelDraft &&
      !answer.noReply &&
      !answer.optionPending &&
      asksQuestion(question)
    )
  ) {
    return {
      reason: answer.noReply
        ? answer.notice
          ? 'notice-no-reply'
          : 'question-summary-complete'
        : 'question-unanswered',
      answer,
    };
  }
  const { messages: _messages, ...summary } = candidate;
  return {
    draft: {
      ...summary,
      id: draftId(automation, candidate),
      automation: automation.id,
      automationName: automation.name,
      form: 'neutral',
      addressForm: { form: 'neutral', reason: 'answer' },
      text: answer.text,
      answer: { ...answer, turn, message: latest.id, savedAutomation },
      edited: false,
      prefill: prefillLinkFor({ ...candidate, text: answer.text }),
    },
  };
};

const selectedAnswerRules = (links, action) =>
  links.filter(
    (link) =>
      link?.id?.startsWith(QA_RULE_PREFIX) &&
      (!action.ruleIds?.length || action.ruleIds.includes(link.id))
  );

const planningContext = (links, automation, options, now) => {
  const { contacts, selfIds, isSelf } = findDormantContacts(links, {
    now,
    days: 0,
    self:
      automation.action.kind === 'answer-questions'
        ? ['me', ...(options.self ?? [])]
        : (options.self ?? []),
    requireMutual: false,
  });
  const ctx = {
    now,
    isSelf,
    self: options.self ?? [],
    contacts: contacts.map((c) => ({ ...c, personal: true })),
    targets: options.targets ?? null,
    test: Boolean(options.test && options.targets),
    resolveAudience: options.resolveAudience ?? null,
    answerRules: selectedAnswerRules(links, automation.action),
    answerPolicy: links.find((link) => link?.id === QA_POLICY_ID) ?? {},
    acceptedSummaries:
      automation.action.kind === 'answer-questions'
        ? (options.acceptedSummaries ??
          acceptedSummariesFromLinks(links, [...selfIds]))
        : undefined,
    savedAutomation: links.some((link) => link?.id === automation.id),
    modelCandidates: options.modelCandidates === true,
    ...ledgerContext(links, automation),
  };
  return { ctx, selfIds, isSelf };
};

export const planAutomation = (links = [], input, options = {}) => {
  const automation = plannedAutomation(input);
  if (automation.action.kind === 'answer-questions') {
    automation.action = resolveAnswerProfile(
      automation.action,
      links.find((link) => link?.id === automation.action.profileId)
    );
  }
  const now = toMs(options.now) ?? Number(options.now ?? Date.now());
  const { ctx, selfIds, isSelf } = planningContext(
    links,
    automation,
    options,
    now
  );
  const rules = [...defaultAddressRules, ...addressRulesFromPatterns(links)];
  const drafts = [];
  const excluded = [];
  const seen = new Set();
  for (const candidate of pickCandidates(links, automation, ctx)) {
    if (seen.has(candidate.key)) {
      continue;
    }
    seen.add(candidate.key);
    const reason = exclusionReason(candidate, automation, ctx);
    if (reason) {
      excluded.push({ key: candidate.key, name: candidate.name, reason });
    } else {
      if (automation.action.kind === 'answer-questions') {
        const result = answerDraft(automation, candidate, ctx);
        if (result.draft) {
          drafts.push(result.draft);
        } else {
          excluded.push({
            key: candidate.key,
            name: candidate.name,
            ...result,
          });
        }
      } else {
        drafts.push(draftFor(automation, candidate, { isSelf, rules }));
      }
    }
  }
  const limit = Number(options.limit ?? automation.limit);
  return {
    automation: automation.id,
    name: automation.name,
    mode: automation.mode,
    generatedAt: new Date(now).toISOString(),
    selfIds: [...selfIds],
    total: drafts.length,
    drafts: limit > 0 ? drafts.slice(0, limit) : drafts,
    excluded,
  };
};

// ---- the user's edit, carried to the next chats (R-Y86) -------------

/** `automation-edit:<automation>`: the text the user last sent, as templates. */
export const editId = (automation) =>
  `${EDIT_PREFIX}${automationKey(automation)}`;

const escapeRegExp = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// A name stands as a word, not inside one ("Ян" in "Январь").
const wordPattern = (word) =>
  new RegExp(
    `(?<![\\p{L}\\p{N}])${escapeRegExp(word)}(?![\\p{L}\\p{N}])`,
    'gu'
  );

/**
 * The text the user sent to one person as a template for the next: their
 * name becomes `{name}`, their first name `{first}`, so the same edit
 * greets the next person by theirs.
 */
export const templateFromText = (text, draft = {}) => {
  let template = String(text ?? '');
  const name = String(draft.name ?? '').trim();
  const first = firstName(name);
  if (name.length >= 2 && name !== first) {
    template = template.replace(wordPattern(name), '{name}');
  }
  if (first.length >= 2) {
    template = template.replace(wordPattern(first), '{first}');
  }
  return template;
};

/** The automation with the user's edited templates in place of its own. */
export const withEdit = (automation, edit) =>
  automation.action.kind === 'send-template' &&
  edit?.templates &&
  Object.keys(edit.templates).length > 0
    ? {
        ...automation,
        edited: Object.keys(edit.templates),
        action: {
          ...automation.action,
          templates: { ...automation.action.templates, ...edit.templates },
        },
      }
    : automation;

/** The edit link after the user sent `text` (null: nothing to keep). */
export const editAfterSend = (automation, before, draft, text, at) => {
  if (automation.action.kind === 'answer-questions') {
    return null;
  }
  const original = automation.action.templates;
  const rendered = renderReengageText(templateFor(original, draft.form), draft);
  const templates = { ...(before?.templates ?? {}) };
  if (String(text).trim() === rendered.trim()) {
    // Sent as the automation wrote it: its own text stands again.
    delete templates[draft.form];
  } else {
    templates[draft.form] = templateFromText(text, draft);
  }
  if (Object.keys(templates).length === 0) {
    return null;
  }
  return {
    id: editId(automation),
    tokens: ['automation-edit', automationKey(automation)],
    automation: automation.id,
    templates,
    at,
  };
};
