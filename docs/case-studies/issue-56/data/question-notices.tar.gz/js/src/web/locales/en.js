import { enAnswerModel } from './en-answer-model.js';
import { enBrowserAnswer } from './en-browser-answer.js';
import { enForms } from './en-forms.js';
import { enSharedProfile } from './en-shared-profile.js';
import { enProfileImport } from './en-profile-import.js';
import { enChatRemoval } from './en-chat-removal.js';
import { enFollowTelegram } from './en-follow-telegram.js';
import { enFollow } from './en-follow.js';
import { enTelegramGreetings } from './en-telegram-greetings.js';
import { enChatUsers } from './en-chat-users.js';
import { enPublication } from './en-publication.js';
import { enBrowser } from './en-browser.js';
// English locale (issue #18). Source language — every other locale
// dictionary mirrors this set of keys exactly. The parity test in
// js/tests/i18n.test.js fails the build if a locale is missing or
// adds a key. Provider names ("Telegram", "WhatsApp", …) and API URLs
// stay in their source form because they are proper nouns / API
// brand identifiers.

import { enChat } from './en-chat.js';
import { enChatMore } from './en-chat-more.js';
import { enChatAccount } from './en-chat-account.js';
import { enFolders } from './en-folders.js';
import { enTranscribe } from './en-transcribe.js';
import { enGithub } from './en-github.js';

import { enConversation } from './en-conversation.js';

import { enFeedback } from './en-feedback.js';

import { enStickers } from './en-stickers.js';

export const en = {
  ...enForms,
  ...enAnswerModel,
  ...enBrowserAnswer,
  ...enSharedProfile,
  ...enProfileImport,
  ...enChatRemoval,
  ...enFollow,
  ...enFollowTelegram,
  ...enFollowBacklink,
  ...enTelegramGreetings,
  ...enChatUsers,
  ...enPublication,
  'backup.schedule': 'Automatic recovery',
  'backup.scheduleHint':
    'Save these settings for scheduled and one-off backups. The first automatic backup runs after the chosen interval.',
  'backup.hours': 'Interval in hours (0 turns it off)',
  'backup.retention': 'Copies of each format to keep (0 keeps all)',
  'backup.formats': 'Independent recovery dumps',
  'backup.format.text': 'Text Lino dump',
  'backup.format.binary': 'Binary Lino dump',
  'backup.format.archive': 'Recovery archive',
  'backup.save': 'Save recovery settings',
  'backup.saved': 'Recovery settings saved.',
  'backup.created':
    'Backup verified; {count} independent recovery dumps verified.',
  'backup.restored': 'Restored {count} records.',
  'backup.working': 'Working…',
  'backup.failed':
    'The operation could not be confirmed. Check the file list before retrying.',
  'backup.refused': 'The operation failed: {reason}',
  'backup.empty': 'No recovery files yet.',
  'backup.rawHint':
    'Independent dumps always exclude secret records, even when the archive is encrypted. They still contain your other data. Keep these files private.',
  'backup.unavailable':
    'File backups require a connected server with archive storage. Connect a supported server to configure recovery.',
  'backup.restoreAsk':
    'Restore {file}? Its records will merge into this server and replace records with the same IDs. The file is checked before any records change.',
  ...enBrowser,
  ...enStickers,
  ...enFeedback,
  ...enConversation,

  'nav.calls': 'Calls',
  'panels.hint': 'Drag to resize. Double-click or press Enter to reset.',
  'panels.navigation': 'Resize navigation',
  'panels.chats': 'Resize chat list',
  'panels.details': 'Resize details',
  ...enChat,
  ...enChatMore,
  ...enChatAccount,
  ...enFolders,
  ...enTranscribe,
  ...enGithub,
  appName: 'meta-sovereign',
  skipLink: 'Skip to main content',
  'header.theme': 'Theme',
  'header.themeAria': 'Toggle dark mode',
  'header.tutorial': 'Tutorial',
  'header.tutorialAria': 'Open tutorial',
  'header.language': 'Language',
  'header.languageAria': 'Select interface language',
  'header.systemDefault': 'System default',
  'header.online': 'Online',
  'header.offline': 'Offline',
  'header.reconnecting': 'Reconnecting',
  'settings.connection.title': 'Connection recovery',
  'settings.connection.browserOnly':
    'Offer browser-only mode after connecting a server or Telegram',
  'settings.connection.hint':
    'Off by default. Temporary disconnects keep your place, retry loading and resume queued messages automatically.',
  'header.telegramOffline':
    'Telegram has not been reachable for a while; it keeps trying. Open the Telegram connection',
  'header.telegramSignIn': 'Telegram ended this session; sign in again',
  'webMode.title': 'Browser-only mode',
  'webMode.body':
    'The app is not connected to a local server, so it works with the data stored in this browser. Imports from mail and messengers, scheduled automations, sync between devices, CV sync and greetings turn on once a local server is running. Start one with Node.js 26.12.1 or newer:',
  'webMode.retrying': 'Looking for your local server automatically.',
  'webMode.retry': 'Check again',
  'webMode.checking': 'Looking for a local server…',
  'webMode.notFound':
    'The browser still cannot connect to the local server. Check that it is running and its certificate is trusted. Retrying automatically.',
  'webMode.download': 'Get the desktop app (server included)',
  'webMode.dismiss': 'Hide',
  'webMode.safari':
    'Safari blocks this HTTPS page from reaching the local HTTP API. Trust the local HTTPS certificate once with node js/bin/meta-sovereign.js trust, then keep using this hosted app. The localhost UI is optional (--local-ui=true).',
  'webMode.openLocal': 'Open the app from the server',
  'webMode.localFound':
    'A server runs at {origin}, but this browser does not let this page reach it. Open the app from the server with the link below.',
  'webMode.trust':
    'To let Safari connect from here, trust the server once: run {command}, or click Trust the server, choose Show Details → visit this website and enter your password. Then click Check again.',
  'webMode.trustLink': 'Trust the server',
  'webMode.localOff':
    'A server runs at {origin}. Its optional localhost UI is disabled; GitHub Pages is the default app. For Safari, enable HTTPS and trust the local certificate. Use --local-ui=true only to enable a local web app.',
  'nav.chat': 'Chat',
  'nav.operator': 'Operator',
  'nav.contacts': 'Contacts',
  'nav.automation': 'Automation',
  'nav.patterns': 'Patterns',
  'nav.replies': 'Replies',
  'nav.facts': 'Facts',
  'nav.audience': 'Audience',
  'nav.broadcast': 'Broadcast',
  'nav.outreach': 'Outreach',
  'nav.profile': 'Profile',
  'nav.backup': 'Backup',
  'nav.status': 'Status',
  'nav.connections': 'Connections',
  // Shorter labels for the phone's bottom bar and the tablet rail.
  'nav.short.automation': 'Automation',
  'nav.short.cv': 'CV sync',
  'nav.short.connections': 'Connections',
  'nav.cv': 'CV sync',
  'nav.greetings': 'Stickers',
  'nav.settings': 'Settings',
  'shell.primaryNavAria': 'Primary navigation',
  'shell.more': 'More',
  'shell.moreAria': 'More sections',
  'common.loading': 'Loading…',
  'common.save': 'Save',
  'common.send': 'Send',
  'common.cancel': 'Cancel',
  'common.preview': 'Preview',
  'common.queue': 'Queue',
  'common.evaluate': 'Evaluate',
  'common.infer': 'Infer',
  'operator.remaining': '{count} conversations remaining',
  'operator.empty': 'No unread conversations',
  'operator.emptyHint':
    'New unread conversations will appear here automatically.',
  'operator.failed':
    'Could not mark this conversation read. Your card is still here; try Done again.',
  'nav.unreadAtLeast': 'At least {count} unread',
  'nav.unread.chat':
    '{count} unread messages across all folders, excluding muted chats',
  'nav.unread.calls': '{count} unread missed calls',
  'nav.unread.operator':
    '{count} unfinished Operator conversations across all folders',
  'nav.unreadCount': '{count} unread',
  'marketplace.apiNote':
    'Optional API and archive access. For browser sign-in and profiles, use Work accounts above.',
  'marketplace.title': 'Work accounts',
  'marketplace.intro':
    'Sign in to Upwork, Fiverr, PeoplePerHour or Wellfound in a browser window on the computer running your local server. Save a profile here to view it in Connections and Profile.',
  'marketplace.show': 'Show session window',
  'marketplace.open': 'Open sign-in browser',
  'marketplace.capture': 'Save this profile',
  'marketplace.close': 'Close session window',
  'marketplace.windowOpen': 'Session window is open',
  'marketplace.windowClosed': 'Session window is closed',
  'marketplace.instructions':
    'Complete sign-in yourself, open your own profile in the same tab, then choose Save this profile. Closing the window keeps its sign-in session for your next visit.',
  'marketplace.noProfile': 'No profile saved yet.',
  'marketplace.viewProfile': 'View profile on the service',
  'marketplace.captured': 'Profile saved {at}',
  'marketplace.signInObserved': 'Sign-in observed {at}',
  'marketplace.working': 'Working…',
  'marketplace.help': 'Profile help',
  'marketplace.needsProfile':
    'Open your own profile in the session window first. Login pages and challenges cannot be saved as a profile.',
  'marketplace.sessionClosed':
    'The session window is closed. Open it again to save your profile.',
  'marketplace.pageChanged':
    'The browser changed pages while reading. Open your profile and try again.',
  'marketplace.browserUnavailable':
    'Browser support is unavailable on the server. Install browser-commander and Playwright there, then try again.',
  'marketplace.serverRequired':
    'Connect to an updated local server to sign in and save these profiles.',
  'marketplace.failed':
    'This action could not finish. Check the session window and try again.',
  'operator.loading': 'Loading unread conversations…',
  'operator.checking': 'Checking unread status with Telegram…',
  'operator.title': 'Operator',
  'operator.next': 'Next (N)',
  'operator.done': 'Done (D)',
  'operator.progress': '{current} / {total}',
  'contacts.title': 'Contacts ({count})',
  'contacts.identity': 'Identity',
  'contacts.networks': 'Networks',
  'contacts.chats': 'Chats',
  'contacts.messages': 'Messages',
  'contacts.lastSeen': 'Last seen',
  'contacts.actions': 'Actions',
  'contacts.message': 'Message',
  'contacts.messageTo': 'Message {name}',
  'contacts.addressBook': 'Address book',
  'contacts.showMore': 'Show more ({count} remaining)',
  'contacts.import.title': 'Import contacts',
  'contacts.import.hint':
    'Import from Contacts on this Mac, including synced iCloud, Google and Exchange accounts, or choose a vCard (.vcf) export. Review before saving. Nothing is uploaded to a messaging service.',
  'contacts.import.system': 'macOS / iCloud contacts',
  'contacts.import.vcard': 'Choose vCard file',
  'contacts.import.server': 'Contact import needs an up-to-date local server.',
  'contacts.import.permission':
    'Allow Contacts access for the app in the macOS permission prompt or in System Settings → Privacy & Security → Contacts, then try again.',
  'contacts.import.expired': 'The preview expired. Preview the contacts again.',
  'contacts.import.unavailable':
    'System Contacts is available on macOS. You can import a vCard export on other systems.',
  'contacts.import.tooLarge': 'Choose a vCard file no larger than 10 MB.',
  'contacts.import.failed': 'Could not import contacts: {error}',
  'contacts.import.summary':
    '{created} new, {updated} to update, {skipped} unchanged or skipped.',
  'contacts.import.apply': 'Import {count} contacts',
  'contacts.import.cancel': 'Cancel',
  'contacts.import.reading': 'Reading contacts… macOS may ask for permission.',
  'contacts.import.importing': 'Saving contacts…',
  'contacts.import.done': 'Imported {count} contacts.',
  'contacts.refresh': 'Refresh contacts',
  'contacts.search': 'Search contacts',
  'automation.title': 'Automation graphs',
  'automation.edges': '{count} edges',
  'patterns.title': 'Patterns',
  'patterns.inferTitle': 'Infer regex from examples',
  'patterns.examplesPlaceholder': 'One example per line',
  'patterns.modeSimple': 'Simple',
  'patterns.modeLcs': 'Lcs (variable gaps)',
  'patterns.idPlaceholder': 'Pattern id (e.g. greet)',
  'patterns.labelPlaceholder': 'Label',
  'patterns.colId': 'ID',
  'patterns.colRegex': 'Regex',
  'replies.title': 'Reply variation groups',
  'replies.newTitle': 'New / update group',
  'replies.idPlaceholder': 'Group id (e.g. thanks)',
  'replies.variationsPlaceholder': 'One variation per line',
  'replies.saveGroup': 'Save group',
  'facts.title': 'Facts ({count})',
  'facts.colQuestion': 'Question',
  'facts.colAnswer': 'Answer',
  'facts.colPattern': 'Pattern',
  'audience.title': 'Audience builder',
  'audience.hint':
    'Operators: AND, OR, NOT, parens. Dimensions: network:, chat:, sender:, kind:, fact:',
  'audience.queryPlaceholder': 'e.g. network:telegram AND chat:general',
  'audience.contactsCount': '{count} contacts',
  'broadcast.title': 'Broadcast',
  'broadcast.sending': 'Sending…',
  'broadcast.sent': 'Sent.',
  'broadcast.partial':
    'Sent to some destinations. Review the remaining results.',
  'broadcast.failed': 'Not sent in this run.',
  'broadcast.unknown':
    'Delivery is uncertain. Check the destination before retrying.',
  'broadcast.queued': 'Queued; delivery has not been confirmed.',
  'broadcast.cancelled': 'Cancelled.',
  'broadcast.unavailable':
    'Connect a supported server to send. Nothing was queued.',
  'broadcast.counts':
    '{sent} sent · {failed} not sent · {unknown} uncertain · {queued} queued',
  'broadcast.placeholder': 'Message for every selected network',
  'outreach.title': 'Outreach',
  'outreach.hint':
    'Mass-personal outreach. Preview always; queue actually dispatches.',
  'outreach.queryPlaceholder':
    'audience query, e.g. network:telegram AND chat:vip',
  'outreach.bodyPlaceholder':
    'Body. Use {name}, {networks}, {chats} to personalise per recipient.',
  'profile.title': 'Profile',
  'profile.namePlaceholder': 'Name',
  'profile.bioPlaceholder': 'Bio',
  'profile.saveProfile': 'Save profile',
  'profile.resumeTitle': 'Resume',
  'profile.titlePlaceholder': 'Job title',
  'profile.bodyPlaceholder': 'Experience',
  'profile.saveResume': 'Save resume',
  'backup.title': 'Backup',
  'backup.hint':
    'Archives live under the server store directory. Tokens and sessions (secret links) are included only when the backup is encrypted: type a passphrase, or start the server with MS_SECRET_PASSPHRASE. A plain backup leaves them out.',
  'backup.passphrasePlaceholder': 'Optional passphrase',
  'backup.keepPlaceholder': 'Keep N (optional)',
  'backup.create': 'Create backup',
  'backup.restore': 'Restore',
  'backup.itemMeta': '{size} bytes - {timestamp} - {state}',
  'backup.encrypted': 'Encrypted',
  'backup.plain': 'Plain',
  'status.title': 'Status',
  'settings.title': 'Settings',
  'settings.intro':
    'App-level preferences live here. Provider credentials, archive imports, and live probes live on the dedicated Connections screen.',
  'settings.openConnections': 'Open Connections',
  'settings.credentials': 'Credentials',
  'settings.optional': '(optional)',
  'settings.storedAs': 'Stored as {id}',
  'settings.saveCredentials': 'Save credentials',
  'settings.saving': 'Saving...',
  'settings.saved': 'Saved.',
  'settings.forget': 'Forget',
  'settings.forgetting': 'Forgetting {label}...',
  'settings.forgotten': '{label} forgotten.',
  'settings.archive': 'Archive import',
  'settings.archivePasteHint': 'Or paste the archive contents below:',
  'settings.archivePastePlaceholder': 'Paste archive contents here',
  'settings.archivePasteWith': 'Paste {label} contents',
  'settings.importPasted': 'Import pasted contents',
  'settings.uploading': 'Sending {label} to the local server... {percent}%',
  'settings.importing': 'Importing {label}...',
  'settings.importedCount': 'Imported {count} messages from {label}.',
  'settings.importFailed': 'Import failed: {message}',
  'settings.nothingToImport': 'Nothing to import.',
  'settings.docsLink': 'How to obtain the credentials ↗',
  'settings.credentialsSaved': 'Credentials saved',
  'settings.noCredentials': 'No credentials yet',
  'settings.probe.idle': 'Endpoint: {url}',
  'settings.probe.notReady': 'Enter a token to enable probe',
  'settings.probe.button': 'Try directly',
  'settings.probe.probing': 'Probing...',
  'settings.probe.connected': 'Connected (HTTP {status})',
  'settings.probe.httpHint': 'API responded with {status}. {hint}',
  'settings.probe.httpNoHint': 'API responded with {status}.',
  'settings.probe.cors':
    'Browser blocked the request (CORS). Start a local server below to proxy the call.',
  'settings.probe.network': 'Network error: {message}.',
  'settings.probe.fetchFailed': 'Fetch failed',
  'guide.connectFirstHint':
    'You must connect a provider first before any data can show up here.',
  'guide.openSettings': 'Open {target}',
  'guide.openSettingsTarget': 'Connections → {label}',
  'guide.openSettingsRoot': 'Connections',
  'guide.openConnections': 'Open {target}',
  'guide.openConnectionsTarget': 'Connections → {label}',
  'guide.openConnectionsRoot': 'Connections',
  'guide.probeDisabled':
    'Enter credentials in Connections to enable the {label} probe.',
  'guide.useThisServer': 'Use this server',
  'guide.fallbackTitle': 'Nothing here yet.',
  'guide.filesLabel': 'Files: {hint}',
  'guide.envVarLabel': 'Env var: {name}',
  'guide.localServer.title': 'Start a local server to unblock this provider',
  'guide.localServer.body':
    'A same-origin local server proxies the provider request and side-steps the browser CORS rule. Pick the runtime you have installed.',
  'guide.localServer.rust': 'Rust (recommended)',
  'guide.localServer.rustHint':
    'Uses the pure-Rust binary from this repository. Defaults to http://127.0.0.1:8787.',
  'guide.localServer.node': 'Node / Bun / Deno',
  'guide.localServer.nodeHint':
    'Reuses the published JS server. Defaults to http://127.0.0.1:8787.',
  'guide.localServer.github': 'Straight from GitHub',
  'guide.localServer.githubHint':
    'Use this while npm answers 404: npx fetches the same server from the GitHub repository. Defaults to http://127.0.0.1:8787.',
  'guide.localServer.docker': 'Docker',
  'guide.localServer.dockerHint':
    'Spins up the same JS server in a container. See docker/web.Dockerfile.',
  'guide.localServer.overrideHint':
    'Once the server is running, paste its URL below and click "use this server" — the SPA will store it and reload.',
  'guide.chat.title': 'Your unified inbox starts empty.',
  'guide.chat.body':
    'meta-sovereign keeps every chat from every connected service in one place. Open Connections to connect a provider or import an exported archive, then come back here.',
  'guide.operator.title': 'Operator queue is empty.',
  'guide.operator.body':
    'The operator card stream walks you through unread messages chat by chat. Open Connections and add a chat-capable provider to start the queue.',
  'guide.contacts.title': 'No contacts yet.',
  'guide.contacts.body':
    'Contacts are aggregated from every connected provider so the same person across networks shows up once. Open Connections to add a provider and populate this list.',
  'guide.automation.title': 'No automation graphs yet.',
  'guide.automation.body':
    'Automation graphs route incoming messages from a pattern to a reply variation. Open Connections to import provider data before building automations.',
  'guide.patterns.title': 'No patterns yet.',
  'guide.patterns.body':
    'Patterns are inferred from example messages. Open Connections to connect a provider or import an archive, then return with examples to infer from.',
  'guide.replies.title': 'No reply variation groups yet.',
  'guide.replies.body':
    'Reply groups are extracted from your previous outgoing messages by fuzzy similarity. Open Connections to add a chat-capable provider and seed your reply library.',
  'guide.facts.title': 'No facts extracted yet.',
  'guide.facts.body':
    'Facts are question -> answer pairs extracted across messages by your patterns. Open Connections to gather provider data, then add a capture pattern here.',
  'guide.audience.title': 'Build your first audience.',
  'guide.audience.body':
    'Cross-reference contacts using AND/OR/NOT plus dimensions like network:, chat:, sender:, kind:, fact:. Open Connections to add at least one provider first.',
  'guide.broadcast.title': 'No broadcast targets yet.',
  'guide.broadcast.body':
    'Broadcasts post the same message to every connected feed. Open Connections to connect a public-posting provider and enable target checkboxes.',
  'guide.outreach.title': 'No outreach surface yet.',
  'guide.outreach.body':
    'Mass-personal outreach sends a templated message 1:1 to each contact in an audience query. Open Connections to add a chat-capable provider first.',
  'guide.profile.title': 'No profile yet.',
  'guide.profile.body':
    'Edit your profile and resume here; saves are pushed to every connected provider. Open Connections to add at least one provider for profile sync.',
  'guide.backup.title': 'No backup archives yet.',
  'guide.backup.body':
    'Backups are encrypted-at-rest archives of the local store. Set a passphrase above, click "create backup" once you have data worth saving, or start a local server first if you want backups to live on disk.',
  'guide.status.title': 'Status is showing the local store only.',
  'guide.status.body':
    'Status fields appear once a server is reachable. Either start a local server below, or keep working fully offline — the SPA writes straight to your browser store.',
  'guide.connections.title': 'Connections',
  'guide.connections.body':
    'External services live on this dedicated screen. Pick a provider to enter its credentials, upload an archive, and probe the live API. Settings only keeps app-level preferences.',
  'guide.cv.title': 'CV synchronisation',
  'guide.cv.body':
    'This screen drives a real browser session over your job-platform profiles: it reads each CV, compares them field by field, and only writes when you apply a sync. Sign in to each platform once in the browser profile the local server uses — no API keys exist for most of these boards.',
  'guide.greetings.title': 'Stickers',
  'guide.greetings.body':
    'Open dialogs in bulk with a "hi" or a greeting sticker, the way konard/vk-bot does on VK. Connect a network first: listing stickers live and sending use the tokens the local server keeps.',
  'guide.settings.title': 'Settings',
  'guide.settings.body':
    'App-level preferences live here. Provider credentials, archive imports, and live probes live on the dedicated Connections screen.',
  'connections.title': 'Connections',
  'connections.intro':
    'Start with "Import with browser": the app opens the service, you download your data there, and it is imported automatically. The most used services come first.',
  'connections.state.connected': 'Connected',
  'connections.state.notConnected': 'Not connected',
  'connections.state.actionRequired': 'Action required',
  'connections.state.browserSession': 'Browser session',
  'connections.session.login': 'Open the sign-in page',
  'connections.session.profile': 'Open the profile page',
  'connections.session.openCv': 'Open the CV screen',
  'connections.openDetail': 'Set up',
  'connections.controlsTitle': 'Connection controls',
  'autoImport.title': 'Import with browser',
  'autoImport.intro':
    'Opens {service} in a separate browser window. Sign in, start the data export there, and every file you download is imported automatically. You stay signed in for next time.',
  'autoImport.introCapture':
    'Opens {service} in a separate browser window. Sign in, open a chat and press "Capture this chat". Downloaded export files are imported automatically too.',
  'autoImport.start': 'Open browser',
  'autoImport.capture': 'Capture this chat',
  'autoImport.finish': 'Finish',
  'autoImport.state.launching': 'Opening the browser…',
  'autoImport.state.waiting': 'The browser is open. Waiting for your export…',
  'autoImport.state.importing': 'Importing…',
  'autoImport.state.done': 'Finished.',
  'autoImport.state.stopped': 'Stopped after a long pause.',
  'autoImport.state.failed': 'Could not open the browser: {error}',
  'autoImport.imported': 'Messages imported: {count}',
  'autoImport.unavailable':
    'Browser import needs the meta-sovereign server running on this computer.',
  'autoImport.unavailableReason': 'Browser import is unavailable: {reason}',
  'common.cancelled': 'Cancelled. Nothing was sent.',
  'outreach.send': 'Send',
  'outreach.confirmSend':
    'Send {count, plural, one {# message} other {# messages}} to these people now?',
  'greetings.confirmSend':
    'Send {count, plural, one {# greeting} other {# greetings}} now?',
  'cv.confirmApply':
    'Write {count, plural, one {# change} other {# changes}} to your CV on the job platforms now?',
  'profile.savedLocally':
    'Saved on this device. Nothing was changed on other services.',
  'profile.publishTitle': 'Update other services',
  'profile.publishHint':
    'Saving keeps your profile and CV here. To change them on other services, tick the networks and confirm what will change.',
  'profile.publish.profile': 'Update profile there',
  'profile.publish.resume': 'Update CV there',
  'profile.confirmPublish.profile':
    'Update your profile on {networks}? People there will see the change.',
  'profile.confirmPublish.resume':
    'Update your CV on {networks}? Employers there will see the change.',
  'settings.privacy.title': 'Privacy',
  'settings.shareTyping': 'Show others when I am typing',
  'settings.shareTypingHint':
    'Off by default. When on, VK and Telegram show "typing…" to the person you are writing to.',
  'settings.readReceipts': 'Mark chats as read when I read them',
  'settings.readReceiptsHint':
    'On by default, as in Telegram’s own apps. When off, reading a chat here does not mark it read on Telegram: the sender does not see ✓✓ and unread counts stay.',
  'settings.notify.title': 'Notifications',
  'settings.notify.on': 'Show new messages as notifications',
  'settings.notify.preview': 'Show the sender and the text',
  'settings.notify.count': 'Unread count in the page title',
  'settings.notify.granted': 'This browser shows notifications from this page.',
  'settings.notify.default':
    'The browser will ask to allow notifications when you turn them on.',
  'settings.notify.denied':
    'Notifications are blocked for this page in the browser’s settings.',
  'settings.notify.unsupported': 'This browser cannot show notifications.',
  // Telegram notification settings (R-Y157).
  'settings.notifyTg.title': 'Telegram notifications',
  'settings.notifyTg.intro':
    'Kept in your Telegram account, so your other devices follow it.',
  'settings.notifyTg.users': 'Private chats',
  'settings.notifyTg.chats': 'Groups',
  'settings.notifyTg.broadcasts': 'Channels',
  'settings.notifyTg.on': 'Notifications',
  'settings.notifyTg.preview': 'Message preview',
  'settings.notifyTg.stories': 'Stories notifications',
  'settings.notifyTg.exceptions': 'Exceptions: {count}',
  'settings.notifyTg.noExceptions': 'No exceptions',
  'settings.notifyTg.muted': 'Muted',
  'settings.notifyTg.mutedUntil': 'Muted until {time}',
  'settings.notifyTg.unmuted': 'Unmuted',
  'settings.notifyTg.custom': 'Custom',
  'settings.notifyTg.failed': 'Telegram did not accept the change.',
  'connections.enterManually': 'Enter manually',
  'connections.howToConnect': 'How to connect',
  'connections.recommended': 'Recommended',
  'connections.users': '{count} users',
  'connections.signedInFrom': 'Signed in via {browsers}',
  'autoImport.signedInFrom':
    'The window opens with your sign-in from {browsers}.',
  'signIns.title': 'Use your browser sign-ins',
  'signIns.intro':
    'See which services you are already signed in to in Chrome, Safari, Firefox and other browsers, and open the import window signed in. Your browsers are only read, and nothing leaves this computer.',
  'signIns.scan': 'Find sign-ins',
  'signIns.rescan': 'Look again',
  'signIns.scanning': 'Looking through your browsers…',
  'signIns.none': 'No browsers found on this computer.',
  'signIns.default': 'default browser',
  'signIns.found': 'Signed in to {services}',
  'signIns.nothing': 'Not signed in to any of these services',
  'signIns.needsAccess': 'Needs Full Disk Access',
  'signIns.error': 'Could not read it: {error}',
  'signIns.use': 'Use these sign-ins',
  'signIns.importing':
    'Copying sign-ins… Your browser or macOS may ask for permission.',
  'signIns.ready': 'Ready: {services}. Each import window opens signed in.',
  'signIns.readyNone': 'No sign-ins were copied.',
  'signIns.fdaTitle': 'Allow access to Safari',
  'signIns.fdaBody':
    'macOS protects Safari data. In System Settings → Privacy & Security → Full Disk Access, turn on {app}, then restart the meta-sovereign server.',
  'signIns.fdaOpen': 'Open System Settings',

  // Find Telegram sign-ins (bot tokens and user sessions) on this computer.
  'telegramSessions.title': 'Find Telegram sessions on this computer',
  'telegramSessions.intro':
    'Looks through your project folders for Telegram sign-ins you already have — bot tokens and user sessions — collapses duplicates, checks each one still works, and lists one per account. Everything stays on this computer; only you connect one.',
  'telegramSessions.scan': 'Find my Telegram sessions',
  'telegramSessions.rescan': 'Look again',
  'telegramSessions.scanning': 'Finding and checking your sessions…',
  'telegramSessions.none': 'No Telegram sign-ins found in those folders.',
  'telegramSessions.connect': 'Connect',
  'telegramSessions.kindBot': 'bot token',
  'telegramSessions.kindUser': 'user session',
  'telegramSessions.kindTelethon': 'Telethon session file',
  'telegramSessions.badgeBot': 'Bot',
  'telegramSessions.badgeUser': 'User',
  'telegramSessions.verified': 'confirmed with Telegram',
  'telegramSessions.telethonHint': 'open this project to sign in',
  'telegramSessions.typeBot': 'Bot token',
  'telegramSessions.typeSession': 'Login by session',
  'telegramSessions.typePassword': 'Login by phone & password',
  'telegramSessions.more': '+{n} more',
  'telegramSessions.less': 'Show less',
  'telegramSessions.signIn': 'Sign in',
  'telegramSessions.connected': 'Connected',
  'telegramSessions.unconfirmed':
    'The session import was not confirmed. Your previous connection is retained; check Telegram and try again.',

  // Sign in to a Telegram user account over MTProto (GramJS), like konard/telegram-bot.
  'telegramLogin.title': 'Log in with your Telegram account',
  'telegramLogin.intro':
    'Sign in with your phone like Telegram Desktop — api_id, api_hash and your number, then the code Telegram sends you (and your 2FA password if you have one). The session is saved here for next time.',
  'telegramLogin.apiId': 'API ID',
  'telegramLogin.apiHash': 'API hash',
  'telegramLogin.phone': 'Phone number',
  'telegramLogin.code': 'Login code',
  'telegramLogin.password': '2FA password (if you have one)',
  'telegramLogin.sendCode': 'Send code',
  'telegramLogin.signIn': 'Sign in',
  'telegramLogin.working': 'Working…',
  'telegramLogin.connected': 'Signed in',
  'telegramLogin.you': 'your account',
  'telegramLogin.codeSent': 'Telegram sent a code to your app. Enter it below.',
  'telegramLogin.twoFactor':
    'Your account has a 2FA password. Enter it to finish.',
  // Sign in by QR code (R-Y203)
  'telegramLogin.byQr': 'Log in by QR code',
  'telegramLogin.byPhone': 'Log in by phone number',
  'telegramLogin.qrStart': 'Show QR code',
  'telegramLogin.qrAlt': 'QR code to log in to Telegram',
  'telegramLogin.qrTitle': 'Log in to Telegram by QR code',
  'telegramLogin.qrStep1': 'Open Telegram on your phone',
  'telegramLogin.qrStep2': 'Go to Settings > Devices > Link Desktop Device',
  'telegramLogin.qrStep3': 'Point your phone at this screen to confirm login',
  'telegramLogin.qrWaiting': 'Waiting for you to scan the code…',
  // BEGIN setup-steps (issue #25 R-N8) — auto-generated
  'connections.email.setup.step1.title': 'Prepare your Email credential',
  'connections.email.setup.step1.body':
    'Open the linked docs and create an API token, OAuth credential, or developer key as the upstream service requires.',
  'connections.email.setup.step2.title': 'Save it inside meta-sovereign',
  'connections.email.setup.step2.body':
    'Paste the credential into the field on this screen. The value is stored under a `secret:*` key and never leaves your browser.',
  'connections.email.setup.step3.title': 'Run the probe',
  'connections.email.setup.step3.body':
    'Tap "Probe connection" — a successful response confirms the credential. Failures surface a translated hint with the exact next action.',
  'connections.telegram.setup.step1.title': 'Prepare your Telegram credential',
  'connections.telegram.setup.step1.body':
    'Open the linked docs and create an API token, OAuth credential, or developer key as the upstream service requires.',
  'connections.telegram.setup.step2.title': 'Save it inside meta-sovereign',
  'connections.telegram.setup.step2.body':
    'Paste the credential into the field on this screen. The value is stored under a `secret:*` key and never leaves your browser.',
  'connections.telegram.setup.step3.title': 'Run the probe',
  'connections.telegram.setup.step3.body':
    'Tap "Probe connection" — a successful response confirms the credential. Failures surface a translated hint with the exact next action.',
  'connections.vk.setup.step1.title': 'Prepare your VK credential',
  'connections.vk.setup.step1.body':
    'Open the linked docs and create an API token, OAuth credential, or developer key as the upstream service requires.',
  'connections.vk.setup.step2.title': 'Save it inside meta-sovereign',
  'connections.vk.setup.step2.body':
    'Paste the credential into the field on this screen. The value is stored under a `secret:*` key and never leaves your browser.',
  'connections.vk.setup.step3.title': 'Run the probe',
  'connections.vk.setup.step3.body':
    'Tap "Probe connection" — a successful response confirms the credential. Failures surface a translated hint with the exact next action.',
  'connections.x.setup.step1.title': 'Prepare your X (Twitter) credential',
  'connections.x.setup.step1.body':
    'Open the linked docs and create an API token, OAuth credential, or developer key as the upstream service requires.',
  'connections.x.setup.step2.title': 'Save it inside meta-sovereign',
  'connections.x.setup.step2.body':
    'Paste the credential into the field on this screen. The value is stored under a `secret:*` key and never leaves your browser.',
  'connections.x.setup.step3.title': 'Run the probe',
  'connections.x.setup.step3.body':
    'Tap "Probe connection" — a successful response confirms the credential. Failures surface a translated hint with the exact next action.',
  'connections.whatsapp.setup.step1.title': 'Prepare your WhatsApp credential',
  'connections.whatsapp.setup.step1.body':
    'Open the linked docs and create an API token, OAuth credential, or developer key as the upstream service requires.',
  'connections.whatsapp.setup.step2.title': 'Save it inside meta-sovereign',
  'connections.whatsapp.setup.step2.body':
    'Paste the credential into the field on this screen. The value is stored under a `secret:*` key and never leaves your browser.',
  'connections.whatsapp.setup.step3.title': 'Run the probe',
  'connections.whatsapp.setup.step3.body':
    'Tap "Probe connection" — a successful response confirms the credential. Failures surface a translated hint with the exact next action.',
  'connections.facebook.setup.step1.title': 'Prepare your Facebook credential',
  'connections.facebook.setup.step1.body':
    'Open the linked docs and create an API token, OAuth credential, or developer key as the upstream service requires.',
  'connections.facebook.setup.step2.title': 'Save it inside meta-sovereign',
  'connections.facebook.setup.step2.body':
    'Paste the credential into the field on this screen. The value is stored under a `secret:*` key and never leaves your browser.',
  'connections.facebook.setup.step3.title': 'Run the probe',
  'connections.facebook.setup.step3.body':
    'Tap "Probe connection" — a successful response confirms the credential. Failures surface a translated hint with the exact next action.',
  'connections.linkedin.setup.step1.title': 'Prepare your LinkedIn credential',
  'connections.linkedin.setup.step1.body':
    'Open the linked docs and create an API token, OAuth credential, or developer key as the upstream service requires.',
  'connections.linkedin.setup.step2.title': 'Save it inside meta-sovereign',
  'connections.linkedin.setup.step2.body':
    'Paste the credential into the field on this screen. The value is stored under a `secret:*` key and never leaves your browser.',
  'connections.linkedin.setup.step3.title': 'Run the probe',
  'connections.linkedin.setup.step3.body':
    'Tap "Probe connection" — a successful response confirms the credential. Failures surface a translated hint with the exact next action.',
  'connections.habr-career.setup.step1.title':
    'Prepare your career.habr.com credential',
  'connections.habr-career.setup.step1.body':
    'Open the linked docs and create an API token, OAuth credential, or developer key as the upstream service requires.',
  'connections.habr-career.setup.step2.title': 'Save it inside meta-sovereign',
  'connections.habr-career.setup.step2.body':
    'Paste the credential into the field on this screen. The value is stored under a `secret:*` key and never leaves your browser.',
  'connections.habr-career.setup.step3.title': 'Run the probe',
  'connections.habr-career.setup.step3.body':
    'Tap "Probe connection" — a successful response confirms the credential. Failures surface a translated hint with the exact next action.',
  'connections.hh.setup.step1.title': 'Prepare your hh.ru credential',
  'connections.hh.setup.step1.body':
    'Open the linked docs and create an API token, OAuth credential, or developer key as the upstream service requires.',
  'connections.hh.setup.step2.title': 'Save it inside meta-sovereign',
  'connections.hh.setup.step2.body':
    'Paste the credential into the field on this screen. The value is stored under a `secret:*` key and never leaves your browser.',
  'connections.hh.setup.step3.title': 'Run the probe',
  'connections.hh.setup.step3.body':
    'Tap "Probe connection" — a successful response confirms the credential. Failures surface a translated hint with the exact next action.',
  'connections.github.setup.step1.title': 'Prepare your GitHub credential',
  'connections.github.setup.step1.body':
    'Open the linked docs and create an API token, OAuth credential, or developer key as the upstream service requires.',
  'connections.github.setup.step2.title': 'Save it inside meta-sovereign',
  'connections.github.setup.step2.body':
    'Paste the credential into the field on this screen. The value is stored under a `secret:*` key and never leaves your browser.',
  'connections.github.setup.step3.title': 'Run the probe',
  'connections.github.setup.step3.body':
    'Tap "Probe connection" — a successful response confirms the credential. Failures surface a translated hint with the exact next action.',
  'connections.upwork.setup.step1.title': 'Prepare your Upwork credential',
  'connections.upwork.setup.step1.body':
    'Open the linked docs and create an API token, OAuth credential, or developer key as the upstream service requires.',
  'connections.upwork.setup.step2.title': 'Save it inside meta-sovereign',
  'connections.upwork.setup.step2.body':
    'Paste the credential into the field on this screen. The value is stored under a `secret:*` key and never leaves your browser.',
  'connections.upwork.setup.step3.title': 'Run the probe',
  'connections.upwork.setup.step3.body':
    'Tap "Probe connection" — a successful response confirms the credential. Failures surface a translated hint with the exact next action.',
  'connections.peopleperhour.setup.step1.title':
    'Prepare your PeoplePerHour credential',
  'connections.peopleperhour.setup.step1.body':
    'Open the linked docs and create an API token, OAuth credential, or developer key as the upstream service requires.',
  'connections.peopleperhour.setup.step2.title':
    'Save it inside meta-sovereign',
  'connections.peopleperhour.setup.step2.body':
    'Paste the credential into the field on this screen. The value is stored under a `secret:*` key and never leaves your browser.',
  'connections.peopleperhour.setup.step3.title': 'Run the probe',
  'connections.peopleperhour.setup.step3.body':
    'Tap "Probe connection" — a successful response confirms the credential. Failures surface a translated hint with the exact next action.',
  'connections.superjob.setup.step1.title': 'Prepare your SuperJob credential',
  'connections.superjob.setup.step1.body':
    'Open the linked docs and create an API token, OAuth credential, or developer key as the upstream service requires.',
  'connections.superjob.setup.step2.title': 'Save it inside meta-sovereign',
  'connections.superjob.setup.step2.body':
    'Paste the credential into the field on this screen. The value is stored under a `secret:*` key and never leaves your browser.',
  'connections.superjob.setup.step3.title': 'Run the probe',
  'connections.superjob.setup.step3.body':
    'Tap "Probe connection" — a successful response confirms the credential. Failures surface a translated hint with the exact next action.',
  'connections.naukri.setup.step1.title': 'Install the browser driver',
  'connections.naukri.setup.step1.body':
    'Naukri publishes no public API. Install Playwright on the machine that runs the local server so browser-commander can drive a real session.',
  'connections.naukri.setup.step2.title': 'Sign in once',
  'connections.naukri.setup.step2.body':
    'Open the CV screen and run a read. The browser opens naukri.com — sign in there once; the browser profile directory keeps the session for later runs.',
  'connections.naukri.setup.step3.title': 'Read, compare, sync',
  'connections.naukri.setup.step3.body':
    'Read the CV, review the differences against the other boards, then plan a sync. Every run is recorded under cv:telemetry with a markup fingerprint, so a broken selector is easy to spot.',
  'connections.vietnamworks.setup.step1.title': 'Install the browser driver',
  'connections.vietnamworks.setup.step1.body':
    'VietnamWorks publishes no public API. Install Playwright on the machine that runs the local server so browser-commander can drive a real session.',
  'connections.vietnamworks.setup.step2.title': 'Sign in once',
  'connections.vietnamworks.setup.step2.body':
    'Open the CV screen and run a read. The browser opens vietnamworks.com — sign in there once; the browser profile directory keeps the session for later runs.',
  'connections.vietnamworks.setup.step3.title': 'Read, compare, sync',
  'connections.vietnamworks.setup.step3.body':
    'Read the CV, review the differences against the other boards, then plan a sync. Every run is recorded under cv:telemetry with a markup fingerprint, so a broken selector is easy to spot.',
  'connections.topcv.setup.step1.title': 'Install the browser driver',
  'connections.topcv.setup.step1.body':
    'TopCV publishes no public API. Install Playwright on the machine that runs the local server so browser-commander can drive a real session.',
  'connections.topcv.setup.step2.title': 'Sign in once',
  'connections.topcv.setup.step2.body':
    'Open the CV screen and run a read. The browser opens topcv.vn — sign in there once; the browser profile directory keeps the session for later runs.',
  'connections.topcv.setup.step3.title': 'Read, compare, sync',
  'connections.topcv.setup.step3.body':
    'Read the CV, review the differences against the other boards, then plan a sync. Every run is recorded under cv:telemetry with a markup fingerprint, so a broken selector is easy to spot.',
  // END setup-steps
  'connections.back': 'Back to connections',
  'connections.email.label': 'Email',
  'connections.email.archive.title': 'Import .eml or mbox mail exports',
  'connections.email.archive.hint':
    'Export mail from your provider as .eml files or an mbox archive, including Gmail Takeout mbox files (the Takeout .zip works as it is). Drop the file into the import box with source "email".',
  'connections.email.archive.fileHint': '*.eml, *.mbox',
  'connections.email.api.title': 'Connect email APIs and protocols',
  'connections.email.api.hint':
    'Use JMAP, Gmail API, or Microsoft Graph directly from the browser when CORS allows it. IMAP, POP3, and SMTP require the local server because browsers cannot open raw TCP/TLS mail sockets.',
  'connections.email.fields.token.label': 'OAuth access token',
  'connections.email.fields.host.label': 'IMAP/SMTP server',
  'connections.email.fields.username.label': 'Login (email address)',
  'connections.email.fields.password.label': 'Password or app password',
  'connections.email.errorHints.401':
    'Token rejected. Re-issue an OAuth token with the gmail.readonly scope.',
  'connections.email.errorHints.403':
    'Insufficient scope. Re-issue the token with gmail.readonly or jmap permissions.',
  'connections.telegram.label': 'Telegram',
  'connections.telegram.archive.title': 'Import a Telegram Desktop archive',
  'connections.telegram.archive.hint':
    'Telegram Desktop -> Settings -> Advanced -> Export Telegram data. Pick "Personal chats" + "JSON" and drop the resulting "result.json" into the import box below.',
  'connections.telegram.archive.fileHint': 'result.json',
  'connections.telegram.api.title': 'Connect the Telegram Bot API',
  'connections.telegram.api.hint':
    'Talk to @BotFather inside Telegram, run /newbot, copy the bot token and paste it as the secret named "secret:telegram:bot-token".',
  'connections.telegram.fields.token.label': 'Bot token',
  'connections.telegram.errorHints.401':
    'Token rejected. Ask @BotFather for a fresh token or revoke the leaked one.',
  'connections.telegram.errorHints.404':
    'Endpoint not found. Double-check there is no whitespace in the bot token.',
  'connections.vk.label': 'VK',
  'connections.vk.archive.title': 'Import a VK conversations archive',
  'connections.vk.archive.hint':
    'Open https://vk.com/data_protection, request your archive and drop the .zip as it is (or the "messages" files from it) into the import box.',
  'connections.vk.archive.fileHint': 'messages*.json',
  'connections.vk.api.title': 'Connect the VK API',
  'connections.vk.api.hint':
    'New VK apps can no longer get the messages right, and Kate Mobile tokens stopped working on 2026-09-08. Prefer the archive import below. For community chats, paste a community token (community settings -> API usage). A legacy user token issued for VK\'s own web client (client_id 6287487 via oauth.vk.ru) may still work, at your own risk of an account freeze. The value is stored as "secret:vk:access-token".',
  'connections.vk.fields.token.label': 'Access token',
  'connections.vk.errorHints.401':
    'VK rejected the token (error 5). Issue a new one: tokens of blocked clients such as Kate Mobile or VK Admin will not recover.',
  'connections.x.label': 'X (Twitter)',
  'connections.x.archive.title': 'Import an X data archive',
  'connections.x.archive.hint':
    'Settings -> Your account -> Download an archive of your data. Once the archive is ready, drop the .zip as it is (or tweets.js and direct-messages.js from its data/ folder) into the import box.',
  'connections.x.archive.fileHint': 'tweets.js, direct-messages.js',
  'connections.x.api.title': 'Connect the X API v2',
  'connections.x.api.hint':
    'Create an app at https://developer.x.com/, generate a user-context bearer token, and paste it as "secret:x:token".',
  'connections.x.fields.token.label': 'Bearer token',
  'connections.x.errorHints.401':
    'Bearer token rejected. Generate a new one in the X developer portal.',
  'connections.x.errorHints.403':
    'Token is valid but lacks the users.read scope.',
  'connections.whatsapp.label': 'WhatsApp',
  'connections.whatsapp.archive.title': 'Import a WhatsApp chat export',
  'connections.whatsapp.archive.hint':
    'In the WhatsApp app, open a chat -> ... -> More -> Export chat (with or without media). Drop the resulting "WhatsApp Chat with NAME.txt" or .zip into the import box.',
  'whatsapp.web.terms':
    "WhatsApp's terms do not allow automated or bulk use of WhatsApp Web or of unofficial clients. Here it is used only to open your own chats and to send a message you confirm yourself; greetings and automations never send to a personal WhatsApp.",
  'whatsapp.web.title': 'WhatsApp Web (personal account)',
  'whatsapp.web.signIn': 'Sign in to WhatsApp Web',
  'whatsapp.web.close': 'Close the window',
  'whatsapp.web.opening': 'Opening the window…',
  'whatsapp.web.waiting':
    'A WhatsApp Web window is open. On your phone: WhatsApp > Linked devices > Link a device, and scan the QR code yourself.',
  'whatsapp.web.signedIn': 'Signed in to WhatsApp Web (confirmed {when}).',
  'whatsapp.web.closed':
    'Not signed in. The window opens here, in plain sight, and only you scan the code.',
  'whatsapp.web.failed': 'Could not open WhatsApp Web: {error}',
  'whatsapp.web.zipFailed': 'Could not read the zip: {error}',
  'whatsapp.web.zipImported': '{label}: {count} messages imported.',
  'connections.whatsapp.archive.fileHint': 'WhatsApp Chat with *.txt',
  'connections.whatsapp.api.title': 'Connect the WhatsApp Cloud API',
  'connections.whatsapp.api.hint':
    'Create a Meta for Developers app, add the WhatsApp product, copy the temporary or system-user access token and the phone number id (WHATSAPP_PHONE_NUMBER_ID).',
  'connections.whatsapp.fields.token.label': 'Access token',
  'connections.whatsapp.fields.phoneNumberId.label': 'Phone number ID',
  'connections.whatsapp.errorHints.400':
    'Meta returned 400. Re-check the access token and that the app is in Live mode.',
  'connections.whatsapp.errorHints.401':
    'Access token rejected. Generate a new system-user token in Meta Business.',
  'connections.facebook.label': 'Facebook',
  'connections.facebook.archive.title': 'Import a Facebook download',
  'connections.facebook.archive.hint':
    'Settings & privacy -> Settings -> Your information -> Download your information. Choose "JSON" and select the categories you need (messages, posts).',
  'connections.facebook.archive.fileHint': 'messages_*.json, posts_*.json',
  'connections.facebook.api.title': 'Connect the Facebook Graph API',
  'connections.facebook.api.hint':
    'In your Meta for Developers app, add a Facebook Page, generate a page access token (FACEBOOK_PAGE_ACCESS_TOKEN) and note the page id (FACEBOOK_PAGE_ID).',
  'connections.facebook.fields.token.label': 'Page access token',
  'connections.facebook.fields.pageId.label': 'Page ID',
  'connections.facebook.errorHints.400':
    'Graph returned 400. Verify the access token has not expired (page tokens are short-lived).',
  'connections.facebook.errorHints.401':
    'Access token rejected. Re-issue a fresh page token in Graph API Explorer.',
  'connections.linkedin.label': 'LinkedIn',
  'connections.linkedin.archive.title': 'Import a LinkedIn data export',
  'connections.linkedin.archive.hint':
    'Settings & Privacy -> Data privacy -> Get a copy of your data. Pick "Want something in particular?" and request "Messages" + "Posts". Drop the .zip LinkedIn sends (or messages.csv from it) into the import box.',
  'connections.linkedin.archive.fileHint': 'messages.csv, Shares.csv',
  'connections.linkedin.api.title': 'Connect the LinkedIn REST API',
  'connections.linkedin.api.hint':
    'Create an app at https://www.linkedin.com/developers/, request the "Share on LinkedIn" + "Sign In with LinkedIn using OpenID Connect" products, and paste the OAuth2 access token plus your author URN (LINKEDIN_AUTHOR_URN).',
  'connections.linkedin.fields.token.label': 'Access token',
  'connections.linkedin.fields.authorUrn.label': 'Author URN',
  'connections.linkedin.errorHints.401':
    'OAuth2 access token rejected. Re-run the auth code flow.',
  'connections.habr-career.label': 'career.habr.com',
  'connections.habr-career.archive.title':
    'Import a career.habr.com applications JSON',
  'connections.habr-career.archive.hint':
    'On career.habr.com, open your account, go to "Отклики на вакансии" and use the export-to-JSON action. Save the file and load it into the SPA.',
  'connections.habr-career.archive.fileHint': 'applications.json',
  'connections.habr-career.api.title':
    'Connect the career.habr.com private API',
  'connections.habr-career.api.hint':
    'Generate a personal access token from career.habr.com -> Settings -> Tokens, and paste it as "secret:habr-career:token".',
  'connections.habr-career.fields.token.label': 'Personal access token',
  'connections.habr-career.errorHints.401':
    'career.habr.com rejected the token. Re-issue it from Settings -> Tokens.',
  'connections.hh.label': 'hh.ru',
  'connections.hh.archive.title': 'Import an hh.ru negotiations archive',
  'connections.hh.archive.hint':
    'Import a JSON file containing actual negotiation messages that you have already obtained. A negotiation list alone contains no message history. For live history, enter an API token and choose Fetch now.',
  'connections.hh.archive.fileHint': 'negotiations.json',
  'connections.hh.api.title': 'Connect the hh.ru API',
  'connections.hh.api.hint':
    'Register an app at https://dev.hh.ru/, authorize your HH account with OAuth and paste the user access token below. Chat access depends on app and account permissions.',
  'connections.hh.fields.token.label': 'Access token',
  'connections.hh.errorHints.401':
    'hh.ru rejected the token. Refresh it via your app at https://dev.hh.ru/.',
  'connections.github.label': 'GitHub',
  'connections.github.archive.title': 'Import a gh api JSON dump',
  'connections.github.archive.hint':
    'Save a JSON dump from `gh api` (e.g. `gh api repos/OWNER/REPO/issues --paginate > issues.json`) or an envelope `{ issues, comments, pulls, reviews, reviewComments, discussions }` and drop the file here.',
  'connections.github.archive.fileHint':
    'issues.json, pulls.json, comments.json, envelope.json',
  'connections.github.api.title': 'Connect the GitHub REST API',
  'connections.github.api.hint':
    'Create a fine-grained personal access token at https://github.com/settings/personal-access-tokens with read access to issues, pull requests, and the repositories you want to clone, plus write access to issues if you intend to post comments. Paste it as "secret:github:access-token".',
  'connections.github.fields.token.label': 'Personal access token',
  'connections.github.errorHints.401':
    'Token rejected. Re-issue a personal access token at https://github.com/settings/personal-access-tokens.',
  'connections.github.errorHints.403':
    'GitHub returned 403. The token may be missing scopes (issues:read, pull_requests:read, contents:read) or hitting a secondary rate limit.',
  'connections.github.errorHints.404':
    'Repository not found or not visible. Confirm the token has access to the target owner/repo.',
  'connections.upwork.label': 'Upwork',
  'connections.upwork.archive.title': 'Import an Upwork data export',
  'connections.upwork.archive.hint':
    'Upwork lets you export transaction history (Reports → Transaction History → Download CSV), per-job archives, and internal admin envelopes (`{ jobs, contracts, rooms, messages, transactions }`). Drop the resulting CSV or JSON file here with source "upwork".',
  'connections.upwork.archive.fileHint':
    'transactions.csv, jobs.json, contracts.json, envelope.json',
  'connections.upwork.api.title': 'Connect the Upwork GraphQL API',
  'connections.upwork.api.hint':
    'Register an OAuth2 application at https://www.upwork.com/services/api/apply, run the 3-legged authorisation-code flow, and paste the access token as "secret:upwork:access-token". Store the optional refresh token at "secret:upwork:refresh-token".',
  'connections.upwork.fields.token.label': 'OAuth access token',
  'connections.upwork.fields.refreshToken.label': 'Refresh token',
  'connections.upwork.fields.organizationId.label': 'Organization (tenant) ID',
  'connections.upwork.errorHints.401':
    'Upwork rejected the access token. Refresh it via your registered OAuth2 app or re-run the authorisation-code flow.',
  'connections.upwork.errorHints.403':
    'Token valid but missing scope. Re-issue with the messaging, search, and reports scopes you need.',
  'connections.upwork.errorHints.429':
    'Upwork rate-limited the call. Back off; the adapter caches results for 24 hours per the API ToS.',
  'connections.peopleperhour.label': 'PeoplePerHour',
  'connections.peopleperhour.archive.title':
    'Import a PeoplePerHour data export',
  'connections.peopleperhour.archive.hint':
    'PeoplePerHour exposes account-level exports through the GDPR data-subject access request bundle (Settings → Privacy → Request my data) and the Earnings CSV (Reports → Earnings → Export). Drop the resulting JSON or CSV here with source "peopleperhour".',
  'connections.peopleperhour.archive.fileHint':
    'projects.json, proposals.json, workstreams.json, earnings.csv',
  'connections.peopleperhour.api.title': 'Connect the PeoplePerHour REST API',
  'connections.peopleperhour.api.hint':
    'Register an OAuth2 application via the PeoplePerHour developer portal (https://www.peopleperhour.com/site/developers), run the authorisation-code flow, and paste the access token as "secret:peopleperhour:access-token". Store the optional refresh token at "secret:peopleperhour:refresh-token". The adapter caches every response for 24 hours per the PPH API ToS.',
  'connections.peopleperhour.fields.accessToken.label': 'OAuth access token',
  'connections.peopleperhour.fields.refreshToken.label': 'Refresh token',
  'connections.peopleperhour.errorHints.401':
    'PeoplePerHour rejected the access token. Refresh it via your registered OAuth2 app or re-run the authorisation-code flow.',
  'connections.peopleperhour.errorHints.403':
    'Token valid but missing scope. Re-issue with the projects, proposals, and workstreams scopes you need.',
  'connections.peopleperhour.errorHints.429':
    'PeoplePerHour rate-limited the call. Back off; the adapter caches results for 24 hours per the API ToS.',
  'connections.superjob.label': 'superjob.ru',
  'connections.superjob.archive.title': 'Import a SuperJob responses archive',
  'connections.superjob.archive.hint':
    'On superjob.ru, open your applicant cabinet -> "Отклики" and use the JSON export action. Save the file and load it here.',
  'connections.superjob.archive.fileHint': 'responses.json',
  'connections.superjob.api.title': 'Connect the SuperJob API',
  'connections.superjob.api.hint':
    'Register an application at https://api.superjob.ru/register/, copy the secret key as SUPERJOB_APP_ID and the access token as "secret:superjob:token".',
  'connections.superjob.fields.appId.label': 'App ID (X-Api-App-Id)',
  'connections.superjob.fields.token.label': 'Access token',
  'connections.superjob.errorHints.401':
    'SuperJob rejected the App ID. Re-check it in your applicant cabinet.',
  'connections.naukri.label': 'naukri.com',
  'connections.naukri.archive.title': 'Import a Naukri recruiter inbox export',
  'connections.naukri.archive.hint':
    'Open naukri.com -> "Recruiter messages", use the browser export (or save the JSON the network tab returns) and load the file here.',
  'connections.naukri.archive.fileHint': 'inbox.json',
  'connections.naukri.session.title':
    'Sign in once in the local browser session',
  'connections.naukri.session.hint':
    'Start the local server, open the CV screen and run a read. The browser opens naukri.com; sign in there once and the profile directory keeps the session for later runs.',
  'connections.vietnamworks.label': 'vietnamworks.com',
  'connections.vietnamworks.archive.title':
    'Import a VietnamWorks message centre export',
  'connections.vietnamworks.archive.hint':
    'Open vietnamworks.com -> "My Jobs" -> messages, save the JSON payload the page loads and import it here.',
  'connections.vietnamworks.archive.fileHint': 'messages.json',
  'connections.vietnamworks.session.title':
    'Sign in once in the local browser session',
  'connections.vietnamworks.session.hint':
    'Start the local server, open the CV screen and run a read. The browser opens vietnamworks.com; sign in there once and the profile directory keeps the session for later runs.',
  'connections.topcv.label': 'topcv.vn',
  'connections.topcv.archive.title': 'Import a TopCV employer message export',
  'connections.topcv.archive.hint':
    'Open topcv.vn -> "Tin nhắn", save the JSON payload the page loads and import it here.',
  'connections.topcv.archive.fileHint': 'messages.json',
  'connections.topcv.session.title':
    'Sign in once in the local browser session',
  'connections.topcv.session.hint':
    'Start the local server, open the CV screen and run a read. The browser opens topcv.vn; sign in there once and the profile directory keeps the session for later runs.',
  'tutorial.button': 'Tutorial',
  'tutorial.skip': 'Skip step',
  'tutorial.next': 'Next',
  'tutorial.showMe': 'Show me',
  'tutorial.back': 'Back',
  'tutorial.finish': 'Finish',
  'tutorial.off': 'Turn off tutorial',
  'tutorial.progress': 'Step {current} of {total}',
  'tutorial.connect.title': 'Connect your first service',
  'tutorial.connect.body':
    'Bring your chats and contacts into one place. Open Connections to start.',
  'tutorial.connect.examples': 'For example:',
  'tutorial.connect.more': 'and more',
  'tutorial.welcome.title': 'Welcome to meta-sovereign',
  'tutorial.welcome.body':
    'Your personal CRM and one inbox for all your messages. Your data stays on your device unless you connect your own server.',
  'tutorial.chat.title': 'Chat',
  'tutorial.chat.body':
    'Conversations from all your connected services, in one inbox. Type below and press Send to reply; the line under the list shows the connected account and when it last synced; it syncs by itself.',
  'tutorial.contacts.title': 'Contacts',
  'tutorial.contacts.body':
    'Everyone you talk to, and your Telegram contacts, each person once even across services. Open Contacts.',
  'tutorial.contactsOpen.title': 'Open a chat',
  'tutorial.contactsOpen.body':
    'Press "Message" next to a person to open your chat with them, even if you never wrote to them before. Search finds anyone by name or @username.',
  'tutorial.automation.title': 'Automation',
  'tutorial.automation.body':
    'Automatic replies: when a message matches a pattern, the app drafts an answer. Nothing is sent until you confirm it.',
  'tutorial.backup.title': 'Backup',
  'tutorial.backup.body':
    'Save an encrypted copy of your data. Only your passphrase can open it.',
  'tutorial.connections.title': 'Pick a service',
  'tutorial.connections.body':
    'Everything here works now: "Find sign-ins" (recommended, with a local server) checks which services your browsers are already signed in to. On any service, "Import with browser" (recommended) signs you in and imports its export, "Enter manually" takes API keys or a file. Next opens the service you picked last (Email at first).',
  'tutorial.connectionDetail.title': 'Import or enter manually',
  'tutorial.connectionDetail.body':
    'On "Import with browser", press "Open browser" and sign in, start the data export there and the downloaded file is imported automatically. Prefer to do it yourself? Switch to "Enter manually".',

  // CV synchronisation screen (issue #29).
  'cv.title': 'CV synchronisation',
  'cv.intro':
    'Read your CV from every supported job platform through the local browser session, compare the versions field by field, then plan and apply an update. Nothing is written until you press Apply.',
  'cv.use': 'Use',
  'cv.platform': 'Platform',
  'cv.markup': 'Markup access',
  'cv.steps': 'Plan steps',
  'cv.snapshot': 'Last snapshot',
  'cv.confidence': '{verified} verified / {draft} draft',
  'cv.noSnapshot': 'Never read',
  'cv.loginPlaceholder': 'Profile login or id',
  'cv.read': 'Read selected',
  'cv.compare': 'Compare',
  'cv.planSync': 'Plan sync',
  'cv.applySync': 'Apply sync',
  'cv.busy': 'Working — the browser session is driving the platform…',
  'cv.differences': 'Differences',
  'cv.field': 'Field',
  'cv.values': 'Values',
  'cv.missing': 'Missing on',
  'cv.noConflicts':
    'No conflicts: every platform agrees on the fields that were read.',
  'cv.syncTitle': 'Sync plan',
  'cv.dryRun': 'Dry run — nothing was written to any platform.',
  'cv.applied': 'Applied — the listed platforms were updated.',
  'cv.action':
    '{platform}: {writable} writable, {unsupported} unsupported — {paths}',
  'cv.morePaths': '(+{count} more)',
  'cv.telemetry': 'Recent runs',
  'cv.noRuns': 'No runs recorded yet.',
  'cv.unavailable':
    'This server does not provide the CV routes. Start the JS server (`meta-sovereign serve`) or use the `meta-sovereign cv-*` commands, which drive the browser locally.',
  'automations.mode.safe': 'safe: drafts to confirm',
  'automations.mode.auto': 'automatic',
  'automations.reason.none': 'no one matched',
  'automations.reason.network': 'another network',
  'automations.reason.not-personal': 'not a personal chat',
  'automations.reason.not-mutual': 'you never wrote there',
  'automations.reason.talked-recently': 'talked recently',
  'automations.reason.last-from-me': 'the last message is yours',
  'automations.reason.last-from-contact': 'the last message is theirs',
  'automations.reason.last-from-nobody': 'no messages',
  'automations.reason.draft-pending': 'a draft is already waiting',
  'automations.reason.already-sent': 'already sent recently',
  'automations.reason.already-skipped': 'skipped recently',
  'automations.title': 'Automations',
  'automations.intro':
    'Each automation says who to message, when, on what conditions and with which text. Safe mode leaves a draft in each chat for you to confirm; automatic mode sends with typing and pauses.',
  'automations.new': 'New automation',
  'automations.newName': 'New automation',
  'automations.pick':
    'Pick an automation to edit, preview or run it, or start a new one.',
  'automations.preset': 'preset',
  'automations.off': 'off',
  'automations.presets.reengage-dormant.name':
    'Say hi to contacts silent for 90 days',
  'automations.presets.reengage-dormant.description':
    'Personal chats with no messages for 90 days get a hello asking whether they or their friends need help with automation.',
  'automations.presets.job-search.name': 'Ask about open positions',
  'automations.presets.job-search.description':
    'Tell contacts you are open to new roles; pair with an audience of colleagues or recruiters.',
  'automations.presets.contract-search.name': 'Offer contract work',
  'automations.presets.contract-search.description':
    'Let contacts know you take contract projects; intersect lists to reach exactly the right people.',
  'automations.presets.greet-back.name': 'Greet back',
  'automations.presets.greet-back.description':
    'When someone says hi in a personal chat, draft a greeting in the right form (at most once a day).',
  'automations.edit': 'Edit {name}',
  'automations.close': 'Close',
  'automations.delete': 'Delete',
  'automations.confirmDelete': 'Delete the automation "{name}"?',
  'automations.preview': 'Preview',
  'automations.runSafe': 'Save and queue drafts',
  'automations.runAuto': 'Save and send now',
  'automations.history': 'History',
  'automations.useSelection': 'The {count} selected',
  'automations.section.about': 'Automation',
  'automations.section.triggers': 'When it runs',
  'automations.section.audience': 'Who',
  'automations.section.conditions': 'Conditions',
  'automations.section.message': 'Message',
  'automations.section.pacing': 'Pacing',
  'automations.field.name': 'Name',
  'automations.field.description': 'Description',
  'automations.field.enabled':
    'Enabled (schedules and incoming messages fire it)',
  'automations.field.mode': 'Mode',
  'automations.field.audience': 'Audience',
  'automations.field.silentDays': 'Silent for at least (days)',
  'automations.field.cooldownDays': 'Not again for (days)',
  'automations.field.mutual': 'Only chats where you wrote too',
  'automations.field.personal': 'Only personal chats',
  'automations.field.lastFrom': 'Last message from',
  'automations.field.networks': 'Networks (empty: all)',
  'automations.field.form': 'Address form',
  'automations.field.limit': 'At most per run',
  'automations.field.dailyCap': 'At most per day',
  'automations.field.minDelay': 'Pause from (seconds)',
  'automations.field.maxDelay': 'Pause up to (seconds)',
  'automations.field.typing': 'Show typing before each message',
  'automations.trigger.manual': 'by hand',
  'automations.trigger.chat-menu': "from a chat's menu",
  'automations.trigger.schedule': 'every',
  'automations.trigger.incoming': 'on an incoming message matching',
  'automations.hint.schedule': '30m, 12h, 1d or 2w; empty: no schedule',
  'automations.hint.incoming': 'A regular expression; empty: not on messages',
  'automations.hint.audience':
    'personal, friends:vk, chat:vk:<id>, community:vk:<id>, list:<id>, audience:<id>, person:vk:<id>; join with | (or), & (and), - (except) and brackets',
  'automations.hint.template':
    '{name}, {days} and {network} are filled in for each person',
  'automations.form.auto': 'detect ты/вы',
  'automations.form.informal': 'informal (ты)',
  'automations.form.formal': 'formal (вы)',
  'automations.lastFrom.any': 'Anyone',
  'automations.lastFrom.me': 'Me',
  'automations.lastFrom.contact': 'Them',
  'automations.status.sent': 'Sent',
  'automations.status.failed': 'Not sent',
  'automations.status.skipped': 'Skipped',
  'automations.plan.title': '{count} to message',
  'automations.plan.nothingSent': 'A preview: nothing was sent or queued.',
  'automations.plan.leftOut': 'Left out: {reasons}',
  'automations.notice.saved': 'Saved "{name}".',
  'automations.notice.deleted': 'Deleted "{name}".',
  'automations.notice.queued':
    '{count, plural, one {# draft waits in its chat: open it} other {# drafts wait in their chats: open each chat}} to review and send.',
  'automations.notice.listSaved':
    'Saved the list "{name}" ({count, plural, one {# person} other {# people}}).',
  'automations.notice.audienceSaved':
    'Saved the audience "{name}" ({count, plural, one {# person} other {# people}}).',
  'automations.error.name': 'Give the automation a name',
  'automations.error.number': 'Numbers must be zero or more',
  'automations.error.audience': 'The audience does not parse',
  'automations.error.trigger': 'Choose at least one way to run it',
  'automations.error.invalid': 'The automation is not valid',
  'automations.people.title': 'People',
  'automations.people.search': 'Search people by name, handle or network',
  'automations.people.sameAs':
    'also on {count, plural, one {# more network} other {# more networks}}',
  'automations.people.selected': '{count} selected',
  'automations.people.test': 'Test: ignore the conditions',
  'automations.people.run': 'Run "{name}" on them',
  'automations.people.pickAutomation':
    'Open an automation to run it on the selected people.',
  'automations.people.listName': 'List name',
  'automations.people.saveList': 'Save as a list',
  'automations.people.clear': 'Clear the selection',
  'automations.audiences.title': 'Audiences',
  'automations.audiences.use': 'Use',
  'automations.audiences.count': 'Count',
  'automations.audiences.resolved': '{count} people: {names}',
  'settings.operator.title': 'Operator',
  'settings.operator.hint':
    'Private chats with people are enabled by default. Bots, groups and channels are off; choose the types to include. The menu badge uses the same selection.',
  'settings.operator.bot': 'Bots',
  'settings.operator.private': 'Private chats with people',
  'settings.operator.group': 'Groups and group chats',
  'settings.operator.channel': 'Channels',
  'settings.stories.title': 'Stories',
  'settings.birthdays.title': 'Birthday reminders',
  'settings.birthdays.tomorrow': 'Also show tomorrow’s birthdays',
  'settings.birthdays.hideGreeted': 'Hide people already congratulated today',
  'settings.birthdays.hint':
    'By default, show only today’s birthdays that still need a greeting. Only confirmed sent birthday wishes count; drafts and queued messages do not.',
  'settings.stories.show': 'Show stories',
  'settings.stories.hint':
    'Off by default. Enable the stories strip, avatar rings and profile stories in this browser.',
  'settings.folderTabs.title': 'Folder tabs',
  'settings.folderTabs.placement': 'All and Unread placement',
  'settings.folderTabs.end': 'At the end (default)',
  'settings.folderTabs.start': 'At the start',
  'settings.folderTabs.hint':
    'All and Unread are first and second from the chosen edge. Other folders keep their order; Telegram is unchanged.',
  'settings.appearance.title': 'Appearance',
  'settings.appearance.intro':
    'The theme and skin apply to every screen and are kept in this browser. The Theme button in the header switches between light and dark.',
  'settings.appearance.theme': 'Theme',
  'settings.appearance.skin': 'Skin',
  'settings.appearance.effects': 'Reduce visual effects',
  'settings.effects.auto': 'Automatic: when this browser renders slowly',
  'settings.effects.on': 'Always reduced (no blur)',
  'settings.effects.off': 'Full effects',
  'settings.theme.system': 'Follow the system',
  'settings.theme.light': 'Light',
  'settings.theme.dark': 'Dark',
  'settings.theme.auto': 'Auto: light by day (7–19), dark at night',
  'settings.skin.t3': 'Like t3.codes (default)',
  'settings.skin.telegram': 'Like Telegram',
  'settings.skin.whatsapp': 'Like WhatsApp',
  'settings.skin.signal': 'Like Signal',
  'greetings.title': 'Greetings',
  'greetings.intro':
    'Pick the stickers and phrases to open dialogs with, preview who would be greeted, then send. Sticker pictures load straight from the networks; nothing is copied into the app.',
  'greetings.stickers': 'Stickers and phrases',
  'greetings.selected': '{count} of {total} stickers selected',
  'greetings.pick': 'Use {label}',
  'greetings.telegramDefault':
    'The stickers Telegram suggests on an empty chat come from its user API ({method} "{emoticon}"), which a bot cannot call. List stickers from the sets below instead, or add your own sets.',
  'greetings.sets': 'Telegram sticker sets to list',
  'greetings.language': 'Greeting language',
  'greetings.prefer': 'Send',
  'greetings.prefer.sticker': 'A sticker where possible',
  'greetings.prefer.text': 'A text greeting',
  'greetings.listLive': 'List stickers live',
  'greetings.save': 'Save selection',
  'greetings.saved': 'Selection saved.',
  'greetings.planTitle': 'Who to greet',
  'greetings.mode': 'Plan',
  'greetings.mode.initiate': 'Start new dialogs',
  'greetings.mode.reply': 'Answer greetings',
  'greetings.delay': 'Pause between sends, s',
  'greetings.preview': 'Preview plan',
  'greetings.send': 'Send greetings',
  'greetings.busy': 'Working…',
  'greetings.noPlan': 'No plan yet. Preview one to see who would be greeted.',
  'greetings.emptyPlan':
    'Nobody to greet: every known chat is already greeted, answered or filtered out.',
  'greetings.chat': 'Chat',
  'greetings.lang': 'Language',
  'greetings.what': 'Greeting',
  'greetings.status': 'Status',
  'greetings.ready': 'Ready',
  'greetings.sent': 'Sent',
  'greetings.skipped': 'Skipped: {reason}',
  'greetings.networks': 'What each network allows',
  'greetings.network': 'Network',
  'greetings.addressing': 'Stickers',
  'greetings.initiate': 'Can start a dialog',
  'greetings.note': 'Note',
  'greetings.initiate.yes': 'Yes',
  'greetings.initiate.window': 'Within {hours} h of their last message',
  'greetings.initiate.reply-only': 'Replies only',
  'greetings.textOnly': 'Text only',

  /* ---- Telegram message display (chat-message.js / message-parts.js) ---- */

  /* Service message strings */

  /* ---- R-Z14 ---- */
  'disk.banner': 'Disk almost full — new messages may not be saved',
  'disk.dismiss': 'Hide',

  /* ---- R-Z17 ---- */
  'schema.tooNew':
    'This data was saved by a newer version of the app. Update the app to keep using it.',
  /* ---- R-Z12 ---- */
  'error.load': 'Could not load this list.',
  'error.retry': 'Try again',
  'settings.saveFailed': 'Could not save: {error}',
  'error.code.unknown': 'Something went wrong',
  'error.code.bad-host': "The local server refused this page's address",
  'error.code.too-large': 'That is too large to send',
  'error.code.bad-json': 'The request was malformed and was not applied',
  'error.code.internal': 'The local server hit an internal error',
  'error.code.send-unknown':
    'It is not known whether this was sent — check the chat before trying again',
  'error.code.unsupported': 'Not supported here',
  'error.code.unsupported-chat': 'Not supported in this chat',
  'error.code.captcha':
    'The network asks for a captcha — complete it in the official app first',
  'error.code.LOW_DISK': 'The disk is almost full — nothing was saved',
  'error.code.STORE_WRITE_FAILED':
    'The store could not write to disk — nothing was saved',
  'error.code.STORE_FULL': 'The disk is full — nothing was saved',
  'error.code.STORE_LOCKED': 'The store is locked by another running copy',
  'error.code.outbox-unavailable':
    'The send log is unavailable, so nothing was sent',
  'error.code.send-in-doubt':
    'A previous send may have gone out — it was not repeated',
  'error.code.timeout': 'The request timed out',
  'error.code.network': 'No answer from the local server',
  'questions.title': 'Questions and saved answers',
  'questions.intro':
    'Reuse answers across chats. Approved saved rules can send automatically; approximate, conflicting and incomplete matches stay for review. Use {{field}} for profile values, … for a short variable phrase, and word* for a word ending.',
  'questions.action': 'Action',
  'questions.kind.send-template': 'Send a template',
  'questions.kind.answer-questions': 'Answer questions',
  'questions.actionHint':
    'Uses the latest unanswered question and saved answers below. Unapproved, approximate, conflicting or incomplete answers pause automatic sending for review.',
  'questions.ruleIds': 'Answer rule IDs',
  'questions.ruleIdsHint':
    'Comma-separated; leave empty to use every enabled rule.',
  'questions.matchingSettings': 'Question matching',
  'questions.matchingThreshold': 'Minimum similarity (%)',
  'questions.matchingCase': 'Match letter case',
  'questions.matchingHint':
    'Approximate matches always require review. Subject, scope and rejected-answer rules still apply.',
  'questions.matchingInvalid': 'Enter a similarity from 0 to 100.',
  'questions.inspectMatches': 'Inspect all eligible matches',
  'questions.matchesTitle': 'Ranked matches',
  'questions.matchesRange': 'Matches {start}–{end} of {total}',
  'questions.matchesPartial':
    'The matching limit was reached. This list is incomplete.',
  'questions.matchScore': 'Similarity: {score}%',
  'questions.matchSelected': 'Selected for this draft',
  'questions.matchesPrevious': 'Previous matches',
  'questions.matchesNext': 'Next matches',
  'questions.approximate': 'Offer approximate matches for review',
  'questions.contract': 'Replace configured values with placeholders',
  'questions.contractHint':
    'Use the profile and salary settings under Preview answer when saving or learning answers. Review the proposed templates before approving them.',
  'questions.salaryTemplateEvidence': 'Salary placeholder values',
  'questions.profile': 'Profile values',
  'questions.fieldName': 'Field name, e.g. city',
  'questions.addField': 'Add field',
  'questions.removeField': 'Remove field',
  'questions.ruleKind': 'Rule type',
  'questions.ruleKind.question': 'Question or form field',
  'questions.ruleKind.notice': 'Passive notice',
  'questions.noticeHint':
    'For passive notices only; questions, requests, invitations, rejections and links stay separate. Text replies require review. Use [без ответа] as the answer for a notice that needs no reply, then mark the rule reviewed.',
  'questions.noticeApproved':
    'Reviewed notice rule (text replies still require review)',
  'questions.noticeReview':
    'Saved notice match. Text replies require review; this preview sends nothing.',
  'questions.noticeNoReplyReview':
    'Proposed no-reply notice. Review and approve its saved rule first.',
  'questions.question': 'Question or pattern',
  'questions.answer': 'Answer',
  'questions.variant': 'Variant {count}',
  'questions.approved': 'Approved for automatic sending with this saved rule',
  'questions.frequency': 'Observed answer turns: {count}',
  'questions.evidence': 'Source messages',
  'questions.addVariant': 'Add answer variant',
  'questions.removeVariant': 'Remove variant',
  'questions.sources': 'Providers, comma-separated; empty means all',
  'questions.chats': 'Chats, e.g. hh:123, telegram:456; empty means all',
  'questions.new': 'New answer rule',
  'questions.refresh': 'Refresh answers',
  'questions.empty':
    'No saved answers yet. Add one or learn proposals from imported conversations.',
  'questions.saved': 'Answer rule saved.',
  'questions.deleted': 'Answer rule deleted.',
  'questions.createAutomation': 'Create question automation',
  'questions.automationName': 'Answer incoming questions',
  'questions.learn': 'Learn from conversations',
  'questions.learnHint':
    'Learn from all messages saved on this device. Actual outgoing answers in complete turns contribute to frequencies; quoted summaries add no uses. Proposals remain unapproved.',
  'questions.previewLearning': 'Preview learned answers',
  'questions.applyLearning': 'Save proposals for review',
  'questions.learned':
    'Proposals saved. Review each answer before approving it.',
  'questions.coverage': 'Archived messages inspected: {retained} of {seen}.',
  'questions.partialHistory':
    'Some conversations lack reliable timestamps and were excluded. Learning covers saved messages; it does not download missing provider history.',
  'questions.preview': 'Preview answer',
  'questions.previewSource': 'Provider for preview',
  'questions.previewChat': 'Chat for preview',
  'questions.match.exact': 'Exact match',
  'questions.match.template': 'Pattern match',
  'questions.match.approximate': 'Approximate match',
  'questions.match.assembled': 'Assembled from separate answers',
  'questions.match.unanswered': 'No matching answer',
  'questions.reviewRequired': 'Review required before automatic sending.',
  'questions.ready': 'Approved and complete. Nothing was sent by this preview.',
  'questions.noAnswer': 'Add or complete a saved answer.',
  'questions.missing': 'Missing profile values: {fields}',
  'questions.enabled': 'Use this answer rule',
  'questions.approvedComplete': 'Approved and complete.',
  'automations.form.neutral': 'Saved answer',
  'chat.form.neutral': 'saved answer',
  'automations.reason.question-unanswered':
    'No saved answer for the latest question',
  'automations.reason.question-already-answered':
    'The latest turn is already outgoing',
  'automations.reason.question-turn-unavailable':
    'The latest turn cannot be used as a question',
  'questions.aliases': 'Equivalent questions, one per line',
  'questions.canonical': 'Use this correction instead of older variants',
  'questions.policy': 'Answer reuse policy',
  'questions.policyHint':
    'Rejected phrases are excluded from learned and saved answers, including profile substitutions. Historical messages are preserved. Punctuation variants stay separate unless you choose to combine them.',
  'questions.rejected': 'Rejected phrases, one per line',
  'questions.punctuationEquivalent':
    'Combine frequencies of answers differing only by final punctuation',
  'questions.policySaved': 'Answer reuse policy saved.',
  'automations.reason.notice-no-reply': 'Saved notice; no reply needed',
  'questions.noReply': 'No reply needed.',
  'questions.match.summary': 'Completed questionnaire summary',
  'automations.reason.question-summary-complete':
    'Completed questionnaire; no reply needed',
  'questions.contexts': 'Context values',
  'questions.contextHint':
    'Set words that select profile values for a currency, work format or another context. The question takes priority, then recent conversation, vacancy pay, vacancy description and your default. Missing values stay unavailable.',
  'questions.contextGroup': 'Context group',
  'questions.contextKey': 'Context field, e.g. currency',
  'questions.contextChoice': 'Context choice',
  'questions.contextChoiceId': 'Choice value, e.g. USD',
  'questions.contextKeywords': 'Words that select this choice, one per line',
  'questions.contextDefault': 'Default when context is absent',
  'questions.contextNoDefault': 'Require context',
  'questions.contextAddGroup': 'Add context group',
  'questions.contextRemoveGroup': 'Remove context group',
  'questions.contextAddChoice': 'Add context choice',
  'questions.contextRemoveChoice': 'Remove context choice',
  'questions.contextPreview': 'Conversation and vacancy for preview',
  'questions.contextPreviewHint':
    'These fields are only for this preview. Sending uses the actual conversation and attached vacancy context.',
  'questions.contextRecent': 'Recent messages, newest first, one per line',
  'questions.contextPay': 'Vacancy pay context',
  'questions.contextDescription': 'Vacancy description',
  'questions.contextEvidence': 'Why these values were selected',
  'questions.contextSource.question': 'Current question',
  'questions.contextSource.conversation': 'Recent conversation',
  'questions.contextSource.vacancy-pay': 'Vacancy pay',
  'questions.contextSource.vacancy-description': 'Vacancy description',
  'questions.contextSource.default': 'Configured default',
  'questions.contextSource.missing': 'Context unavailable',
  'questions.contextSource.ambiguous': 'Ambiguous context',
  'questions.salaryGuidance':
    'Draft vacancy/form minimum pay and a comfortable rate (requires review)',
  'questions.salary.hourlyNet': 'Comfortable hourly net amount (optional)',
  'questions.salary.hourlyGross': 'Comfortable hourly gross amount (optional)',
  'questions.contextSource.form-intro': 'Form introduction',
  'questions.salaryMinimumSource': 'Minimum pay source: {source}',
  'questions.contextSource.owner-target': 'Owner target',
  'questions.salaryTitle': 'Salary targets',
  'questions.salaryHint':
    'Enter an independent monthly net target for each currency. Enter gross amounts or explicitly choose a calculation using your own tax schedule and dated exchange rates. Hourly rates round up using your hours and step. Missing or stale inputs require review.',
  'questions.salaryEnabled': 'Use configured salary targets',
  'questions.salaryApproved':
    'Approve complete salary answers for automatic sending',
  'questions.salaryHours':
    'Work hours per month (empty disables hourly answers)',
  'questions.salaryDefault': 'Default salary currency',
  'questions.salaryBasis': 'Default tax basis',
  'questions.salaryCurrency': 'Salary currency',
  'questions.salaryCode': 'Currency code, e.g. USD',
  'questions.salaryKeywords': 'Currency words, comma-separated',
  'questions.salary.net': 'Monthly net amount',
  'questions.salary.gross': 'Monthly gross amount',
  'questions.salary.hourlyStep': 'Hourly rounding step',
  'questions.salaryAdd': 'Add salary currency',
  'questions.salaryRemove': 'Remove salary currency',
  'questions.salaryClear': 'Remove salary settings',
  'questions.match.salary': 'Configured salary target',
  'questions.salaryMethod': 'Gross amount method',
  'questions.salaryMethod.explicit': 'Entered gross amount',
  'questions.salaryMethod.personal': 'Progressive personal tax',
  'questions.salaryMethod.company': 'Company tax and payout',
  'questions.salary.grossStep': 'Calculated monthly gross rounding step',
  'questions.salaryTaxHint.personal':
    'Enter your applicable annual gross-income bands and rates. Each rate applies only within its band; the final band is unlimited. No jurisdiction or legal rates are assumed.',
  'questions.salaryTaxHint.company':
    'A band selects one tax rate for the whole annual gross income. Payout tax applies after company tax. A band currency can differ from the salary currency when a fresh exchange rate is available.',
  'questions.salaryTaxCurrency': 'Personal tax currency',
  'questions.salaryBand': 'Tax band {number}',
  'questions.salaryBandLimit': 'Annual gross upper limit',
  'questions.salaryBandCurrency': 'Band currency (empty uses salary currency)',
  'questions.salaryTaxRate': 'Tax rate (%)',
  'questions.salaryPayout': 'Additional payout tax (%)',
  'questions.salaryUnlimited': 'Final band: no upper limit',
  'questions.salaryAddBand': 'Add limited tax band',
  'questions.salaryRemoveBand': 'Remove tax band',
  'questions.salaryAddTax': 'Configure tax schedule',
  'questions.salaryRemoveTax': 'Remove tax schedule',
  'questions.salaryExchange': 'Dated exchange rates',
  'questions.salaryExchangeHint':
    'Rates are base-currency units for one unit of each listed currency. They convert tax thresholds only; independent net targets are unchanged. Source and date appear with calculated answers. Missing or stale rates require review.',
  'questions.salaryExchangeBase': 'Exchange base currency',
  'questions.salaryExchangeDate': 'Rate date',
  'questions.salaryExchangeSource': 'Rate source',
  'questions.salaryExchangeSource.manual': 'Owner-supplied rates',
  'questions.salaryExchangeSource.cbr': 'CBR snapshot',
  'questions.salaryExchangeAge': 'Maximum rate age (days)',
  'questions.salaryExchangeRate': 'Base units per one currency unit',
  'questions.salaryAddRate': 'Add exchange rate',
  'questions.salaryRemoveRate': 'Remove exchange rate',
  'questions.salaryAddExchange': 'Configure exchange rates',
  'questions.salaryRemoveExchange': 'Remove exchange rates',
  'questions.salaryCalculationEvidence': 'Salary calculation details',
  'questions.salaryFetchRates': 'Refresh from Bank of Russia',
  'questions.salaryUseCachedRates': 'Use cached rates',
  'questions.salaryRatesLoading': 'Loading exchange rates…',
  'questions.salaryRates.updated': 'Bank of Russia rates loaded ({date}).',
  'questions.salaryRates.cached': 'Cached rates loaded ({date}).',
  'questions.salaryRates.stale':
    'Rates dated {date} are stale. Calculated answers require review.',
  'questions.salaryRates.unavailable':
    'No saved rates are available. Enter a snapshot or retry the refresh.',
  'questions.salaryRatesFallback':
    'Refresh did not provide newer valid rates; any available saved snapshot is retained.',
  'questions.salaryRatesDraft': 'Rates are applied to this draft.',
  'questions.salaryRatesChanged':
    'Exchange settings changed while rates were loading. Your edits are kept; retry to replace them.',
  'questions.salaryExchangeMode': 'Exchange-rate policy',
  'questions.salaryExchangeMode.snapshot': 'Use this saved snapshot',
  'questions.salaryExchangeMode.cbr':
    'Refresh automatically from Bank of Russia',
  'questions.salaryExchangeModeHint':
    'Automatic mode uses fresh cached rates and refreshes missing or stale rates before planning. Failed requests keep the dated cache and retry after five minutes. Saved snapshot values are used only in snapshot mode.',
};
import { enFollowBacklink } from './en-follow-backlink.js';
