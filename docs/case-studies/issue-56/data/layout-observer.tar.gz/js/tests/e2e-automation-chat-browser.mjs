import { requestBody } from './helpers/http-wire.mjs';
// A real chat-menu test creates a visible draft without delivering a message.
import { createMemoryStore } from '../src/storage/universal.js';
import { assert, fulfil, openChatApp } from './helpers/e2e-chat.mjs';
import { verifyLayoutObserver } from './helpers/e2e-layout-observer.mjs';

const store = createMemoryStore();
for (const chat of ['111', '222']) {
  for (const [id, sender, body] of [
    [1, 'me', 'Здравствуйте! Вы свободны?'],
    [2, chat, 'Да, слушаю вас'],
  ]) {
    await store.put({
      id: `msg:telegram:${chat}:${id}`,
      source: 'telegram',
      chat,
      chatType: 'personal_chat',
      chatName: `Fixture ${chat}`,
      sender,
      senderName: sender === 'me' ? 'Me' : `Fixture ${chat}`,
      body,
      timestamp: new Date(Date.now() - (3 - id) * 60_000).toISOString(),
      raw: { id },
    });
  }
}
await store.putMany(
  Array.from({ length: 24 }, (_, i) => ({
    id: `msg:telegram:111:${i + 3}`,
    source: 'telegram',
    chat: '111',
    chatType: 'personal_chat',
    chatName: 'Fixture 111',
    sender: '111',
    body: `Earlier fixture ${i}\n${'A line of history.\n'.repeat(3)}`,
    timestamp: new Date(Date.now() - (30 - i) * 60_000).toISOString(),
  }))
);
const sent = [];
const { page, base, until, finish } = await openChatApp('automation-chat', {
  store,
  send: async (draft) => {
    sent.push(draft);
    return { via: 'fixture' };
  },
});
const requests = [];
const layouts = [];
let fail = false;
let failedAction = null;
await page.route('**/api/automations/run', async (route) => {
  await new Promise((resolve) => globalThis.setTimeout(resolve, 400));
  return fail
    ? fulfil(route, { error: 'fixture planning failure' }, 503)
    : route.continue();
});
await page.route('**/api/automations/drafts/*', (route) =>
  route.request().url().endsWith(`/${failedAction}`)
    ? fulfil(route, { error: 'fixture draft refusal' }, 503)
    : route.continue()
);
page.on('request', (request) => {
  if (request.url().endsWith('/api/client-log')) {
    const entry = requestBody(request);
    if (entry.event === 'chat_layout') {
      layouts.push(entry);
    }
  }
  if (request.url().endsWith('/api/automations/run')) {
    requests.push(requestBody(request));
  }
});
await page.addInitScript(() => {
  globalThis.localStorage.setItem('metaSovereignReadReceipts', 'off');
});

const testButton = () =>
  page.locator(
    '[data-action="chat-automation-test"][data-automation="automation:job-search"]'
  );
const openMenu = async () => {
  await page.locator('[data-action="chat-automations"]').click();
  await testButton().waitFor();
};
const initialTest = async () => {
  await page.goto(`${base}/#chat=telegram:111`);
  await page.locator('.chat-composer').waitFor();
  await openMenu();
  await testButton().click();
  assert(await testButton().isDisabled(), 'busy tests cannot be clicked twice');
  assert(
    (await testButton().getAttribute('aria-busy')) === 'true',
    'preparation is visible'
  );
  await page.locator('.draft-card').waitFor({ timeout: 5000 });
  assert(requests.length === 1, 'test sends one request');
  assert(requests[0].test === true, 'test ignores audience conditions');
  assert(
    JSON.stringify(requests[0].targets) ===
      JSON.stringify([{ source: 'telegram', chat: '111' }]),
    'only the selected conversation is targeted'
  );
  assert(sent.length === 0, 'a safe test does not deliver a message');
  assert(
    (await page.locator('.draft-card').count()) === 1,
    'one visible draft'
  );
  const geometry = await page.locator('.draft-card').evaluate((card) => ({
    bottom: card.getBoundingClientRect().bottom,
    composer: document.querySelector('.chat-composer').getBoundingClientRect()
      .top,
  }));
  assert(
    geometry.bottom < geometry.composer,
    'draft actions are visible above the composer'
  );
};

const closeAndReopen = async () => {
  await page.locator('.draft-card textarea').fill('My unsent edit');
  await page.locator('[data-action="draft-close"]').click();
  await page.locator('.draft-card').waitFor({ state: 'detached' });
  const saved = await store.query((link) =>
    link.id.startsWith('automation-draft:')
  );
  assert(
    saved.length === 1 && saved[0].status === 'pending',
    'close does not skip or send the draft'
  );
  await openMenu();
  await page.keyboard.press('Escape');
  await page.locator('.chat-menu-list').waitFor({ state: 'detached' });
  await openMenu();
  await page.locator('.chat-composer textarea').click();
  await page.locator('.chat-menu-list').waitFor({ state: 'detached' });
  await openMenu();
  await testButton().click();
  await page.locator('.draft-card').waitFor();
  await page.waitForTimeout(250);
  assert(
    (await page.locator('.draft-card').count()) === 1,
    're-test reopens one draft'
  );
  assert(
    (await page.locator('.draft-card textarea').inputValue()) ===
      'My unsent edit',
    'unsent edits survive close and refresh'
  );
  assert(
    (await page.locator('[data-notice="queued"]').count()) === 1,
    're-test reports the available draft rather than nothing'
  );
  assert(sent.length === 0, 'testing and closing never send');
};

const failedAndLateResults = async () => {
  fail = true;
  await openMenu();
  await testButton().click();
  await page
    .locator('[data-notice="failed"]')
    .filter({ hasText: 'fixture planning failure' })
    .waitFor();
  assert(
    (await page.locator('[data-notice="failed"]').textContent()).includes(
      'fixture planning failure'
    ),
    'the owned action reports its actual error'
  );
  fail = false;
  await openMenu();
  await testButton().click();
  await page.locator('[data-chat="telegram:222"]').click();
  await page.locator('[data-row="msg:telegram:222:2"]').waitFor();
  await page.waitForTimeout(600);
  assert(
    (await page.locator('.draft-card').count()) === 0,
    'an old draft never appears in the newly selected conversation'
  );
  assert(sent.length === 0, 'late results never send');
};

const refusedDraftAction = async () => {
  for (const action of ['send', 'form', 'mark', 'skip']) {
    failedAction = action;
    await page.locator(`[data-action="draft-${action}"]`).click();
    await page.waitForFunction(
      (name) =>
        document.querySelector(`[data-action="draft-${name}"]`)?.disabled ===
        false,
      action
    );
    await page.waitForFunction(() =>
      document
        .querySelector('[data-notice="failed"]')
        ?.textContent.includes('fixture draft refusal')
    );
    assert(
      (await page.locator('.draft-card textarea').inputValue()) ===
        'My unsent edit',
      'refused actions retain the unsent edit'
    );
    const pending = await store.query((link) =>
      link.id.startsWith('automation-draft:')
    );
    assert(
      pending.length === 1 && pending[0].status === 'pending',
      'the preview remains pending after a refusal'
    );
  }
  failedAction = null;
  assert(sent.length === 0, 'refused actions never deliver');
};

const sentLayout = async () => {
  await page.route('**/api/automations/next', (route) =>
    fulfil(route, {
      draft: { source: 'telegram', chat: '222', name: 'Fixture 222' },
    })
  );
  await page.locator('[data-chat="telegram:111"]').click();
  await openMenu();
  await testButton().click();
  await page.locator('.draft-card').waitFor();
  await page
    .locator('.draft-card textarea')
    .fill(`Sent fixture\n\n${'A multiline confirmed message.\n'.repeat(5)}`);
  await page.locator('.chat-scroll').evaluate((node) => {
    node.scrollTop = 0;
  });
  await page
    .locator('[data-action="draft-send"]')
    .evaluate((node) => node.click());
  const row = page.locator('.bubble-row').filter({ hasText: 'Sent fixture' });
  await row.waitFor();
  await page.locator('.draft-card').waitFor({ state: 'detached' });
  await page.locator('[data-notice="draft-send"]').waitFor();
  await page.locator('.chat-notice.next-chat').waitFor();
  await until(async () => {
    const gap = await row.evaluate((node) => {
      const composer = globalThis.document.querySelector('.chat-composer');
      return (
        composer.getBoundingClientRect().top -
        node.getBoundingClientRect().bottom
      );
    });
    return gap >= 6 && gap <= 12;
  }, 'sent automation message stays above the composer after preview removal');
  assert(sent.length === 1, 'explicit Send delivers exactly once');
  await until(
    () => layouts.some((entry) => entry.messages === 27 && entry.following),
    'settled send geometry is recorded'
  );
  assert(
    !layouts.some((entry) => entry.level === 'warn'),
    `normal reading and sent messages do not produce false overlap warnings: ${JSON.stringify(layouts.filter((entry) => entry.level === 'warn'))}`
  );
  await page.locator('.chat-notice.next-chat .icon-btn').click();
  await page.locator('[data-notice="draft-send"] .icon-btn').click();
  const composer = page.locator('.chat-composer textarea');
  await composer.focus();
  await composer.fill('A new draft\n'.repeat(6));
  await composer.fill('');
  await until(async () => {
    const gap = await row.evaluate(
      (node) =>
        globalThis.document
          .querySelector('.chat-composer')
          .getBoundingClientRect().top - node.getBoundingClientRect().bottom
    );
    return gap >= 6 && gap <= 12;
  }, 'clearing banners and changing composer height keep the confirmed send visible');
};

await finish(async () => {
  await initialTest();
  await closeAndReopen();
  await refusedDraftAction();
  await failedAndLateResults();
  await sentLayout();
  await verifyLayoutObserver(page.context().browser());
});
