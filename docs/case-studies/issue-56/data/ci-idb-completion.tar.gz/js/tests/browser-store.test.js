/**
 * Browser-side store tests. We exercise the contract directly with
 * the in-memory driver and the localStorage driver (with a hand-
 * rolled tiny shim) to keep the test suite zero-dep and runnable
 * under plain Node.
 *
 * The IndexedDB driver is exercised via a minimal in-memory IDB
 * shim that implements the subset we touch — enough to prove the
 * adapter wires the request/transaction lifecycle correctly.
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { snapshotLocks } from './helpers/snapshot-locks.mjs';

import {
  createBrowserStore,
  createDoubletsWebDriver,
  createInMemoryDriver,
  createLocalStorageDriver,
  createIndexedDbDriver,
} from '../src/storage/browser-store.js';

test('browser store: put / get / delete / query / subscribe', async () => {
  const store = await createBrowserStore();
  const seen = [];
  store.subscribe((e) => seen.push(e));

  await store.put({ id: 'l:a', tokens: ['hello'] });
  await store.put({ id: 'l:b', tokens: ['world'] });

  assert.equal((await store.get('l:a')).tokens[0], 'hello');
  assert.equal((await store.query()).length, 2);

  const filtered = await store.query((l) => l.id === 'l:b');
  assert.equal(filtered.length, 1);

  await store.delete('l:a');
  assert.equal(await store.get('l:a'), null);
  assert.deepEqual(
    seen.map((e) => e.type),
    ['put', 'put', 'delete']
  );
});

test('browser store: in-memory driver round-trips via reload', async () => {
  const driver = createInMemoryDriver();
  const a = await createBrowserStore({ driver });
  await a.put({ id: 'l:keep-me', tokens: ['x'] });
  await a.flush();

  const b = await createBrowserStore({ driver });
  assert.equal((await b.get('l:keep-me'))?.tokens[0], 'x');
});

test('browser store: localStorage driver persists snapshots', async () => {
  const fakeStorage = (() => {
    const map = new Map();
    return {
      getItem: (k) => (map.has(k) ? map.get(k) : null),
      setItem: (k, v) => map.set(k, String(v)),
      removeItem: (k) => map.delete(k),
    };
  })();
  const driver = createLocalStorageDriver(fakeStorage, 'test:snapshot', {
    locks: snapshotLocks(),
  });

  const a = await createBrowserStore({ driver });
  await a.put({ id: 'l:p', tokens: ['persist'] });
  await a.flush();

  // Verify the raw shape so future debugging is easier.
  const raw = JSON.parse(fakeStorage.getItem('test:snapshot'));
  assert.equal(raw.links[0].id, 'l:p');

  const b = await createBrowserStore({ driver });
  assert.equal((await b.get('l:p'))?.tokens[0], 'persist');
});

test('browser store: doublets-web driver indexes snapshots as triples', async () => {
  class Link {
    constructor(id, from_id, to_id) {
      this.id = id;
      this.from_id = from_id;
      this.to_id = to_id;
    }
  }
  class LinksConstants {
    constructor() {
      this.any = 0;
    }
  }
  class UnitedLinks {
    constructor(constants) {
      this.constants = constants;
      this.next = 0;
      this.rows = new Map();
    }
    create() {
      this.next += 1;
      return this.next;
    }
    update(id, from_id, to_id) {
      this.rows.set(id, new Link(id, from_id, to_id));
      return id;
    }
    count(query = null) {
      if (!query) {
        return this.rows.size;
      }
      return [...this.rows.values()].filter((row) => {
        const any = this.constants.any;
        return (
          (query.id === any || query.id === row.id) &&
          (query.from_id === any || query.from_id === row.from_id) &&
          (query.to_id === any || query.to_id === row.to_id)
        );
      }).length;
    }
  }

  const snapshotDriver = createInMemoryDriver();
  const driver = createDoubletsWebDriver({
    doubletsWeb: { Link, LinksConstants, UnitedLinks },
    snapshotDriver,
  });
  const store = await createBrowserStore({ driver });
  await store.put({
    id: 'l:doublets',
    tokens: ['message', 'web'],
    children: ['body:l:doublets'],
  });
  await store.flush();

  const stats = driver.stats();
  assert.equal(stats.package, 'doublets-web');
  assert.equal(stats.records, 1);
  assert.ok(stats.atoms >= 5);
  assert.ok(stats.triples >= 5);

  const raw = await snapshotDriver.load();
  assert.equal(raw.doubletsWeb.package, 'doublets-web');
  assert.equal(raw.links[0].id, 'l:doublets');

  const reloaded = await createBrowserStore({ driver });
  assert.equal((await reloaded.get('l:doublets'))?.tokens[1], 'web');
});

test(
  'browser store: indexedDB driver works against a minimal IDB shim',
  { timeout: 2000 },
  async () => {
    const databases = new Map();
    const makeDb = () => {
      const stores = new Map();
      return {
        _stores: stores,
        objectStoreNames: { contains: (n) => stores.has(n) },
        createObjectStore(n) {
          stores.set(n, new Map());
          return stores.get(n);
        },
        transaction(n) {
          const map = stores.get(n);
          let pending = 0;
          let aborted = false;
          const request = (run) => {
            const req = {};
            pending++;
            // Deliberately exceed the old shim's four-ms completion timer.
            // Completion belongs to the request tree, not elapsed wall time.
            setTimeout(() => {
              if (aborted) {
                return;
              }
              req.result = run();
              req.onsuccess?.();
              pending--;
              globalThis.queueMicrotask(() => {
                if (!pending && !aborted) {
                  tx.oncomplete?.();
                }
              });
            }, 10);
            return req;
          };
          const tx = {
            oncomplete: null,
            onabort: null,
            onerror: null,
            abort() {
              aborted = true;
              tx.onabort?.();
            },
            objectStore: () => ({
              get: (key) => request(() => map.get(key)),
              put: (value, key) => request(() => map.set(key, value)),
            }),
          };
          return tx;
        },
      };
    };

    const idbShim = {
      open(name) {
        const req = {};
        setTimeout(() => {
          let db = databases.get(name);
          const fresh = !db;
          if (fresh) {
            db = makeDb();
            databases.set(name, db);
          }
          req.result = db;
          if (fresh) {
            req.onupgradeneeded?.();
          }
          req.onsuccess?.();
        });
        return req;
      },
    };

    const driver = createIndexedDbDriver({ factory: idbShim });
    const a = await createBrowserStore({ driver });
    await a.put({ id: 'l:idb', tokens: ['stored'] });
    assert.equal(
      (await driver.load())?.links[0]?.id,
      'l:idb',
      'a completed transaction must contain its nested write'
    );
    await a.flush();

    const driver2 = createIndexedDbDriver({ factory: idbShim });
    const b = await createBrowserStore({ driver: driver2 });
    assert.equal((await b.get('l:idb'))?.tokens[0], 'stored');
  }
);

test('browser store: indexedDB driver attaches transaction completion before writes', async () => {
  let completionHandlerWasAttachedBeforePut = null;
  let snapshot = null;
  const objectStoreNames = new Set(['snapshot']);
  const makeRequest = (run) => {
    const req = {};
    Promise.resolve().then(() => {
      try {
        req.result = run();
        req.onsuccess?.();
      } catch (error) {
        req.error = error;
        req.onerror?.();
      }
    });
    return req;
  };

  const db = {
    objectStoreNames: { contains: (name) => objectStoreNames.has(name) },
    createObjectStore(name) {
      objectStoreNames.add(name);
    },
    transaction() {
      const tx = {
        oncomplete: null,
        onabort: null,
        onerror: null,
        objectStore: () => ({
          get() {
            return makeRequest(() => snapshot);
          },
          put(value) {
            completionHandlerWasAttachedBeforePut =
              typeof tx.oncomplete === 'function';
            const req = makeRequest(() => {
              snapshot = value;
              return undefined;
            });
            setTimeout(() => tx.oncomplete?.(), 0);
            return req;
          },
        }),
      };
      return tx;
    },
  };

  const factory = {
    open() {
      return makeRequest(() => db);
    },
  };

  const store = await createBrowserStore({
    driver: createIndexedDbDriver({ factory }),
  });
  await store.put({ id: 'l:idb-listener-order', tokens: ['stored'] });
  await store.flush();

  assert.equal(completionHandlerWasAttachedBeforePut, true);
});
