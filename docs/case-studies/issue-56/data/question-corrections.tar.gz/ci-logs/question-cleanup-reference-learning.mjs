/** Learning shared by the chat window, application panel and history slot. */
import { learnedPairs, isSupportChat, countChatAnswers, ANSWER_COUNTS_VERSION } from './chat-answers.mjs';
import { createChatHistory } from './chat-history.mjs';
import { normalizeQuestion } from './qa-database.mjs';
import { contractContacts } from './contacts.mjs';
import { ANSWER_SEPARATOR } from './qa.mjs';
import { mergeAnswerFrequencies } from './answer-variants.mjs';
import { fitsAvailabilityQuestion } from './answer-preferences.mjs';
import { allowedCorrectedAnswer, emptyAnswerCorrections, applyAnswerCorrections } from './answer-corrections.mjs';

/** Access-controlled recruiter links belong in the private transcript, never the shared Q&A. */
export const hasPrivateRecruiterLinks = (text) => /https?:\/\/\S*(?:\/private\/|[?&](?:token|access_token|auth|key|p)=)/iu.test(String(text));

/**
 * Read every distinct answer given to the same question, without changing the user's saved
 * wording. Checkbox arrays keep their meaning. Contacts are templated before expansion in the
 * vacancy's context. The archive is the source of variants, including answers to known questions.
 */
export function withChatHistoryAnswers(db, { history = createChatHistory(), contacts = {}, finalPeriod, corrections = emptyAnswerCorrections } = {}) {
  let previous;
  let recordedCounts = [];
  const read = async () => {
    const policy = await corrections.read();
    const raw = applyAnswerCorrections(await db.readQADatabase(), policy);
    const chats = await history.read();
    if (chats !== previous) {
      recordedCounts = Object.values(chats).filter((chat) => !isSupportChat(chat))
        .flatMap((chat) => chat.answerCountsVersion === ANSWER_COUNTS_VERSION ? chat.answerCounts : countChatAnswers(chat.messages));
      previous = chats;
    }
    const keys = new Map([...raw.keys()].map((key) => [normalizeQuestion(key), key]));
    const frequencies = new Map([...raw].filter(([, answer]) => !Array.isArray(answer)).map(([question, answer]) =>
      [question, new Map(String(answer).split(ANSWER_SEPARATOR).map((text) => [text, 0]))]));
    for (const { question, answer: reply, count } of recordedCounts) {
      if (!allowedCorrectedAnswer(question, reply, policy)) continue;
      const normalized = normalizeQuestion(question);
      const key = keys.get(normalized) ?? question;
      keys.set(normalized, key);
      const saved = raw.get(key);
      if (Array.isArray(saved)) continue;
      const answers = frequencies.get(key) ?? new Map();
      const answer = contractContacts(reply, contacts).trim();
      if (answer) answers.set(answer, (answers.get(answer) ?? 0) + count);
      frequencies.set(key, answers);
    }
    const ranked = new Map();
    for (const [question, counts] of frequencies) {
      const answers = mergeAnswerFrequencies([...counts].filter(([answer]) => fitsAvailabilityQuestion(question, answer))
        .map(([answer, count]) => ({ answer, count })), { finalPeriod, question });
      if (answers.length) raw.set(question, answers.map(({ answer }) => answer).join(ANSWER_SEPARATOR));
      else raw.delete(question);
      ranked.set(question, answers);
    }
    return { answers: applyAnswerCorrections(raw, policy), frequencies: ranked };
  };
  return {
    ...db,
    answerCorrections: corrections,
    readSavedQADatabase: async () => applyAnswerCorrections(await db.readQADatabase(), await corrections.read()),
    async readQADatabase() {
      return (await read()).answers;
    },
    async readAnswerFrequencies() {
      return (await read()).frequencies;
    },
  };
}

/** Persist the transcript first, then learn new questions; existing saved answers stay intact. */
export async function learnChatQuestions(chat, { history, qaDatabase, buttonQuestions = new Set(), log = console.log, corrections = qaDatabase.answerCorrections ?? emptyAnswerCorrections }) {
  if (chat?.transitioning) return;
  await history.record(chat);
  if (!chat?.id || isSupportChat(chat)) return;
  const kept = (await history.read())[chat.id] ?? chat;
  const { questions, templates } = learnedPairs(kept.messages);
  const asked = templates.filter(([question]) => buttonQuestions.has(normalizeQuestion(question)));
  const known = await (qaDatabase.readSavedQADatabase ?? qaDatabase.readQADatabase)();
  const policy = await corrections.read();
  for (const [question, answer] of [...questions, ...asked]) {
    if (!allowedCorrectedAnswer(question, answer, policy)) continue;
    if (hasPrivateRecruiterLinks(question)) continue;
    if (known.has(question)) continue;
    if (qaDatabase.addQAIfMissing) {
      if (!await qaDatabase.addQAIfMissing(question, answer)) continue;
    } else {
      if ((await qaDatabase.readQADatabase()).has(question)) continue;
      await qaDatabase.addOrUpdateQA(question, answer);
    }
    known.set(question, answer);
    log(`💾 Learned from the chat (qa.lino): ${question}`);
  }
}
