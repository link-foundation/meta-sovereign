// The frame the chat screen's browser e2e tests share: skipped unless
// RUN_BROWSER_E2E is set (and Playwright is there), a server on a free
// port over the test's memory store with Telegram's sends faked, a
// headless page on it with Telegram connected, and the run ended as a
// pass or a fail with a screenshot. Nothing reaches a network or a
// running app.

import { mkdtemp, mkdir, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { startServer } from '../../src/server/index.js';
import { fulfilWire } from './http-wire.mjs';
import { watchChatPages, screenshotChatPages } from './e2e-page-errors.mjs';

export const assert = (cond, msg) => {
  if (!cond) {
    throw new Error(`assertion failed: ${msg}`);
  }
};

/** A route answered with JSON. */
export const fulfil = (route, body, status = 200) =>
  fulfilWire(route, {
    status,
    contentType: 'application/json',
    body: JSON.stringify(body),
  });

// The browser asked for, or the test skipped as a pass.
export const browserOf = async (name) => {
  const skip = (msg) => {
    console.log(`[e2e-${name}] SKIP: ${msg}`);
    process.exit(0);
  };
  if (!process.env.RUN_BROWSER_E2E) {
    skip('RUN_BROWSER_E2E not set');
  }
  const engine = process.env.E2E_BROWSER || 'chromium';
  try {
    return { engine, browserType: (await import('playwright'))[engine] };
  } catch (cause) {
    throw new Error(
      'RUN_BROWSER_E2E requires Playwright; run npm ci and playwright install',
      { cause }
    );
  }
};

/**
 * The app on `store` in a headless page: `{ engine, base, page, errors,
 * until, finish }`. `send` takes the drafts the composer sends;
 * `finish(steps)` runs the test's steps and exits.
 */
export const openChatApp = async (
  name,
  {
    store,
    send = async () => ({ via: 'fake' }),
    telegramAccount = false,
    secure = false,
    launchOptions = {},
    fileBackups = false,
    acceptDialog,
    traceRequests = false,
    // More server options (R-Y202: the extra accounts' stores and services).
    serverOptions = {},
  }
) => {
  const { engine, browserType } = await browserOf(name);
  const dir = await mkdtemp(path.join(os.tmpdir(), `ms-e2e-${name}-`));
  const handle = await startServer({
    localUi: true,
    port: 0,
    storeDir: dir,
    store,
    ...(fileBackups ? { archiveDir: path.join(dir, 'archives') } : {}),
    enableSync: false,
    enableHandlers: false,
    telegramAccount,
    tls: secure,
    log: null,
    automations: {
      scheduler: false,
      setTyping: async () => ({ supported: false }),
      send,
    },
    ...serverOptions,
  });
  const base = `${secure ? 'https' : 'http'}://127.0.0.1:${handle.port}`;
  const browser = await browserType.launch({
    headless: true,
    ...(process.env.E2E_EXECUTABLE_PATH
      ? { executablePath: process.env.E2E_EXECUTABLE_PATH }
      : {}),
    ...launchOptions,
  });
  const context = await browser.newContext({
    viewport: { width: 1200, height: 800 },
    ignoreHTTPSErrors: secure,
  });
  const errors = [];
  watchChatPages(context, {
    errors,
    engine,
    base,
    acceptDialog,
    trace:
      process.env.CI_BROWSER_DEBUG === '1' || traceRequests
        ? (event) => console.log(`[e2e-${name}] ${event}`)
        : undefined,
  });
  const page = await context.newPage();
  await page.route('**/api/telegram/status', (route) =>
    fulfil(route, {
      connected: true,
      kind: 'user',
      account: { username: 'owner' },
      offline: false,
      needsLogin: false,
    })
  );
  if (!telegramAccount && !serverOptions.telegramAccount) {
    // A connected fixture with only cached messages has no real history
    // reader. Tests that exercise loading override this route explicitly.
    await page.route('**/api/telegram/history', (route) =>
      fulfil(route, { written: 0, cached: true, complete: true })
    );
    await page.route('**/api/telegram/calls', (route) =>
      fulfil(route, { ok: true, calls: [], next: null })
    );
  }
  const until = async (check, what, ms = 10_000) => {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      if (await check()) {
        return;
      }
      await page.waitForTimeout(50);
    }
    throw new Error(`timed out: ${what}`);
  };
  const finish = async (steps) => {
    let failed = false;
    const artifactDir = process.env.E2E_ARTIFACT_DIR || os.tmpdir();
    await mkdir(artifactDir, { recursive: true });
    try {
      await steps();
      assert(errors.length === 0, `page errors: ${errors.join('; ')}`);
      console.log(`[e2e-${name}] OK (${engine})`);
    } catch (error) {
      failed = true;
      console.error(`[e2e-${name}] FAIL (${engine}): ${error.message}`);
      await screenshotChatPages(context, { artifactDir, name, engine });
    } finally {
      await browser.close();
      await handle.close();
      await rm(dir, { recursive: true, force: true });
    }
    process.exit(failed ? 1 : 0);
  };
  return { engine, base, page, errors, until, finish };
};
