import { prepareAnswerModelContext } from './answer-model-context.js';
import { runAnswerModelDrafts } from './answer-model-drafts.js';
import { answerModelFailure } from './answer-model-config.js';
import { questionKey } from './question-match.js';
const validOptions = (options) =>
  options === undefined ||
  (Array.isArray(options) &&
    options.length <= 100 &&
    options.every(
      (choice) => typeof choice === 'string' && choice.length <= 6000
    ));

const unresolvedRequests = (answer, input) => {
  if (answer.noReply) {
    return [];
  }
  if (answer.parts?.length && !input.options?.length) {
    return answer.parts.flatMap((part, index) =>
      part.text
        ? []
        : [
            {
              id: `part:${index}`,
              question: part.question,
              options: [],
            },
          ]
    );
  }
  return answer.text
    ? []
    : [
        {
          id: 'question',
          question: input.question,
          options: input.options ?? [],
        },
      ];
};

const draftedAnswer = (answer, draft, choices, model) => {
  const optionMismatch =
    choices.length > 0 &&
    choices.filter((choice) => questionKey(choice) === questionKey(draft.text))
      .length !== 1;
  return {
    ...answer,
    ...draft,
    match: 'model',
    source: 'model',
    complete: !draft.missing.length && Boolean(draft.text) && !optionMismatch,
    requiresReview: true,
    optionMismatch,
    rules: [],
    model,
  };
};

const mergedAnswer = (answer, result, choices) => {
  if (!result.drafts.length) {
    return { ...answer, model: result.model };
  }
  if (result.drafts[0].id === 'question') {
    return draftedAnswer(answer, result.drafts[0], choices, result.model);
  }
  const byId = new Map(result.drafts.map((draft) => [draft.id, draft]));
  const parts = answer.parts.map((part, index) => {
    const draft = byId.get(`part:${index}`);
    return draft ? draftedAnswer(part, draft, [], result.model) : part;
  });
  const text = parts
    .map(
      (part, index) => `${index + 1}. ${part.text || `{{answer:${index + 1}}}`}`
    )
    .join('\n');
  if (text.length > 12000) {
    return {
      ...answer,
      model: {
        ...result.model,
        state: 'refused',
        used: false,
        code: 'answer-model-output',
      },
    };
  }
  return {
    ...answer,
    text,
    parts,
    complete: parts.every((part) => part.complete),
    requiresReview: true,
    missing: [...new Set(parts.flatMap((part) => part.missing))],
    model: result.model,
  };
};

export const modelAnswerPreview = async (
  store,
  input,
  answer,
  context,
  options
) => {
  if (input.modelDraft !== undefined && typeof input.modelDraft !== 'boolean') {
    throw answerModelFailure(
      'answer-model-config',
      'Model draft opt-in must be a boolean.'
    );
  }
  if (!input.modelDraft) {
    return answer;
  }
  if (!validOptions(input.options)) {
    throw answerModelFailure(
      'answer-model-context',
      'Draft answer options must be bounded text.'
    );
  }
  const prepared = await prepareAnswerModelContext(store, context, [
    input.question,
  ]);
  const requests = unresolvedRequests(answer, input);
  const result = await runAnswerModelDrafts({
    ...options,
    prepared,
    requests,
    policy: context.policy,
  });
  return mergedAnswer(answer, result, input.options ?? []);
};
