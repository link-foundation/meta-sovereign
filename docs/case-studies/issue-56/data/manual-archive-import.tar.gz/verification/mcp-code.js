await (async (page) => {
  const origin = 'http://127.0.0.1:38931';
  const pageExceptions = [];
  let interruptedApiRequests = 0;
  const widths = {};
  page.on('pageerror', (error) => pageExceptions.push(error.message));
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript(() => {
    localStorage.setItem('metaSovereignLocale', 'en');
    localStorage.setItem('metaSovereignTutorial', JSON.stringify({ off: true, v: 5 }));
  });
  const viewport = () => page.evaluate(() => ({
    viewport: innerWidth, scroll: document.documentElement.scrollWidth
  }));
  const messengerBody = 'MCP fixture pasted Messenger message';
  await page.goto(origin + '/#conn-facebook/manual');
  const facebook = page.locator('#conn-facebook');
  await facebook.locator('[data-action="archive-paste"]').fill(JSON.stringify({
    title: 'MCP Messenger archive',
    thread_path: 'inbox/mcp_messenger',
    messages: [{sender_name:'Fixture', timestamp_ms:1760000000000, content:messengerBody}]
  }));
  await facebook.locator('[data-action="archive-import"]').click();
  const facebookReceipt = facebook.getByText(/Imported 1 messages from pasted snippet/);
  await facebookReceipt.waitFor();
  widths.messenger = await viewport();
  await page.route('**/api/**', (route) => {
    interruptedApiRequests += 1;
    return route.abort();
  });
  await page.goto(origin + '/#conn-telegram/manual');
  await page.reload();
  const telegram = page.locator('#conn-telegram');
  const telegramBody = 'MCP fixture uploaded Telegram message';
  await telegram.locator('[data-action="archive-file"]').setInputFiles({
    name:'result.json', mimeType:'application/json', buffer:Buffer.from(JSON.stringify({
      id:7902, name:'MCP Telegram archive',
      messages:[{id:7903, type:'message', text:telegramBody, date:'2026-01-01T10:00:00Z'}]
    }))
  });
  const telegramReceipt = telegram.getByText(/Imported 1 messages from result.json/);
  await telegramReceipt.waitFor();
  widths.telegram = await viewport();
  await page.reload();
  const messages = {};
  for (const [chat, body] of [
    ['facebook:mcp_messenger', messengerBody], ['telegram:7902', telegramBody]
  ]) {
    await page.goto(origin + '/#chat=' + encodeURIComponent(chat));
    const message = page.locator('[data-message]').filter({ hasText: body });
    await message.waitFor();
    messages[chat] = await message.count();
    widths[chat] = await viewport();
  }
  if (pageExceptions.length || !interruptedApiRequests) throw new Error(JSON.stringify({pageExceptions, interruptedApiRequests}));
  return { viewport:[390,844], imported:{messengerPaste:1,telegramFile:1}, restoredMessages:messages, interruptedApiRequests, pageExceptions, widths };
})(page);
