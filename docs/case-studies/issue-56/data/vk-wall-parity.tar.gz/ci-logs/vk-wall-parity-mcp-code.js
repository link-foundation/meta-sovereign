async (page) => { const session = await page.context().newCDPSession(page); await session.send("Network.enable"); await session.send("Network.setCacheDisabled", {cacheDisabled: true}); try { return await (async (page) => (async (page, fixture, check) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      language
    );
    await page.goto(`${fixture.base}/?vkLocale=${language}#conn-vk/manual`);
    const panel = page.locator(`[data-${fixture.feature}]`);
    const ready = () =>
      page.waitForFunction((feature) => {
        const input = document.querySelector(
          `[data-${feature}] input[type=checkbox]`
        );
        return input && !input.disabled;
      }, fixture.feature);
    // A mounted heading and an enabled control distinguish loading from absence.
    await panel
      .getByRole('heading', { name: words.title, exact: true })
      .waitFor();
    await ready();
    for (const key of fixture.keys) {
      if (!(await panel.innerText()).includes(words[key])) {
        throw Error(`Missing ${language}.${key}`);
      }
    }
    const { focus, ...checked } = await check(page, {
      panel,
      words,
      ready,
      feature: fixture.feature,
      action: async (name) => {
        await panel.locator(`[data-action=${fixture.feature}-${name}]`).click();
        await ready();
      },
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await panel.locator(focus).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-${fixture.evidenceName}/mcp-${language}-phone.png`,
    });
    result.push({ language, translated: true, ...checked });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:37151","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","feature":"vk-wall","evidenceName":"vk-wall-parity","keys":["holdAnyVisible"],"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"VK community invitations","holdAnyVisible":"Hold when an invitation from any author is in the top ten"},"ru":{"title":"Приглашения в сообщества ВКонтакте","holdAnyVisible":"Приостанавливать при приглашении любого автора в верхних десяти записях"},"hi":{"title":"VK समुदाय आमंत्रण","holdAnyVisible":"शीर्ष दस में किसी भी लेखक का आमंत्रण होने पर रोकें"},"zh":{"title":"VK 社区邀请","holdAnyVisible":"前十条中有任意作者的邀请时暂停"}}}, (async (page, { panel, ready, action }) => {
  const any = panel.locator('[data-wall-field=holdAnyVisible]');
  await panel.locator('[data-wall-field=communities]').fill('42');
  await panel.locator('[data-wall-field=replaceOwned]').check();
  await any.check();
  await action('save');
  await action('plan');
  if (
    (await panel.locator('[data-wall-reason=visibleInvitation]').count()) !== 1
  ) {
    throw Error('Missing any-author invitation hold');
  }
  const done = await panel.locator('[data-wall-absent]').count();
  if (!done) {
    await any.uncheck();
    await action('save');
    await action('plan');
    await action('run');
    await panel.locator('[data-vk-wall-status=confirmed]').waitFor();
  }
  const absent = panel.locator('[data-wall-absent]');
  const evidence = await absent.innerText();
  if (!evidence.trim() || evidence.includes('vkWall.')) {
    throw Error('Missing translated confirmed-absence evidence');
  }
  await any.check();
  await action('save');
  await page.reload();
  await ready();
  if (!(await any.isChecked())) {
    throw Error('Any-author hold was not retained');
  }
  await action('plan');
  if (
    (await panel.locator('[data-wall-reason=visibleInvitation]').count()) !== 1
  ) {
    throw Error('Missing held destination after reload');
  }
  return {
    focus: '[data-wall-absent]',
    anyAuthorHold: true,
    retainedAfterReload: true,
    confirmedAbsence: true,
  };
})))(page); } finally { await session.detach(); } }