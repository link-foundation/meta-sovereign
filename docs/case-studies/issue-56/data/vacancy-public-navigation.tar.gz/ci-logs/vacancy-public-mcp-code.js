async (page) => {
    await page.goto("https://hh.ru/vacancy/139480236", {waitUntil:'domcontentloaded'});
    await page.locator('[data-qa="vacancy-description"]').waitFor({timeout:20000});
    const read = await page.evaluate(() => {
  const { document } = globalThis;
  const challenge = [
    ...document.querySelectorAll(
      '[data-qa="captcha"], iframe[src*="captcha"], input[name="captcha"], input[data-qa="account-captcha-input"], input[name="captchaText"], .smart-captcha, .g-recaptcha, .h-captcha'
    ),
  ].some((node) => node.getClientRects().length);
  if (challenge) {
    return { url: globalThis.location.href, challenge: true };
  }
  const readText = (elements, limit, equivalentAliases = false) => {
    if (
      elements.length > 1 &&
      (!equivalentAliases ||
        elements.some(
          (node) => node.innerText.trim() !== elements[0].innerText.trim()
        ))
    ) {
      return null;
    }
    const element = elements[0];
    if (!element) {
      return '';
    }
    const value = element.innerText.trim();
    return value.length <= limit ? value : null;
  };
  const visible = (selector) =>
    [...document.querySelectorAll(selector)].filter(
      (node) => node.getClientRects().length
    );
  const text = (selector, limit, equivalentAliases = false) =>
    readText(visible(selector), limit, equivalentAliases);
  const publication = () => {
    const aliases = visible(
      '[data-qa="vacancy-view-creation-time"], [data-qa="vacancy-creation-time"]'
    );
    const times = visible('time');
    if (times.length > 100) {
      return null;
    }
    const dates = new Set();
    for (const node of times) {
      const parent = node.parentElement;
      if (
        node.closest(
          '[data-qa="vacancy-description"], [data-qa="vacancy-serp__vacancy"], form, [contenteditable]'
        ) ||
        !/^Вакансия опубликована(?:\s|$)/u.test(parent?.innerText.trim())
      ) {
        continue;
      }
      const date = node.getAttribute('datetime');
      if (
        !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/u.test(
          date
        ) ||
        !Number.isFinite(Date.parse(date))
      ) {
        return null;
      }
      dates.add(date);
      aliases.push(parent);
    }
    return dates.size > 1 ? null : readText(aliases, 1000, true);
  };
  const texts = (selector, limit, maxItems) => {
    const nodes = [...document.querySelectorAll(selector)];
    if (nodes.length > 200) {
      return null;
    }
    const values = [
      ...new Set(
        nodes
          .filter((node) => node.getClientRects().length)
          .map((node) => node.innerText.trim())
          .filter(Boolean)
      ),
    ];
    return values.length <= maxItems && values.join('\n').length <= limit
      ? values
      : null;
  };
  const workFormats = texts('[data-qa*="work-format"]', 1000, 100);
  const descriptions = [
    ...document.querySelectorAll('[data-qa="vacancy-description"]'),
  ].filter((node) => node.getClientRects().length);
  const description = descriptions.length === 1 ? descriptions[0] : null;
  const html = description?.innerHTML;
  return {
    url: globalThis.location.href,
    challenge: false,
    title: text('[data-qa="vacancy-title"]', 500),
    company: text('[data-qa="vacancy-company-name"]', 500),
    description: text('[data-qa="vacancy-description"]', 30000),
    descriptionHtml: html?.length <= 120000 ? html : null,
    salary: text(
      '[data-qa="vacancy-salary"], [data-qa="vacancy-salary-compensation-type-net"], [data-qa="vacancy-salary-compensation-type-gross"]',
      1000,
      true
    ),
    location: text(
      '[data-qa="vacancy-view-raw-address"], [data-qa="vacancy-view-location"]',
      1000
    ),
    experience: text('[data-qa="vacancy-experience"]', 1000),
    employment: text(
      '[data-qa="vacancy-view-employment-mode"], [data-qa="common-employment-text"] dd',
      1000,
      true
    ),
    workFormat: workFormats?.join('\n') ?? null,
    published: publication(),
    skills: texts(
      '[data-qa="skills-element"], [data-qa="bloko-tag__text"]',
      50000,
      100
    ),
  };
});
    const visible = await page.locator('[data-qa="vacancy-description"]').innerText();
    const html = await page.locator('[data-qa="vacancy-description"]').innerHTML();
    if(read.challenge || !read.title || read.description !== visible.trim() || read.descriptionHtml !== html || read.description.length < 1000) throw Error('Public collection mismatch');
    await page.screenshot({path:"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459/docs/screenshots/issue-56-vacancy-modern/public-source-after.png"});
    return {source:read.url,anonymous:true,liveProvider:true,descriptionCharacters:read.description.length,descriptionHtmlCharacters:read.descriptionHtml.length,skills:read.skills.length,employment:read.employment,published:read.published,fullDomTextEqual:true,exactPrivateHtmlEqual:true,issueComplete:false};
  }