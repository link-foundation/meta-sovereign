import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  readFileSync,
  readdirSync,
  mkdtempSync,
  mkdirSync,
  writeFileSync,
  rmSync,
} from 'node:fs';
import { spawnSync } from 'node:child_process';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parse } from 'yaml';

const root = fileURLToPath(new URL('../../', import.meta.url));
const workflow = (name) =>
  parse(readFileSync(path.join(root, '.github/workflows', name), 'utf8'));

test('browser failures cannot become a green release', () => {
  const jobs = workflow('release.yml').jobs;
  assert.ok(
    jobs['e2e-browser'].strategy.matrix.include.some(
      ({ browser }) => browser === 'webkit'
    )
  );
  for (const step of jobs['e2e-browser'].steps) {
    assert.notEqual(step['continue-on-error'], true);
  }
  assert.ok(jobs.release.needs.includes('pipeline-status'));
});

test('every Rust documentation path rejects warnings', () => {
  const flow = workflow('release.yml');
  let checked = 0;
  for (const job of Object.values(flow.jobs)) {
    for (const step of job.steps || []) {
      if (!step.run?.includes('cargo doc ')) {
        continue;
      }
      const flags =
        step.env?.RUSTDOCFLAGS ??
        job.env?.RUSTDOCFLAGS ??
        flow.env?.RUSTDOCFLAGS;
      assert.match(flags ?? '', /(?:^|\s)-D\s*warnings(?:\s|$)/);
      checked++;
    }
  }
  assert.equal(checked, 3, 'Check and both release documentation paths');
});

test('read-only jobs use supported pinned runner labels and no stored checkout credentials', () => {
  for (const name of readdirSync(path.join(root, '.github/workflows'))) {
    if (!name.endsWith('.yml')) {
      continue;
    }
    const flow = workflow(name);
    for (const job of Object.values(flow.jobs)) {
      assert.doesNotMatch(String(job['runs-on']), /-latest/, name);
      for (const step of job.steps || []) {
        if (step.uses?.startsWith('actions/checkout@')) {
          assert.equal(step.with?.['persist-credentials'], false, name);
        }
      }
    }
    assert.equal(flow.permissions.contents, 'read', name);
  }
});

const fixture = (t) => {
  const dir = mkdtempSync(path.join(os.tmpdir(), 'ms-ci-check-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  spawnSync('git', ['init', '-b', 'main'], { cwd: dir });
  return dir;
};

for (const [message, expected] of [
  ['all checks passed', 0],
  ['SKIP: playwright not installed', 1],
  ['SKIP: playwright is not installed', 1],
  ['SKIP: no Playwright browser is installed', 1],
  ['webkit not installed, skipped', 1],
  ['SKIP: set RUN_BROWSER_E2E=1 to run', 1],
]) {
  test(`mandatory browser runner classifies: ${message}`, (t) => {
    const cwd = fixture(t);
    const checks = expected
      ? ['tutorial']
      : [
          'tutorial',
          'forms-reader',
          'forms-learning',
          'forms-answers',
          'forms-assignment',
        ];
    const scripts = path.join(cwd, 'js/scripts');
    const helpers = path.join(cwd, 'js/tests/helpers');
    mkdirSync(scripts, { recursive: true });
    mkdirSync(helpers, { recursive: true });
    writeFileSync(
      path.join(scripts, 'run-browser-checks.mjs'),
      readFileSync(path.join(root, 'js/scripts/run-browser-checks.mjs'))
    );
    writeFileSync(
      path.join(scripts, 'browser-checks.json'),
      JSON.stringify(checks)
    );
    writeFileSync(
      path.join(helpers, 'e2e-reduced-effects.mjs'),
      '// fixture\n'
    );
    writeFileSync(
      path.join(cwd, 'package.json'),
      JSON.stringify({
        scripts: Object.fromEntries(
          checks.map((name) => [`test:e2e:${name}`, 'node fixture.mjs'])
        ),
      })
    );
    writeFileSync(
      path.join(cwd, 'fixture.mjs'),
      `console.log('group:' + process.env.FORMS_GROUP);\nconsole.log(${JSON.stringify(message)});\n`
    );
    // The CI runner is a Node entry point even when this contract runs on Deno/Bun.
    const result = spawnSync(
      'node',
      [path.join(scripts, 'run-browser-checks.mjs')],
      {
        cwd,
        encoding: 'utf8',
        env: {
          ...process.env,
          NODE_OPTIONS: '--max-old-space-size=384',
          E2E_ARTIFACT_DIR: path.join(cwd, 'artifacts'),
        },
      }
    );
    assert.equal(result.status, expected, result.stdout + result.stderr);
    const summary = JSON.parse(
      readFileSync(path.join(cwd, 'artifacts/summary.json'))
    );
    assert.deepEqual(summary.failures, expected ? ['tutorial'] : []);
    if (!expected) {
      for (const group of checks.slice(1)) {
        assert.match(
          readFileSync(path.join(cwd, `artifacts/${group}.log`), 'utf8'),
          new RegExp(`group:${group}`)
        );
      }
    }
  });
}

test('syntax checking finds malformed nested JavaScript', (t) => {
  const cwd = fixture(t);
  mkdirSync(path.join(cwd, 'js/src/nested'), { recursive: true });
  writeFileSync(path.join(cwd, 'js/src/nested/broken.js'), 'const = ;');
  spawnSync('git', ['add', '.'], { cwd });
  const result = spawnSync(
    'bash',
    [path.join(root, 'js/scripts/check-mjs-syntax.sh').replaceAll('\\', '/')],
    { cwd, encoding: 'utf8' }
  );
  assert.notEqual(result.status, 0, result.stdout);
});

test('missing lychee report fails instead of claiming all links archived', (t) => {
  const cwd = fixture(t);
  const result = spawnSync(
    process.execPath,
    [
      ...(globalThis.Deno ? ['run', '-A'] : []),
      path.join(root, 'js/scripts/check-web-archive.mjs'),
    ],
    {
      cwd,
      encoding: 'utf8',
      env: {
        ...process.env,
        LYCHEE_OUTPUT: path.join(cwd, 'missing.md'),
        GITHUB_OUTPUT: '',
      },
    }
  );
  assert.notEqual(result.status, 0, result.stdout);
});

test('workflow policy detects mutable matrix runners and unbounded auxiliary jobs', async () => {
  const { workflowPolicyErrors } =
    await import('../scripts/workflow-policy.mjs');
  const text = `permissions:\n  contents: read\njobs:\n  test:\n    runs-on: \${{ matrix.os }}\n    strategy:\n      matrix:\n        os: [ubuntu-latest]\n    steps: []\n`;
  const errors = workflowPolicyErrors(text);
  assert.ok(errors.some((error) => error.includes('runner')));
  assert.ok(errors.some((error) => error.includes('timeout')));
  assert.deepEqual(
    workflowPolicyErrors(
      text
        .replace('ubuntu-latest', 'ubuntu-24.04')
        .replace('    steps: []', '    timeout-minutes: 5\n    steps: []')
    ),
    []
  );
});

test('committed dependency tree contains no deprecated registry packages', () => {
  const lock = JSON.parse(
    readFileSync(path.join(root, 'package-lock.json'), 'utf8')
  );
  const deprecated = Object.entries(lock.packages)
    .filter(([, info]) => info.deprecated)
    .map(([name, info]) => `${name}@${info.version}: ${info.deprecated}`);
  assert.deepEqual(deprecated, []);
});

test('standalone shell lint selects maintained scripts without reference evidence', (t) => {
  const cwd = fixture(t);
  const files = [
    'js/scripts/check.sh',
    '.husky/pre-commit',
    'dev/log/issues/43/pulls/44/templates/js/files/scripts/reference.sh',
    'docs/case-studies/example/data/reference.sh',
  ];
  for (const file of files) {
    mkdirSync(path.dirname(path.join(cwd, file)), { recursive: true });
    writeFileSync(path.join(cwd, file), '#!/bin/sh\n');
  }
  spawnSync('git', ['add', '.'], { cwd });
  const step = workflow('release.yml').jobs['workflow-lint'].steps.find(
    ({ name }) => name === 'ShellCheck standalone scripts and hooks'
  );
  const selection = step.run.split(' | xargs')[0];
  const result = spawnSync('bash', ['-c', selection], {
    cwd,
    encoding: 'utf8',
  });
  assert.equal(result.status, 0, result.stderr);
  assert.deepEqual(
    result.stdout.split('\0').filter(Boolean).sort(),
    files.slice(0, 2).sort()
  );
});

// Browser Commander now launches Chrome for Testing directly. Ubuntu's
// AppArmor restriction must be lifted before that sandbox starts.
test('Ubuntu browser fixtures permit Chromium user-namespace sandboxing', () => {
  const steps = workflow('release.yml').jobs['e2e-browser'].steps;
  const setup = steps.findIndex((step) =>
    step.run?.includes('kernel.apparmor_restrict_unprivileged_userns=0')
  );
  const browser = steps.findIndex((step) =>
    step.run?.includes('run-browser-checks.mjs')
  );
  assert.ok(
    setup >= 0 && setup < browser,
    'enable namespaces before browser checks'
  );
  assert.equal(steps[setup].if, "runner.os == 'Linux'");
});

test('browser jobs install Chromium for the cross-origin Pages fixture in either matrix lane', () => {
  const steps = workflow('release.yml').jobs['e2e-browser'].steps;
  const install = steps.find(({ name }) => name === 'Install the browser');
  // e2e-pages always compares the server and hosted copies in Chromium,
  // even while the rest of the matrix lane exercises WebKit.
  assert.match(
    install.run,
    /playwright install --with-deps chromium "\$BROWSER"/
  );
  assert.equal(install.env.BROWSER, '${{ matrix.browser }}');
});

test('inbox history and form inspection run in both mandatory browser lanes', () => {
  const checks = JSON.parse(
    readFileSync(path.join(root, 'js/scripts/browser-checks.json'))
  );
  const scripts = JSON.parse(
    readFileSync(path.join(root, 'package.json'))
  ).scripts;
  assert.ok(checks.includes('inbox-pull'));
  assert.match(scripts['test:e2e:inbox-pull'], /e2e-inbox-pull-browser/);
  assert.match(scripts['test:e2e:inbox-pull:webkit'], /E2E_BROWSER=webkit/);
  assert.ok(checks.includes('forms-reader'));
  for (const group of ['forms-learning', 'forms-answers', 'forms-assignment']) {
    assert.ok(checks.includes(group));
    assert.match(scripts[`test:e2e:${group}`], /e2e-forms-reader-browser/);
  }
  assert.match(scripts['test:e2e:forms-reader'], /e2e-forms-reader-browser/);
  assert.match(scripts['test:e2e:forms-reader:webkit'], /E2E_BROWSER=webkit/);
  assert.match(scripts['test:e2e:forms-watchers'], /e2e-forms-watcher-browser/);
  const reader = readFileSync(
    path.join(root, 'js/tests/e2e-forms-reader-browser.mjs'),
    'utf8'
  );
  assert.match(reader, /await import\('\.\/e2e-forms-watcher-browser\.mjs'\)/);
});

test('question provider and control scenarios have separate mandatory browser budgets', () => {
  const checks = JSON.parse(
    readFileSync(path.join(root, 'js/scripts/browser-checks.json'))
  );
  const scripts = JSON.parse(
    readFileSync(path.join(root, 'package.json'))
  ).scripts;
  const questions = readFileSync(
    path.join(root, 'js/tests/e2e-questions-browser.mjs'),
    'utf8'
  );
  const groups = {
    'question-providers': ['verifyProviderChoices', 'verifyHhChoices'],
    'question-text-replies': ['verifyTextReplyControls'],
    'question-text-guards': ['verifyTextReplyGuards'],
    'question-chat-lists': ['verifyHhChatList', 'verifyHhChatScan'],
    'question-history': ['verifyConversationHistory'],
    'question-controls': [
      'verifyQuestionBrowserControls',
      'verifySummaryChoices',
      'verifyQuestionBrowserWatch',
    ],
  };
  assert.equal(checks.filter((name) => name === 'questions').length, 1);
  const groupSources = Object.keys(groups).map((name) =>
    readFileSync(path.join(root, `js/tests/e2e-${name}-browser.mjs`), 'utf8')
  );
  assert.match(questions, /await verifyHhHistory\(/u);
  assert.match(
    questions,
    /await verifyQuestionNotices\(\{\s*page,\s*base,\s*store,\s*until\s*\}\)/u
  );
  assert.match(
    questions,
    /await verifyNoticeLearning\(\{\s*page,\s*base,\s*store,\s*until\s*\}\)/u
  );
  assert.match(
    questions,
    /await verifyNoticeLearning\(\{\s*page,\s*base,\s*store,\s*until,\s*patterns: true\s*\}\)/u
  );
  assert.doesNotMatch(
    readFileSync(
      path.join(root, 'js/tests/e2e-question-controls-browser.mjs'),
      'utf8'
    ),
    /\bverify(?:QuestionNotices|NoticeLearning)\b/u,
    'notice review needs the shared page/store fixture, not a Browser'
  );
  assert.match(
    readFileSync(
      path.join(root, 'js/tests/helpers/e2e-question-browser-controls.mjs'),
      'utf8'
    ),
    /await verifyBrowserPendingTurn\(\{ \.\.\.scenario, inspect: readCurrent \}\)/u
  );
  for (const [name, scenarios] of Object.entries(groups)) {
    assert.equal(checks.filter((check) => check === name).length, 1, name);
    const command = scripts[`test:e2e:${name}`];
    assert.equal(command, `node js/tests/e2e-${name}-browser.mjs`);
    assert.equal(
      scripts[`test:e2e:${name}:webkit`],
      `E2E_BROWSER=webkit ${command}`
    );
    const entry = readFileSync(path.join(root, command.slice(5)), 'utf8');
    const registered = entry.slice(entry.indexOf('await runBrowserScenarios('));
    for (const scenario of scenarios) {
      assert.match(registered, new RegExp(`\\b${scenario}\\b`, 'u'));
      assert.equal(
        groupSources.filter((source) => source.includes(scenario)).length,
        1,
        `${scenario} runs in exactly one bounded group`
      );
      assert.ok(
        !questions.includes(scenario),
        `${scenario} runs only in its group`
      );
    }
  }
  assert.match(
    readFileSync(path.join(root, 'js/scripts/run-browser-checks.mjs'), 'utf8'),
    /timeout: 180_000/u
  );
  assert.equal(
    workflow('release.yml').jobs['e2e-browser']['timeout-minutes'],
    35
  );
});
