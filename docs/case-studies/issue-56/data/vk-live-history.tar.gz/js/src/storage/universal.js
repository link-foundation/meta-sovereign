/**
 * Universal Links Access interface.
 *
 * Every storage backend (text-only `.lino`, binary doublets, dual store,
 * or a remote HTTP client) implements the same API so callers do not
 * care which substrate is underneath. This is requirement R-F8.
 *
 * A "link" is `{ id: string, tokens: string[], children?: string[] }`.
 * `tokens` are the human-readable payload; `children` is an optional
 * list of child link IDs for hierarchical structures.
 */

/**
 * @typedef {Object} Link
 * @property {string} id
 * @property {string[]} tokens
 * @property {string[]} [children]
 * @property {Object<string, number>} [vc] observed synchronization clock
 */

/**
 * @typedef {Object} UniversalLinksAccess
 * @property {(link: Link, options?: object) => Promise<Link>} put
 * @property {(id: string, change: (before: Link|null) => Link, options?: object) => Promise<Link>} [update] synchronous transform at write admission
 * @property {(links: Link[], options?: object) => Promise<Link[]>} [putMany] bulk put; file
 *   backed stores write once for the whole batch
 * @property {(id: string, project?: (link: Link) => unknown) => Promise<Link | null>} get
 * @property {(id: string, options?: object) => Promise<boolean>} delete
 * @property {(filter?: (l: Link) => boolean) => Promise<Link[]>} query
 * @property {(handler: (event: {type: string, link: Link}) => void) => () => void} subscribe
 */

import {
  changedLink,
  changedBatch,
  atomicBatch,
  mutationEvent,
  admitMutation,
} from './mutation.js';

export const createMemoryStore = ({
  retain = (link) => ({ ...link }),
  release = () => {},
  copy = (link) => ({ ...link }),
} = {}) => {
  const data = new Map();
  const handlers = new Set();
  const emit = (event) => handlers.forEach((h) => h(event));

  const remember = (link) => {
    if (!link || typeof link.id !== 'string') {
      throw new Error('link.id is required');
    }
    const held = retain(link);
    release(data.get(link.id));
    data.set(link.id, held);
    return link;
  };
  const put = (link, options) => {
    remember(link);
    admitMutation('put', link.id, options);
    emit(mutationEvent('put', link, options));
    return link;
  };

  return {
    async put(link, options) {
      return put(link, options);
    },
    async putMany(links, options) {
      // A bulk log record cannot be interrupted halfway by a subscriber's
      // write. Admit the complete batch before exposing any of its events.
      const out = links.map(remember);
      out.forEach((link) => {
        admitMutation('put', link.id, options);
        emit(mutationEvent('put', link, options));
      });
      return out;
    },
    async update(id, change, options) {
      const before = data.get(id);
      return put(
        changedLink(id, change, before ? copy(before) : null),
        options
      );
    },
    async [atomicBatch](links, change, options) {
      return this.putMany(
        changedBatch(links, change, (id) => data.get(id), copy),
        options
      );
    },
    // A projection reads retained metadata without detaching cold payloads,
    // as scan's projection does. It must not mutate the stored record.
    async get(id, project = copy) {
      const v = data.get(id);
      return v ? project(v) : null;
    },
    async delete(id, options) {
      const existed = data.has(id);
      const link = data.get(id);
      admitMutation('delete', id, options);
      data.delete(id);
      release(link);
      if (existed) {
        emit(mutationEvent('delete', link, options));
      }
      return existed;
    },
    // Only the matches are copied: a query for a few links of a large
    // store (graphs, secrets) does not copy every message first. The
    // filter reads the stored link; it must not change it.
    async query(filter) {
      const out = [];
      for (const link of data.values()) {
        if (!filter || filter(link)) {
          out.push(copy(link));
        }
      }
      return out;
    },
    subscribe(handler) {
      handlers.add(handler);
      return () => handlers.delete(handler);
    },
    /** How many links are held. */
    size: () => data.size,
    /**
     * The matching links in batches of `batchSize` copies, each handed to
     * `onBatch` (awaited) before the next is gathered: a pass over a large
     * store holds one batch, not every match (R-Z17). Writes made by
     * `onBatch` are safe (a link written again keeps its place). Resolves
     * to how many links were looked at.
     */
    async scan(filter, batchSize, onBatch, project = copy) {
      let batch = [];
      let looked = 0;
      for (const link of data.values()) {
        looked += 1;
        if (!filter || filter(link)) {
          batch.push(project(link));
          if (batch.length >= batchSize) {
            const full = batch;
            batch = [];
            await onBatch(full);
          }
        }
      }
      if (batch.length > 0) {
        await onBatch(batch);
      }
      return looked;
    },
  };
};

/**
 * Put a batch through `putMany` when the store offers it (file-backed
 * stores then write once), else one `put` at a time.
 */
export const putAll = async (store, links, options) => {
  if (typeof store.putMany === 'function') {
    await store.putMany(links, options);
    return links.length;
  }
  for (const link of links) {
    await store.put(link, options);
  }
  return links.length;
};
