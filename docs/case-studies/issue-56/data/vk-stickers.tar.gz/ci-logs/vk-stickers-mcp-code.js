async (page) => {
  const session = await page.context().newCDPSession(page);
  const syntheticPreview = (route) => route.fulfill({ contentType: 'image/svg+xml', body: '<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128"><text y="95" font-size="90">👋</text></svg>' });
  try {
    await page.context().route('https://vk.com/sticker/**', syntheticPreview);
    await session.send('Network.enable');
    await session.send('Network.setCacheDisabled', { cacheDisabled: true });
    return await (async (page) => (async (page, fixture, check) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      language
    );
    await page.goto(`${fixture.base}/?vkLocale=${language}#conn-vk/manual`);
    const panel = page.locator(`[data-${fixture.feature}]`);
    const ready = () =>
      page.waitForFunction((feature) => {
        const input = document.querySelector(feature);
        return input && !input.disabled;
      }, `[data-${fixture.feature}] ${fixture.readySelector}`);
    // A mounted heading and an enabled control distinguish loading from absence.
    await panel
      .getByRole('heading', { name: words.title, exact: true })
      .waitFor();
    await ready();
    for (const key of fixture.keys) {
      if (!(await panel.innerText()).includes(words[key])) {
        throw Error(`Missing ${language}.${key}`);
      }
    }
    const { focus, ...checked } = await check(page, {
      panel,
      words,
      ready,
      feature: fixture.feature,
      fixture,
      action: async (name) => {
        await panel.locator(`[data-action=${fixture.feature}-${name}]`).click();
        await ready();
      },
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await panel.locator(focus).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-${fixture.evidenceName}/mcp-${language}-phone.png`,
    });
    result.push({ language, translated: true, ...checked });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:43119","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","feature":"vk-stickers","evidenceName":"vk-stickers","readySelector":"input[data-sticker-field=accountId]","exportRoot":"/tmp/ms-vk-stickers-N7PwgT","keys":["hint","accountId","exportHint"],"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"VK sticker catalog","hint":"Inspect saved packs and keywords without contacting VK. Refresh explicitly reads the current account, purchased active packs and greeting packs. Only a purchased, active pack with an explicit sticker permission is marked usable. Saved permission is a snapshot; sending can still be refused.","accountId":"VK account ID","exportHint":"Save catalog, usable stickers, keywords, greeting IDs, the current filter and optional received IDs as bounded JSON parts in a new folder on the server computer. Existing folders are refused. Preview links are retained; artwork files are not downloaded."},"ru":{"title":"Каталог стикеров VK","hint":"Просмотр сохранённых наборов и ключевых слов не обращается к VK. Обновление читает текущий аккаунт, купленные активные наборы и приветствия. Доступность требует купленного активного набора и явного разрешения стикера. Сохранённые права — снимок; отправка может быть отклонена.","accountId":"ID аккаунта VK","exportHint":"Сохраните каталог, доступные стикеры, ключевые слова, ID приветствий, текущий фильтр и полученные ID частями JSON в новой папке компьютера сервера. Существующие папки отклоняются. Ссылки предпросмотра сохраняются; изображения не скачиваются."},"hi":{"title":"VK स्टिकर कैटलॉग","hint":"VK से संपर्क किए बिना सहेजे पैक और कीवर्ड देखें। रिफ़्रेश वर्तमान खाता, खरीदे सक्रिय पैक और अभिवादन पैक पढ़ता है। उपयोग योग्य के लिए खरीदा सक्रिय पैक और स्पष्ट स्टिकर अनुमति चाहिए। सहेजी अनुमति एक स्नैपशॉट है; भेजना फिर भी अस्वीकार हो सकता है।","accountId":"VK खाता ID","exportHint":"कैटलॉग, उपयोग योग्य स्टिकर, कीवर्ड, अभिवादन ID, वर्तमान फ़िल्टर और वैकल्पिक प्राप्त ID सर्वर कंप्यूटर के नए फ़ोल्डर में सीमित JSON भागों के रूप में सहेजें। मौजूदा फ़ोल्डर अस्वीकार होंगे। पूर्वावलोकन लिंक रहेंगे; चित्र फ़ाइलें डाउनलोड नहीं होंगी।"},"zh":{"title":"VK 贴纸目录","hint":"查看已保存的贴纸包与关键词不会连接 VK。刷新会读取当前账户、已购买的启用贴纸包和问候包。仅已购买、已启用且明确允许使用的贴纸标为可用。保存的权限只是快照，发送仍可能被拒绝。","accountId":"VK 账户 ID","exportHint":"将目录、可用贴纸、关键词、问候 ID、当前筛选及可选的收到 ID 保存为有行数限制的 JSON 分卷，存入服务器电脑的新文件夹。已有文件夹会被拒绝。保留预览链接，不下载图像文件。"}}}, (async (page, { panel, ready, fixture }) => {
  const action = async (name) => {
    await panel.locator(`[data-sticker-action=${name}]`).click();
    await ready();
  };
  await panel.locator('[data-sticker-field=accountId]').fill('1');
  await action('refresh');
  await panel.locator('[data-sticker-field=category]').selectOption('greeting');
  await action('inspect');
  if (await panel.locator('[data-catalog-sticker]').count() !== 2) {
    throw Error('Greeting catalog incomplete');
  }
  await panel.locator('details').evaluate((node) => { node.open = true; });
  await panel.locator('[data-sticker-field=received]').fill(JSON.stringify({ 101: { productId: 11 }, 401: { productId: 13 } }));
  await action('filter');
  await panel.locator('[data-filtered-products]').waitFor();
  const language = await page.evaluate(() => globalThis.localStorage.getItem('metaSovereignLocale'));
  await panel.locator('[data-sticker-field=folder]').fill(`${fixture.exportRoot}/mcp-${language}`);
  await action('export');
  await panel.locator('[data-catalog-exported]').waitFor();
  const receipt = await panel.locator('[data-catalog-exported]').innerText();
  if (!receipt.trim() || receipt.includes('vkStickers.')) {
    throw Error('Missing translated export receipt');
  }
  await page.reload();
  await ready();
  await panel.locator('[data-sticker-field=accountId]').fill('1');
  await action('inspect');
  await panel.locator('[data-usable-greeting-ids]').waitFor();
  return { focus: '[data-sticker-catalog-evidence]', usableGreetingIds: 2, receivedFiltering: true, receipt, reloadInspection: true };
})))(page);
  } finally {
    await page.context().unroute('https://vk.com/sticker/**', syntheticPreview);
    await session.detach();
  }
}