OAuth 2.0 user-context setup is rejected unless an OAuth 1.0a-style access-token secret is provided. Supplying that extra value then constructs an OAuth 1.0a client with the OAuth 2.0 client ID/secret.

Observed by inspecting current commit [1b98a0a](https://github.com/konard/broadcast/blob/1b98a0a0eb02edbdf74f481db853f72a0fab6a8a/x.mjs). I have not sent requests to X or tested live credentials.

Reproduction (after installing this repository's normal dependencies, no network request to X):

```sh
env -u X_API_KEY -u X_API_KEY_SECRET -u X_ACCESS_TOKEN_SECRET -u X_BEARER_TOKEN \
  X_CLIENT_ID=example-client X_CLIENT_SECRET=example-secret \
  X_ACCESS_TOKEN=example-oauth2-user-token \
  bun -e 'const {default: X} = await import("./x.mjs"); const x = new X(); console.log({configured: x.isConfigured(), method: x.authMethod, errors: x.getConfigurationErrors()});'
```

The configuration is rejected as unconfigured even though an already-issued OAuth 2.0 user access token does not have an access-token secret. This example deliberately uses dummy values to isolate local validation; it cannot establish that a real token has the required scopes.

With the same environment plus `X_ACCESS_TOKEN_SECRET=example-secret`, local validation passes, but `initializeClient()` maps `clientId/clientSecret` to `appKey/appSecret` and labels the resulting OAuth 1.0a client “OAuth 2.0 User”. An OAuth 2.0 Client ID is not an OAuth 1.0a API key.

Expected behavior: accept an existing OAuth 2.0 user token independently of client credentials, use bearer authentication for it, and keep OAuth 1.0a credentials and the read-only application bearer token as distinct modes. Report identity/post permission failures accurately.

The SDK's [authentication documentation](https://github.com/PLhery/node-twitter-api-v2/blob/d4ba72dfcf30395f02c551b318d53f51310ccdd0/doc/auth.md#use-your-access-token) constructs a client from the OAuth 2.0 user token string. Client ID/secret are used for obtaining/refreshing OAuth 2.0 tokens; the four-field `appKey/appSecret/accessToken/accessSecret` constructor is OAuth 1.0a. The [X authentication overview](https://docs.x.com/fundamentals/authentication/overview) also distinguishes application-only and user-context bearer tokens.

Workaround: configure a complete OAuth 1.0a API key/secret and access token/secret, leave `X_CLIENT_ID` and `X_CLIENT_SECRET` unset to avoid the incorrect higher-priority branch, and ensure the user token has write permissions. An application-only bearer token remains unsuitable for posting.

Suggested fix: select an explicit authentication mode; construct OAuth 2.0 user clients from the user access token string, reserve the four-field constructor for OAuth 1.0a, and never infer write capability merely from an application bearer token. Add mocked-constructor tests for OAuth 2.0 token-only, complete/incomplete OAuth 1.0a, mixed credentials and app-only modes, checking both the reported mode and the actual SDK constructor arguments. Keep connectivity checks read-only.

Found during the broadcast compatibility audit in [meta-sovereign PR 57](https://github.com/link-foundation/meta-sovereign/pull/57).
