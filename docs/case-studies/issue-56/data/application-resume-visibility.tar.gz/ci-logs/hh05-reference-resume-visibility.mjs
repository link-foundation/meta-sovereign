/**
 * hh.ru's notice on a response form when the resume is not visible to all employers:
 * «Чтобы откликнуться на эту вакансию, поменяйте видимость резюме на «Видно всем работодателям,
 * зарегистрированным на hh.ru»». Such a vacancy is skipped without asking and kept in
 * skipped-vacancies.lino (`bun run skipped -- --clear resume_not_visible` opens them again once the
 * resume is visible to all employers).
 *
 * @module resume-visibility
 */

import { RESUME_HIDDEN_NOTICES } from './hh-words.mjs';

/**
 * Runs in the page: whether the notice is rendered in the scope. hh.ru keeps it in every response
 * popup inside a collapsed block (data-qa="hidden-resume-warning", height 0) that opens only for a
 * hidden resume, so text inside a collapsed or hidden element does not count. Any text of that
 * block is the notice, in any language; elsewhere its words are looked for
 * @param {string|null} selector - The popup; the whole page when null
 * @param {string[]} notices - Lowercase texts, ё as е
 * @returns {boolean}
 */
export function findShownNotice(selector, notices) {
  const scope = selector ? document.querySelector(selector) : document.body;
  if (!scope) {
    return false;
  }
  const collapsed = (element) => {
    const style = window.getComputedStyle(element);
    return style.display === 'none' || style.visibility === 'hidden' ||
      (element.getBoundingClientRect().height === 0 && style.overflow !== 'visible');
  };
  const walker = document.createTreeWalker(scope, window.NodeFilter.SHOW_TEXT);
  for (let node = walker.nextNode(); node; node = walker.nextNode()) {
    const text = node.textContent.toLowerCase().replace(/ё/g, 'е');
    if (!(text.trim() && node.parentElement?.closest('[data-qa="hidden-resume-warning"]')) && !notices.some((notice) => text.includes(notice))) {
      continue;
    }
    let shown = true;
    for (let element = node.parentElement; element && element !== scope.parentElement; element = element.parentElement) {
      if (collapsed(element)) {
        shown = false;
        break;
      }
    }
    if (shown) {
      return true;
    }
  }
  return false;
}

/**
 * Whether the form (or the page) shows the notice
 * @param {Object} commander
 * @param {string} [scopeSelector] - The popup; the whole page when not given
 * @returns {Promise<boolean>}
 */
export async function isResumeHiddenNoticeShown(commander, scopeSelector) {
  const { value } = await commander.safeEvaluate({
    fn: findShownNotice,
    args: [scopeSelector ?? null, RESUME_HIDDEN_NOTICES],
    defaultValue: false,
    operationName: 'resume visibility notice',
    silent: true,
  });
  return value;
}

/**
 * Whether the vacancy can be applied to with this resume; logged when it cannot
 * @param {Object} commander
 * @param {Object} [options]
 * @param {string} [options.scopeSelector] - The popup; the whole page when not given
 * @param {string|number} [options.vacancyId]
 * @returns {Promise<'visible'|'skip'>} 'skip' when the notice is shown
 */
export async function resumeVisibility(commander, { scopeSelector, vacancyId } = {}) {
  if (!await isResumeHiddenNoticeShown(commander, scopeSelector)) {
    return 'visible';
  }
  console.log(`🙈 Skipped: hh.ru takes responses to vacancy ${vacancyId ?? ''} only from a resume visible to all employers ` +
    '(«поменяйте видимость резюме на «Видно всем работодателям, зарегистрированным на hh.ru»»)');
  return 'skip';
}
