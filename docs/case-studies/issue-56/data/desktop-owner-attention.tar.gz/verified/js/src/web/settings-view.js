// Settings view (issue #27).
//
// Provider credentials, archive import, and live probing now belong to
// Connections -> provider detail. Settings stays available for app-level
// preferences — the appearance (issue #31 / PR #34: theme mode and skin)
// — and points users to the dedicated connection surface.

import React from 'react';
import { refreshNotificationPreference } from './desktop-attention.js';
import { useT } from './i18n.js';
import { workspaceName } from './cloud-workspace.js';
import { TelegramNotifySettings } from './settings-notify.js';
import { SoundSettings } from './settings-sounds.js';
import { MediaSettings } from './settings-media.js';
import { StorageSettings } from './settings-storage.js';
import { ScaleSettings } from './settings-scale.js';
import { ProxySettings } from './settings-proxy.js';
import { SKINS, THEME_MODES, useAppearance } from './appearance.js';
import { EFFECTS_MODES, useEffectsSetting } from './effects.js';
import { api } from './dom.js';
import { ChatBackgroundSettings } from './chat-wallpaper.js';
import { CloudThemeSettings } from './cloud-themes.js';
import { TranslateSettings } from './chat-translate-bar.js';
import { FoldersSettings } from './chat-folder-edit.js';
import { useAllFirst } from './chat-folders.js';
import { useStoriesEnabled } from './stories-pref.js';
import { useOperatorScope } from './operator-prefs.js';
import { useBrowserOnlyOffer } from './connection-prefs.js';
import { useReadReceipts, useShareTyping } from './privacy-prefs.js';
import { ConversationSettings } from './settings-conversation.js';
import { BirthdaySettings } from './settings-birthdays.js';
import { FeedbackSettings } from './settings-feedback.js';
import { BrowserSettings } from './settings-browser.js';
import { DiagnosticSettings } from './settings-diagnostics.js';
import { RunnerSettings } from './settings-runner.js';
import { HiddenSenderSettings } from './settings-hidden-senders.js';
import { useContinueLast } from './continuation-pref.js';
import {
  NOTIFY_KEY,
  NOTIFY_PREVIEW_KEY,
  TITLE_COUNT_KEY,
  usePref,
} from './chat-notify.js';

const el = React.createElement;

const Choices = ({ name, legend, options, value, onChange, label }) =>
  el('fieldset', { className: 'appearance-choices' }, [
    el('legend', { key: 'l' }, legend),
    ...options.map((option) =>
      el('label', { key: option, className: 'check' }, [
        el('input', {
          key: 'i',
          type: 'radio',
          name,
          value: option,
          checked: value === option,
          'data-action': name,
          onChange: () => onChange(option),
        }),
        ` ${label(option)}`,
      ])
    ),
  ]);

/** Theme mode (system, light, dark, auto) and skin (t3, Telegram, …). */
export const AppearanceSettings = ({ appearance }) => {
  const t = useT();
  const { effects, setEffects } = useEffectsSetting();
  return el(
    'section',
    { className: 'card appearance', 'aria-labelledby': 'appearance-title' },
    [
      el(
        'h3',
        { key: 'h', id: 'appearance-title' },
        t('settings.appearance.title')
      ),
      el('p', { key: 'p', className: 'meta' }, t('settings.appearance.intro')),
      el(
        'button',
        {
          key: 'reset',
          type: 'button',
          'data-action': 'appearance-reset',
          onClick: appearance.reset,
        },
        t('settings.appearance.reset')
      ),
      el(
        'div',
        { key: 'c', className: 'row appearance-row' },
        el(Choices, {
          key: 'theme',
          name: 'theme-mode',
          legend: t('settings.appearance.theme'),
          options: THEME_MODES,
          value: appearance.mode,
          onChange: appearance.setMode,
          label: (mode) => t(`settings.theme.${mode}`),
        }),
        el(Choices, {
          key: 'skin',
          name: 'skin',
          legend: t('settings.appearance.skin'),
          options: SKINS,
          value: appearance.skin,
          onChange: appearance.setSkin,
          label: (skin) => t(`settings.skin.${skin}`),
        }),
        // Blur and dims off on a slow browser (R-Z21).
        el(Choices, {
          key: 'effects',
          name: 'effects-mode',
          legend: t('settings.appearance.effects'),
          options: EFFECTS_MODES,
          value: effects,
          onChange: setEffects,
          label: (mode) => t(`settings.effects.${mode}`),
        })
      ),
    ]
  );
};

const Check = ({ action, checked, onChange, label }) =>
  el('label', { className: 'check' }, [
    el('input', {
      key: 'i',
      type: 'checkbox',
      checked,
      'data-action': action,
      onChange: (event) => onChange(event.target.checked),
    }),
    ` ${label}`,
  ]);

/** A local layout preference; never changes Telegram's remote folder order. */
export const FolderTabSettings = () => {
  const t = useT();
  const [allFirst, setAllFirst] = useAllFirst();
  return el('section', { className: 'card folder-tab-settings' }, [
    el('h3', { key: 'h' }, t('settings.folderTabs.title')),
    el('label', { key: 'position' }, [
      t('settings.folderTabs.placement'),
      el(
        'select',
        {
          key: 'select',
          'data-action': 'folder-special-position',
          value: allFirst ? 'start' : 'end',
          onChange: (event) => setAllFirst(event.target.value === 'start'),
        },
        ['end', 'start'].map((position) =>
          el(
            'option',
            { key: position, value: position },
            t(`settings.folderTabs.${position}`)
          )
        )
      ),
    ]),
    el('p', { key: 'hint', className: 'meta' }, t('settings.folderTabs.hint')),
  ]);
};

export const StoriesSettings = () => {
  const t = useT();
  const [enabled, setEnabled] = useStoriesEnabled();
  return el('section', { className: 'card stories-settings' }, [
    el('h3', { key: 'h' }, t('settings.stories.title')),
    el(Check, {
      key: 'show',
      action: 'stories-enabled',
      checked: enabled,
      onChange: setEnabled,
      label: t('settings.stories.show'),
    }),
    el('p', { key: 'hint', className: 'meta' }, t('settings.stories.hint')),
  ]);
};

const ConnectionSettings = () => {
  const t = useT();
  const [allowed, setAllowed] = useBrowserOnlyOffer();
  return el('section', { className: 'card connection-settings' }, [
    el('h3', { key: 'h' }, t('settings.connection.title')),
    el(Check, {
      key: 'allow',
      action: 'offer-browser-only',
      checked: allowed,
      onChange: setAllowed,
      label: t('settings.connection.browserOnly'),
    }),
    el('p', { key: 'hint', className: 'meta' }, t('settings.connection.hint')),
  ]);
};

export const OperatorSettings = () => {
  const t = useT();
  const [scope, setScope] = useOperatorScope();
  return el('section', { className: 'card operator-settings' }, [
    el('h3', { key: 'h' }, t('settings.operator.title')),
    el('p', { key: 'hint', className: 'meta' }, t('settings.operator.hint')),
    ...Object.entries(scope).map(([kind, enabled]) =>
      el(Check, {
        key: kind,
        action: `operator-${kind}`,
        checked: enabled,
        onChange: (on) => setScope(kind, on),
        label: t(`settings.operator.${kind}`),
      })
    ),
  ]);
};

/**
 * What other people may see: "typing…" (off by default) and that a chat
 * was read (on by default, as in Telegram's own apps).
 */
export const PrivacySettings = () => {
  const t = useT();
  const [shareTyping, setShareTyping] = useShareTyping();
  const [readReceipts, setReadReceipts] = useReadReceipts();
  return el(
    'section',
    { className: 'card privacy', 'aria-labelledby': 'privacy-title' },
    [
      el('h3', { key: 'h', id: 'privacy-title' }, t('settings.privacy.title')),
      el(Check, {
        key: 'typing',
        action: 'share-typing',
        checked: shareTyping,
        onChange: setShareTyping,
        label: t('settings.shareTyping'),
      }),
      el(
        'p',
        { key: 'hint', className: 'meta' },
        t('settings.shareTypingHint')
      ),
      el(Check, {
        key: 'read',
        action: 'read-receipts',
        checked: readReceipts,
        onChange: setReadReceipts,
        label: t('settings.readReceipts'),
      }),
      el(
        'p',
        { key: 'read-hint', className: 'meta' },
        t('settings.readReceiptsHint')
      ),
    ]
  );
};

// What the browser says of notifications: allowed, blocked, or not asked.
const permissionNow = () =>
  typeof globalThis.Notification === 'function'
    ? globalThis.Notification.permission
    : 'unsupported';

/** New messages as the system's notifications, and the title's count (R-Y134). */
export const NotificationSettings = () => {
  const t = useT();
  const [notify, setNotify] = usePref(NOTIFY_KEY, true);
  const [preview, setPreview] = usePref(NOTIFY_PREVIEW_KEY, true);
  const [count, setCount] = usePref(TITLE_COUNT_KEY, true);
  const [permission, setPermission] = React.useState(permissionNow);
  const turn = async (on) => {
    setNotify(on);
    refreshNotificationPreference();
    if (on && permission === 'default') {
      const answer = await globalThis.Notification.requestPermission();
      setPermission(answer);
      refreshNotificationPreference();
    }
  };
  return el(
    'section',
    { className: 'card notifications', 'aria-labelledby': 'notify-title' },
    [
      el('h3', { key: 'h', id: 'notify-title' }, t('settings.notify.title')),
      el(Check, {
        key: 'on',
        action: 'notify',
        checked: notify && permission !== 'denied',
        onChange: turn,
        label: t('settings.notify.on'),
      }),
      el(
        'p',
        { key: 'state', className: 'meta', 'data-permission': permission },
        t(`settings.notify.${permission}`)
      ),
      el(Check, {
        key: 'preview',
        action: 'notify-preview',
        checked: preview,
        onChange: setPreview,
        label: t('settings.notify.preview'),
      }),
      el(Check, {
        key: 'count',
        action: 'title-count',
        checked: count,
        onChange: setCount,
        label: t('settings.notify.count'),
      }),
    ]
  );
};

const SendingSettings = () => {
  const t = useT();
  const [on, setOn] = useContinueLast();
  return el(
    'section',
    { className: 'card', 'aria-labelledby': 'sending-title' },
    [
      el('h3', { key: 'h', id: 'sending-title' }, t('settings.sending.title')),
      el(Check, {
        key: 'on',
        action: 'continue-last-message',
        checked: on,
        onChange: setOn,
        label: t('settings.sending.continueLast'),
      }),
      el(
        'p',
        { key: 'hint', className: 'meta' },
        t('settings.sending.continueHint')
      ),
    ]
  );
};

export const SettingsView = () => {
  const t = useT();
  const appearance = useAppearance();
  const navigate = () => {
    globalThis.dispatchEvent?.(
      new globalThis.CustomEvent('meta-sovereign:navigate', {
        detail: { view: 'connections', anchor: '' },
      })
    );
  };

  return el('div', { className: 'col settings-view' }, [
    el('h2', { key: 'h' }, t('settings.title')),
    el('p', { key: 'intro', className: 'meta' }, t('settings.intro')),
    el(
      'button',
      {
        key: 'connections',
        type: 'button',
        className: 'primary',
        onClick: navigate,
        'data-action': 'open-connections',
      },
      t('settings.openConnections')
    ),
    el(AppearanceSettings, { key: 'appearance', appearance }),
    workspaceName() ? null : el(BrowserSettings, { key: 'browser', api }),
    el(DiagnosticSettings, { key: 'diagnostics', api }),
    workspaceName() ? null : el(RunnerSettings, { key: 'runner', api }),
    el(FolderTabSettings, { key: 'folder-tabs' }),
    el(StoriesSettings, { key: 'stories' }),
    el(BirthdaySettings, { key: 'birthdays' }),
    workspaceName() ? null : el(ConnectionSettings, { key: 'connection' }),
    el(OperatorSettings, { key: 'operator' }),
    el(SendingSettings, { key: 'sending' }),
    el(ConversationSettings, { key: 'conversation', api }),
    el(FeedbackSettings, { key: 'feedback', api }),
    el(ChatBackgroundSettings, { key: 'background', api }),
    el(CloudThemeSettings, { key: 'cloud-themes', api }),
    el(FoldersSettings, { key: 'folders', api }),
    el(TranslateSettings, { key: 'translate' }),
    el(PrivacySettings, { key: 'privacy' }),
    el(HiddenSenderSettings, { key: 'hidden-senders' }),
    el(NotificationSettings, { key: 'notify' }),
    el(TelegramNotifySettings, { key: 'notify-telegram', api }),
    el(SoundSettings, { key: 'sounds', api }),
    el(MediaSettings, { key: 'media', api }),
    el(ScaleSettings, { key: 'scale' }),
    el(ProxySettings, { key: 'proxy', api }),
    el(StorageSettings, { key: 'storage', api }),
  ]);
};
