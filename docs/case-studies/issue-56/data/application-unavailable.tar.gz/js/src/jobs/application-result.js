import {
  applicationDraft,
  draftRestoration,
} from './application-draft-data.js';
import {
  applicationConfirmations,
  applicationContinuationData,
} from './application-confirmations.js';
import { jobsFailure } from './options.js';
import {
  assignmentVacancy,
  assignmentVacancyUrl,
  assignmentSourceUrl,
} from '../assignments/validation.js';
import { validateFormInspection } from '../forms/plan-validation.js';
import { applicationHoldReasons } from './application-holds.js';
import { applicationResumeData } from './application-resume-data.js';
import { applicationLimitData } from './application-limit-data.js';
import { applicationLimitWaitData } from './application-limit-wait-data.js';
import { validApplicationAnswerContext } from './application-answer-context.js';
import { applicationSalaryDecision } from './application-salary.js';

export const applicationStates = [
  'opening',
  'ready',
  'review',
  'provider-error',
  'verification',
  'daily-limit',
  'external',
  'resume-not-visible',
  'vacancy-unavailable',
  'delivered',
  'wrong-page',
  'unavailable',
  'interrupted',
  'sending',
  'review-delay',
  'deferred',
  'paused',
  'test-preview',
  'closed',
];
const text = (value, max) => typeof value === 'string' && value.length <= max;
const optionalChoice = (value, choices) =>
  value === null || value === undefined || choices.includes(value);
const fail = () => {
  throw jobsFailure(
    'application-unconfirmed',
    'This native application receipt was not confirmed.'
  );
};
const identity = (raw, input) =>
  raw?.ok === true &&
  raw.mode === 'hh-application-review' &&
  raw.url === assignmentVacancyUrl(input.url) &&
  raw.browserSlot === (input.browserSlot ?? 'jobs') &&
  (input.requestId === undefined || raw.requestId === input.requestId) &&
  typeof raw.requestId === 'string' &&
  /^[a-zA-Z0-9_-]{1,100}$/u.test(raw.requestId) &&
  text(raw.revision, 100) &&
  raw.revision.length > 0;
const supervised = (raw) =>
  (raw.autoAnswerViewedVacancy === undefined ||
    typeof raw.autoAnswerViewedVacancy === 'boolean') &&
  (raw.supervised === undefined || typeof raw.supervised === 'boolean') &&
  (raw.autoSelectResumeLanguage === undefined ||
    typeof raw.autoSelectResumeLanguage === 'boolean') &&
  optionalChoice(raw.letterLanguage, ['en', 'ru']) &&
  !(raw.supervised && raw.autoExact);
const reentry = (raw) =>
  (raw.reentryAvailable === undefined ||
    typeof raw.reentryAvailable === 'boolean') &&
  (!raw.reentryAvailable ||
    (raw.active &&
      raw.state === 'ready' &&
      raw.attempted.enter &&
      !raw.attempted.submit &&
      raw.delivery === 'none' &&
      !raw.hold &&
      !raw.paused &&
      raw.page?.bound &&
      raw.page.enter &&
      !raw.page.submit));
const state = (raw) =>
  applicationStates.includes(raw.state) &&
  ['none', 'provider-confirmed', 'unknown'].includes(raw.delivery) &&
  ['enter', 'submit'].every(
    (name) => typeof raw.attempted?.[name] === 'boolean'
  ) &&
  [
    'active',
    'testMode',
    'autoExact',
    'noQuestionnaires',
    'paused',
    'exact',
  ].every((name) => typeof raw[name] === 'boolean') &&
  optionalChoice(raw.dailyRejection, ['recorded', 'released']) &&
  supervised(raw) &&
  Number.isInteger(raw.reviewDelayMs) &&
  raw.reviewDelayMs >= 0 &&
  raw.reviewDelayMs <= 30000 &&
  (raw.code === null || text(raw.code, 100)) &&
  optionalChoice(raw.hold, applicationHoldReasons) &&
  [
    'not-requested',
    'verified',
    'not-attached',
    'unavailable',
    'unverified',
    'owner-conflict',
  ].includes(raw.letter) &&
  (raw.state !== 'delivered' || raw.delivery === 'provider-confirmed');
const actionDescriptor = (value) =>
  value === null ||
  (value && typeof value.disabled === 'boolean' && text(value.qa, 100));
const page = (value) =>
  value === null ||
  (value &&
    [
      'bound',
      'challenge',
      'dailyLimit',
      'external',
      'delivered',
      'questions',
      'ambiguousLetter',
      'scope',
    ].every((key) => typeof value[key] === 'boolean') &&
    (value.url === null || text(value.url, 4000)) &&
    optionalChoice(value.error, ['generic-error', 'validation-error']) &&
    ['resumeNotVisible', 'vacancyUnavailable'].every(
      (key) => value[key] === undefined || typeof value[key] === 'boolean'
    ) &&
    (value.externalUrl === undefined ||
      value.externalUrl === null ||
      (value.external &&
        !value.challenge &&
        value.bound &&
        assignmentSourceUrl(value.externalUrl) === value.externalUrl)) &&
    ['enter', 'submit', 'letterToggle'].every((key) =>
      actionDescriptor(value[key])
    ));

const validateReport = (report) => {
  if (report !== null) {
    if (report.mode !== 'answer-plan' || !report.reviewPlan?.id) {
      fail();
    }
    validateFormInspection({ ...report, mode: 'read-only' });
  }
};

const validateMissing = (raw, input) => {
  applicationLimitData(raw.applicationLimit);
  if (
    raw.ok !== true ||
    raw.url !== assignmentVacancyUrl(input.url) ||
    raw.browserSlot !== (input.browserSlot ?? 'jobs') ||
    raw.requestId !== (input.requestId ?? null)
  ) {
    fail();
  }
};

const validateLimitWait = (raw) => {
  applicationLimitData(raw.applicationLimit);
  const wait = applicationLimitWaitData(raw.limitWait);
  if (
    wait &&
    ['waiting', 'refreshing', 'restoring'].includes(wait.phase) &&
    !raw.active
  ) {
    fail();
  }
};

const validReceiptContext = (raw, input) =>
  identity(raw, input) &&
  state(raw) &&
  page(raw.page) &&
  validApplicationAnswerContext(raw) &&
  ((raw.salaryAdmission === undefined &&
    applicationSalaryDecision(raw, raw.vacancy) === null) ||
    JSON.stringify(raw.salaryAdmission) ===
      JSON.stringify(applicationSalaryDecision(raw, raw.vacancy)));

/** Bind public receipts before any UI uses their readiness or delivery state. */
export const applicationResult = (raw, input) => {
  try {
    if (raw?.mode === 'hh-application-missing') {
      validateMissing(raw, input);
      return raw;
    }
    if (!validReceiptContext(raw, input)) {
      fail();
    }
    applicationConfirmations(raw.confirmations);
    applicationContinuationData(raw.continuation, raw);
    validateLimitWait(raw);
    if (raw.vacancy !== null) {
      if (raw.vacancy.url !== raw.url) {
        fail();
      }
      assignmentVacancy(raw.vacancy);
    }
    validateReport(raw.report);
    applicationResumeData(raw, input);
    if (!reentry(raw)) {
      fail();
    }
    applicationDraft(raw.draft);
    draftRestoration(raw.restoration);
    if (raw.exact && (!raw.report || !raw.page?.scope)) {
      fail();
    }
    if (JSON.stringify(raw).length > 3 * 1024 ** 2) {
      fail();
    }
  } catch {
    fail();
  }
  return raw;
};
