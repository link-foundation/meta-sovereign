async (page) => {
  const assert = { equal(a, b) { if (a !== b) throw new Error('Browser assertion failed'); } };
  const translate = (_locale, key) => ({"questions.sharedLoad":"Load profiles","questions.sharedSelect":"Linked profile","questions.shared.id":"Profile identifier","questions.salaryEnabled":"Use configured salary targets","questions.salaryApproved":"Approve complete salary answers for automatic sending","questions.salaryHours":"Work hours per month (empty disables hourly answers)","questions.salaryAdd":"Add salary currency","questions.salaryCode":"Currency code, e.g. USD","questions.salaryKeywords":"Currency words, comma-separated","questions.salary.net":"Monthly net amount","questions.salary.gross":"Monthly gross amount","questions.salaryDefault":"Default salary currency"})[key];
  const applicationAnswerSalary = {"enabled":true,"approved":true,"exchangeMode":"snapshot","defaultCurrency":"RUB","defaultBasis":"net","monthlyHours":160,"currencies":[{"code":"USD","keywords":["USD"],"net":6200,"gross":7400},{"code":"RUB","keywords":["RUB"],"net":450000,"gross":530000}]};
  const applicationPanelBrowser = (fixture) => {
  const { page } = fixture;
  page.setDefaultTimeout(10000);
  const panel = page.locator('[data-application-panel]');
  const action = (name) => panel.locator(`[data-application-action="${name}"]`);
  const confirm = () =>
    panel.locator('[data-application-option="confirm"]').check();
  return {
    page,
    panel,
    action,
    confirm,
    batch() {
      const batch = panel.locator('[data-application-batch]');
      return {
        batch,
        field: (name) =>
          batch.locator(`[data-application-batch-field="${name}"]`),
        button: (name) =>
          batch.locator(`[data-application-batch-action="${name}"]`),
        phase: (name) =>
          batch
            .locator(`[data-application-batch-phase="${name}"]`)
            .waitFor({ timeout: 60000 }),
      };
    },
    screenshot(directory, prefix) {
      return async (name) => {
        if (directory) {
          await mkdir(directory, { recursive: true });
          await panel.screenshot({
            path: join(directory, `${prefix}-${name}.png`),
          });
        }
      };
    },
    async locales(selector, verify = async () => {}) {
      for (const locale of ['ru', 'hi', 'zh', 'en']) {
        await page.evaluate(
          (value) =>
            globalThis.localStorage.setItem('metaSovereignLocale', value),
          locale
        );
        await page.reload();
        await panel.locator(selector).waitFor();
        assert.equal(
          /\bapplication\.[a-z]/iu.test(await panel.innerText()),
          false
        );
        await verify(locale);
      }
    },
    async phone() {
      await page.setViewportSize({ width: 390, height: 1440 });
      assert.equal(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= globalThis.innerWidth
        ),
        true
      );
    },
    async close(owned) {
      await action('close').click();
      await panel.locator('[data-application-state="closed"]').waitFor();
      assert(owned.isClosed());
      assert(fixture.records.every((record) => record.closed));
      assert.deepEqual(fixture.errors, []);
    },
    async confirmed(name) {
      await confirm();
      await action(name).click();
      // Completion includes the new receipt and its renewed owner confirmation.
      await page.waitForFunction(
        () =>
          !document.querySelector('[data-application-option="confirm"]')
            .checked &&
          !document.querySelector('[data-application-action="read"]').disabled
      );
    },
    async select() {
      await page.goto(`${fixture.base}/#/cv`);
      const vacancies = page.locator('[data-vacancies]');
      await vacancies.locator('[data-vacancy-field="query"]').fill('Python');
      await vacancies.locator('[data-vacancy-action="search"]').click();
      await vacancies
        .locator('[data-vacancy-action="collect"]')
        .first()
        .click();
      await panel.locator('[data-application-missing]').waitFor();
      const languagePolicy = panel.locator(
        '[data-application-option="autoSelectResumeLanguage"]'
      );
      if (await languagePolicy.count()) {
        await languagePolicy.uncheck();
      }
      return vacancies;
    },
  };
};
  const configureApplicationAnswerContext = async (panel) => {
  const t = (key) => translate('en', key);
  const context = panel.locator('[data-application-answer-context]');
  const profile = context.locator('[data-shared-profile]');
  await profile.locator(':scope > summary').click();
  await profile
    .getByRole('button', { name: t('questions.sharedLoad'), exact: true })
    .click();
  await profile
    .getByLabel(t('questions.sharedSelect'), { exact: true })
    .selectOption('qa-profile:questionnaire');
  await profile
    .getByLabel(t('questions.shared.id'), { exact: true })
    .filter({ visible: true })
    .waitFor();
  await profile.locator(':scope > summary').click();
  const salary = context.locator('[data-answer-salary]');
  await salary.locator(':scope > summary').click();
  await salary
    .getByLabel(t('questions.salaryEnabled'), { exact: true })
    .check();
  await salary
    .getByLabel(t('questions.salaryApproved'), { exact: true })
    .check();
  await salary
    .getByLabel(t('questions.salaryHours'), { exact: true })
    .fill('160');
  for (const [
    index,
    currency,
  ] of applicationAnswerSalary.currencies.entries()) {
    if (index) {
      await salary
        .getByRole('button', { name: t('questions.salaryAdd'), exact: true })
        .click();
    }
    const row = salary.locator('[data-salary-currency]').nth(index);
    for (const [key, value] of Object.entries({
      Code: currency.code,
      Keywords: currency.keywords.join(', '),
    })) {
      await row
        .getByLabel(t(`questions.salary${key}`), { exact: true })
        .fill(value);
    }
    for (const key of ['net', 'gross']) {
      await row
        .getByLabel(t(`questions.salary.${key}`), { exact: true })
        .fill(String(currency[key]));
    }
  }
  await salary
    .getByLabel(t('questions.salaryDefault'), { exact: true })
    .selectOption('RUB');
  await salary.locator(':scope > summary').click();
};
  return (async (page, panel, configure) => {
  const url = new URL(page.url());
  const before = url.searchParams.get('phase') === 'before';
  const stats = url.searchParams.get('stats');
  if (!stats || !['before', 'after'].includes(url.searchParams.get('phase'))) {
    throw new Error('Supply the owned stats URL and phase.');
  }
  const errors = [];
  page.on('pageerror', (error) => errors.push(String(error)));
  await page.addInitScript((phase) => {
    if (globalThis.localStorage.getItem('salary-batch-evidence-phase') !== phase) {
      globalThis.localStorage.removeItem('meta-sovereign:hh-application-intent');
      globalThis.localStorage.setItem('salary-batch-evidence-phase', phase);
    }
    globalThis.localStorage.setItem('metaSovereignTutorial', '{"off":true,"v":5}');
  }, url.searchParams.get('phase'));
  await page.setViewportSize({ width: 1200, height: 1050 });
  const exercise = async (
  page,
  applicationPanelBrowser,
  configureApplicationAnswerContext,
  { before = false, screenshot } = {}
) => {
  const controls = applicationPanelBrowser({
    page,
    base: new URL(page.url()).origin,
  });
  const { panel, action } = controls;
  const { batch, field, button, phase } = controls.batch();
  const follow = async (release = false) => {
    if (release) {
      await action('recover').click();
      await page.waitForFunction(
        () =>
          !document.querySelector('[data-application-action="release"]')
            .disabled
      );
      await action('release').click();
    }
    await page.waitForFunction(
      () =>
        !document.querySelector('[data-application-batch-action="follow"]')
          .disabled
    );
    await button('follow').click();
    await panel.locator('[data-application-continuation="send"]').waitFor();
  };
  const current = (url) =>
    page.waitForFunction(
      (value) =>
        document.querySelector('[data-application-batch-current]')
          ?.textContent === value,
      url,
      { timeout: 60000 }
    );
  await controls.select();
  await configureApplicationAnswerContext(panel);
  await panel.locator('[data-application-option="pacing"]').check();
  await panel.locator('[data-application-pacing-interval]').fill('2');
  await field('urls').fill(
    'https://hh.ru/vacancy/123\nhttps://hh.ru/vacancy/456'
  );
  await field('confirmBatch').check();
  await button('start').click();
  await current('https://hh.ru/vacancy/456');
  await follow();
  const salary = batch.locator('[data-application-batch-salary]');
  if (!before && !(await salary.innerText()).includes('450000')) {
    throw new Error('The initial salary tier was not displayed.');
  }
  await controls.confirmed('confirm-step');
  if (before) {
    await phase('completed');
    await screenshot?.('before', batch);
    return { before: true, deliveries: 1, salaryRevisited: false };
  }
  await current('https://hh.ru/vacancy/123');
  await follow(true);
  if (!(await salary.innerText()).includes('400000')) {
    throw new Error(
      'The exhausted batch did not lower its floor by 50000 RUB.'
    );
  }
  if (!(await action('confirm-step').isDisabled())) {
    throw new Error('The salary revisit lost its separate send confirmation.');
  }
  await screenshot?.('after', batch);
  await controls.locales('[data-application-batch-salary]', async () => {
    if (!(await salary.innerText()).includes('400000')) {
      throw new Error('Reload changed the live salary floor.');
    }
  });
  await controls.phone();
  await screenshot?.('phone', batch);
  await controls.confirmed('confirm-step');
  await phase('completed');
  await page.reload();
  await phase('completed');
  return {
    before: false,
    deliveries: 2,
    salaryRevisited: true,
    initialFloorRub: 450000,
    nextFloorRub: 400000,
    locales: 4,
    phoneOverflow: false,
    restartReplayed: false,
  };
};
  const result = await exercise(page, panel, configure, { before,
    screenshot: async (name, batch) => {
      const receipt = batch.locator('[data-application-batch-phase]');
      await receipt.evaluate((node) => node.scrollIntoView({ block: 'center' }));
      await receipt.screenshot({ path: "/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459/docs/screenshots/issue-56-application-salary-batch/" + 'application-salary-batch-' + name + '.png' });
    }
  });
  const native = await (await page.request.get(stats)).json();
  const sends = native.outcomes.reduce((n, row) => n + row.attempts, 0);
  if (sends !== result.deliveries || !native.closed || errors.length || native.errors.length) {
    throw new Error(JSON.stringify({ result, native, errors }));
  }
  return { ...result, native, errors, liveProvider: false };
})(page, applicationPanelBrowser, configureApplicationAnswerContext);
}