Final: 63 focused checks pass; browser-final Chrome passes; lint-final has zero warnings; web build and formatting pass.
Before, iterator-before and peer-before logs are intentional draft/baseline failures; peer-before checks canonical typed input, not a proven SDK phone parsing defect.
Initial lint logs preserve review warnings and are superseded by lint-final. Reference code was inspected only, never executed or copied.
124a2234 full CI has Windows Deno rolling-host startup and WebKit older-birthday-fixture failures; separate investigation remains open.
