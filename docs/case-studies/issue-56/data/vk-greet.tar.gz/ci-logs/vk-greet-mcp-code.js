async (page) => (async (page, fixture, check) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      language
    );
    await page.goto(`${fixture.base}/?vkLocale=${language}#conn-vk/manual`);
    const panel = page.locator(`[data-${fixture.feature}]`);
    const ready = () =>
      page.waitForFunction((feature) => {
        const input = document.querySelector(
          `[data-${feature}] input[type=checkbox]`
        );
        return input && !input.disabled;
      }, fixture.feature);
    // A mounted heading and an enabled control distinguish loading from absence.
    await panel
      .getByRole('heading', { name: words.title, exact: true })
      .waitFor();
    await ready();
    for (const key of fixture.keys) {
      if (!(await panel.innerText()).includes(words[key])) {
        throw Error(`Missing ${language}.${key}`);
      }
    }
    const { focus, ...checked } = await check(page, {
      panel,
      words,
      ready,
      feature: fixture.feature,
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await panel.locator(focus).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-${fixture.evidenceName}/mcp-${language}-phone.png`,
    });
    result.push({ language, translated: true, ...checked });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:44217","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","feature":"vk-greet","evidenceName":"vk-greet","keys":["hint","onlineOnly","orderByFriends","cooldownDays","run"],"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"VK friend greetings","hint":"Review current friends, complete history and write permission. Online-only starts on; scheduling starts off. Empty chats come first, then oldest conversations; optional friend-count ordering takes precedence. Unread chats, protected accounts and uncertain sends are held. A saved sticker replaces text.","onlineOnly":"Only friends currently online","orderByFriends":"Order by total friends first","cooldownDays":"Per-person cooldown in days (1–3650)","run":"Confirm reviewed greetings"},"ru":{"title":"Приветствия друзьям ВКонтакте","hint":"Проверьте текущую дружбу, полную историю и разрешение писать. По умолчанию только онлайн; расписание выключено. Сначала пустые, затем старые беседы; сортировка по числу друзей имеет приоритет. Непрочитанные беседы, защищённые аккаунты и неизвестная отправка запрещают действие. Стикер заменяет текст.","onlineOnly":"Только друзья онлайн","orderByFriends":"Сначала по общему числу друзей","cooldownDays":"Пауза для человека в днях (1–3650)","run":"Подтвердить просмотренные приветствия"},"hi":{"title":"VK मित्रों को अभिवादन","hint":"वर्तमान मित्रता, पूरी हिस्ट्री और लिखने की अनुमति जाँचें। केवल ऑनलाइन चालू है; शेड्यूल बंद है। पहले खाली, फिर पुरानी बातचीत; मित्रों की संख्या का क्रम पहले लागू होता है। अपठित बातचीत, सुरक्षित खाते और अज्ञात भेजना रोका जाता है। स्टीकर टेक्स्ट की जगह जाता है।","onlineOnly":"केवल अभी ऑनलाइन मित्र","orderByFriends":"पहले कुल मित्रों की संख्या का क्रम","cooldownDays":"प्रति व्यक्ति विराम के दिन (1–3650)","run":"समीक्षित अभिवादनों की पुष्टि करें"},"zh":{"title":"VK 好友问候","hint":"审核当前好友关系、完整历史及发送权限。默认仅在线好友；自动计划关闭。先空对话，再按最早对话排序；可选好友数量排序优先。未读对话、受保护账户及发送结果未知时不执行。设置贴纸后将替代文字。","onlineOnly":"仅当前在线好友","orderByFriends":"优先按好友总数排序","cooldownDays":"每人间隔天数（1–3650）","run":"确认已审核的问候"}}}, (async (page, { panel, ready }) => {
  for (const [key, value] of [
    ['message', 'Hello, friend.'],
    ['limit', '1'],
  ]) {
    await panel.locator(`[data-greet-field=${key}]`).fill(value);
  }
  for (const action of ['save', 'plan']) {
    await panel.locator(`[data-action=vk-greet-${action}]`).click();
    await ready();
  }
  const cooled = await panel.locator('[data-greet-reason=cooldown]').count();
  if (
    !cooled &&
    (await panel
      .locator('[data-greet-id="9"] [data-greet-message]')
      .innerText()) !== 'Hello, friend.'
  ) {
    throw Error('Reviewed greeting mismatch');
  }
  if (!cooled) {
    await panel.locator('[data-action=vk-greet-run]').click();
    await ready();
  }
  await page.reload();
  await ready();
  await panel.locator('[data-action=vk-greet-plan]').click();
  await ready();
  if ((await panel.locator('[data-greet-reason=cooldown]').count()) !== 1) {
    throw Error('Greeting cooldown did not survive reload');
  }
  if (
    (await panel.locator('[data-action=vk-greet-enabled]').isChecked()) ||
    !(await panel.locator('[data-greet-field=onlineOnly]').isChecked())
  ) {
    throw Error('Greeting opt-in defaults changed');
  }
  return {
    focus: '[data-vk-greet-plan]',
    reviewed: true,
    savedText: true,
    cooldown: true,
    automaticOff: true,
  };
}))