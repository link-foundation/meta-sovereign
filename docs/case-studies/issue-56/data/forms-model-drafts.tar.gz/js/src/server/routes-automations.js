/**
 * Automations API (issue #31 / PR #34) — see `../automation/`.
 *
 * Endpoints:
 *   GET    /api/automations            → { automations } saved + presets
 *   GET    /api/automations/presets    → { presets }
 *   PUT    /api/automations            { automation } → saved automation
 *   DELETE /api/automations/:id
 *   POST   /api/automations/plan       { automation, targets?, limit? }
 *                                      → who it would message and why not
 *   POST   /api/automations/run        { automation, targets?, confirm?,
 *                                        trigger?, test?, limit? }
 *          Safe mode queues drafts; auto mode sends paced and needs
 *          `confirm: true` for manual and chat-menu runs. `test: true`
 *          with targets ignores the conditions (the chat menu's "test").
 *   GET    /api/automations/drafts?source=&chat=&automation=
 *   POST   /api/automations/drafts/send { id, confirm: true, text?, form? }
 *   POST   /api/automations/drafts/form { id, form }
 *   POST   /api/automations/drafts/mark { id }  (sent by hand)
 *   POST   /api/automations/drafts/skip { id }
 *   GET    /api/automations/history?automation=
 *   POST   /api/automations/next { automation, exclude?, queue? }
 *          → the next chat it fits, its draft written with `queue` (R-Y86)
 *   POST   /api/automations/edit/reset { automation } → its own text again
 *   GET    /api/automations/autopilot → { autopilots } (R-Y87)
 *   POST   /api/automations/autopilot { automation, on?, monitor? }
 *          `on: true` is confirmed (how many chats, how paced) first
 *   GET    /api/automations/outbox?status= → { outbox } every automated send
 *          (sending, sent, failed, unknown), newest first (R-Z3)
 *   POST   /api/automations/outbox/resolve { id, decision: 'sent'|'failed' }
 *          the user's decision about an `unknown` send; never retried by itself
 *   GET    /api/automations/settings → quiet hours, timezone, opt-out list
 *   PUT    /api/automations/settings { quietHours?, timezone?, optOut? }
 *   POST   /api/send   { source, chat, text, contact? } → the chat composer;
 *                      API first, the official web UI when it fails
 *   POST   /api/typing { source, chat, cancel? } → show our typing status
 *                      (`cancel`: stop showing it)
 *   GET    /api/typing?source=&chat=   → who is typing now
 *
 * `automation` is an id (saved or preset) or a whole definition, so the
 * chat menu can test an edited automation before saving it.
 */

import { createLiveSubset } from './live-subset.js';
import { bodyFailure, json, readBody } from './util.js';
import { confirmed } from './confirmations.js';
import { previewFields } from '../sources/telegram-link-preview.js';
import {
  AUTOMATION_PREFIX,
  automationPresets,
  normalizeAutomation,
} from '../automation/automations.js';
import { listAutomations } from '../automation/drafts.js';
import { listOutbox, resolveOutbox } from '../automation/outbox.js';
import { loadSettings, saveSettings } from '../automation/safety.js';
import { isTypingActive, typingLink } from '../sources/live-links.js';
import { validSchedule } from '../sources/telegram-scheduled.js';
import { paidField, validSendAs } from '../sources/telegram-send-as-client.js';
import { validEffect } from './routes-telegram-effects.js';
import { questionAnswerRoute } from './routes-question-answers.js';
import { followRoute } from './routes-follow.js';

const fail = (res, status, code, error) =>
  json(res, status, { error, code }) ?? true;

const validChat = (body) =>
  typeof body.source === 'string' &&
  body.source !== '' &&
  body.chat !== undefined &&
  body.chat !== null &&
  String(body.chat) !== '';

const targetsOf = (body) =>
  Array.isArray(body.targets)
    ? body.targets.filter(validChat).map((t) => ({
        source: t.source,
        chat: String(t.chat),
      }))
    : undefined;

const automationOf = (body) => {
  if (!body.automation) {
    throw new Error('automation (an id or a definition) is required');
  }
  return body.automation;
};

/** Store an outgoing message so the chat and the reply graph see it. */
const sentMessage = ({ source, chat, text }, { at, via }) => ({
  id: `msg:${source}:${chat}:out-${Date.parse(at)}`,
  tokens: ['message', source, String(chat)],
  source,
  chat: String(chat),
  sender: 'me',
  body: text,
  timestamp: at,
  ...(via ? { via } : {}),
});

// The links a send stores: the network's own (a connected Telegram
// account knows the message ids, so the next sync does not show the
// message twice), else one local "sent" link. Each carries the composer's
// `clientId`, which is how the chat matches it to its pending bubble.
const sentLinks = (draft, result) => {
  const stamp = (link) => ({
    ...link,
    ...(result?.via ? { via: result.via } : {}),
    ...(draft.clientId ? { clientId: draft.clientId } : {}),
  });
  // Scheduled: held by Telegram, not yet in the chat.
  if (result?.scheduled) {
    return [];
  }
  const known = result?.links ?? (result?.link ? [result.link] : []);
  if (known.length > 0) {
    return known.map(stamp);
  }
  // Already sent by an earlier try (Telegram told us): the sync brings it.
  if (result?.duplicate) {
    return [];
  }
  return [
    stamp(
      sentMessage(draft, { at: new Date().toISOString(), via: result?.via })
    ),
  ];
};

const SEND_MEMORY_MS = 10 * 60_000;

// Build the outgoing draft from the POST body.
// A forum topic it goes to (R-Y122).
const topicField = (body) =>
  Number.isInteger(body.topic) && body.topic > 0 ? { topic: body.topic } : {};

// A message effect's id, a decimal string (R-Y149), already validated.
const effectField = (body) =>
  body.effect === undefined ? {} : { effect: body.effect };

const buildDraft = (body) => {
  const clientId =
    typeof body.clientId === 'string' && body.clientId.length <= 100
      ? body.clientId
      : null;
  const replyTo =
    typeof body.replyTo === 'number' && body.replyTo > 0 ? body.replyTo : null;
  // The part of it quoted (Quote & Reply); Telegram takes up to 1024.
  const replyQuote =
    replyTo && typeof body.replyQuote === 'string' && body.replyQuote.trim()
      ? body.replyQuote.slice(0, 1024)
      : null;
  return {
    source: body.source,
    chat: String(body.chat),
    contact: body.contact ?? null,
    text: String(body.text),
    ...(clientId ? { clientId } : {}),
    ...(replyTo ? { replyTo } : {}),
    ...(replyQuote ? { replyQuote } : {}),
    ...topicField(body),
    // The identity it is sent as in a group (R-Y141).
    ...(body.sendAs === undefined ? {} : { sendAs: body.sendAs }),
    // The Stars the user confirmed for a paid chat (R-Y184).
    ...paidField(body),
    // A message effect's id, a decimal string (R-Y149).
    ...effectField(body),
    // The link preview's choice (R-Y145), already validated.
    ...previewFields(body),
    // Without sound; at a time (R-Y102).
    ...(body.silent === true ? { silent: true } : {}),
    ...(body.scheduleDate !== undefined
      ? { scheduleDate: body.scheduleDate }
      : {}),
  };
};

// A draft (one `clientId`) is sent at most once per server: a second
// request — a double click, a retry after a lost answer — shares the
// first one's outcome instead of sending again. A failed send is
// forgotten, so the user can retry it.
const sendOnce = (ctx, draft, send) => {
  if (!draft.clientId) {
    return send();
  }
  const sends = (ctx.sends ??= new Map());
  const key = `${draft.source}:${draft.chat}:${draft.clientId}`;
  const now = Date.now();
  for (const [k, entry] of sends) {
    if (now - entry.at > SEND_MEMORY_MS) {
      sends.delete(k);
    }
  }
  const known = sends.get(key);
  if (known) {
    return known.promise;
  }
  const promise = send().catch((error) => {
    sends.delete(key);
    throw error;
  });
  sends.set(key, { at: now, promise });
  return promise;
};

// The network has it: a store that cannot take the copy (a full disk,
// R-Z14) does not make it unsent — answering "failed" would invite a
// second send. The sync brings the message once the store takes writes.
const keepSent = async (store, links) => {
  try {
    for (const link of links) {
      await store.put(link);
    }
    return true;
  } catch {
    return false;
  }
};

const validReply = (id) =>
  id === undefined || id === null || (Number.isInteger(id) && id > 0);
const sendTrace = (draft) => ({
  source: draft.source,
  chat: draft.chat,
  clientId: draft.clientId ?? null,
  replyTo: draft.replyTo ?? null,
  quoted: Boolean(draft.replyQuote),
  topic: draft.topic ?? null,
});
const reportSend = (ctx, trace, result, error) =>
  ctx.log?.({
    level: error ? 'error' : 'debug',
    event: 'message_send_result',
    ...trace,
    success: !error,
    ...(error
      ? { code: error.code ?? 'send-failed' }
      : { count: result.links?.length ?? 0, stored: result.stored !== false }),
  });

const deliverMessage = async (store, ctx, draft) => {
  const result = await ctx.send(draft);
  const links = sentLinks(draft, result);
  const stored = await keepSent(store, links);
  return {
    status: 'sent',
    via: result?.via,
    link: links.at(-1) ?? null,
    links,
    ...(stored ? {} : { stored: false }),
    ...(result?.scheduled ? { scheduled: true } : {}),
  };
};

const sendFailure = (res, error) =>
  json(res, error.code === 'flood-wait' ? 429 : 502, {
    error: error.message,
    code: error.code ?? 'send-failed',
    ...(error.retryAfter ? { retryAfter: error.retryAfter } : {}),
  });

const handleSend = async (store, res, body, ctx) => {
  if (!validChat(body) || !String(body.text ?? '').trim()) {
    return fail(res, 400, 'bad-message', 'source, chat and text are needed');
  }
  if (typeof ctx.send !== 'function') {
    return fail(res, 501, 'no-sender', 'no sender is configured');
  }
  if (!validReply(body.replyTo)) {
    return fail(res, 400, 'bad-reply', 'a valid reply message id is required');
  }
  if (body.scheduleDate !== undefined && !validSchedule(body.scheduleDate)) {
    return fail(res, 400, 'bad-schedule', 'a time from now to a year ahead');
  }
  if (!validSendAs(body.sendAs)) {
    return fail(res, 400, 'bad-send-as', 'a peer id to send as');
  }
  if (!validEffect(body.effect)) {
    return fail(res, 400, 'bad-effect', 'an effect id as a decimal string');
  }
  if (!previewFields(body)) {
    return fail(res, 400, 'bad-preview', 'a valid link preview choice');
  }
  const draft = buildDraft(body);
  const trace = sendTrace(draft);
  ctx.log?.({
    level: 'debug',
    event: 'message_send_requested',
    ...trace,
    confirmed: Boolean(body.confirmToken),
  });
  // The composer's Send press confirms exactly this text.
  const ok = await confirmed(ctx, res, {
    action: 'message.send',
    body,
    prepare: async () => ({ preview: draft }),
  });
  if (!ok) {
    return true;
  }
  try {
    const sent = await sendOnce(ctx, draft, () =>
      deliverMessage(store, ctx, draft)
    );
    reportSend(ctx, trace, sent);
    return json(res, 200, sent);
  } catch (error) {
    reportSend(ctx, trace, null, error);
    return sendFailure(res, error);
  }
};

const handleTyping = async (store, res, body, ctx) => {
  if (!validChat(body)) {
    return fail(res, 400, 'bad-chat', 'source and chat are needed');
  }
  // Shown in our own UI even when the network has no typing API.
  // `cancel`: the user sent or cleared the message, typing stops now.
  const cancel = body.cancel === true;
  const link = typingLink({
    source: body.source,
    chat: body.chat,
    user: 'me',
    ...(cancel ? { state: 'idle' } : {}),
  });
  await store.put(link);
  const out = await ctx.setTyping({
    source: body.source,
    chat: body.chat,
    ...(cancel ? { cancel } : {}),
  });
  return json(res, 200, { ...out, link });
};

const draftAction = (method) => async (store, res, body, ctx) => {
  if (typeof body.id !== 'string') {
    return fail(res, 400, 'bad-draft', 'id is required');
  }
  const runner = ctx.automations.runner;
  if (method === 'send') {
    // One draft per confirmation, exactly as the user saw (or edited) it.
    const ok = await confirmed(ctx, res, {
      action: 'draft.send',
      body,
      prepare: async () => ({
        preview: { id: body.id, text: body.text ?? null, form: body.form },
      }),
    });
    if (!ok) {
      return true;
    }
  }
  const result = {
    send: () =>
      runner.sendDraft(body.id, {
        confirm: true,
        text: body.text,
        form: body.form,
      }),
    form: () => runner.setDraftForm(body.id, body.form),
    mark: () => runner.markSent(body.id),
    skip: () => runner.skip(body.id),
  }[method]();
  const outcome = await result;
  return json(res, outcome.status === 'failed' ? 502 : 200, outcome);
};

// Autopilot: turning it on sends to every chat the automation fits, so
// the user first sees how many and how paced, and confirms.
const handleAutopilot = async (store, res, body, ctx) => {
  const { runner, autopilot } = ctx.automations;
  if (!autopilot) {
    return fail(res, 501, 'no-autopilot', 'autopilot needs the server');
  }
  const automation = automationOf(body);
  if (body.on === false) {
    return json(res, 200, await autopilot.stop(automation));
  }
  if (body.on !== true) {
    return json(res, 200, await autopilot.monitor(automation, body.monitor));
  }
  const ok = await confirmed(ctx, res, {
    action: 'automation.autopilot',
    body,
    prepare: async () => {
      const loaded = await runner.load(automation);
      const planned = await runner.plan(loaded, { limit: 1 });
      return {
        preview: {
          name: loaded.name,
          total: planned.total,
          pacing: loaded.pacing,
          edited: loaded.edited ?? [],
        },
      };
    },
  });
  if (!ok) {
    return true;
  }
  return json(
    res,
    200,
    await autopilot.start(automation, {
      monitor: body.monitor !== false,
      resumeOnStart: body.resumeOnStart === true,
    })
  );
};

// Safe mode only queues drafts. Auto mode sends, so the user first sees
// the planned messages and confirms them; exactly those are sent.
const handleRun = async (store, res, body, ctx) => {
  const runner = ctx.automations.runner;
  const automation = await runner.load(automationOf(body));
  const options = {
    targets: targetsOf(body),
    trigger: body.trigger === 'chat-menu' ? 'chat-menu' : 'manual',
    test: body.test === true,
    limit: body.limit,
  };
  if (automation.mode !== 'auto') {
    return json(res, 200, await runner.run(automation, options));
  }
  const ok = await confirmed(ctx, res, {
    action: 'automation.send',
    body,
    prepare: async () => {
      const planned = await runner.plan(automation, options);
      return { preview: planned, data: planned.drafts };
    },
  });
  if (!ok) {
    return true;
  }
  return json(
    res,
    200,
    await runner.run(automation, { ...options, confirmed: ok.data })
  );
};

const POST = {
  '/api/automations/plan': async (store, res, body, ctx) =>
    json(
      res,
      200,
      await ctx.automations.runner.plan(
        await ctx.automations.runner.load(automationOf(body)),
        {
          targets: targetsOf(body),
          limit: body.limit,
          test: body.test === true,
        }
      )
    ),
  '/api/automations/run': handleRun,
  '/api/automations/drafts/send': draftAction('send'),
  '/api/automations/drafts/form': draftAction('form'),
  '/api/automations/drafts/mark': draftAction('mark'),
  '/api/automations/drafts/skip': draftAction('skip'),
  '/api/automations/next': async (store, res, body, ctx) =>
    json(
      res,
      200,
      await ctx.automations.runner.next(automationOf(body), {
        exclude: targetsOf({ targets: body.exclude }) ?? [],
        queue: body.queue === true,
      })
    ),
  '/api/automations/edit/reset': async (store, res, body, ctx) =>
    json(res, 200, await ctx.automations.runner.resetEdit(automationOf(body))),
  '/api/automations/autopilot': handleAutopilot,
  '/api/automations/outbox/resolve': async (store, res, body) => {
    if (typeof body.id !== 'string' || !body.id.startsWith('outbox:')) {
      return fail(res, 400, 'bad-outbox', 'id of an outbox record is needed');
    }
    return json(res, 200, {
      outbox: await resolveOutbox(store, body.id, body.decision),
    });
  },
  '/api/send': handleSend,
  '/api/typing': handleTyping,
};

// Only typing links are read (asked every few seconds: copying the
// whole store each time cost memory and time).
const typingByStore = new WeakMap();
const typingNow = async (store, q) => {
  if (!typingByStore.has(store)) {
    typingByStore.set(
      store,
      createLiveSubset(store, (link) => link?.id?.startsWith('typing:'))
    );
  }
  const now = Date.now();
  return (await typingByStore.get(store)()).filter(
    (l) =>
      (!q.get('source') || l.source === q.get('source')) &&
      (!q.has('chat') || String(l.chat) === q.get('chat')) &&
      isTypingActive(l, now)
  );
};

const GET = {
  '/api/automations': async (store) => ({
    automations: await listAutomations(store),
  }),
  '/api/automations/presets': async () => ({ presets: automationPresets() }),
  '/api/automations/drafts': async (store, q, ctx) => ({
    drafts: await ctx.automations.runner.drafts({
      source: q.get('source') || undefined,
      chat: q.has('chat') ? q.get('chat') : undefined,
      automation: q.get('automation') || undefined,
    }),
  }),
  '/api/automations/outbox': async (store, q) => ({
    outbox: await listOutbox(store, { status: q.get('status') || null }),
  }),
  '/api/automations/settings': async (store) => loadSettings(store),
  '/api/automations/history': async (store, q, ctx) => ({
    records: await ctx.automations.runner.history({
      automation: q.get('automation') || undefined,
    }),
  }),
  '/api/typing': async (store, q) => ({ typing: await typingNow(store, q) }),
  '/api/automations/autopilot': async (store, q, ctx) => ({
    autopilots: (await ctx.automations.autopilot?.states()) ?? [],
  }),
};

const handleWrite = async (store, req, res, p) => {
  if (req.method === 'PUT' && p === '/api/automations/settings') {
    const body = await readBody(req);
    return json(res, 200, await saveSettings(store, body)) ?? true;
  }
  if (req.method === 'PUT' && p === '/api/automations') {
    const body = await readBody(req);
    const automation = normalizeAutomation(body.automation ?? body);
    await store.put(automation);
    return json(res, 200, automation) ?? true;
  }
  const prefix = '/api/automations/';
  if (req.method === 'DELETE' && p.startsWith(prefix)) {
    const key = decodeURIComponent(p.slice(prefix.length));
    const id = key.startsWith(AUTOMATION_PREFIX)
      ? key
      : `${AUTOMATION_PREFIX}${key}`;
    await store.delete(id);
    return json(res, 200, { deleted: id }) ?? true;
  }
  return false;
};

const statusFor = (error) => {
  if (error.code?.startsWith('answer-model-')) {
    return [error.code === 'answer-model-changed' ? 409 : 400, error.code];
  }
  if (error.code === 'confirm-required') {
    return [400, error.code];
  }
  // A body that is not JSON, or too big (R-Z1).
  return bodyFailure(error) ? [error.status, error.code] : [400, 'bad-request'];
};

const featureRoute = (path) =>
  [
    ['/api/automations/answers', questionAnswerRoute],
    ['/api/automations/follow', followRoute],
  ].find(([root]) => path === root || path.startsWith(`${root}/`))?.[1];

export const handleAutomationRoutes = async (store, req, res, p, url, ctx) => {
  const feature = featureRoute(p);
  if (feature) {
    try {
      return await feature(store, req, res, p, url, ctx);
    } catch (error) {
      const [status, code] = statusFor(error);
      fail(res, status, code, error.message);
      return true;
    }
  }
  const get = req.method === 'GET' ? GET[p] : null;
  const post = req.method === 'POST' ? POST[p] : null;
  const isWrite = ['PUT', 'DELETE'].includes(req.method);
  if (!get && !post && !(isWrite && p.startsWith('/api/automations'))) {
    return false;
  }
  try {
    if (get) {
      json(res, 200, await get(store, url.searchParams, ctx));
    } else if (post) {
      await post(store, res, await readBody(req), ctx);
    } else if (!(await handleWrite(store, req, res, p))) {
      return false;
    }
  } catch (error) {
    const [status, code] = statusFor(error);
    fail(res, status, code, error.message);
  }
  return true;
};
