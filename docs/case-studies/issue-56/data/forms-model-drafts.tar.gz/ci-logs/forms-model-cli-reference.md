# Claude Code adapter contract, checked 2026-11-10

Primary sources: [CLI reference](https://code.claude.com/docs/en/cli-reference) and [programmatic bare mode](https://code.claude.com/docs/en/headless#start-faster-with-bare-mode).

The adapter combines bare discovery isolation with an empty built-in tool list and denied MCP tools. Bare mode alone retains tools. Browser integration and session persistence are disabled. Print mode reads the private prompt from stdin; JSON schema output is accepted only from the structured result field. One turn and a bounded timeout limit each request. The optional model is a validated CLI alias or ID.

Bare mode ignores subscription OAuth/keychain login. The server needs Anthropic API credentials in its environment, or the configured cloud provider's credentials. This adapter neither configures nor reads credentials. No live provider request was made during validation; finite synthetic child processes verify arguments, stdin, structured output, errors, bounds and actual shutdown.
