import { test } from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import {
  watchChatPages,
  watchFixturePages,
  screenshotChatPages,
} from './helpers/e2e-page-errors.mjs';

const base = 'http://127.0.0.1:49743';
const accessError = (
  url = `${base}/api/status?probe=1`,
  initiator = 'Fetch API'
) => {
  // Match the actual Error.name/message split captured by the WebKit probe.
  const scheme = /^https?:/.exec(url)?.[0].slice(0, -1) ?? 'http';
  const error = new Error(
    `${url.replace(/^https?:(?:\/\/| \/)/, '/')} due to access control checks.`
  );
  error.name = `${initiator} cannot load ${scheme}`;
  return error;
};
const fixture = (options = {}) => {
  const context = new EventEmitter();
  const pages = [];
  context.pages = () => pages;
  const newPage = () => {
    const page = new EventEmitter();
    pages.push(page);
    context.emit('page', page);
    return page;
  };
  const first = newPage();
  const errors = [];
  watchChatPages(context, { base, engine: 'webkit', errors, ...options });
  return { first, newPage, errors };
};

test('standalone fixtures retain their actual engine, origin and genuine errors', () => {
  for (const engine of ['webkit', 'chromium']) {
    const context = new EventEmitter();
    const page = new EventEmitter();
    context.pages = () => [page];
    const errors = [];
    watchFixturePages(
      context,
      { browserType: () => ({ name: () => engine }) },
      base,
      errors
    );
    const native = accessError();
    const foreign = accessError('http://127.0.0.1:49744/api/status?probe=1');
    const genuine = new TypeError('Load failed');
    for (const error of [native, foreign, genuine]) {
      page.emit('pageerror', error);
    }
    assert.deepEqual(
      errors,
      (engine === 'webkit'
        ? [foreign, genuine]
        : [native, foreign, genuine]
      ).map(String)
    );
  }
});

test('reopened pages apply the same WebKit policy and retain genuine errors', () => {
  const { first, newPage, errors } = fixture();
  first.emit('pageerror', accessError());
  first.emit(
    'pageerror',
    accessError('http: /127.0.0.1:49743/api/status?probe=1')
  );
  const reopened = newPage();
  reopened.emit('pageerror', accessError());
  reopened.emit('pageerror', new Error('real application failure'));
  assert.deepEqual(errors, ['Error: real application failure']);
});

test('access-control errors from another origin or engine remain failures', () => {
  for (const engine of ['chromium', 'firefox', 'webkit']) {
    const { first, errors } = fixture({ engine });
    const error = accessError(
      engine === 'webkit'
        ? 'http://127.0.0.1:49744/api/status?probe=1'
        : undefined
    );
    first.emit('pageerror', error);
    assert.deepEqual(errors, [String(error)], engine);
  }
});

test('native EventSource cancellation is scoped to WebKit and the fixture origin', () => {
  for (const engine of ['webkit', 'chromium', 'firefox']) {
    const { first, errors } = fixture({ engine });
    const native = accessError(
      `${base}/api/telegram/accounts-events`,
      'EventSource'
    );
    const foreign = accessError('http://127.0.0.1:49744/events', 'EventSource');
    const genuine = new Error(String(native));
    first.emit('pageerror', native);
    first.emit('pageerror', foreign);
    first.emit('pageerror', genuine);
    assert.deepEqual(
      errors,
      (engine === 'webkit'
        ? [foreign, genuine]
        : [native, foreign, genuine]
      ).map(String)
    );
  }
});

test('malformed URLs and real unhandled fetch rejections remain failures', () => {
  const { first, errors } = fixture();
  const failures = [
    accessError('not-a-url'),
    new TypeError('Load failed'),
    new Error('Failed to fetch'),
  ];
  for (const error of failures) {
    first.emit('pageerror', error);
  }
  assert.deepEqual(errors, failures.map(String));
});

test('browser dialogs are rejected and dismissed on reopened pages', async () => {
  const { newPage, errors } = fixture();
  let dismissed = false;
  newPage().emit('dialog', {
    message: () => 'unexpected confirm',
    dismiss: async () => {
      dismissed = true;
    },
  });
  assert.deepEqual(errors, ['browser dialog: unexpected confirm']);
  assert.equal(dismissed, true);
});

test('handled WebKit diagnostics have opt-in tracing', () => {
  const trace = [];
  const { newPage, errors } = fixture({ trace: (event) => trace.push(event) });
  newPage().emit('pageerror', accessError());
  assert.deepEqual(errors, []);
  assert.deepEqual(trace, ['handled WebKit same-origin network diagnostic']);
});

test('only explicitly expected confirmations are accepted', async () => {
  const { first, errors } = fixture({
    acceptDialog: (dialog) => dialog.message() === 'Delete recorded post?',
  });
  const accepted = [];
  const dismissed = [];
  for (const message of ['Delete recorded post?', 'Unexpected prompt']) {
    first.emit('dialog', {
      message: () => message,
      accept: async () => accepted.push(message),
      dismiss: async () => dismissed.push(message),
    });
  }
  assert.deepEqual(accepted, ['Delete recorded post?']);
  assert.deepEqual(dismissed, ['Unexpected prompt']);
  assert.deepEqual(errors, ['browser dialog: Unexpected prompt']);
});

test('native WebKit display-form URLs retain the exact origin boundary', () => {
  const { newPage, errors } = fixture();
  const page = newPage();
  page.emit(
    'pageerror',
    accessError('http: /127.0.0.1:49743/api/status?probe=1')
  );
  const foreign = accessError('http: /127.0.0.1:49744/api/status?probe=1');
  page.emit('pageerror', foreign);
  assert.deepEqual(errors, [String(foreign)]);
});

test('failure screenshot uses reopened pages and continues after a capture fails', async () => {
  const captures = [];
  const reports = [];
  const page = (closed, screenshot) => ({ isClosed: () => closed, screenshot });
  const context = {
    pages: () => [
      page(true, () => assert.fail('closed original page')),
      page(false, async () => {
        throw new Error('page vanished');
      }),
      page(false, async ({ path }) => captures.push(path)),
    ],
  };
  await screenshotChatPages(context, {
    artifactDir: 'artifacts/browser',
    name: 'history',
    engine: 'webkit',
    report: (message) => reports.push(message),
  });
  assert.equal(captures.length, 1);
  assert.match(captures[0], /ms-e2e-history-webkit-1\.png$/);
  assert.deepEqual(reports, ['[e2e-history] screenshot failed: page vanished']);
});

test('genuine exceptions using native diagnostic text still fail', () => {
  const { first, errors } = fixture();
  const failures = [
    new Error(
      `Fetch API cannot load ${base}/api/status?probe=1 due to access control checks.`
    ),
    new TypeError(
      `Fetch API cannot load http: /127.0.0.1:49743/api/status?probe=1 due to access control checks.`
    ),
  ];
  for (const error of failures) {
    first.emit('pageerror', error);
  }
  assert.deepEqual(errors, failures.map(String));
});
