async (page) => {
  const prepareQuestionBrowserMcp = (async (page, { screenshots } = {}) => {
  if (screenshots) {
    page.setDefaultTimeout(10000);
    await page.addInitScript(() =>
      globalThis.localStorage.setItem(
        'metaSovereignOperatorScope',
        JSON.stringify({ private: true, bot: true })
      )
    );
  }
  const url = new URL(page.url());
  const base = url.origin;
  const control = url.searchParams.get('fixtureControl');
  if (!control || new URL(control).hostname !== '127.0.0.1') {
    throw new Error('Open the private fixture with its loopback control URL.');
  }
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.addInitScript(() => {
    globalThis.localStorage.setItem('metaSovereignLocale', 'en');
    globalThis.localStorage.setItem(
      'metaSovereignTutorial',
      JSON.stringify({ off: true, v: 5 })
    );
  });
  await page.setViewportSize({ width: 1180, height: 950 });
  await page.goto(`${base}/#/automation`);
  await page.locator('[data-question-controls] > summary').click();
  const controls = page.locator(
    '[data-question-controls] [data-browser-answer-controls]'
  );
  await controls.locator(':scope > summary').click();
  await controls.getByLabel('Web-chat reference', { exact: true }).fill('7');
  const read = async () => {
    const previous = await controls
      .locator('[data-browser-answer-review]')
      .getAttribute('data-browser-answer-review')
      .catch(() => null);
    await controls.locator('[data-browser-answer-inspect]').click();
    await controls
      .locator(
        previous
          ? `[data-browser-answer-review]:not([data-browser-answer-review="${previous}"])`
          : '[data-browser-answer-review]'
      )
      .waitFor();
  };
  const stats = async () => (await page.request.get(control)).json();
  const check = (ok, message) => {
    if (!ok) {
      throw new Error(message);
    }
  };
  const shot = async (name, node) => {
    await node.scrollIntoViewIfNeeded();
    await page.screenshot({ path: `${screenshots}/mcp-${name}.png` });
  };
  const unreadSurface = async (surface, hash, width) => {
    await page.request.get(`${control}/seed`);
    await page.setViewportSize({ width, height: 950 });
    await page.goto(`${base}/?unread-${surface}${hash}`);
    await page.locator('[data-action="chat-automations"]').click();
    const menu = page.locator('.chat-menu-list [data-browser-answer-controls]');
    await menu.locator(':scope > summary').click();
    return menu.locator('[data-browser-unread-controls]');
  };
  const recoverHeldSurfaces = async (chat) => {
    for (const [surface, hash, width] of [
      ['chat', '#chat=hh:7', 1180],
      ['operator', '#/operator?chat=hh%3A7', 390],
    ]) {
      const shared = await unreadSurface(surface, hash, width);
      await shared
        .getByRole('button', {
          name: 'Recover unread pass status',
          exact: true,
        })
        .click();
      await shared.locator(`[data-browser-unread-held="${chat}"]`).waitFor();
      await shot(surface, shared);
      check(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= globalThis.innerWidth
        ),
        'No viewport overflow'
      );
    }
  };
  const localizedUnread = async (localized, language) => {
    localized.on('pageerror', (error) => errors.push(error.message));
    await localized.addInitScript((locale) => {
      globalThis.localStorage.setItem('metaSovereignLocale', locale);
      globalThis.localStorage.setItem(
        'metaSovereignTutorial',
        JSON.stringify({ off: true, v: 5 })
      );
    }, language);
    await localized.goto(`${base}/#/automation`);
    await localized.locator('[data-question-controls] > summary').click();
    const panel = localized.locator(
      '[data-question-controls] [data-browser-answer-controls]'
    );
    await panel.locator(':scope > summary').click();
    return panel.locator('[data-browser-unread-controls]');
  };
  return {
    control,
    controls,
    errors,
    read,
    stats,
    check,
    shot,
    unreadSurface,
    recoverHeldSurfaces,
    localizedUnread,
  };
});
  return (async (page, screenshots, dictionaries) => {
  const {
    controls,
    errors,
    stats,
    check,
    shot,
    recoverHeldSurfaces,
    localizedUnread,
  } = await prepareQuestionBrowserMcp(page, { screenshots });
  const unread = controls.locator('[data-browser-unread-controls]');
  await unread.locator('[data-browser-unread-answers]').check();
  const model = unread.locator('[data-model-draft-opt-in]');
  check(!(await model.isChecked()), 'Unread model use defaults off');
  await model.check();
  check(
    await unread.locator('[data-browser-unread-start]').isDisabled(),
    'Mark-read confirmation is required'
  );
  await unread.locator('[data-browser-unread-confirm]').check();
  await unread.locator('[data-browser-unread-start]').click();
  await unread.locator('[data-browser-unread-result="completed"]').waitFor();
  await unread.locator('[data-browser-unread-held="8"]').waitFor();
  await unread.locator('[data-browser-unread-answer="prefilled"]').waitFor();
  await shot('questions', unread);
  const counts = await stats();
  check(
    counts.scans === 1 &&
      counts.modelCalls === 1 &&
      counts.prefills === 1 &&
      counts.sends === 0,
    'One generated review draft without delivery'
  );
  await recoverHeldSurfaces('8');
  const locales = [];
  for (const [language, dictionary] of Object.entries(dictionaries)) {
    const localized = await page.context().newPage();
    try {
      const unread = await localizedUnread(localized, language);
      await unread
        .getByRole('button', { name: dictionary.recover, exact: true })
        .click();
      await unread.locator('[data-browser-unread-held="8"]').waitFor();
      await unread.locator('[data-browser-unread-answers]').check();
      const optIn = unread.getByRole('checkbox', {
        name: dictionary['answerModel.optIn'],
        exact: true,
      });
      await optIn.waitFor();
      check(
        !(await optIn.isChecked()),
        `${language} model opt-in defaults off`
      );
      locales.push({ language, translated: true, defaultOff: true });
    } finally {
      await localized.close();
    }
  }
  check(!errors.length, errors.join(', '));
  check(
    (await stats()).modelCalls === 1,
    'Recovery and locales never regenerate'
  );
  return { locales, cases: 4, pageErrors: errors, ...(await stats()) };
})(page, "/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459/docs/screenshots/issue-56-unread-model", {"en":{"answerModel.title":"Optional Claude Code drafts","answerModel.hint":"Runs Claude Code on this server using API/provider credentials available to the server. Selected CV, current profile, recent context and nearby approved answers are sent to that provider. Requires Claude Code and API/provider credentials; subscription login is not used. Tools and session persistence are disabled. Opt in for each plan; every model answer needs review. Nothing is sent to a chat or submitted to a form.","answerModel.enable":"Enable model drafts","answerModel.model":"Model alias or ID (empty uses the CLI default)","answerModel.cv":"Stored CV to include","answerModel.noCv":"Do not include a CV","answerModel.cvMissing":"unavailable","answerModel.timeout":"Request limit in milliseconds (1000–120000)","answerModel.save":"Save model settings","answerModel.reload":"Reload model settings","answerModel.saved":"Model settings saved.","answerModel.changed":"Model settings changed elsewhere. Your draft is preserved; reload before saving.","answerModel.error":"Model settings are unconfirmed ({code}). Reload to recover.","answerModel.optIn":"Use configured model for unresolved answers in this plan","answerModel.state.disabled":"Model drafts are disabled.","answerModel.state.unavailable":"Model drafts require the local server adapter.","answerModel.state.unneeded":"Saved answers already cover this plan; the model was not called.","answerModel.state.refused":"No model draft was accepted ({code}). Existing answers are preserved.","answerModel.state.drafted":"Model drafts need review. Requested: {count}; outside this batch: {omitted}.","answerModel.source":"Model draft","answerModel.clarification":"Ask the owner to clarify missing facts.","answerModel.review":"Review the model draft before applying it.","questions.match.model":"Model draft","forms.plan.source.model":"Model draft","forms.plan.reason.model-clarification":"Ask the owner to clarify missing facts.","forms.plan.reason.model-review":"Review the model draft before applying it.","recover":"Recover unread pass status"},"ru":{"answerModel.title":"Необязательные черновики Claude Code","answerModel.hint":"Claude Code запускается на этом сервере с доступными серверу учётными данными API/провайдера. Выбранное резюме, текущий профиль, недавний контекст и близкие одобренные ответы передаются этому провайдеру. Требуются Claude Code и учётные данные API/провайдера; вход по подписке не используется. Инструменты и сохранение сессии отключены. Включайте для каждого плана; ответы модели требуют проверки. Сообщения не отправляются, формы не отправляются.","answerModel.enable":"Включить черновики модели","answerModel.model":"Псевдоним или ID модели (пусто — модель CLI по умолчанию)","answerModel.cv":"Сохранённое резюме для контекста","answerModel.noCv":"Не включать резюме","answerModel.cvMissing":"недоступно","answerModel.timeout":"Лимит запроса в миллисекундах (1000–120000)","answerModel.save":"Сохранить настройки модели","answerModel.reload":"Перезагрузить настройки модели","answerModel.saved":"Настройки модели сохранены.","answerModel.changed":"Настройки модели изменены в другом месте. Ваш черновик сохранён; перезагрузите перед сохранением.","answerModel.error":"Настройки модели не подтверждены ({code}). Перезагрузите для восстановления.","answerModel.optIn":"Использовать настроенную модель для нерешённых ответов в этом плане","answerModel.state.disabled":"Черновики модели отключены.","answerModel.state.unavailable":"Для черновиков модели нужен адаптер локального сервера.","answerModel.state.unneeded":"Сохранённые ответы уже покрывают план; модель не вызывалась.","answerModel.state.refused":"Черновики модели не приняты ({code}). Прежние ответы сохранены.","answerModel.state.drafted":"Проверьте черновики модели. Запрошено: {count}; вне пакета: {omitted}.","answerModel.source":"Черновик модели","answerModel.clarification":"Уточните недостающие факты у владельца.","answerModel.review":"Проверьте черновик модели перед применением.","questions.match.model":"Черновик модели","forms.plan.source.model":"Черновик модели","forms.plan.reason.model-clarification":"Уточните недостающие факты у владельца.","forms.plan.reason.model-review":"Проверьте черновик модели перед применением.","recover":"Восстановить статус прохода"},"hi":{"answerModel.title":"वैकल्पिक Claude Code ड्राफ़्ट","answerModel.hint":"इस सर्वर पर Claude Code सर्वर को उपलब्ध API/प्रदाता क्रेडेंशियल से चलता है। चुना हुआ CV, मौजूदा प्रोफ़ाइल, हाल का संदर्भ और मिलते-जुलते स्वीकृत उत्तर उस प्रदाता को भेजे जाते हैं। Claude Code और API/प्रदाता क्रेडेंशियल चाहिए; सब्सक्रिप्शन लॉगिन इस्तेमाल नहीं होता। टूल और सत्र सहेजना बंद हैं। हर योजना के लिए अलग से चालू करें; हर मॉडल उत्तर की समीक्षा ज़रूरी है। चैट में संदेश या फ़ॉर्म सबमिट नहीं होते।","answerModel.enable":"मॉडल ड्राफ़्ट चालू करें","answerModel.model":"मॉडल उपनाम या ID (खाली होने पर CLI डिफ़ॉल्ट)","answerModel.cv":"संदर्भ में शामिल सहेजा गया CV","answerModel.noCv":"CV शामिल न करें","answerModel.cvMissing":"अनुपलब्ध","answerModel.timeout":"अनुरोध सीमा मिलीसेकंड में (1000–120000)","answerModel.save":"मॉडल सेटिंग सहेजें","answerModel.reload":"मॉडल सेटिंग फिर लोड करें","answerModel.saved":"मॉडल सेटिंग सहेजी गईं।","answerModel.changed":"मॉडल सेटिंग कहीं और बदली गई हैं। आपका ड्राफ़्ट सुरक्षित है; सहेजने से पहले फिर लोड करें।","answerModel.error":"मॉडल सेटिंग की पुष्टि नहीं हुई ({code})। फिर लोड करके सुधारें।","answerModel.optIn":"इस योजना के अनसुलझे उत्तरों के लिए कॉन्फ़िगर किया मॉडल इस्तेमाल करें","answerModel.state.disabled":"मॉडल ड्राफ़्ट बंद हैं।","answerModel.state.unavailable":"मॉडल ड्राफ़्ट के लिए स्थानीय सर्वर एडैप्टर चाहिए।","answerModel.state.unneeded":"सहेजे गए उत्तर योजना के लिए पर्याप्त हैं; मॉडल नहीं बुलाया गया।","answerModel.state.refused":"कोई मॉडल ड्राफ़्ट स्वीकार नहीं हुआ ({code})। मौजूदा उत्तर सुरक्षित हैं।","answerModel.state.drafted":"मॉडल ड्राफ़्ट की समीक्षा करें। अनुरोधित: {count}; इस बैच से बाहर: {omitted}।","answerModel.source":"मॉडल ड्राफ़्ट","answerModel.clarification":"गायब तथ्यों के लिए मालिक से स्पष्टीकरण लें।","answerModel.review":"लागू करने से पहले मॉडल ड्राफ़्ट की समीक्षा करें।","questions.match.model":"मॉडल ड्राफ़्ट","forms.plan.source.model":"मॉडल ड्राफ़्ट","forms.plan.reason.model-clarification":"गायब तथ्यों के लिए मालिक से स्पष्टीकरण लें।","forms.plan.reason.model-review":"लागू करने से पहले मॉडल ड्राफ़्ट की समीक्षा करें।","recover":"अपठित प्रक्रिया की स्थिति पुनः प्राप्त करें"},"zh":{"answerModel.title":"可选 Claude Code 草稿","answerModel.hint":"在此服务器上运行 Claude Code，使用服务器可用的 API/提供商凭据。所选简历、当前资料、近期上下文和相近的已批准答案将发送给该提供商。需要安装 Claude Code 并提供 API/提供商凭据；不使用订阅登录。工具及会话持久化已禁用。每个计划需单独启用；所有模型答案都需审核。不会向聊天发送消息或提交表单。","answerModel.enable":"启用模型草稿","answerModel.model":"模型别名或 ID（留空使用 CLI 默认模型）","answerModel.cv":"包含的已保存简历","answerModel.noCv":"不包含简历","answerModel.cvMissing":"不可用","answerModel.timeout":"请求限制（毫秒，1000–120000）","answerModel.save":"保存模型设置","answerModel.reload":"重新加载模型设置","answerModel.saved":"模型设置已保存。","answerModel.changed":"模型设置已在别处更改。您的草稿已保留；保存前请重新加载。","answerModel.error":"模型设置未经确认（{code}）。请重新加载以恢复。","answerModel.optIn":"对此计划中的未解决答案使用已配置的模型","answerModel.state.disabled":"模型草稿已禁用。","answerModel.state.unavailable":"模型草稿需要本地服务器适配器。","answerModel.state.unneeded":"已保存的答案已覆盖此计划；未调用模型。","answerModel.state.refused":"未接受任何模型草稿（{code}）。原有答案已保留。","answerModel.state.drafted":"模型草稿需要审核。请求数：{count}；此批次以外：{omitted}。","answerModel.source":"模型草稿","answerModel.clarification":"请向所有者确认缺失的事实。","answerModel.review":"应用前请审核模型草稿。","questions.match.model":"模型草稿","forms.plan.source.model":"模型草稿","forms.plan.reason.model-clarification":"请向所有者确认缺失的事实。","forms.plan.reason.model-review":"应用前请审核模型草稿。","recover":"恢复未读读取状态"}});
}