// Tests for the i18n core (issue #18). Exercises:
//   - dictionary parity (every locale has identical keys to the
//     English source). The CI build fails if a key drifts.
//   - placeholder interpolation, including missing-variable safety.
//   - RFC 4647 §3.4 prefix lookup (zh-Hans-CN → zh, EN_US → en).
//   - detection precedence: stored override beats navigator beats
//     fallback.
//   - persistence + clearing of LOCALE_STORAGE_KEY.
//   - language-switcher SSR markup includes a "system default" option
//     plus one option per available locale.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';

import {
  LOCALE_STORAGE_KEY,
  detectInitialLocale,
  translate,
  applyLocale,
  LocaleContext,
  availableLocales,
  DEFAULT_LOCALE,
  formatChatTime,
  formatDateTime,
  formatTime,
} from '../src/web/i18n.js';
import { dictionaries } from '../src/web/locales/index.js';
import { LanguageSwitcher } from '../src/web/language-switcher.js';

const fakeStorage = () => {
  const map = new Map();
  return {
    map,
    getItem: (k) => (map.has(k) ? map.get(k) : null),
    setItem: (k, v) => map.set(k, String(v)),
    removeItem: (k) => map.delete(k),
  };
};

test('LOCALE_STORAGE_KEY is the documented metaSovereignLocale key', () => {
  assert.equal(LOCALE_STORAGE_KEY, 'metaSovereignLocale');
});

test('availableLocales lists en, ru, zh, hi with ltr direction', () => {
  const ids = availableLocales.map((entry) => entry.id);
  assert.deepEqual(ids.sort(), ['en', 'hi', 'ru', 'zh']);
  for (const entry of availableLocales) {
    assert.equal(entry.dir, 'ltr');
    assert.ok(typeof entry.label === 'string' && entry.label.length > 0);
  }
});

test('every non-en dictionary mirrors the en key set exactly', () => {
  const enKeys = Object.keys(dictionaries.en).sort();
  for (const id of Object.keys(dictionaries)) {
    if (id === 'en') {
      continue;
    }
    const keys = Object.keys(dictionaries[id]).sort();
    assert.deepEqual(
      keys,
      enKeys,
      `${id} dictionary keys must mirror en exactly`
    );
  }
});

test('no English literal leaks into a non-en dictionary (issue #25)', () => {
  // Issue #25: translated builds must not show English copy when the
  // locale is non-English. The heuristic: for every en value that
  // contains 3+ consecutive Latin letters, every non-en dictionary
  // must define a different value. Brand names and identifiers stay
  // on an allow-list because they are language-neutral.
  const HAS_LATIN_WORD = /[A-Za-z]{3,}/;
  // Brand names and runtime identifiers stay in English in every
  // locale. Listing the exact keys keeps the heuristic strict for
  // every other entry.
  const LANG_NEUTRAL = new Set([
    'appName',
    'guide.localServer.rust',
    'guide.localServer.node',
    'guide.localServer.docker',
    // Provider-supplied identifiers that mirror the API's own naming
    // (HTTP header names, env var keys) stay verbatim across locales.
    'connections.superjob.fields.appId.label',
    // Telegram's own credential names, verbatim in every language.
    'telegramLogin.apiId',
    'telegramLogin.apiHash',
    // A format's name: Telegram's apps say "GIF" in every language.
    'chat.media.gifLabel',
    'chat.stickers.gif',
  ]);
  // Some keys hold only filename glob patterns or other technical
  // identifiers (e.g. "*.eml, *.mbox", "result.json", "messages.csv").
  // The convention is that *.archive.fileHint values never contain a
  // translatable sentence, only file globs.
  const isFileHintKey = (key) => key.endsWith('.archive.fileHint');
  // The connections.<provider>.label keys hold the provider's brand
  // name (Telegram, GitHub, WhatsApp, …) and are language-neutral.
  const isProviderLabelKey = (key) =>
    /^connections\.[a-z0-9-]+\.label$/.test(key);
  // Strip ICU-lite placeholders ({name}) before deciding whether the
  // value carries English copy: '{current} / {total}' is a layout
  // primitive, not a translatable sentence.
  const stripPlaceholders = (s) => s.replace(/\{[^}]+\}/g, '');
  for (const [key, enValue] of Object.entries(dictionaries.en)) {
    if (typeof enValue !== 'string') {
      continue;
    }
    if (LANG_NEUTRAL.has(key)) {
      continue;
    }
    if (isFileHintKey(key)) {
      continue;
    }
    if (isProviderLabelKey(key)) {
      continue;
    }
    // Networks' names (LinkedIn, GitHub, …) are brands.
    if (
      key.startsWith('chat.about.network.') &&
      key !== 'chat.about.network.email'
    ) {
      continue;
    }
    if (!HAS_LATIN_WORD.test(stripPlaceholders(enValue))) {
      continue;
    }
    for (const id of Object.keys(dictionaries)) {
      if (id === 'en') {
        continue;
      }
      assert.notStrictEqual(
        dictionaries[id][key],
        enValue,
        `${id}.${key} is identical to en — translation missing`
      );
    }
  }
});

test('every translated string is non-empty in every locale', () => {
  for (const id of Object.keys(dictionaries)) {
    for (const [key, value] of Object.entries(dictionaries[id])) {
      assert.equal(typeof value, 'string', `${id}.${key} must be a string`);
      assert.ok(value.length > 0, `${id}.${key} must not be empty`);
    }
  }
});

test('translate falls back to en for unknown locales', () => {
  assert.equal(translate('en', 'common.save'), dictionaries.en['common.save']);
  // Unknown locale falls back to en.
  assert.equal(translate('xx', 'common.save'), dictionaries.en['common.save']);
});

test('translate returns the key when missing in every dictionary', () => {
  assert.equal(translate('en', 'no.such.key'), 'no.such.key');
});

test('translate interpolates {placeholders}', () => {
  const formatted = translate('en', 'tutorial.progress', {
    current: 2,
    total: 5,
  });
  assert.equal(formatted, 'Step 2 of 5');
});

test('translate leaves unknown placeholders intact', () => {
  const formatted = translate('en', 'tutorial.progress', { current: 2 });
  assert.equal(formatted, 'Step 2 of {total}');
});

test('translate works for every locale that defines the same key', () => {
  for (const id of Object.keys(dictionaries)) {
    const out = translate(id, 'tutorial.progress', { current: 1, total: 3 });
    assert.ok(typeof out === 'string' && out.length > 0);
    // Placeholders must be substituted in every locale.
    assert.ok(!out.includes('{current}'), `${id} must replace {current}`);
    assert.ok(!out.includes('{total}'), `${id} must replace {total}`);
  }
});

test('detectInitialLocale prefers a stored override over navigator', () => {
  const storage = fakeStorage();
  storage.setItem(LOCALE_STORAGE_KEY, 'ru');
  assert.equal(
    detectInitialLocale({
      storage,
      navigator: { languages: ['zh-CN'], language: 'zh-CN' },
    }),
    'ru'
  );
});

test('detectInitialLocale walks navigator.languages and prefix-matches zh-Hans-CN → zh', () => {
  assert.equal(
    detectInitialLocale({
      storage: fakeStorage(),
      navigator: { languages: ['zh-Hans-CN', 'en'], language: 'zh-Hans-CN' },
    }),
    'zh'
  );
});

test('detectInitialLocale handles BCP-47 underscore form (en_US)', () => {
  assert.equal(
    detectInitialLocale({
      storage: fakeStorage(),
      navigator: { languages: ['en_US'], language: 'en_US' },
    }),
    'en'
  );
});

test('detectInitialLocale falls back to default when nothing matches', () => {
  assert.equal(
    detectInitialLocale({
      storage: fakeStorage(),
      navigator: { languages: ['fr-FR', 'es-ES'], language: 'fr-FR' },
    }),
    DEFAULT_LOCALE
  );
});

test('detectInitialLocale tolerates a navigator without languages array', () => {
  assert.equal(
    detectInitialLocale({
      storage: fakeStorage(),
      navigator: { language: 'hi-IN' },
    }),
    'hi'
  );
});

test('detectInitialLocale tolerates a missing storage', () => {
  assert.equal(
    detectInitialLocale({
      storage: null,
      navigator: { languages: ['ru-RU'], language: 'ru-RU' },
    }),
    'ru'
  );
});

test('detectInitialLocale tolerates a storage that throws', () => {
  const broken = {
    getItem: () => {
      throw new Error('locked');
    },
    setItem: () => {},
    removeItem: () => {},
  };
  assert.equal(
    detectInitialLocale({
      storage: broken,
      navigator: { languages: ['hi'], language: 'hi' },
    }),
    'hi'
  );
});

test('applyLocale sets <html lang> and <html dir> when document is available', () => {
  const attrs = {};
  const fakeDocument = {
    documentElement: {
      setAttribute: (name, value) => {
        attrs[name] = value;
      },
    },
  };
  applyLocale('zh', { document: fakeDocument });
  assert.equal(attrs.lang, 'zh');
  assert.equal(attrs.dir, 'ltr');
});

test('applyLocale is a no-op when document is unavailable (SSR-safe)', () => {
  applyLocale('ru', { document: null });
});

test('LanguageSwitcher renders a system-default option plus every locale', () => {
  const html = renderToStaticMarkup(
    React.createElement(
      LocaleContext.Provider,
      {
        value: {
          locale: 'en',
          setLocale: () => {},
          clearLocale: () => {},
          t: (key) => key,
          available: availableLocales,
        },
      },
      React.createElement(LanguageSwitcher)
    )
  );
  assert.match(html, /value="__system__"/);
  for (const entry of availableLocales) {
    assert.ok(
      html.includes(`value="${entry.id}"`),
      `LanguageSwitcher must render an option for ${entry.id}`
    );
    assert.ok(
      html.includes(entry.label),
      `LanguageSwitcher must render the ${entry.id} label "${entry.label}"`
    );
  }
});

test('LanguageSwitcher pre-selects the active locale via the <select value>', () => {
  const html = renderToStaticMarkup(
    React.createElement(
      LocaleContext.Provider,
      {
        value: {
          locale: 'hi',
          setLocale: () => {},
          clearLocale: () => {},
          t: (key) => key,
          available: availableLocales,
        },
      },
      React.createElement(LanguageSwitcher)
    )
  );
  // React's renderToStaticMarkup adds `selected` to the matching option.
  assert.match(html, /<option[^>]*value="hi"[^>]*selected/);
});

test('default LocaleContext returns translations from the default locale', () => {
  // The fallback context exposes a working `t` so components can render
  // before the App-level <Provider> is mounted (used by the tutorial
  // tests that render TutorialOverlay in isolation).
  const Probe = () => {
    const ctx = React.useContext(LocaleContext);
    return React.createElement('span', null, ctx.t('common.save'));
  };
  const html = renderToStaticMarkup(React.createElement(Probe));
  assert.ok(html.includes(dictionaries[DEFAULT_LOCALE]['common.save']));
});

test('times follow the interface language, not the browser', () => {
  // 14:05 local time, whatever the machine's time zone.
  const at = new Date(2026, 9, 12, 14, 5).toISOString();
  const ru = formatTime(at, 'ru');
  const en = formatTime(at, 'en');
  assert.equal(ru, '14:05', 'Russian uses a 24-hour clock');
  assert.match(en, /^2:05\sPM$/, 'English uses AM/PM');
  // Dates are spelled out and seconds dropped: "Oct 12, 2026, 2:05 PM".
  // Newer CLDR data (macOS's ICU, used by Bun there) joins date and time
  // with "at" / "в" instead of a comma; both are right.
  assert.match(formatDateTime(at, 'en'), /^Oct 12, 2026(,| at) 2:05\sPM$/);
  assert.match(formatDateTime(at, 'ru'), /^12 окт\. 2026 г\.(,| в) 14:05$/);
  assert.equal(formatTime(null, 'ru'), '');
  assert.equal(formatDateTime('not a date', 'ru'), '');
});

test('a chat list dates rows as messengers do', () => {
  // Monday 12 Oct 2026, 15:00 local time.
  const now = new Date(2026, 9, 12, 15, 0).getTime();
  const at = (...ymdhm) => new Date(...ymdhm).toISOString();
  // Today: the time.
  assert.equal(formatChatTime(at(2026, 9, 12, 9, 30), 'ru', now), '09:30');
  // Within the week: the weekday (Wednesday the 7th).
  // CLDR versions differ on the case of Russian weekdays ("ср", "Ср").
  assert.equal(formatChatTime(at(2026, 9, 7, 9, 30), 'en', now), 'Wed');
  assert.equal(
    formatChatTime(at(2026, 9, 7, 9, 30), 'ru', now).toLowerCase(),
    'ср'
  );
  // Earlier this year: day and month, no time.
  assert.equal(formatChatTime(at(2026, 4, 26, 4, 10), 'en', now), 'May 26');
  assert.equal(formatChatTime(at(2026, 4, 26, 4, 10), 'ru', now), '26 мая');
  // Another year: with the year.
  assert.equal(
    formatChatTime(at(2025, 8, 12, 4, 10), 'en', now),
    'Sep 12, 2025'
  );
  assert.equal(formatChatTime(null, 'en', now), '');
});

test('translate picks the plural form for the locale (ICU subset)', () => {
  const t = (n) => translate('en', 'chat.notice.queued', { count: n });
  assert.equal(t(1), '1 draft is ready below: review, then send.');
  assert.equal(t(3), '3 drafts are ready below: review, then send.');
  assert.equal(
    translate('en', 'chat.suggest.count', { count: 1 }),
    'Used once'
  );
  assert.equal(
    translate('en', 'chat.subtitle.group', { source: 'vk', count: 1 }),
    'vk · 1 person'
  );
  // Without the variable the message stays as written.
  assert.match(translate('en', 'chat.notice.sentAuto'), /\{count, plural,/);
  // No English string asks the reader to decode "(s)".
  for (const [key, value] of Object.entries(dictionaries.en)) {
    assert.ok(!/\w\(s\)/.test(value), `${key}: "${value}"`);
  }
});
