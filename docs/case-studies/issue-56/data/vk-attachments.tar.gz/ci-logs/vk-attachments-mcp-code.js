async (page) => (async (page, fixture) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(([key, value]) => globalThis.localStorage.setItem(key, value), fixture.tutorial);
  await page.goto(fixture.base);
  const result = [];
  const ready = () => page.waitForFunction(() => {
    const input = document.querySelector('[data-action=vk-attachments-enabled]');
    return input && !input.disabled;
  });
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate((value) => globalThis.localStorage.setItem('metaSovereignLocale', value), language);
    await page.goto(`${fixture.base}/?attachmentLocale=${language}#conn-vk/manual`);
    const panel = page.locator('[data-vk-attachments]');
    await panel.getByRole('heading', { name: words.title, exact: true }).waitFor();
    await panel.locator('[data-vk-attachment]').first().waitFor();
    if (!(await panel.innerText()).includes(words.hint) || !(await panel.innerText()).includes(words.enabled)) {
      throw Error(`Missing translated collection controls: ${language}`);
    }
    const enabled = panel.locator('[data-action=vk-attachments-enabled]');
    await ready();
    const previous = await enabled.isChecked();
    const changing = page.waitForResponse((response) => response.url().endsWith('/api/vk/attachments') && response.request().method() === 'POST');
    await enabled.click();
    if ((await changing).status() !== 200) {
      throw Error('Collection configuration was not acknowledged');
    }
    await page.waitForFunction((checked) => {
      const input = document.querySelector('[data-action=vk-attachments-enabled]');
      return input && !input.disabled && input.checked === checked;
    }, !previous);
    await page.reload();
    await ready();
    if ((await enabled.isChecked()) === previous || await panel.locator('[data-vk-attachment]').count() !== 3) {
      throw Error('Acknowledged configuration or saved metadata lost on reload');
    }
    const photo = panel.locator('[data-vk-attachment="attachment:vk:photo:41:11"]');
    await photo.locator('summary').click();
    const text = await photo.locator('pre').textContent();
    if (!text.includes('First <script>fixture</script> 元数据') || await photo.locator('script').count()) {
      throw Error('First metadata must remain literal text');
    }
    await page.setViewportSize({ width: 390, height: 844 });
    await photo.scrollIntoViewIfNeeded();
    if (!(await page.evaluate(() => document.documentElement.scrollWidth <= globalThis.innerWidth))) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({ path: `${fixture.root}/docs/screenshots/issue-56-vk-attachments/mcp-${language}-phone.png` });
    result.push({ language, translated: true, retainedRecords: 3, savedChoiceRetained: true, literalMetadata: true });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:43559","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"Received VK attachments","hint":"Keep the first metadata for each incoming attachment. Media stays with the message; files are not downloaded here. Pausing keeps saved records. Attachments without a stable provider ID are skipped.","enabled":"Collect incoming attachment metadata"},"ru":{"title":"Полученные вложения ВКонтакте","hint":"Сохранять первые метаданные каждого входящего вложения. Медиа остаются в сообщениях; файлы здесь не скачиваются. Пауза сохраняет уже собранные записи. Вложения без постоянного ID провайдера пропускаются.","enabled":"Собирать метаданные входящих вложений"},"hi":{"title":"प्राप्त VK अटैचमेंट","hint":"हर आने वाले अटैचमेंट का पहला मेटाडेटा रखें। मीडिया संदेश में रहता है; यहाँ फ़ाइलें डाउनलोड नहीं होतीं। संग्रह रोकने पर सहेजे रिकॉर्ड बने रहते हैं। स्थिर प्रदाता ID के बिना अटैचमेंट छोड़ दिए जाते हैं।","enabled":"आने वाले अटैचमेंट का मेटाडेटा एकत्र करें"},"zh":{"title":"收到的 VK 附件","hint":"为每个收到的附件保留首次元数据。媒体仍在消息中；此处不下载文件。暂停收集会保留已保存记录。没有稳定服务商 ID 的附件将被跳过。","enabled":"收集收到的附件元数据"}}})