// Locale catalogue (issue #18). Single source of truth for the
// dictionaries the SPA bundles plus the metadata the language switcher
// renders (label in the locale's own script + writing direction).
//
// `en` is the source language; every other dictionary mirrors its key
// set exactly. The parity test in js/tests/i18n.test.js fails the
// build if a dictionary drifts.
//
// `dir` is `'ltr'` for all four current locales but is read by
// applyLocale() so adding `ar` / `he` / `fa` later is a one-line
// change instead of a SPA-wide CSS audit.

import { en } from './en.js';
import { ru } from './ru.js';
import { zh } from './zh.js';
import { hi } from './hi.js';
import { diagnosticsLocale } from './diagnostics.js';
import { vkTokenLocale } from './vk-token.js';
import { runnerLocale } from './runner.js';
import { cvExperienceLocale } from './cv-experience.js';
import { linkedinExperienceLocale } from './cv-linkedin-experience.js';
import { experienceFilesLocale } from './cv-experience-files.js';
import { experiencePlanLocale } from './cv-experience-plan.js';
import { formalReportLocale } from './cv-formal-report.js';

export const dictionaries = Object.fromEntries(
  Object.entries({ en, ru, zh, hi }).map(([language, dictionary]) => [
    language,
    {
      ...dictionary,
      ...diagnosticsLocale(language),
      ...vkTokenLocale(language),
      ...runnerLocale(language),
      ...cvExperienceLocale(language),
      ...experienceFilesLocale(language),
      ...linkedinExperienceLocale(language),
      ...experiencePlanLocale(language),
      ...formalReportLocale(language),
    },
  ])
);

export const availableLocales = [
  { id: 'en', label: 'English', dir: 'ltr' },
  { id: 'ru', label: 'Русский', dir: 'ltr' },
  { id: 'zh', label: '中文', dir: 'ltr' },
  { id: 'hi', label: 'हिन्दी', dir: 'ltr' },
];

export const DEFAULT_LOCALE = 'en';
