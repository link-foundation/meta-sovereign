export const hiGratitude = {
  'automations.presets.gratitude.name': 'आभार का उत्तर दें',
  'automations.presets.gratitude.description':
    'निजी VK संदेश या स्टिकर में मिले आभार का उत्तर जाँचें; स्टिकर या अपने औपचारिक और अनौपचारिक पाठ चुनें।',
  'questions.kind.reply-gratitude': 'आभार का उत्तर दें',
  'gratitude.recognizer': 'आने वाले संदेश की पहचान',
  'gratitude.recognizer.pattern': 'आपका नियमित व्यंजक',
  'gratitude.recognizer.gratitude': 'आभार वाक्य और VK स्टिकर',
  'gratitude.hint':
    'केवल निजी VK चैट में अनुत्तरित आभार मान्य है। आने वाले और निर्धारित कार्य समीक्षा के लिए ड्राफ़्ट बनाते हैं।',
  'gratitude.preferSticker': 'VK स्टिकर से उत्तर दें',
  'gratitude.stickers': 'उत्तर स्टिकर की ID',
  'gratitude.stickersHint':
    'अल्पविराम से अलग VK ID। नीचे के पाठ का उपयोग करने के लिए स्टिकर बंद करें। API पहुँच और स्टिकर पैक आवश्यक हैं।',
  'gratitude.preview': 'VK स्टिकर {id}',
  'gratitude.editHint':
    'इस स्टिकर के बजाय भेजने के लिए पाठ लिखें। संबोधन बदलने से भी आपका पाठ विकल्प चुना जाता है।',
  'automations.reason.gratitude-incoming-required':
    'अंतिम संदेश आने वाला आभार होना चाहिए।',
  'automations.reason.gratitude-message-required':
    'पूरे संदेश को आभार के रूप में नहीं पहचाना गया।',
  'automations.presets.identity.name': 'पहचान के प्रश्नों का उत्तर',
  'automations.presets.identity.description':
    'व्यक्तिगत VK “आप कौन हैं?” प्रश्न का औपचारिक या अनौपचारिक उत्तर जाँचें। संबोधन आने वाले इतिहास से सीखा जाता है।',
  'gratitude.recognizer.identity': 'पहचान का प्रश्न: आप कौन हैं?',
  'automations.reason.identity-incoming-required':
    'नवीनतम संदेश व्यक्तिगत VK पहचान का आने वाला प्रश्न होना चाहिए।',
  'automations.reason.identity-question-required':
    'पूरा संदेश पहचान के प्रश्न के रूप में नहीं पहचाना गया।',
  'chat.about.identity': 'पहचान के प्रश्न में संबोधन {when}',
  'questions.kind.reply-identity': 'पहचान के प्रश्नों का उत्तर',
};
