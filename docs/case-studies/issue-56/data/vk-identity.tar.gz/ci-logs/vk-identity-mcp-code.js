async (page) => (async (page, fixture) => {
  const exceptions = [];
  page.on('pageerror', (error) => exceptions.push(error.message));
  await page.addInitScript(([key, value]) => globalThis.localStorage.setItem(key, value), fixture.tutorial);
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate((language) => globalThis.localStorage.setItem('metaSovereignLocale', language), language);
    await page.goto(`${fixture.base}/?identity=${language}#/automation`);
    await page.locator('[data-automation="automation:identity"]').click();
    const form = page.locator('.automation-editor');
    const action = form.locator('[name="actionKind"]');
    if ((await action.locator('option:checked').innerText()) !== words.kind) throw Error(`Untranslated ${language} action`);
    if ((await form.locator('[name="incomingRecognizer"]').inputValue()) !== 'identity') throw Error('Lost identity recognizer');
    if (language === 'en') {
      await form.locator('[name="informal"]').fill(fixture.informal);
      await form.locator('[name="formal"]').fill(fixture.formal);
      const put = page.waitForResponse((r) => r.url().endsWith('/api/automations') && r.request().method() === 'PUT');
      await form.getByRole('button', { name: words.save, exact: true }).click();
      if ((await put).status() !== 200) throw Error('Identity save failed');
      await page.reload();
      await page.locator('[data-automation="automation:identity"]').click();
    }
    if ((await form.locator('[name="formal"]').inputValue()) !== fixture.formal ||
        (await form.locator('[name="informal"]').inputValue()) !== fixture.informal) throw Error('Identity variants changed');
    const request = page.waitForResponse((r) => r.url().endsWith('/api/automations/plan'));
    await form.getByRole('button', { name: words.preview, exact: true }).click();
    if ((await request).status() !== 200) throw Error('Identity preview failed');
    const replies = await page.locator('.automation-plan blockquote').allTextContents();
    if (JSON.stringify(replies) !== JSON.stringify([fixture.informal, fixture.formal])) throw Error(`Unexpected private replies: ${replies}`);
    if (language === 'en') {
      await page.setViewportSize({ width: 390, height: 844 });
      await action.scrollIntoViewIfNeeded();
      if (!(await page.evaluate(() => document.documentElement.scrollWidth <= globalThis.innerWidth))) throw Error('Identity phone overflow');
      await page.screenshot({ path: `${fixture.root}/docs/screenshots/issue-56-vk-identity/mcp-phone.png` });
      await page.setViewportSize({ width: 1180, height: 950 });
    }
    result.push({ language, translated: true, retainedVariants: true, privateReplies: 2 });
  }
  if (exceptions.length) throw Error(JSON.stringify(exceptions));
  return { result, exceptions, liveProvider: false };
})(page, {"base":"http://127.0.0.1:37689","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","informal":"Informal identity \u003cMCP\u003e & 👋","formal":"Formal identity \u003cMCP\u003e & 👋","tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"kind":"Reply to identity questions","save":"Save","preview":"Preview"},"ru":{"kind":"Ответить на вопрос «кто ты/вы?»","save":"Сохранить","preview":"Предпросмотр"},"hi":{"kind":"पहचान के प्रश्नों का उत्तर","save":"सहेजें","preview":"पूर्वावलोकन"},"zh":{"kind":"回复身份问题","save":"保存","preview":"预览"}}})