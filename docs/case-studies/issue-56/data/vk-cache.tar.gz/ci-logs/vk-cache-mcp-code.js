async (page) => {
  const session = await page.context().newCDPSession(page);
  try {
    await session.send('Network.enable');
    await session.send('Network.setCacheDisabled', { cacheDisabled: true });
    return await (async (page) => (async (page, fixture, check) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      language
    );
    await page.goto(`${fixture.base}/?vkLocale=${language}#conn-vk/manual`);
    const panel = page.locator(`[data-${fixture.feature}]`);
    const ready = () =>
      page.waitForFunction((feature) => {
        const input = document.querySelector(feature);
        return input && !input.disabled;
      }, `[data-${fixture.feature}] ${fixture.readySelector}`);
    // A mounted heading and an enabled control distinguish loading from absence.
    await panel
      .getByRole('heading', { name: words.title, exact: true })
      .waitFor();
    await ready();
    for (const key of fixture.keys) {
      if (!(await panel.innerText()).includes(words[key])) {
        throw Error(`Missing ${language}.${key}`);
      }
    }
    const { focus, ...checked } = await check(page, {
      panel,
      words,
      ready,
      feature: fixture.feature,
      fixture,
      action: async (name) => {
        await panel.locator(`[data-action=${fixture.feature}-${name}]`).click();
        await ready();
      },
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await panel.locator(focus).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-${fixture.evidenceName}/mcp-${language}-phone.png`,
    });
    result.push({ language, translated: true, ...checked });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:34283","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","feature":"vk-cache","evidenceName":"vk-cache","readySelector":"input[data-cache-field=accountId]","exportRoot":"/tmp/ms-vk-cache-T1NhBC","keys":["hint","accountId","peerId","exportHint"],"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"VK history and metadata cache","hint":"Inspect saved data without contacting VK. Refresh reads only the selected account and peer, at most 200 records per page. Partial history resumes from its saved offset; Restart reads a new snapshot. Cache age does not prove current provider state.","accountId":"VK account ID","peerId":"Peer ID","exportHint":"Export saved history, including partial or expired coverage, to a new folder on the server computer. Linked Markdown and full native JSON parts contain at most 1500 lines. Existing folders are refused. Media is referenced in JSON, not downloaded."},"ru":{"title":"История VK и кэш метаданных","hint":"Просмотр сохранённых данных не обращается к VK. Загрузка читает только выбранный аккаунт и диалог, до 200 записей на страницу. Неполная история продолжается с сохранённого смещения; перезапуск создаёт новый снимок. Возраст кэша не подтверждает текущее состояние VK.","accountId":"ID аккаунта VK","peerId":"ID диалога","exportHint":"Экспорт сохранённой истории, включая неполные и устаревшие данные, в новую папку на компьютере сервера. Связанные части Markdown и полного исходного JSON содержат до 1500 строк. Существующие папки отклоняются. Медиа указаны в JSON и не скачиваются."},"hi":{"title":"VK इतिहास और मेटाडेटा कैश","hint":"VK से संपर्क किए बिना सहेजा डेटा देखें। लोड केवल चुने खाते और संवाद को पढ़ता है, हर पृष्ठ में अधिकतम 200 रिकॉर्ड। अधूरा इतिहास सहेजे ऑफ़सेट से आगे बढ़ता है; फिर शुरू करने से नया स्नैपशॉट बनता है। कैश की उम्र VK की वर्तमान स्थिति का प्रमाण नहीं है।","accountId":"VK खाता ID","peerId":"संवाद ID","exportHint":"अधूरे या पुराने कैश सहित सहेजा इतिहास सर्वर कंप्यूटर के नए फ़ोल्डर में निर्यात करें। जुड़े Markdown और पूर्ण मूल JSON भागों में अधिकतम 1500 पंक्तियाँ हैं। मौजूदा फ़ोल्डर अस्वीकार होंगे। मीडिया JSON में संदर्भित है, डाउनलोड नहीं होता।"},"zh":{"title":"VK 历史与元数据缓存","hint":"查看已保存的数据不会连接 VK。加载仅读取所选账户和会话，每页最多 200 条记录。不完整历史从已保存的偏移量继续；重新开始会创建新快照。缓存时间不能证明 VK 当前状态。","accountId":"VK 账户 ID","peerId":"会话 ID","exportHint":"将已保存的历史（包括不完整或已过期的数据）导出到服务器电脑的新文件夹。相互链接的 Markdown 与完整原始 JSON 分卷最多包含 1500 行。已有文件夹会被拒绝。媒体仅在 JSON 中保留引用，不会下载。"}}}, (async (page, { panel, ready, fixture }) => {
  const action = async (name) => {
    await panel.locator(`[data-cache-action=${name}]`).click();
    await ready();
  };
  await panel.locator('[data-cache-field=accountId]').fill('1');
  await panel.locator('[data-cache-field=peerId]').fill('42');
  await panel.locator('[data-cache-field=maxPages]').fill('1');
  await action('restart');
  await panel.locator('[data-cache-state=partial]').waitFor();
  const language = await page.evaluate(() =>
    globalThis.localStorage.getItem('metaSovereignLocale')
  );
  await panel
    .locator('[data-cache-field=folder]')
    .fill(`${fixture.exportRoot}/mcp-${language}`);
  await action('export');
  const exported = await panel.locator('[data-cache-exported]').innerText();
  if (!exported.trim() || exported.includes('vkCache.')) {
    throw Error('Missing translated export receipt');
  }
  await page.reload();
  await ready();
  await panel.locator('[data-cache-field=accountId]').fill('1');
  await panel.locator('[data-cache-field=peerId]').fill('42');
  await action('inspect');
  await panel.locator('[data-cache-state=partial]').waitFor();
  return {
    focus: '[data-cache-state]',
    partialCacheRetained: true,
    exportReceipt: exported,
    reloadInspection: true,
  };
})))(page);
  } finally {
    await session.detach();
  }
}