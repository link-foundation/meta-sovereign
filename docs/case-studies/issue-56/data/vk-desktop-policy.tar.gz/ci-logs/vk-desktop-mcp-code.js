async (page) => (async (page, fixture, check) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      language
    );
    await page.goto(`${fixture.base}/?vkLocale=${language}#conn-vk/manual`);
    const panel = page.locator(`[data-${fixture.feature}]`);
    const ready = () =>
      page.waitForFunction((feature) => {
        const input = document.querySelector(
          `[data-${feature}] input[type=checkbox]`
        );
        return input && !input.disabled;
      }, fixture.feature);
    // A mounted heading and an enabled control distinguish loading from absence.
    await panel
      .getByRole('heading', { name: words.title, exact: true })
      .waitFor();
    await ready();
    for (const key of fixture.keys) {
      if (!(await panel.innerText()).includes(words[key])) {
        throw Error(`Missing ${language}.${key}`);
      }
    }
    const { focus, ...checked } = await check(page, {
      panel,
      words,
      ready,
      feature: fixture.feature,
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await panel.locator(focus).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-${fixture.evidenceName}/mcp-${language}-phone.png`,
    });
    result.push({ language, translated: true, ...checked });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:44053","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","feature":"vk-friends","evidenceName":"vk-desktop","keys":["acceptancePolicy","desktopHint","plan","run"],"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"VK friend requests","acceptancePolicy":"Incoming acceptance policy","desktopHint":"Desktop mode reserves ten percent of distinct incoming requesters observed by this account, ranked by mutual friends. Repeated reviews do not increase allowance. At or above the threshold only requests with mutual friends qualify. VK’s 10,000-friend hard limit still applies. Priority requests come first and do not spend this allowance; unknown attempts keep their reservation.","plan":"Prepare review","run":"Confirm reviewed friend actions"},"ru":{"title":"Заявки в друзья ВКонтакте","acceptancePolicy":"Правила приёма входящих","desktopHint":"Настольный режим резервирует десять процентов разных входящих заявителей этого аккаунта по числу общих друзей. Повторный просмотр не увеличивает квоту. Начиная с порога допускаются лишь заявки с общими друзьями. Жёсткий предел ВКонтакте — 10 000 друзей. Приоритетные заявки идут первыми и не расходуют квоту; неизвестные попытки сохраняют резерв.","plan":"Подготовить просмотр","run":"Подтвердить просмотренные действия"},"hi":{"title":"VK मित्र अनुरोध","acceptancePolicy":"आने वाले अनुरोध स्वीकारने की नीति","desktopHint":"डेस्कटॉप मोड इस खाते में देखे गए अलग अनुरोधकर्ताओं के दस प्रतिशत को साझा मित्रों के क्रम में सुरक्षित रखता है। दोबारा समीक्षा से कोटा नहीं बढ़ता। सीमा पर या उससे ऊपर केवल साझा मित्रों वाले अनुरोध योग्य हैं। VK की 10,000 मित्रों की कठोर सीमा लागू रहती है। प्राथमिक अनुरोध पहले आते हैं और कोटा नहीं लेते; अज्ञात प्रयास आरक्षण रखते हैं।","plan":"समीक्षा तैयार करें","run":"समीक्षित मित्र कार्रवाइयों की पुष्टि करें"},"zh":{"title":"VK 好友请求","acceptancePolicy":"收到请求的接受规则","desktopHint":"桌面模式按共同好友排序，为此账户观察到的不同请求者保留百分之十的名额。重复审核不会增加名额。达到阈值后仅允许有共同好友的请求。VK 的一万好友硬性上限仍然有效。优先请求先处理且不消耗该名额；结果未知的尝试保留预留名额。","plan":"准备审核","run":"确认已审核的好友操作"}}}, (async (page, { panel, ready }) => {
  const choice = panel.locator('[data-friend-field=acceptancePolicy]');
  await choice.selectOption('desktop-ten-percent');
  await ready();
  for (const [key, value] of [
    ['maxFriends', '1'],
    ['batchSize', '2'],
  ]) {
    await panel.locator(`[data-friend-field=${key}]`).fill(value);
  }
  for (const action of ['save', 'plan', 'run']) {
    await panel.locator(`[data-action=vk-friends-${action}]`).click();
    await ready();
    if (action === 'plan') {
      await panel.locator('[data-friend-quota]').waitFor();
    }
  }
  await page.reload();
  await ready();
  await panel.locator('[data-vk-friends-status=confirmed]').waitFor();
  if ((await choice.inputValue()) !== 'desktop-ten-percent') {
    throw new Error('Desktop choice lost');
  }
  return {
    focus: '[data-friend-quota]',
    reviewed: true,
    acknowledged: true,
    savedChoiceRetained: true,
  };
}))