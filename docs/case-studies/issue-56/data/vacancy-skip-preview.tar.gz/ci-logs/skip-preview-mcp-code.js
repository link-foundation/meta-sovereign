async (page) => (async (originalPage, fixture) =>
  fixture(originalPage, async (tools) => {
    const { page, panel, action, state, owner, confirmed, require } = tools;
    const vacancies = page.locator('[data-vacancies]');
    await vacancies.locator('[data-vacancy-field="query"]').fill('Python');
    await vacancies.locator('[data-vacancy-action="search"]').click();
    await vacancies.locator('[data-vacancy-action="collect"]').first().click();
    await panel.locator('[data-application-missing]').waitFor();
    await panel
      .locator('[data-application-option="autoSelectResumeLanguage"]')
      .uncheck();
    await panel.locator('[data-application-option="testMode"]').check();
    await action('start').click();
    await state('ready');
    await owner('refusal', 'POST');
    await confirmed('read');
    await state('external');
    require((await owner('stats')).skips ===
      null, 'Preview persisted a refusal');
    await action('close').click();
    await state('closed');
    const result = [];
    for (const locale of ['en', 'ru', 'hi', 'zh']) {
      await page.evaluate(
        (value) =>
          globalThis.localStorage.setItem('metaSovereignLocale', value),
        locale
      );
      await page.reload();
      const skips = vacancies.locator('[data-vacancy-skips="jobs"]');
      await skips.locator('[data-vacancy-skip-empty]').waitFor();
      require(!/vacancySkip\./u.test(
        await skips.innerText()
      ), 'Untranslated skip recovery');
      await skips.screenshot({
        path: `docs/screenshots/issue-56-skip-preview/mcp-${locale}.png`,
      });
      result.push({ locale, emptyAfterReload: true, translated: true });
    }
    await page.setViewportSize({ width: 390, height: 1440 });
    require(await page.evaluate(
      () => document.documentElement.scrollWidth <= globalThis.innerWidth
    ), 'Phone overflow');
    await vacancies.locator('[data-vacancy-skips="jobs"]').screenshot({
      path: 'docs/screenshots/issue-56-skip-preview/mcp-phone.png',
    });
    const stats = await owner('stats');
    require(stats.closed &&
      stats.skips === null &&
      stats.clicks === 0 &&
      stats.outcomes.length === 1 &&
      stats.outcomes[0].attempts === 0 &&
      stats.outcomes[0].entries === 0 &&
      stats.errors.length === 0 &&
      tools.errors.length === 0, 'Preview owner did not drain without effects');
    return {
      result,
      previewLedgerUnchanged: true,
      providerEntries: 0,
      providerSubmissions: 0,
      browsersClosed: true,
      phoneFits: true,
      errors: tools.errors,
      liveProvider: false,
    };
  }))(page, async (originalPage, work) => {
  const source = new URL(originalPage.url());
  const control = source.searchParams.get('control');
  const before = source.searchParams.has('expect-parent');
  const context = await originalPage.context().browser().newContext();
  const page = await context.newPage();
  page.setDefaultTimeout(10000);
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  const require = (value, message) => {
    if (!value) {
      throw new Error(message);
    }
  };
  const owner = async (operation, method = 'GET') => {
    const response = await page.request.fetch(`${control}/${operation}`, {
      method,
      headers: { connection: 'close' },
    });
    require(response.ok(), 'Synthetic native fixture refused control');
    return response.json();
  };
  try {
    await page.setViewportSize({ width: 1280, height: 1100 });
    await page.addInitScript(() => {
      if (!globalThis.localStorage.getItem('metaSovereignLocale')) {
        globalThis.localStorage.setItem('metaSovereignLocale', 'en');
      }
      globalThis.localStorage.setItem(
        'metaSovereignTutorial',
        '{"off":true,"v":5}'
      );
    });
    await page.goto(`${source.origin}/#/cv`);
    const panel = page.locator('[data-application-panel]');
    const vacancies = page.locator('[data-vacancies]');
    const action = (name) =>
      panel.locator(`[data-application-action="${name}"]`);
    const state = (name) =>
      panel.locator(`[data-application-state="${name}"]`).waitFor();
    const confirm = () =>
      panel.locator('[data-application-option="confirm"]').check();
    const confirmed = async (name) => {
      await confirm();
      await action(name).click();
      await page.waitForFunction(
        () =>
          !document.querySelector('[data-application-option="confirm"]')
            .checked &&
          !document.querySelector('[data-application-action="read"]').disabled
      );
    };
    const locales = async (attribute, blockedAction) => {
      for (const locale of ['ru', 'hi', 'zh', 'en']) {
        await page.evaluate(
          (value) =>
            globalThis.localStorage.setItem('metaSovereignLocale', value),
          locale
        );
        await page.reload();
        await panel.locator(`[data-application-${attribute}]`).waitFor();
        require(!/\bapplication\.[a-z]/iu.test(
          await panel.innerText()
        ), 'Recovery hint is untranslated');
        require(await action(
          blockedAction
        ).isDisabled(), 'Locale recovery reused confirmation');
      }
    };
    const start = async (settings = async () => {}, entry = 'enter') => {
      await vacancies.locator('[data-vacancy-field="query"]').fill('Python');
      await vacancies.locator('[data-vacancy-action="search"]').click();
      await vacancies
        .locator('[data-vacancy-action="collect"]')
        .first()
        .click();
      await panel.locator('[data-application-missing]').waitFor();
      const languagePolicy = panel.locator(
        '[data-application-option="autoSelectResumeLanguage"]'
      );
      if (await languagePolicy.count()) {
        await languagePolicy.uncheck();
      }
      await settings(panel);
      await action('start').click();
      await state('ready');
      await confirm();
      await action(entry).click();
      await state('review');
    };
    return await work({
      source,
      before,
      page,
      errors,
      require,
      owner,
      panel,
      action,
      state,
      confirm,
      confirmed,
      locales,
      start,
    });
  } finally {
    await context.close();
  }
})
