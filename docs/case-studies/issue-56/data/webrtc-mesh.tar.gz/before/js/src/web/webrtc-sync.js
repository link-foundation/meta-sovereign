/**
 * Browser-side WebRTC sync wiring.
 *
 * Browser stores replicate over a peer-to-peer WebRTC data channel.
 * The server's `/rtc` endpoint relays signaling; application records
 * travel directly between the browser stores (R-J7).
 *
 * Wire-up:
 *   1. Open a browser `WebSocket` to `/rtc?room=<room>` on the
 *      discovered server. The signaling broker fans negotiated Lino messages to
 *      everyone else in the same room.
 *   2. Wrap that WebSocket in a `signalingChannel` so SDP / ICE
 *      messages are typed.
 *   3. Construct `createWebRtcTransport({ initiator: false, ... })` —
 *      both peers start as followers. When a `peer-joined` event
 *      arrives (meaning a *new* peer just entered the room behind
 *      us), we know we're the existing one so we call
 *      `transport.startAsInitiator()` to send the offer. The newcomer
 *      sees the offer first and answers it; no race.
 *   4. Plug the transport into `createPeer(store).connect(transport)`
 *      so every local write fans out over the data channel and
 *      remote writes flow into the local store.
 *
 * The room defaults to `default`; production deployments that want
 * tenant isolation can set it from the URL or a config endpoint.
 *
 * `secret:*` links are filtered by `createPeer` itself — they never
 * traverse this transport (or any sync transport).
 */

// Import from leaf files instead of `sync/index.js` so the browser
// bundle does not pull in `node:net` / `node:http` (re-exported by
// the TCP/WebSocket *server* transports through index.js).
import {
  signalingChannel,
  createWebRtcTransport,
} from '../sync/webrtc-transport.js';
import { createPeer } from '../sync/peer.js';
import { syncWire, syncQueue } from '../sync/wire.js';
import { CURRENT_SCHEMA } from '../storage/migrations/index.js';

const wrapBrowserWebSocket = (ws, wire, onError) => {
  const queue = syncQueue();
  ws.binaryType = 'arraybuffer';
  ws.addEventListener('open', () => {
    if (ws.protocol !== wire.protocol) {
      onError(new Error('signaling sync protocol was not negotiated'));
      ws.close();
      return;
    }
    queue.drain((event) => ws.send(wire.encode(event)));
  });
  ws.addEventListener('close', () => queue.clear());
  ws.addEventListener('error', () =>
    onError(new Error('signaling connection failed'))
  );
  const handlers = new Set();
  ws.addEventListener('message', (event) => {
    let parsed;
    try {
      parsed = wire.decode(event.data);
    } catch (error) {
      onError(error);
      ws.close(1003, 'invalid signaling message');
      return;
    }
    for (const h of handlers) {
      h(parsed);
    }
  });
  return {
    send(msg) {
      const data = wire.encode(msg);
      if (ws.readyState === ws.OPEN) {
        ws.send(data);
      } else if (ws.readyState === ws.CONNECTING) {
        queue.push(msg);
      } else {
        throw new Error('signaling connection is closed');
      }
    },
    onMessage(h) {
      handlers.add(h);
      return () => handlers.delete(h);
    },
  };
};

export const attachWebRtcSync = ({
  store,
  origin,
  capabilities,
  room = 'default',
  RTCPeerConnection = globalThis.RTCPeerConnection,
  WebSocketImpl = globalThis.WebSocket,
  rtcConfig = { iceServers: [] },
  format,
  jsonCompatibility = false,
  onMismatch = () => {},
  onError = (error) =>
    globalThis.console?.warn?.('WebRTC negotiation failed', error),
} = {}) => {
  if (
    capabilities?.webRtcSync === false ||
    !RTCPeerConnection ||
    !WebSocketImpl
  ) {
    return null;
  }
  const wsUrl = (() => {
    const u = new URL(origin);
    u.protocol = u.protocol === 'https:' ? 'wss:' : 'ws:';
    u.pathname = '/rtc';
    u.searchParams.set('room', room);
    return u.toString();
  })();
  const wire = syncWire({ format, jsonCompatibility });
  const ws = new WebSocketImpl(wsUrl, wire.protocol);
  const wsTransport = wrapBrowserWebSocket(ws, wire, onError);
  const signaling = signalingChannel(wsTransport);
  const transport = createWebRtcTransport({
    signaling,
    RTCPeerConnection,
    initiator: false,
    rtcConfig,
    format,
    jsonCompatibility,
    onError,
  });
  // Existing peers (us, until someone else joins) become initiator
  // when the broker says a new peer arrived.
  signaling.on('peer-joined', () => {
    transport.startAsInitiator().catch(onError);
  });
  // A browser and a peer of another data schema exchange nothing (R-Z17).
  const peer = createPeer(store, {
    node: 'web',
    schemaVersion: CURRENT_SCHEMA,
    onMismatch,
  });
  const detach = peer.connect(transport);
  return {
    transport,
    peer,
    close() {
      try {
        detach();
      } catch {
        // ignore
      }
      try {
        transport.close();
      } catch {
        // ignore
      }
      try {
        ws.close();
      } catch {
        // ignore
      }
    },
  };
};
