Both local and remote launch builders pass `--name` to `link-foundation/start`. Current start accepts `--session` / `-s` for the isolation session and rejects unknown wrapper options, so these commands are refused before launching the bot.

Sources checked:
- [bot lifecycle at 8fbf3b7](https://github.com/konard/vk-bot-desktop/blob/8fbf3b7c42fd8e995ef137cab9b9653a7dc9b1a1/src/server/bot-lifecycle.js)
- [SSH installer at the same commit](https://github.com/konard/vk-bot-desktop/blob/8fbf3b7c42fd8e995ef137cab9b9653a7dc9b1a1/src/server/ssh-installer.js)
- [start parser at 3872bd0](https://github.com/link-foundation/start/blob/3872bd031f5b51902e20bd22b84e9d51a59fcc0b/js/src/lib/args-parser.js#L352): the session selector is `--session`; `parseWrapperArgs` rejects unknown flags.

Minimal reproduction with current start installed (no VK token or account needed):

```sh
'$' --isolated screen --name vk-bot-contract --detached -- node -e 'process.exit(0)'
```

The parser rejects `--name` as `Unknown wrapper option: --name`. This report is based on source inspection; I did not install or execute the third-party project in the development environment.

Workaround: use `--session vk-bot-contract` in place of `--name vk-bot-contract`. Suggested change: update both branches of `buildStartCommand`, both generated installer commands and the examples in the lifecycle documentation, and add a contract regression for the documented start interface. Preserve the explicit detached behavior where required. Existing fake-runner tests accept arbitrary arguments and therefore miss this incompatibility.

The same incorrect argument was found while implementing [meta-sovereign PR #57](https://github.com/link-foundation/meta-sovereign/pull/57). A finite admission assertion fails on its parent and passes with the supported flag; local/SSH controller tests now reject unsupported wrapper options before reporting a launch.
