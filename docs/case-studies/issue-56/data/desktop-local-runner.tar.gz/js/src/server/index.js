/**
 * Local web server (R-F4) + universal links HTTP surface (R-F8) + UI (R-F1).
 *
 * Endpoints (full list lives in `routes-derived.js` and `routes-mutating.js`):
 *   GET  /                         -> GitHub Pages redirect (SPA with localUi=true)
 *   GET  /app.js, /app.min.js, /app.css -> optional SPA assets (localUi=true)
 *   GET  /links, /links/:id        -> read links
 *   PUT  /links                    -> upsert
 *   DEL  /links/:id                -> delete
 *   GET  /sources                  -> list message-source adapters
 *   GET  /api/contacts             -> contacts derived from messages
 *   GET  /api/status               -> service identity + store stats + verify diff count
 *   GET  /api/autocomplete?q=&me=  -> outgoing-history-driven completions
 *   GET  /api/suggest?source=&chat=&typed= -> reply-graph autocomplete
 *   GET  /api/audience?q=          -> set-algebra over store filters
 *   GET  /api/facts                -> question-answer pairs per partner
 *   GET  /api/search?q=            -> dice-similarity search
 *   GET  /api/patterns             -> persisted patterns
 *   PUT  /api/patterns             -> upsert pattern link
 *   POST /api/patterns/infer       -> { examples, mode } -> { regex, flags }
 *   GET  /api/graphs               -> persisted automation graphs
 *   PUT  /api/graphs               -> upsert graph
 *   POST /api/graphs/run           -> { id, message, mode } -> plan
 *   GET  /api/replies              -> persisted reply variation groups
 *   PUT  /api/replies              -> upsert reply variation group
 *   GET  /api/profile              -> read profile (R-D5)
 *   PUT  /api/profile              -> upsert + plan cross-network sync
 *   GET  /api/resume               -> read resume (R-D6)
 *   PUT  /api/resume               -> upsert + plan cross-network sync
 *   POST /api/broadcast            -> queue post for outbound networks
 *   POST /api/outreach             -> { query, text, networks, mode } -> plan
 *   /api/automations/*, POST /api/send, /api/typing -> routes-automations.js
 *   /api/message/* (edit, delete, react, read, forward) -> routes-messages.js
 *   /api/passcode/* -> the local passcode and its lock gate (routes-passcode.js)
 *   POST /api/client-log           -> the page's errors, in the log (routes-client-log.js)
 *   /api/people, /api/audiences, /api/lists -> routes-people.js
 *   GET  /api/people/learned?key=  -> what a conversation tells (routes-learned.js)
 *   GET  /api/greetings/*          -> greeting stickers/texts (routes-greetings.js)
 *   POST /api/email/pull           -> local-server email API/protocol proxy
 *   POST /api/email/send           -> local-server email send proxy
 *   GET  /api/email/attachment     -> a mail attachment from the media folder (routes-email.js)
 *   GET  /api/media/<network>/<sha256>[.ext] -> imported archive media (routes-media.js, R-Z15)
 *   POST /api/archive/upload?source=&name= -> import an export file (routes-archive-upload.js)
 *   GET  /api/backups              -> list archives (gated on archiveDir)
 *   POST /api/backups              -> { passphrase?, keep? } -> { file }
 *   POST /api/backups/restore      -> { file, passphrase? } -> { restored }
 *   GET  /api/auto-import          -> browser auto-import status + jobs
 *   POST /api/auto-import          -> { provider } -> job (see routes-auto-import.js)
 *
 * Implemented with Node's built-in `http` module to keep the dependency
 * footprint at zero. The Docker images in `docker/` simply run
 * `node js/bin/meta-sovereign serve`.
 */

import http from 'node:http';
import { validateUiDefaults } from '../configuration/ui-defaults.js';
import path from 'node:path';
import { promises as fs } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { openDualStore, wrapSecretStore } from '../storage/index.js';
import { CURRENT_SCHEMA } from '../storage/migrations/index.js';
import { createRequestGate } from './request-gate.js';
import { createRuntimeLifecycle } from './runtime-lifecycle.js';
import { serverOwnerAttention } from './owner-attention.js';
import { traceShutdown } from './shutdown-trace.js';
import { createVkTokenAcquisition } from '../sources/vk-token-acquisition.js';
import { handleVkToken } from './routes-vk-token.js';
import { listenFailure } from './listen-error.js';
import {
  getSource as getSourceDefault,
  liveOptionsFrom,
  listSources,
} from '../sources/index.js';
import { createTelegramAccount } from '../sources/telegram-account.js';
import { createExtraAccounts } from '../sources/telegram-accounts.js';
import { createExtraRuntime, telegramChats } from './telegram-extras.js';
import { accountScope } from './account-scope.js';
import { bodyFailure, fail, json, text } from './util.js';
import { createCloudAccess } from './cloud-access.js';
import { cloudIndex } from './cloud-pages.js';
import { bindWire, requestWireFailure } from './wire.js';
import { handleDerivedRoutes } from './routes-derived.js';
import { handleMutatingRoutes } from './routes-mutating.js';
import {
  handleCvRoutes,
  handleVacancyRoutes,
  handleTelegramRoutes,
} from './route-modules.js';
import { handleBrowserRoutes } from './routes-browser.js';
import { handleFormRoutes } from './routes-forms.js';
import { createFormReader } from '../forms/reader.js';
import { createLocalAnswerModel } from '../automation/local-answer-model.js';
import { createFormReportWriter } from '../forms/report-file.js';
import { handleGreetingRoutes } from './routes-greetings.js';
import { handleBackupRoutes } from './routes-backup.js';
import { handleSuggestRoutes } from './routes-suggest.js';
import { handleAutomationRoutes } from './routes-automations.js';
import { createFollowDiscovery } from '../follow/chat-discovery.js';
import { handlePeopleRoutes } from './routes-people.js';
import { handleContactsImport } from './routes-contacts-import.js';
import {
  createAutomationRunner,
  createAutomationScheduler,
} from '../automation/runner.js';
import { createDefaultSender } from '../sources/browser-sender.js';
import { createQuestionBrowser } from '../automation/question-browser.js';
import { createAssignmentVacancyReader } from '../assignments/vacancy-reader.js';
import { createAutopilot } from '../automation/autopilot.js';
import { recoverOutbox } from '../automation/outbox.js';
import { backgroundJobs } from './background-jobs.js';
import { handleDeletedRoutes } from './routes-deleted.js';
import { handleVersionRoutes } from './routes-message-versions.js';
import { withMessageVersions } from '../storage/message-versions.js';
import { withCausalWrites } from '../storage/causal-writes.js';
import { handleAudienceSyncRoute } from './audience-sync.js';
import { setTypingFor } from '../sources/live-links.js';
import { createReplyService } from '../replies/reply-service.js';
import { createChatIndex } from './chat-index.js';
import { handleChatRoutes } from './routes-chat.js';
import { handleFeedbackRoutes } from './routes-feedback.js';
import { handleStickerCollections } from './routes-sticker-collections.js';
import { handleVkSendQueue } from './routes-vk-send-queue.js';
import { handleVkAttachments } from './routes-vk-attachments.js';
import { handleVkCache } from './routes-vk-cache.js';
import { createVkCacheRuntime } from './vk-cache-runtime.js';
import { createVkStickerRuntime } from './vk-sticker-runtime.js';
import { handleVkOnline } from './routes-vk-online.js';
import { createVkOnlineJob } from '../automation/vk-online.js';
import { configureAutomationSettings } from '../automation/configured-settings.js';
import { validateAutomationDefaults } from '../configuration/automation-defaults.js';
import { createVkFriendsJob } from '../automation/vk-friends.js';
import { handleVkFriends } from './routes-vk-friends.js';
import { handleVkMaintenance } from './routes-vk-maintenance.js';
import { createVkMaintenanceJob } from '../automation/vk-maintenance.js';
import { createVkCancelledJob } from '../automation/vk-cancelled.js';
import { handleVkCancelled } from './routes-vk-cancelled.js';
import { createVkGreetJob } from '../automation/vk-greet.js';
import { handleVkGreet } from './routes-vk-greet.js';
import { createVkReengageJob } from '../automation/vk-reengage.js';
import { reengageKinds } from '../automation/vk-reengage-settings.js';
import { handleVkReengage } from './routes-vk-reengage.js';
import { createVkWallJob } from '../automation/vk-wall.js';
import { handleVkWall } from './routes-vk-wall.js';
import { createVkBirthdayJob } from '../automation/vk-birthday.js';
import { handleVkBirthday } from './routes-vk-birthday.js';
import { createVkRetentionJob } from '../automation/vk-retention.js';
import { handleVkRetention } from './routes-vk-retention.js';
import { createVkDiscoveryJob } from '../automation/vk-discovery.js';
import { handleVkDiscovery } from './routes-vk-discovery.js';
import { discoveryKinds } from '../automation/vk-discovery-settings.js';
import { maintenanceKinds } from '../automation/vk-maintenance-settings.js';
import { createClinkReplyStore } from '../replies/reply-store-clink.js';
import { handleAutoImportRoutes } from './routes-auto-import.js';
import { handleWhatsAppRoutes } from './routes-whatsapp.js';
import { handleMarketplaceRoutes } from './routes-marketplaces.js';
import { profileDirIn } from '../sources/whatsapp-web-signin.js';
import { handleMessageRoutes } from './routes-messages.js';
import { handleEmailGets } from './routes-email.js';
import { handleMediaGets } from './routes-media.js';
import {
  handleArchiveUpload,
  UPLOAD_TIMEOUT_MS,
} from './routes-archive-upload.js';
import { createAttachmentStore } from './email-attachments.js';
import {
  VK_CAPTCHA_HOSTS,
  VK_IMAGE_HOSTS,
  VK_MEDIA_HOSTS,
  cspSources,
} from '../sources/vk-hosts.js';
import { setAttachmentSink } from '../sources/email.js';
import { handleEventRoutes } from './routes-events.js';
import { createPasscodeLock } from './passcode.js';
import { gateLocked, handlePasscodeRoutes } from './routes-passcode.js';
import { createClientLogRoute } from './routes-client-log.js';
import { createLearnedRoute } from './routes-learned.js';
import { createConversationKnowledge } from './conversation-knowledge.js';
import { createGitHubCheck } from '../sources/github-check.js';
import { handleMetrics } from './metrics.js';
import { jsonLog } from './log.js';
import { createLogJournal } from './log-journal.js';
import { withLoggedSession } from './log-session.js';
import { createLogSettings } from './log-settings.js';
import { handleDiagnostics } from './routes-diagnostics.js';
import { handleRunner } from './routes-runner.js';
import { createRunnerRuntime } from './runner-runtime.js';
import { defaultStoreDir } from '../storage/app-directory.js';
import { listenLocal } from './local-tls.js';
import { handlePullRoutes, pullContext } from './routes-pull.js';
import { createPeer, attachSyncWebSocket } from '../sync/index.js';
import { attachSignaling } from '../sync/webrtc-signaling.js';
import {
  classifyOrigin,
  corsContext,
  handleCors,
  hostAllowed,
  parseAllowedOrigins,
} from './cors.js';
import {
  hostedUiUrl,
  localUiEnabled,
  redirectToHosted,
  serveBeacon,
  serveTrust,
  withHostedOrigin,
} from './hosted-ui.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const webRoot = path.resolve(here, '..', 'web');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.wav': 'audio/wav',
  '.wasm': 'application/wasm',
};

// Conservative Content-Security-Policy. The SPA loads no remote
// resources except VK greeting-sticker previews from https://vk.com
// (issue #35; Telegram thumbnails are proxied through
// /api/greetings/file) and ships no inline scripts/styles: only same-origin SPA
// modules/bundles and app.css. WebSockets connect to the same
// origin (/ws + /rtc); discovery may also attempt 127.0.0.1 / localhost
// on alternate ports. Browser-first provider API calls (JMAP, Gmail,
// Graph, etc.) use HTTPS directly when CORS allows them.
// `frame-src https:` is for a bot's mini app (R-Y168), shown in a sandboxed
// iframe of the bot's own https origin; nothing else may be framed.
export const CSP =
  "default-src 'self'; " +
  "script-src 'self' 'wasm-unsafe-eval'; " +
  "style-src 'self'; " +
  "img-src 'self' data: blob: https://vk.com " +
  // VK's picture CDNs, for photos and stickers in VK chats (R-Z8).
  `${cspSources(VK_IMAGE_HOSTS)} ${cspSources(VK_CAPTCHA_HOSTS)}; ` +
  // Direct VK audio and video files (R-Z20); a VK video page is a link.
  `media-src 'self' ${cspSources(VK_MEDIA_HOSTS)}; ` +
  'frame-src https:; ' +
  "connect-src 'self' https: ws: wss: http://127.0.0.1:* http://localhost:*; " +
  "worker-src 'self'; " +
  "font-src 'self' data:; " +
  "object-src 'none'; " +
  "base-uri 'self'; " +
  "frame-ancestors 'none'";

const SECURITY_HEADERS = {
  'content-security-policy': CSP,
  'x-content-type-options': 'nosniff',
  'referrer-policy': 'no-referrer',
  'x-frame-options': 'DENY',
};

// SPA assets keep their names across releases, so browsers must
// revalidate them (`no-cache`) instead of guessing a lifetime — Safari
// otherwise kept running an old bundle after an update. The ETag makes
// the revalidation a cheap 304 when nothing changed.
const serveStatic = async (req, res, filePath) => {
  try {
    const stat = await fs.stat(filePath);
    const etag = `"${stat.size.toString(16)}-${Math.floor(stat.mtimeMs).toString(16)}"`;
    const headers = { 'cache-control': 'no-cache', etag };
    if (req.headers['if-none-match'] === etag) {
      res.writeHead(304, headers);
      res.end();
      return true;
    }
    const buf = await fs.readFile(filePath);
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      ...headers,
      'content-type': MIME[ext] ?? 'application/octet-stream',
    });
    res.end(buf);
    return true;
  } catch {
    return false;
  }
};

// Browser-safe modules outside js/src/web that the SPA imports directly.
// Each entry maps a URL prefix to the directory under src/ that holds
// the matching file. Only files whose name matches the allow-list
// regex are served, and the resolved path must stay under the mapped
// directory (no `..`).
const SRC_ROOT = path.resolve(here, '..');
const BROWSER_MOUNTS = [
  ['/storage/', path.join(SRC_ROOT, 'storage')],
  ['/handlers/', path.join(SRC_ROOT, 'handlers')],
  ['/sync/', path.join(SRC_ROOT, 'sync')],
];

const handleStatic = async (req, res, p, cloud) => {
  if (req.method !== 'GET') {
    return false;
  }
  if (p === '/' || p === '/index.html') {
    if (cloud) {
      const template = await fs.readFile(
        path.join(webRoot, 'index.html'),
        'utf8'
      );
      text(res, 200, cloudIndex(template, cloud.brand), MIME['.html']);
      return true;
    }
    return serveStatic(req, res, path.join(webRoot, 'index.html'));
  }
  if (
    p === '/notification-chime.wav' ||
    /^\/[a-zA-Z0-9._-]+\.(js|css|svg|wasm)$/.test(p)
  ) {
    return serveStatic(req, res, path.join(webRoot, p.slice(1)));
  }
  for (const [prefix, dir] of BROWSER_MOUNTS) {
    if (!p.startsWith(prefix)) {
      continue;
    }
    const tail = p.slice(prefix.length);
    if (!/^[a-zA-Z0-9._-]+\.js$/.test(tail)) {
      continue;
    }
    const resolved = path.join(dir, tail);
    if (!resolved.startsWith(dir + path.sep) && resolved !== dir) {
      continue;
    }
    return serveStatic(req, res, resolved);
  }
  return false;
};

// The hosted app may use the server; the local copy is optional.
const uiContext = (allowOrigins, uiUrl, localUi) => {
  const hosted = hostedUiUrl(uiUrl);
  const allowed = parseAllowedOrigins(allowOrigins);
  // A hosted copy named by hand may use the server too — unless
  // cross-origin use is off (`--allow-origin=none`).
  const custom = uiUrl ?? process.env.MS_UI_URL;
  return {
    allowOrigins:
      custom && allowed.length > 0
        ? withHostedOrigin(allowed, hosted)
        : allowed,
    uiUrl: hosted,
    localUi: localUiEnabled(localUi),
  };
};

/**
 * CV routes accept an injected browser so tests — and any embedder
 * that already owns a session — never open a second one.
 * @param {{commander?: object, sessionFactory?: Function, artifactDir?: string}} cv
 */
const cvContext = (cv = {}, vacancies) => ({
  vacancyOptions: vacancies,
  cvCommander: cv.commander ?? null,
  cvSessionFactory: cv.sessionFactory ?? null,
  cvArtifactDir: cv.artifactDir ?? null,
  cvExperienceOptions: cv.experience,
  cvExperiencePlanningOptions: cv.experiencePlanning,
  cvFormalReportOptions: cv.formalReports,
});

/**
 * The reply service behind /api/suggest. `replies.clink` (or
 * `MS_REPLY_CLINK=1`) mirrors the reply graph into a link-cli database
 * next to the store.
 */
const replyService = (store, storeDir, replies = {}) => {
  const option = replies.clink ?? process.env.MS_REPLY_CLINK === '1';
  const clink =
    option === true
      ? createClinkReplyStore({ db: path.join(storeDir, 'replies.links') })
      : option || null;
  return createReplyService({ store, self: replies.self ?? [], clink });
};

const vkPolicyJobs = (store, kinds, create, options, log) =>
  Object.fromEntries(
    kinds.map((kind) => [
      kind,
      create({ store, kind, ...options?.[kind], log }),
    ])
  );

const vkAutomationJobs = (store, automations, say) => {
  const providerJob = (create, options) =>
    create({ store, ...options, log: say });
  const vkOnline = providerJob(createVkOnlineJob, automations.vkOnline);
  const vkFriends = providerJob(createVkFriendsJob, automations.vkFriends);
  const vkGreet = providerJob(createVkGreetJob, automations.vkGreet);
  const vkWall = providerJob(createVkWallJob, automations.vkWall);
  const vkBirthday = providerJob(createVkBirthdayJob, automations.vkBirthday);
  const vkRetention = providerJob(
    createVkRetentionJob,
    automations.vkRetention
  );
  const vkReengage = vkPolicyJobs(
    store,
    reengageKinds,
    createVkReengageJob,
    automations.vkReengage,
    say
  );
  const vkCancelled = providerJob(
    createVkCancelledJob,
    automations.vkCancelled
  );
  const vkMaintenance = vkPolicyJobs(
    store,
    maintenanceKinds,
    createVkMaintenanceJob,
    automations.vkMaintenance,
    say
  );
  const vkDiscovery = vkPolicyJobs(
    store,
    discoveryKinds,
    createVkDiscoveryJob,
    automations.vkDiscovery,
    say
  );
  const ownedVkJobs = [
    vkOnline,
    vkFriends,
    vkCancelled,
    vkGreet,
    vkWall,
    vkBirthday,
    vkRetention,
    ...Object.values(vkReengage),
    ...Object.values(vkMaintenance),
    ...Object.values(vkDiscovery),
  ];
  return {
    vkOnline,
    vkFriends,
    vkCancelled,
    vkGreet,
    vkReengage,
    vkWall,
    vkBirthday,
    vkRetention,
    vkMaintenance,
    vkDiscovery,
    ownedVkJobs,
  };
};

/**
 * Sending, typing and automations. `automations.send` and `.setTyping`
 * replace the adapters (tests); by default a message goes through the
 * network's API and falls back to its official web UI. The scheduler
 * fires schedule and incoming triggers unless `scheduler: false`.
 */
const automationContext = (
  store,
  automations = {},
  log = null,
  getSource = getSourceDefault,
  later = []
) => {
  const say = (event) => log?.(event);
  // The saved connection's token and ids, so the API is really tried
  // before the web app.
  const optionsFor = (source) =>
    liveOptionsFrom(store, source).catch(() => ({}));
  const send =
    automations.send ??
    createDefaultSender({
      store,
      getSource,
      options: automations.options,
      optionsFor,
      browser:
        automations.browser === false
          ? false
          : { store, ...automations.browser },
      log: say,
    });
  const setTyping =
    automations.setTyping ??
    (async ({ source, chat, cancel }) =>
      setTypingFor(getSource, {
        source,
        chat,
        cancel,
        options: await optionsFor(source),
      }).catch((error) => ({
        supported: false,
        source,
        error: error.message,
      })));
  const self = (automations.self ?? []).map(String);
  const runner = createAutomationRunner({
    store,
    send,
    setTyping,
    markRead:
      automations.markRead ??
      (async ({ chat, id }) =>
        getSource('vk').live.markRead({ chat, id }, await optionsFor('vk'))),
    resolveAudience: automations.resolveAudience,
    self,
    log: say,
    modelRunner: automations.modelRunner,
    vkQueue: automations.vkQueue,
  });
  const scheduler = createAutomationScheduler({
    store,
    runner,
    isSelf: (sender) => sender === 'me' || self.includes(String(sender)),
    tickMs: automations.tickMs,
    log: say,
  });
  const autopilot = createAutopilot({ store, runner, log: say });
  const {
    vkOnline,
    vkFriends,
    vkCancelled,
    vkGreet,
    vkReengage,
    vkWall,
    vkBirthday,
    vkRetention,
    vkMaintenance,
    vkDiscovery,
    ownedVkJobs,
  } = vkAutomationJobs(store, automations, say);
  // A send the last run never finished may have gone out: it becomes
  // `unknown` and is never retried by itself (R-Z3).
  const recover = () =>
    recoverOutbox(store).catch((error) =>
      say({
        level: 'warn',
        event: 'outbox_recover_failed',
        error: error.message,
      })
    );
  const recovered = automations.deferRecovery ? null : recover();
  if (automations.scheduler !== false) {
    // Started once the port is really ours (R-Z1): a second `serve` on a
    // busy port must not run automation on the same store.
    later.push(() => {
      scheduler.start();
      ownedVkJobs.forEach((job) => job.start());
      // An autopilot left on stays paused after a restart until the user
      // resumes it (or it was set to resume on start) (R-Z3).
      (recovered ?? recover())
        .then(() => autopilot.resume())
        .catch((error) =>
          say({
            level: 'warn',
            event: 'autopilot_resume_failed',
            error: error.message,
          })
        );
    });
  }
  const questionBrowser = createQuestionBrowser({
    store,
    send,
    runner: automations.modelRunner,
    readVacancy:
      automations.readVacancy ?? createAssignmentVacancyReader({ store }),
    log: say,
  });
  return {
    send,
    setTyping,
    automations: { runner, scheduler, autopilot },
    vkOnline,
    vkFriends,
    vkCancelled,
    vkGreet,
    vkReengage,
    vkWall,
    vkBirthday,
    vkRetention,
    vkMaintenance,
    vkDiscovery,
    vkOnlineScheduled: automations.scheduler !== false,
    questionBrowser,
    closeAutomations: async () => {
      const stoppedAutopilots = autopilot.stopAll();
      // Signal every owner before awaiting any held provider operation.
      await Promise.allSettled([
        traceShutdown('autopilots', stoppedAutopilots),
        traceShutdown('scheduler', scheduler.stop()),
        traceShutdown('automationRunner', runner.close()),
        ...ownedVkJobs.map((job, index) =>
          traceShutdown(`vkJob:${index}`, job.stop())
        ),
      ]);
      await traceShutdown('questionBrowser', questionBrowser.close());
      await traceShutdown('browserSender', send.close?.());
    },
  };
};

/**
 * Greeting routes accept injected sources (and a sleep) so tests send
 * nothing to a real network.
 * @param {{resolveSource?: Function, sleep?: Function}} greetings
 */
// Whether GitHub accounts link back (R-Y53): the given one, or GitHub's.
const githubCheckOf = (store, log, given) =>
  given ?? createGitHubCheck({ store, log });

// Pictures shown in Chat are kept next to the store.
const mediaDirOf = (storeDir) =>
  storeDir ? path.join(storeDir, 'media', 'telegram') : null;

// Mail (R-Z5): where attachments are kept next to the store, and the
// periodic pull of a connected mailbox (`emailPoll: false` turns it off).
const emailContext = (storeDir) => {
  const emailFiles = storeDir
    ? createAttachmentStore(path.join(storeDir, 'media', 'email'))
    : null;
  setAttachmentSink(emailFiles ? (bytes) => emailFiles.save(bytes) : null);
  return { emailFiles };
};

// Listen (with HTTPS beside HTTP when asked, ./local-tls.js) and track
// the front server's sockets as well, so close() ends them all.
const listenTracked = async (server, sockets, options) => {
  const { listener, tls } = await listenLocal(server, options);
  if (listener === server) {
    return { listener, tls, closeFront: () => {} };
  }
  listener.on('connection', (socket) => {
    sockets.add(socket);
    socket.on('close', () => sockets.delete(socket));
  });
  return { listener, tls, closeFront: () => listener.close() };
};
/**
 * The connected Telegram account (sync, history, sending). Tests that
 * inject a fake login (`telegramMtproto`/`telegramCreds`) get no real
 * account unless they pass one, so nothing ever dials Telegram.
 */
const telegramAccountFor = (store, log, options, later = []) => {
  if (options.telegramAccount !== undefined) {
    return options.telegramAccount || null;
  }
  if (options.telegramMtproto || options.telegramCreds) {
    return null;
  }
  const account = createTelegramAccount({
    store,
    log: (e) => log?.(e),
    chats: options.chats,
    mediaDir: options.mediaDir ?? null,
  });
  later.push(() => account.start());
  return account;
};

// The extra accounts' live side (R-Y198): lazy, it dials nothing until an
// extra account exists in the store and is asked for. None without an
// account 1.
// R-Y202: each signed-in extra account also runs on its own store, in a
// subdirectory of the store dir (a memory store when the server was given
// a store of its own, as tests do, so nothing is made on disk).
const telegramContext = (store, log, account, extra = {}, later = []) => {
  const say = (e) => log?.(e);
  const runtime = account
    ? createExtraRuntime({
        home: store,
        storeDir: extra.providedStore ? null : extra.storeDir,
        openStore: extra.telegramExtraStore ?? null,
        build: extra.telegramExtraBuild ?? undefined,
        log: say,
      })
    : null;
  // Signed-in extra accounts start with the server.
  later.push(() => runtime?.startAll().catch(() => {}));
  return {
    telegramAccount: account,
    telegramStore: store,
    telegramAccounts: account ? createExtraAccounts({ store, log: say }) : null,
    telegramExtras: runtime,
  };
};

// `telegram` sends and types through the connected account; every other
// network keeps its adapter.
const accountSources = (account) => (name) => {
  const adapter = getSourceDefault(name);
  return name === 'telegram' && account && adapter
    ? { ...adapter, live: { ...adapter.live, ...account.live } }
    : adapter;
};

const greetingContext = (greetings = {}) => ({
  greetingSources: greetings.resolveSource ?? null,
  greetingSleep: greetings.sleep ?? null,
  greetingRandom: greetings.random ?? null,
});

const applySecurityHeaders = (res, cloud) => {
  for (const [k, v] of Object.entries(SECURITY_HEADERS)) {
    if (!res.hasHeader(k)) {
      res.setHeader(k, v);
    }
  }
  if (cloud) {
    res.setHeader(
      'content-security-policy',
      `${CSP.replace(
        'ws: wss: http://127.0.0.1:* http://localhost:*',
        `wss://${cloud.host}`
      )}; form-action 'self'`
    );
  }
};

// The app's own files, or — with the local copy off — the way to the
// hosted one (R-Y59).
const handlePage = (req, res, p, ctx) =>
  ctx.cloud
    ? handleStatic(req, res, p, ctx.cloud)
    : serveBeacon(req, res, p, ctx) ||
      serveTrust(req, res, p, ctx) ||
      (ctx.localUi
        ? handleStatic(req, res, p)
        : redirectToHosted(req, res, p, ctx.uiUrl));

// Same rule as HTTP: no sockets for pages on other websites, none while
// locked (R-Y183).
// Nor for a Host that is not this server's own (DNS rebinding, R-Z1).
const localSocketAllowed = (ctx, req) =>
  hostAllowed(req, ctx.port) &&
  classifyOrigin(req, ctx.allowOrigins) !== 'denied' &&
  (!ctx.tls ||
    req.socket?.encrypted ||
    classifyOrigin(req, ctx.allowOrigins) === 'allowed');

const socketAllowed = (ctx) => (req) =>
  !ctx.passcode.locked() &&
  (ctx.cloud
    ? ctx.cloud.socketAuthorized.has(req)
    : localSocketAllowed(ctx, req));

// With TLS enabled, direct local access uses the trusted certificate.
// The public bootstrap routes stay usable before trust; an allow-listed
// hosted page may still use HTTP where its browser supports loopback.
const redirectLocalTls = (req, res, url, ctx) => {
  if (
    !ctx.tls ||
    req.socket?.encrypted ||
    classifyOrigin(req, ctx.allowOrigins) === 'allowed'
  ) {
    return false;
  }
  const p = url.pathname;
  if (
    p === '/trust' ||
    p === '/api/beacon.svg' ||
    (!ctx.localUi && (p === '/' || p === '/index.html'))
  ) {
    return false;
  }
  res.writeHead(307, {
    location: `https://${req.headers.host}${url.pathname}${url.search}`,
    'content-length': '0',
  });
  res.end();
  return true;
};

// The local passcode (R-Y183): its own routes, then the gate that refuses
// everything else while the server is locked.
const passcodeHandled = async (req, res, p, ctx) =>
  (await handlePasscodeRoutes(req, res, p, ctx)) || gateLocked(res, p, ctx);

const handlePageOrLock = async (req, res, p, ctx) =>
  (await handlePage(req, res, p, ctx)) || passcodeHandled(req, res, p, ctx);

const deviceOnlyRoutes = [
  '/api/runner',
  '/api/browser',
  '/api/vk/token',
  '/api/vacancies',
  '/api/forms/read',
  '/api/forms/sessions',
];

const requiresDevice = (p) =>
  deviceOnlyRoutes.some((route) => p === route || p.startsWith(`${route}/`)) ||
  p.startsWith('/api/automations/answers/browser/') ||
  p.startsWith('/api/cv/experience/linkedin-') ||
  p.startsWith('/api/cv/experience/hh-about-') ||
  p.startsWith('/api/cv/experience/auto-');

const route = async (store, req, res, ctx) => {
  applySecurityHeaders(res, ctx.cloud);
  if (!ctx.cloud) {
    if (!hostAllowed(req, ctx.port)) {
      return fail(res, 421, 'bad-host', 'unexpected Host header');
    }
    if (handleCors(req, res, ctx.allowOrigins)) {
      return;
    }
  }
  const url = new URL(req.url, 'http://localhost');
  const p = url.pathname;
  if (ctx.cloud && !(await ctx.cloud.allowHttp(req, res, p))) {
    return;
  }
  if (redirectLocalTls(req, res, url, ctx)) {
    return;
  }
  const wireFailure = requestWireFailure(req);
  if (wireFailure) {
    return fail(res, ...wireFailure);
  }
  if (await handlePageOrLock(req, res, p, ctx)) {
    return;
  }
  if (ctx.cloud && requiresDevice(p)) {
    return fail(
      res,
      501,
      'local-device-only',
      'This operation runs on your own device'
    );
  }
  // A request for an extra Telegram account runs on that account's own
  // store and service; none for account 1 (R-Y202).
  const scope = await accountScope(req, url, p, ctx);
  if (scope.refuse) {
    return json(res, scope.refuse[0], scope.refuse[1]);
  }
  return routeOn(scope.store ?? store, req, res, scope.ctx ?? ctx, url, p);
};

const routeOn = async (store, req, res, ctx, url, p) => {
  if (p === '/sources' && req.method === 'GET') {
    return json(res, 200, listSources());
  }
  if (await handleMetrics(store, req, res, p, ctx)) {
    return;
  }
  if (await handleCvRoutes(store, req, res, p, url, ctx)) {
    return;
  }
  if (await handleVacancyRoutes(store, req, res, p, ctx)) {
    return;
  }
  if (await handleSuggestRoutes(req, res, p, url, ctx)) {
    return;
  }
  if (await handleAutomationRoutes(store, req, res, p, url, ctx)) {
    return;
  }
  if (await handlePeopleRoutes(store, req, res, p, url)) {
    return;
  }
  if (await handleStickerCollections(store, req, res, p, url, ctx)) {
    return;
  }
  if (await handleGreetingRoutes(store, req, res, p, url, ctx)) {
    return;
  }
  if (await handleMutatingRoutes(store, req, res, p, url, ctx)) {
    return;
  }
  if (
    await handleBackupRoutes(store, req, res, p, ctx.archiveDir, {
      fallbackPassphrase: ctx.secretPassphrase,
      recovery: ctx.recovery,
    })
  ) {
    return;
  }
  for (const handle of [
    () => handleDiagnostics(req, res, p, url, ctx),
    () => handleRunner(req, res, p, ctx),
    () => handleVkToken(req, res, p, ctx),
    () => handleVkAttachments(store, req, res, p, url, ctx),
    () => handleVkSendQueue(store, req, res, p, url, ctx),
    () => handleVkCache(store, req, res, p, url, ctx),
    () => handleVkOnline(store, req, res, p, url, ctx),
    () => handleVkFriends(store, req, res, p, url, ctx),
    () => handleVkCancelled(store, req, res, p, url, ctx),
    () => handleVkGreet(store, req, res, p, url, ctx),
    () => handleVkReengage(store, req, res, p, url, ctx),
    () => handleVkWall(store, req, res, p, url, ctx),
    () => handleVkBirthday(store, req, res, p, url, ctx),
    () => handleVkRetention(store, req, res, p, url, ctx),
    () => handleVkDiscovery(store, req, res, p, url, ctx),
    () => handleVkMaintenance(store, req, res, p, url, ctx),
    () => handleContactsImport(store, req, res, p, ctx),
    () => handleEventRoutes(store, req, res, p, ctx),
    () => handleBrowserRoutes(store, req, res, p, url, ctx),
    () => handleFormRoutes(store, req, res, p, ctx),
    () => ctx.clientLog?.(req, res, p, ctx) ?? false,
    () => handleAutoImportRoutes(store, req, res, p, ctx),
    () => handleWhatsAppRoutes(store, req, res, p, ctx),
    () => handleMarketplaceRoutes(store, req, res, p, ctx),
    () => handleArchiveUpload(store, req, res, p, ctx),
    () => handlePullRoutes(store, req, res, p, ctx),
    () => handleTelegramRoutes(req, res, p, ctx),
    () => handleMessageRoutes(store, req, res, p, url, ctx),
    () => handleEmailGets(store, req, res, p, url, ctx),
    () => handleMediaGets(req, res, p, ctx),
    () => handleDeletedRoutes(store, req, res, p, url, ctx),
    () => handleVersionRoutes(store, req, res, p, url, ctx),
    () => handleAudienceSyncRoute(store, req, res, p, ctx),
    () => handleChatRoutes(req, res, p, url, ctx),
    () => handleFeedbackRoutes(store, req, res, p, url, ctx),
    () => ctx.learned?.(store, req, res, p, url, ctx) ?? false,
    () => handleDerivedRoutes(store, req, res, p, url, ctx),
  ]) {
    if (await handle()) {
      return;
    }
  }
  return fail(res, 404, 'unknown-route', 'unknown route');
};

const initStore = async ({
  providedStore,
  storeDir,
  archiveDir,
  secretPassphrase,
  log,
}) => {
  let store = providedStore;
  let resolvedArchiveDir = archiveDir;
  if (!store) {
    store = await openDualStore(storeDir, {
      // How many lines could not be read, never what they said (R-Z2).
      onCorrupt: ({ count, file, quarantined }) =>
        log?.({
          level: 'warn',
          event: quarantined ? 'store_corrupt_quarantined' : 'store_corrupt',
          count,
          file,
        }),
      onError: (error) =>
        log?.({
          level: 'warn',
          event: 'store_snapshot_failed',
          error: error.message,
        }),
      // A full disk: degraded, recovered, *_skipped (R-Z14).
      onEvent: (event) => log?.(event),
    });
    // The binary snapshot may have missed the last writes (a crash).
    await store.reconcile();
    if (!resolvedArchiveDir) {
      resolvedArchiveDir = path.join(storeDir, 'archives');
      await fs.mkdir(resolvedArchiveDir, { recursive: true });
    }
  }
  // Kept before wrapping: the secret wrapper does not pass `flush` on.
  store = withMessageVersions(withCausalWrites(store));
  const unwrapped = store;
  const flush = async () => {
    await unwrapped.flush?.();
  };
  // An injected store belongs to its caller (including the rolling host).
  const releaseStore = async () => {
    if (!providedStore) {
      await unwrapped.close?.();
    }
  };
  if (secretPassphrase) {
    store = wrapSecretStore({ inner: store, passphrase: secretPassphrase });
  }
  // The unwritten-changes state for /api/health (R-Z14).
  // ... and the data schema it was opened at (R-Z17).
  const storeHealth = () => ({
    ...(unwrapped.health?.() ?? { degraded: false, queuedBytes: 0 }),
    schema: unwrapped.schema ?? null,
  });
  return { store, resolvedArchiveDir, flush, releaseStore, storeHealth };
};

// The HTTP server: each request is logged, and routed (./account-scope.js
// picks the Telegram account it is for).
const createHttpServer = (store, ctx, log) => {
  // A big export uploaded over Wi-Fi takes longer than Node's default 5
  // minutes to arrive (R-Z23); headers still time out at Node's 60 s.
  const dispatch = (req, res) => {
    const start = Date.now();
    const pathname = (req.url ?? '').split('?')[0];
    if (
      /^\/api\/(people|audience|facts|search|autocomplete|greetings\/plan)(\/|$)/.test(
        pathname
      )
    ) {
      log?.({
        level: 'debug',
        event: 'http_analysis_started',
        method: req.method,
        path: pathname,
      });
    }
    res.on('finish', () => {
      log?.({
        event: 'http',
        method: req.method,
        path: (req.url ?? '').split('?')[0],
        status: res.statusCode,
        ...(res.statusCode === 403 ? corsContext(req) : {}),
        duration_ms: Date.now() - start,
      });
    });
    return route(store, req, res, ctx).catch((err) => {
      log?.({
        level: 'error',
        event: 'http_error',
        method: req.method,
        path: (req.url ?? '').split('?')[0],
        error: err.message,
        stack: err.stack ?? null,
      });
      // A body the client sent badly is its own error (400/413); any other
      // failure is told in the log, not to the page (paths, internals).
      const [status, body] = bodyFailure(err) ?? [
        500,
        { ok: false, error: 'internal server error', code: 'internal' },
      ];
      json(res, status, body);
    });
  };
  const gate = createRequestGate(dispatch, ctx.front);
  const server = http.createServer(
    { requestTimeout: UPLOAD_TIMEOUT_MS },
    (req, res) => {
      bindWire(req, res, ctx.jsonCompatibility);
      return gate.handle(req, res);
    }
  );
  server.requestGate = gate;
  server.prependListener('upgrade', (req, socket) => {
    if (
      !gate.authorize(req) ||
      (ctx.cloud && !ctx.cloud.allowUpgrade(req, socket))
    ) {
      socket.destroy();
    }
  });
  return server;
};

// Listen; when the port cannot be had, let go of what was opened (nothing
// background was started) and fail with a message a person can act on.
const listenOrRelease = async (server, sockets, options, release) => {
  try {
    return await listenTracked(server, sockets, options);
  } catch (error) {
    await release();
    throw listenFailure(error, options.port);
  }
};

// The page's live sockets: sync and WebRTC signalling (same rules as HTTP).
const attachSockets = (server, ctx, store, { enableSync, node }) => {
  if (!enableSync) {
    return { wsHandle: null, signaling: null };
  }
  const originAllowed = socketAllowed(ctx);
  const verifyOrigin = (req) =>
    server.requestGate.authorize(req) && originAllowed(req);
  const wsHandle = attachSyncWebSocket(server, {
    path: '/ws',
    verifyOrigin,
    jsonCompatibility: ctx.jsonCompatibility,
  });
  // Peers of another data schema are refused, with a log line (R-Z17).
  createPeer(store, {
    node,
    schemaVersion: CURRENT_SCHEMA,
    hub: true,
    onMismatch: (error) =>
      ctx.log?.({
        level: 'warn',
        event: 'schema_mismatch',
        local: error.local,
        remote: error.remote,
        message: error.message,
      }),
  }).connect(wsHandle.transport);
  const signaling = attachSignaling(server, {
    path: '/rtc',
    verifyOrigin,
    jsonCompatibility: ctx.jsonCompatibility,
  });
  ctx.sync = wsHandle;
  ctx.signaling = signaling;
  return { wsHandle, signaling };
};

// The browser sender signs in to the web apps in profiles inside the store
// (owner only), the same ones "Sign in to WhatsApp Web" opens (R-Z9).
const withStoreProfiles = (
  automations = {},
  storeDir,
  front,
  providedStore,
  cloud,
  withOpenHhImport
) => ({
  ...automations,
  ...(!providedStore
    ? { vkFriends: { storeDir, ...automations.vkFriends } }
    : {}),
  ...(front?.warming ? { deferRecovery: true } : {}),
  browser:
    cloud || automations.browser === false
      ? false
      : {
          profileDirFor: (source) => profileDirIn(storeDir, source),
          withOpenHhImport,
          ...automations.browser,
        },
});

// The open connections of `server`, so a shutdown can end them.
const trackSockets = (server) => {
  const sockets = new Set();
  server.on('connection', (socket) => {
    sockets.add(socket);
    socket.on('close', () => sockets.delete(socket));
  });
  return sockets;
};

// The automations' part of the context, fed by the Telegram account.
const automationFor = (store, automations, log, telegramAccount, later) => ({
  vkCache: createVkCacheRuntime({ store, ...automations.vkCache }),
  vkStickers: createVkStickerRuntime({ store, ...automations.vkStickers }),
  ...automationContext(
    store,
    automations,
    log,
    accountSources(telegramAccount),
    later
  ),
});

const logFlusher = (store) => store?.flushLog;

const workspaceUiContext = (cloud, allowOrigins, uiUrl, localUi) =>
  cloud
    ? { allowOrigins: [cloud.origin], uiUrl: cloud.origin, localUi: true }
    : uiContext(allowOrigins, uiUrl, localUi);
const applyServerAddress = (ctx, listening, front, activate) => {
  ctx.tls = front?.tls ?? listening.tls;
  ctx.port = front?.port ?? listening.listener.address().port;
  if (!front?.warming) {
    activate();
  }
};

const releaseBeforeListen =
  ({ wsHandle, signaling, lifecycle, flush, releaseStore }) =>
  async () => {
    wsHandle?.close();
    signaling?.close();
    await lifecycle.stopRuntime();
    try {
      await flush().catch(() => {});
    } finally {
      await releaseStore();
    }
  };

const serverForms = (store, options) =>
  createFormReader({
    store,
    reportWriter: createFormReportWriter(),
    ...options,
  });

const modelContext = (
  store,
  forms,
  automations,
  service = createLocalAnswerModel()
) => {
  automations.modelRunner ??= service.draft;
  return {
    answerModel: service,
    forms: serverForms(store, { modelRunner: service.draft, ...forms }),
  };
};

export const startServer = async (options = {}) =>
  withLoggedSession(
    {
      ...options,
      uiDefaults: validateUiDefaults(options.uiDefaults ?? {}),
      automationDefaults: await validateAutomationDefaults(
        options.automationDefaults
      ),
    },
    startServerRuntime
  );

const initLogSettings = async (options, releaseStore) => {
  try {
    return await createLogSettings(options);
  } catch (error) {
    await releaseStore().catch(() => {});
    throw error;
  }
};

const initRuntimeStore = async (
  { automationDefaults, ...options },
  logging
) => {
  const resources = await initStore({ ...options, log: logging.journal.log });
  configureAutomationSettings(resources.store, automationDefaults);
  const diagnostics = await initLogSettings(
    { ...logging, store: resources.store },
    resources.releaseStore
  );
  return { ...resources, diagnostics };
};

const tokenService = (store, passphrase, options) =>
  createVkTokenAcquisition({
    ...options,
    store,
    protectedStorage: Boolean(passphrase),
  });

const cloudAccess = (config) => (config ? createCloudAccess(config) : null);

const startListening = async (
  ctx,
  { store, flush, releaseStore },
  { later, enableHandlers, enableSync, node, providedStore, listen }
) => {
  const server = createHttpServer(store, ctx, ctx.log);
  const sockets = trackSockets(server);
  const lifecycle = createRuntimeLifecycle({
    server,
    ctx,
    store,
    later,
    enableHandlers,
    sockets,
    flush,
    releaseStore,
    flushLog: logFlusher(providedStore),
  });
  const transports = attachSockets(server, ctx, store, { enableSync, node });
  const listening = await listenOrRelease(
    server,
    sockets,
    listen,
    releaseBeforeListen({ ...transports, lifecycle, flush, releaseStore })
  );
  applyServerAddress(ctx, listening, ctx.front, lifecycle.activate);
  return serverHandle(store, ctx, listening, lifecycle, {
    ...transports,
    server,
  });
};

const startServerRuntime = async ({
  port = 0,
  storeDir = defaultStoreDir(),
  archiveDir,
  store: providedStore,
  enableHandlers = true,
  enableSync = true,
  log = process.env.MS_LOG_FORMAT === 'json' ? jsonLog() : null,
  verbose,
  diagnosticsSession,
  runnerSessions,
  node = 'server',
  secretPassphrase = process.env.MS_SECRET_PASSPHRASE ?? null,
  vkToken,
  automationDefaults,
  emailLiveFactory = null,
  emailPoll,
  cv = {},
  vacancies,
  forms,
  answerModel,
  // replies: `{ self?, clink? }` for /api/suggest; automations: `{ send?,
  // setTyping?, resolveAudience?, self?, scheduler?, tickMs? }`.
  replies,
  automations,
  greetings,
  broadcasting,
  allowOrigins,
  follow,
  autoImportLauncher,
  // Tests inject a fake `createSignIns()` and a fake MTProto (no real browsers
  // or network are used).
  autoImportSignIns,
  telegramMtproto,
  telegramCreds,
  // A `createTelegramAccount()` (or `false` for none); see telegramAccountFor.
  telegramAccount: telegramAccountOption,
  // Tests: the extra accounts' stores and services (R-Y202), see
  // ./telegram-extras.js `createExtraRuntime`.
  telegramExtraStore,
  telegramExtraBuild,
  // Tests and demos pass a fake, so GitHub is never asked (R-Y53).
  githubCheck,
  systemContactsReader,
  // The hosted app, and whether this serves its own copy (./hosted-ui.js).
  uiUrl,
  localUi,
  uiDefaults,
  // Legacy JSON is an explicit opt-in. Normal servers speak text/binary LINO.
  jsonCompatibility = process.env.MS_JSON_COMPATIBILITY === '1',
  // HTTPS on the same port for Safari (./local-tls.js, R-Y64); `serve` sets it.
  tls,
  // diskFree: a test fake `(dir) => bytes|null` (R-Z14); backups:
  // `{ intervalHours?, keep? }` for the automatic backup (R-Z7).
  diskFree,
  pulls,
  backups,
  // Private rolling-worker options; the public listener remains in its host.
  front,
  // Cloud workspaces use a proxy for TLS and their own Host and session gate.
  cloud: cloudConfig,
  host,
} = {}) => {
  const cloud = cloudAccess(cloudConfig);
  const logJournal = createLogJournal({ sink: log });
  log = logJournal.log;
  const resources = await initRuntimeStore(
    {
      providedStore,
      storeDir,
      archiveDir,
      secretPassphrase,
      automationDefaults,
    },
    { journal: logJournal, session: diagnosticsSession, verbose }
  );
  const { store, storeHealth, diagnostics } = resources;
  // Services that run in the background start only after the port is ours.
  const later = [];
  automations = withStoreProfiles(
    automations,
    storeDir,
    front,
    providedStore,
    cloud,
    (slot, work) => ctx.autoImport?.withOpenHhImport(slot, work)
  );
  const chatIndex = createChatIndex(store, { log });
  const telegramAccount = telegramAccountFor(
    store,
    log,
    {
      telegramAccount: telegramAccountOption,
      telegramMtproto,
      telegramCreds,
      chats: () => telegramChats(chatIndex),
      mediaDir: mediaDirOf(storeDir),
    },
    later
  );
  const ctx = {
    cloud,
    front,
    jsonCompatibility: jsonCompatibility === true,
    archiveDir: resources.resolvedArchiveDir,
    sync: null,
    signaling: null,
    secretPassphrase,
    emailLiveFactory,
    vkToken: tokenService(store, secretPassphrase, vkToken),
    ...emailContext(storeDir),
    ...workspaceUiContext(cloudConfig, allowOrigins, uiUrl, localUi),
    uiDefaults,
    ...cvContext(cv, vacancies),
    ...modelContext(store, forms, automations, answerModel),
    replies: replyService(store, storeDir, replies),
    ...automationFor(store, automations, log, telegramAccount, later),
    ...greetingContext(greetings),
    broadcasting,
    storeDir,
    followDiscovery: createFollowDiscovery({ store, ...follow }),
    followBacklinkOptions: follow?.backlinks,
    storeHealth,
    systemContactsReader,
    diskFree,
    passcode: createPasscodeLock({ dir: storeDir }),
    log,
    clientLog: createClientLogRoute(),
    logJournal,
    diagnostics,
    diagnosticsSession,
    runnerSessions: createRunnerRuntime(runnerSessions),
    learned: createLearnedRoute(),
    githubCheck: githubCheckOf(store, log, githubCheck),
    autoImport: null,
    autoImportLauncher,
    autoImportSignIns,
    telegramMtproto,
    telegramCreds,
    ...telegramContext(
      store,
      log,
      telegramAccount,
      { providedStore, storeDir, telegramExtraStore, telegramExtraBuild },
      later
    ),
    chatIndex,
    knowledge: createConversationKnowledge({ store, index: chatIndex, log }),
    ...pullContext(store, log, pulls, later, emailPoll),
  };
  Object.assign(ctx, backgroundJobs({ ctx, store, log, later, backups }));
  return startListening(ctx, resources, {
    later,
    enableHandlers,
    enableSync,
    node,
    providedStore,
    listen: { port, storeDir, tls, log, host },
  });
};

const serverHandle = (
  store,
  ctx,
  listening,
  lifecycle,
  { wsHandle, signaling, server }
) => ({
  port: listening.listener.address().port,
  tls: ctx.tls,
  store,
  bus: lifecycle.bus,
  sync: wsHandle,
  signaling,
  archiveDir: ctx.archiveDir,
  allowOrigins: ctx.allowOrigins,
  uiUrl: ctx.uiUrl,
  localUi: ctx.localUi,
  activate: lifecycle.activate,
  drain: server.requestGate.drain,
  passcodeState: () => ctx.passcode.status(),
  storeHealth: ctx.storeHealth,
  ownerAttention: serverOwnerAttention(ctx),
  inheritUnlock: () => ctx.passcode.inheritUnlock(),
  close: (options) => {
    ctx.cloud?.close();
    return lifecycle.close(listening, { wsHandle, signaling }, options);
  },
});
