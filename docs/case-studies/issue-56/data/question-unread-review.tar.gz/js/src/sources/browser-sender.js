/**
 * Send and receive messages through the official web UIs (issue #31,
 * PR #34).
 *
 * The API adapters (`./vk.js`, `./telegram.js`, `./whatsapp.js`) are
 * the first choice, but they are not always usable: a VK community
 * token cannot write to a personal friend, a Telegram bot cannot open a
 * conversation, WhatsApp Cloud needs a business number, and any token
 * can expire. In every one of those cases the person can still send the
 * message by hand in vk.com, web.telegram.org or web.whatsapp.com — so
 * this module does exactly that, through browser-commander, in the
 * persistent profile where the user signed in once.
 *
 * - `WEB_UIS` (./web-uis.js) is the declarative per-network table: chat
 *   URL, composer, send control, message list, chat list, message menu
 *   and logged-in markers.
 * - `createBrowserSender()` drives those pages: `send`, `setTyping`,
 *   `readRecent`, `readChats`, `editMessage`, `deleteMessages`, `react`,
 *   `forwardMessages`, `markRead` (./browser-actions.js) and `close`,
 *   with one lazily opened page per network.
 * - `createFallbackSender()` tries the API first and falls back to the
 *   browser when the API throws (or is not configured).
 * - `createDefaultSender()` wires the source adapters and the browser
 *   together for automations and the chat composer.
 *
 * The browser session itself comes from `../cv/browser.js`, so the
 * optional-dependency story (`browser-commander` + `playwright`,
 * `BrowserUnavailableError`, persistent profiles) is shared with CV runs.
 */

/* global document -- `extractMessages` runs in the page */

import { createHash } from 'node:crypto';
import { setTimeout as sleep } from 'node:timers/promises';

import {
  defaultProfileDir,
  openBrowserSession,
  slotProfileDir,
} from '../cv/browser.js';
import { resolveBrowserPolicy } from '../browser/policy.js';
import { selectorCandidates } from '../cv/runner.js';
import { createAdapterSender } from '../crm/reengage.js';
import { WEB_UIS } from './web-uis.js';
import { createBrowserActions } from './browser-actions.js';
import { createMessageActions } from './message-actions.js';
import { markSendOutcome } from './http.js';
import {
  createBrowserChoiceActions,
  enrichBrowserChoices,
  readBrowserHistory,
} from './browser-choices.js';
import { resolveBrowserChoiceDocument } from './browser-choice-document.js';
import { createBrowserChatScans } from './browser-chat-scan.js';
import { createBrowserTextActions } from './browser-text-reply.js';

const isNumericId = (value) => /^-?\d+$/.test(String(value));

export { WEB_UIS };

/** The user has to sign in once in the persistent browser profile. */
export class BrowserLoginRequiredError extends Error {
  constructor({ source, loginUrl, profileDir }) {
    super(
      `${source}: not signed in to the web UI — open ${loginUrl} in the browser profile ${profileDir} (headless: false) and log in once; the session is kept for later runs`
    );
    this.name = 'BrowserLoginRequiredError';
    this.code = 'login-required';
    this.source = source;
    this.loginUrl = loginUrl;
    this.profileDir = profileDir;
  }
}

/** Both the API and the browser failed; `causes` holds both errors. */
export class SendFallbackError extends AggregateError {
  constructor(causes, message) {
    super(causes, message);
    this.name = 'SendFallbackError';
    this.code = 'send-failed';
    this.causes = causes;
  }
}

const codedError = (message, code) =>
  Object.assign(new Error(message), { code });

const requireTextUi = (ui, code = 'answer-choice-required') => {
  if (ui.documents) {
    throw codedError(
      'Review the current provider answer controls; free-text browser input is unavailable',
      code
    );
  }
  return ui;
};

/** Errors that must never trigger a browser retry. */
export const NO_FALLBACK_CODES = Object.freeze([
  'safe-mode',
  'bad-draft',
  'unknown-delivery', // alias of send-unknown (R-Z1)
]);

// An adapter marks an error `fallback: false` when the message may
// already be out (a connected account): sending it again through the
// browser could post it twice.
// An `ambiguous` error (timeout, reset, 5xx after the request left, see
// `markSendOutcome` in ./http.js) may have been delivered too (R-Z4);
// only a clear "not sent" (auth/4xx, unsupported) falls back.
const defaultShouldFallback = (error) =>
  error?.fallback !== false &&
  error?.ambiguous !== true &&
  !NO_FALLBACK_CODES.includes(error?.code);

/**
 * Page-side extractor for the visible message history. It runs inside
 * the browser through `commander.evaluate`, so it must stay
 * self-contained (no closures over module scope).
 */
export const extractMessages = (spec) => {
  const squash = (value) =>
    String(value ?? '')
      .replace(/\s+/g, ' ')
      .trim();
  const pick = (node, selector, attribute) => {
    if (!selector) {
      return null;
    }
    const found = node.querySelector(selector);
    if (!found) {
      return null;
    }
    return attribute
      ? (found.getAttribute(attribute) ?? null)
      : (found.textContent ?? '');
  };
  const pattern = spec.idPattern ? new RegExp(spec.idPattern) : null;
  const idOf = (node) => {
    const raw = spec.idAttribute ? node.getAttribute(spec.idAttribute) : null;
    const match = raw && pattern ? pattern.exec(raw) : null;
    return match ? match[1] : raw;
  };
  const chatPattern = spec.chatPattern ? new RegExp(spec.chatPattern) : null;
  const chatOf = (node) => {
    const raw = spec.idAttribute ? node.getAttribute(spec.idAttribute) : null;
    const match = raw && chatPattern ? chatPattern.exec(raw) : null;
    return match ? match[1] : null;
  };
  const rows = Array.from(document.querySelectorAll(spec.item));
  return rows.slice(-spec.limit).map((node) => ({
    id: idOf(node),
    ...(chatPattern ? { chat: chatOf(node) } : {}),
    sender: squash(pick(node, spec.sender, spec.senderAttribute)),
    body: String(pick(node, spec.body) ?? '').trim(),
    time: squash(pick(node, spec.time, spec.timeAttribute)) || null,
    timestamp: spec.timestampAttribute
      ? node.getAttribute(spec.timestampAttribute)
      : null,
    outgoing: spec.outgoing ? Boolean(node.matches?.(spec.outgoing)) : false,
  }));
};

/** Keep HH history and choice metadata in one read-only verified snapshot. */
const readCurrentHistory = async (commander, page, ui, target, limit) => {
  if (ui.documents) {
    const document = await resolveBrowserChoiceDocument(
      commander,
      page,
      ui,
      target
    );
    const history = await readBrowserHistory(document, ui, target);
    if (process.env.MS_BROWSER_HISTORY_DEBUG === '1') {
      console.error('[browser-history]', {
        source: ui.id,
        rows: history.length,
        services: history.filter((row) => row.service === true).length,
      });
    }
    return history.slice(-limit);
  }
  const history = await commander.evaluate({
    fn: extractMessages,
    args: [{ ...ui.messages, limit }],
  });
  return enrichBrowserChoices(commander, ui, target, history);
};

/** WhatsApp's `data-pre-plain-text`: "[10:15, 11/10/2026] Anna: ". */
const PRE_PLAIN = /^\[([^\]]+)\]\s*(.*?):?\s*$/;

const toIso = (value) => {
  if (value === null || value === undefined || value === '') {
    return null;
  }
  if (isNumericId(value)) {
    const n = Number(value);
    return new Date(n < 1e12 ? n * 1000 : n).toISOString();
  }
  const parsed = Date.parse(value);
  return Number.isNaN(parsed) ? null : new Date(parsed).toISOString();
};

const shortHash = (value) =>
  createHash('sha1').update(value).digest('hex').slice(0, 12);

/** Turn an extracted row into a message link like the API adapters'. */
const toMessageLink = (source, chat, row) => {
  const pre = PRE_PLAIN.exec(row.sender ?? '');
  const sender = (pre ? pre[2] : row.sender) || (row.outgoing ? 'me' : '');
  const timestamp =
    toIso(row.timestamp) ?? toIso(pre ? pre[1] : row.time) ?? null;
  const key = row.id || shortHash(`${sender}\n${row.body}\n${row.time ?? ''}`);
  return {
    id: `msg:${source}:${chat}:${key}`,
    tokens: ['message', source, chat],
    source,
    chat,
    sender: sender || null,
    body: row.body,
    timestamp,
    outgoing: Boolean(row.outgoing),
    ...(row.service === true ? { service: true } : {}),
    ...(row.strictOptions !== undefined
      ? { strictOptions: row.strictOptions, answerOptions: row.answerOptions }
      : {}),
    via: 'browser',
  };
};

/** First candidate of a comma-separated selector list that matches. */
export const firstMatch = async (commander, selector) => {
  for (const candidate of selectorCandidates(selector)) {
    if ((await commander.count({ selector: candidate })) > 0) {
      return candidate;
    }
  }
  return null;
};

/** Poll until one of `want` matches; give up early when `stop` matches. */
const waitForAny = async (
  commander,
  want,
  { stop = null, timeoutMs, pollMs }
) => {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    const found = await firstMatch(commander, want);
    if (found) {
      return found;
    }
    if (
      (stop && (await firstMatch(commander, stop))) ||
      Date.now() >= deadline
    ) {
      return null;
    }
    await sleep(pollMs);
  }
};

/**
 * Real key events, so the other side sees "typing…". Line breaks are
 * Shift+Enter: a bare Enter would send the message half-written.
 */
const typeLines = async (commander, text, delayMs) => {
  for (const [index, line] of text.split('\n').entries()) {
    if (index > 0) {
      await commander.pressKey({ key: 'Shift+Enter' });
    }
    if (line && delayMs > 0) {
      for (const char of line) {
        await commander.typeText({ text: char });
        await sleep(delayMs);
      }
    } else if (line) {
      await commander.typeText({ text: line });
    }
  }
};

// A failure while pressing Send may come after the press took effect: the
// message may be out, so it is never retried or sent another way (R-Z4).
const sentInDoubt = (error) =>
  Object.assign(markSendOutcome(error, { ambiguous: true }), {
    code: 'send-unknown',
    outcome: 'unknown',
    fallback: false,
  });

/** Click the send button when it is there, otherwise press the key. */
const pressSend = async (ui, commander) => {
  const button = ui.send?.selector
    ? await firstMatch(commander, ui.send.selector)
    : null;
  try {
    if (button) {
      await commander.clickButton({ selector: button, scrollIntoView: true });
      return;
    }
    await commander.pressKey({ key: ui.send?.key ?? 'Enter' });
  } catch (error) {
    throw sentInDoubt(error);
  }
};

/**
 * One page per network, opened on first use and then reused. One page
 * also means one action at a time: concurrent calls for a network queue
 * up instead of interleaving keystrokes in the same composer.
 */
const createSessionPool = ({ open, log }) => {
  const sessions = new Map();
  const queues = new Map();
  return {
    existing: (source) => sessions.get(source),
    get(source) {
      if (!sessions.has(source)) {
        const opening = Promise.resolve(open({ source })).then((session) => ({
          session,
          commander: session.commander,
          url: null,
        }));
        // A failed launch is forgotten so the next call tries again.
        opening.catch(() => {
          if (sessions.get(source) === opening) {
            sessions.delete(source);
          }
        });
        sessions.set(source, opening);
      }
      return sessions.get(source);
    },
    queue(source, fn) {
      const run = (queues.get(source) ?? Promise.resolve()).then(fn);
      queues.set(
        source,
        run.catch(() => {})
      );
      return run;
    },
    sources: () => [...sessions.keys()],
    async closeAll() {
      const pending = [...sessions.values()];
      sessions.clear();
      queues.clear();
      const results = await Promise.allSettled(
        pending.map(async (opening) => (await opening).session.close?.())
      );
      const failed = results.filter((r) => r.status === 'rejected').length;
      if (failed > 0) {
        log(`[browser] ${failed} session(s) failed to close`);
      }
    },
  };
};

/**
 * Pages of one network: `inChat(source, target, options, fn)` and
 * `inList(source, fn)` run `fn(commander, page)` with the chat (or the
 * chat list) open and the login checked, in the network's queue.
 */
const createChatPages = ({ pool, uiFor, waitFor, log, profileDirFor }) => {
  /** Navigate to `url` (if not already there) and check the login. */
  const openPage = async (source, url, { reload = false } = {}) => {
    const ui = uiFor(source);
    const state = await pool.get(source);
    if (state.url !== url || reload) {
      log(`[browser:${source}] open ${url}`);
      await state.commander.goto({ url, waitUntil: 'domcontentloaded' });
      state.url = url;
    }
    if (
      !(await waitFor(state.commander, ui.loggedIn, { stop: ui.loggedOut }))
    ) {
      state.url = null;
      throw new BrowserLoginRequiredError({
        source,
        loginUrl: ui.loginUrl,
        profileDir: profileDirFor(source),
      });
    }
    return state;
  };

  /** Open the chat; a pre-filled URL is reloaded every time. */
  const openChat = (source, target, { text = '', browserUrl } = {}) => {
    const ui = uiFor(source);
    if (target === null || target === undefined || target === '') {
      throw codedError(
        `${source}: a chat or recipient is required`,
        'bad-draft'
      );
    }
    // The reload is what puts the text back into the composer.
    const prefill = ui.prefill && text ? text : '';
    return openPage(source, ui.chatUrl(target, { text: prefill, browserUrl }), {
      reload: Boolean(prefill),
    });
  };

  /** Run `fn(commander, page)` with the chat open, in the network's queue. */
  const inChat = (source, target, options, fn) =>
    pool.queue(source, async () => {
      if (options.signal?.aborted) {
        throw codedError(
          'The browser conversation scan was cancelled',
          'cancelled'
        );
      }
      const state = await openChat(source, target, options);
      return fn(state.commander, state.session?.page ?? null);
    });

  /** Run `fn(commander, page)` with the chat list open. */
  const inList = (source, fn, { signal } = {}) =>
    pool.queue(source, async () => {
      if (signal?.aborted) {
        throw codedError('The browser chat scan was cancelled', 'cancelled');
      }
      const ui = uiFor(source);
      const state = await openPage(source, ui.listUrl ?? ui.loginUrl);
      return fn(state.commander, state.session?.page ?? null);
    });

  const inExisting = (source, fn, { signal } = {}) =>
    pool.queue(source, async () => {
      if (signal?.aborted) {
        throw codedError('The unread browser scan was cancelled', 'cancelled');
      }
      const opening = pool.existing(source);
      if (!opening) {
        throw codedError(
          'An existing browser view is required',
          'browser-view-unavailable'
        );
      }
      const state = await opening;
      const page = state.session?.page;
      if (!page || page.isClosed()) {
        throw codedError(
          'An existing browser view is required',
          'browser-view-unavailable'
        );
      }
      try {
        return await fn(state.commander, page);
      } finally {
        state.url = page.isClosed() ? null : page.url();
      }
    });
  return { inChat, inList, inExisting };
};

const choiceSources = (platforms) =>
  Object.entries(platforms)
    .filter(([, ui]) => ui.choices && ui.location)
    .map(([id, ui]) => ({ id, name: ui.name ?? id }));

const textReplySources = (platforms) =>
  choiceSources(platforms).filter(({ id }) => {
    const ui = platforms[id];
    return ui.documents && ui.textReply?.send && ui.textReply.closedText;
  });

const browserUiFor = (platforms) => (source) => {
  const ui = platforms[source];
  if (!ui) {
    throw codedError(
      `${source}: no web UI is known; known: ${Object.keys(platforms).join(', ')}`,
      'unsupported-source'
    );
  }
  return ui;
};

const composerFocus = (waitFor) => async (source, ui, commander) => {
  const composer = await waitFor(commander, ui.composer);
  if (!composer) {
    throw codedError(
      `${source}: message composer not found (selector ${ui.composer}); update WEB_UIS.${source}.composer`,
      'composer-missing'
    );
  }
  await commander.clickButton({ selector: composer, scrollIntoView: true });
  return composer;
};

/**
 * Drive the official web UIs through browser-commander.
 *
 * @param {object} [options]
 * @param {(args: {source: string}) => Promise<{commander: object, close: Function}>} [options.openSession]
 *   session factory; defaults to `openBrowserSession` from
 *   `../cv/browser.js` with the per-network persistent profile
 * @param {object} [options.platforms] web UI table, default `WEB_UIS`
 * @param {number} [options.typingDelayMs] pause between characters;
 *   0 types each line in one burst (still real key events)
 * @param {'type'|'fill'} [options.input] type key by key (shows
 *   "typing…") or fill the composer in one go
 * @param {number} [options.loginTimeoutMs] how long to wait for the
 *   logged-in marker after navigation
 * @param {number} [options.pollMs] polling interval while waiting
 * @param {boolean} [options.headless] for the default session factory
 * @param {(source: string) => string} [options.profileDirFor] persistent
 *   profile per network (default `~/.meta-sovereign/browser-profiles/<id>`)
 * @param {Function} [options.log] progress messages
 * @param {() => Date} [options.clock]
 */
const noticeReplySources = (platforms) =>
  textReplySources(platforms).filter(
    ({ id }) => platforms[id].noticeContext && platforms[id].historyScan
  );

const senderCapabilities = (platforms) => ({
  choiceSources: () => choiceSources(platforms),
  textReplySources: () => textReplySources(platforms),
  noticeReplySources: () => noticeReplySources(platforms),
  unreadConversationSources: () =>
    choiceSources(platforms).filter(({ id }) => {
      const ui = platforms[id];
      return (
        ui.chatNavigation?.sameDocument &&
        ui.documents &&
        ui.historyScan &&
        ui.chatScan?.unreadFilter
      );
    }),
  answerWatchSources: () =>
    choiceSources(platforms).filter(({ id }) => platforms[id].documents),
});

export const createBrowserSender = ({
  openSession = null,
  platforms = WEB_UIS,
  typingDelayMs = 0,
  input = 'type',
  loginTimeoutMs = 20000,
  pollMs = 250,
  choiceReceiptMs = 10000,
  headless,
  store = null,
  slot = 'main',
  profileDirFor = defaultProfileDir,
  log = () => {},
  clock = () => new Date(),
} = {}) => {
  const open = async ({ source }) => {
    const policy = await resolveBrowserPolicy(store, {
      platform: source,
      useCase: 'messages',
      headless,
      slot,
    });
    return (openSession ?? openBrowserSession)({
      source,
      platform: source,
      useCase: 'messages',
      slot,
      headless: policy.headless,
      profileDir: slotProfileDir(profileDirFor(source), slot),
    });
  };
  const pool = createSessionPool({ open, log });

  const uiFor = browserUiFor(platforms);

  const waitFor = (commander, want, extra = {}) =>
    waitForAny(commander, want, {
      timeoutMs: loginTimeoutMs,
      pollMs,
      ...extra,
    });

  const { inChat, inList, inExisting } = createChatPages({
    pool,
    uiFor,
    waitFor,
    log,
    profileDirFor: (source) => slotProfileDir(profileDirFor(source), slot),
  });

  const focusComposer = composerFocus(waitFor);

  const actions = createBrowserActions({
    inChat: (source, chat, fn) => inChat(source, chat, {}, fn),
    inList,
    uiFor,
    waitFor,
    firstMatch,
    focusComposer,
    typeLines: (commander, text) => typeLines(commander, text, typingDelayMs),
    pressSend,
    clock,
  });
  const choices = createBrowserChoiceActions({
    inChat,
    queue: (source, work) => pool.queue(source, work),
    uiFor,
    receiptMs: choiceReceiptMs,
    pollMs,
  });
  const scans = createBrowserChatScans({ uiFor, inList, inChat, inExisting });
  const texts = createBrowserTextActions({
    uiFor,
    inChat,
    receiptMs: choiceReceiptMs,
    pollMs,
  });

  return {
    platforms,
    ...actions,
    ...choices,
    ...scans,
    ...texts,
    ...senderCapabilities(platforms),

    /** Type and send one message in the network's web UI. */
    async send(draft = {}) {
      const { source, chat, to, text, answer } = draft;
      if (answer?.strictOptions) {
        return choices.chooseAnswer(draft);
      }
      const body = String(text ?? '');
      if (!body.trim()) {
        throw codedError(`${source}: message text is required`, 'bad-draft');
      }
      const ui = requireTextUi(uiFor(source));
      const target = ui.target({ chat, to });
      await inChat(source, target, { text: body }, async (commander) => {
        const composer = await focusComposer(source, ui, commander);
        // A pre-filled chat URL already put the text into the composer.
        if (!ui.prefill && input === 'fill') {
          await commander.fillTextArea({
            selector: composer,
            text: body,
            checkEmpty: false,
            simulateTyping: true,
          });
        } else if (!ui.prefill) {
          await typeLines(commander, body, typingDelayMs);
        }
        await pressSend(ui, commander);
      });
      log(`[browser:${source}] sent to ${target}`);
      return {
        via: 'browser',
        source,
        chat: String(target),
        sentAt: clock().toISOString(),
      };
    },

    /** Emit the "typing…" status: type a character and erase it. */
    async setTyping({ source, chat, to } = {}) {
      const ui = requireTextUi(uiFor(source), 'unsupported');
      await inChat(source, ui.target({ chat, to }), {}, async (commander) => {
        await focusComposer(source, ui, commander);
        await commander.typeText({ text: '.' });
        await commander.pressKey({ key: 'Backspace' });
      });
      return { via: 'browser', source, typing: true };
    },

    /** Read the visible history of a chat as message links. */
    async readRecent({ source, chat, to, browserUrl, limit = 20 } = {}) {
      const ui = uiFor(source);
      const target = ui.target({ chat, to });
      // A stable chat id (E.164 number / group JID), not the typed form
      // and not the page's title (R-Z9).
      const normalize = (value) => ui.normalizeChat?.(value) ?? null;
      const chatOf = (row) =>
        normalize(row.chat) ?? normalize(target) ?? String(target);
      const rows = await inChat(
        source,
        target,
        { browserUrl },
        (commander, page) =>
          readCurrentHistory(commander, page, ui, target, limit)
      );
      return (Array.isArray(rows) ? rows : [])
        .filter((row) => row?.service === true || row?.body)
        .map((row) => toMessageLink(source, chatOf(row), row));
    },

    /** Networks with an open page. */
    openSources: pool.sources,

    /** Close every page that was opened. */
    close: async () => {
      await scans.closeChatScans();
      await texts.closeTextReplies();
      await choices.closeAnswerWatches();
      await pool.closeAll();
    },
  };
};

const annotate = (result, via, extra = {}) =>
  result !== null && typeof result === 'object' && !Array.isArray(result)
    ? { ...result, ...extra, via }
    : { result: result ?? null, ...extra, via };

// Maybe delivered: the caller records it as `unknown` and does not retry
// on its own (R-Z4).
const markUnknown = (error) => {
  if (error?.ambiguous === true) {
    error.outcome = 'unknown';
    error.code ??= 'send-unknown';
  }
  return error;
};

// What a failed web-UI send raises after the API failed with `apiError`.
const browserFailure = (error, apiError, draft, action) => {
  // "Not allowed to automate this" is the answer, not a pair of failures.
  if (error?.code === 'unsupported') {
    return error;
  }
  // Maybe delivered by the web UI: told as such, never "failed" (R-Z4).
  if (!apiError || error?.ambiguous === true) {
    return markUnknown(error);
  }
  return new SendFallbackError(
    [apiError, error],
    `${draft?.source}: ${action === 'send' ? 'sending' : action} failed through the API (${apiError.message}) and the web UI (${error.message})`
  );
};

/**
 * API first, browser second.
 *
 * @param {object} options
 * @param {(draft: object) => Promise<any>} [options.apiSend]
 * @param {(draft: object) => Promise<any>} [options.browserSend]
 * @param {(error: Error) => boolean} [options.shouldFallback] default:
 *   every error except `safe-mode` and `bad-draft`
 * @param {Function} [options.log]
 * @param {string} [options.action] what is done (`send`, `edit`…), for
 *   the log and the error
 * @returns {(draft: object) => Promise<object>} result with `via`
 */
export const createFallbackSender =
  ({
    apiSend = null,
    browserSend = null,
    log = () => {},
    shouldFallback = defaultShouldFallback,
    action = 'send',
  } = {}) =>
  async (draft) => {
    let apiError = null;
    if (typeof apiSend === 'function') {
      try {
        return annotate(await apiSend(draft), 'api');
      } catch (error) {
        if (!shouldFallback(error) || typeof browserSend !== 'function') {
          throw markUnknown(error);
        }
        apiError = error;
        log(
          `[${action}:${draft?.source}] API failed (${error.message}); trying the web UI`
        );
      }
    }
    if (typeof browserSend !== 'function') {
      throw codedError(
        `${draft?.source}: no API or browser sender is configured`,
        'no-sender'
      );
    }
    try {
      const result = await browserSend(draft);
      return annotate(
        result,
        'browser',
        apiError ? { apiError: apiError.message } : {}
      );
    } catch (error) {
      throw browserFailure(error, apiError, draft, action);
    }
  };

/**
 * Networks whose web app may only be driven for a send the user confirms:
 * WhatsApp's terms forbid automated and bulk use of Web, so an automated
 * draft (`automated: true`, set by `guardedSend` for everything the user
 * did not press Send on) is refused with `unsupported` (R-Z9).
 */
export const WEB_USER_CONFIRMED_ONLY = Object.freeze(['whatsapp']);

const refuseAutomatedWeb = (draft) => {
  if (
    draft?.automated === true &&
    WEB_USER_CONFIRMED_ONLY.includes(draft.source)
  ) {
    throw codedError(
      `${draft.source}: an automated send cannot go through the web app (its terms forbid automation); send it yourself, or connect the Business Cloud API`,
      'unsupported'
    );
  }
};

/**
 * The sender automations and the chat composer use: the source adapter's
 * `live.post` first, the official web UI second. It also does every other
 * action on a message the same way (`perform`, ./message-actions.js).
 *
 * @param {object} [options]
 * @param {(source: string) => object} [options.getSource] adapter lookup;
 *   without it every draft goes through the browser
 * @param {object} [options.options] per-source `live.post` options
 * @param {(source: string) => Promise<object>} [options.optionsFor] the
 *   saved connection's options (token, ids) for a network
 * @param {object} [options.browser] a `createBrowserSender()` instance,
 *   or options for one (created lazily on the first fallback)
 * @param {Function} [options.log]
 * @returns {Function & {close: Function, perform: Function, supports: Function}}
 *   `(draft) => result`
 */
export const createDefaultSender = ({
  getSource = null,
  options = {},
  optionsFor = async () => ({}),
  browser = {},
  log = () => {},
} = {}) => {
  let browserSender = typeof browser?.send === 'function' ? browser : null;
  const browserFor = () => {
    browserSender ??= createBrowserSender({ log, ...browser });
    return browserSender;
  };
  const merged = async (source) => ({
    ...(await optionsFor(source)),
    ...(options[source] ?? {}),
  });
  const adapterSend = getSource
    ? async (draft) =>
        createAdapterSender({
          getSource,
          options: { [draft.source]: await merged(draft.source) },
        })(draft)
    : null;
  const sendText = createFallbackSender({
    apiSend: adapterSend,
    browserSend: (draft) => {
      refuseAutomatedWeb(draft);
      // A plain browser send cannot preserve these message semantics.
      // Refuse rather than silently turning a reply into a normal message.
      if (
        draft.replyTo ||
        draft.replyQuote ||
        draft.topic ||
        draft.sendAs ||
        draft.scheduleDate ||
        draft.allowPaidStars ||
        draft.silent ||
        draft.effect ||
        draft.noWebpage ||
        draft.invertMedia ||
        draft.previewUrl ||
        draft.previewSize
      ) {
        throw codedError(
          'this message requires the network API to preserve its reply and send options',
          'unsupported-send-options'
        );
      }
      return browserFor().send({
        source: draft.source,
        chat: draft.chat,
        to: draft.contact ?? draft.to,
        text: draft.text,
      });
    },
    log,
  });
  const send = (draft) => {
    if (draft.answer?.strictOptions) {
      refuseAutomatedWeb(draft);
      const chooser = browserFor();
      if (typeof chooser.chooseAnswer === 'function') {
        return chooser.chooseAnswer(draft);
      }
      throw codedError(
        'This answer requires a verified option click; open the provider chat to select it',
        'answer-choice-required'
      );
    }
    return sendText(draft);
  };
  const actions = createMessageActions({
    getSource,
    optionsFor: merged,
    browser: browserFor,
    log,
  });
  return Object.assign(send, {
    perform: actions.perform,
    supports: actions.supports,
    readChats: (params) => browserFor().readChats(params),
    scanChats: (params) => browserFor().scanChats(params),
    scanConversation: (params) => browserFor().scanConversation(params),
    scanUnreadConversations: (params) =>
      browserFor().scanUnreadConversations(params),
    readRecent: (params) => browserFor().readRecent(params),
    readAnswerChoices: (params) => browserFor().readAnswerChoices(params),
    prefillAnswer: (params) => browserFor().prefillAnswer(params),
    replyText: (params) => browserFor().replyText(params),
    choiceSources: () => browserFor().choiceSources?.() ?? [],
    textReplySources: () => browserFor().textReplySources?.() ?? [],
    noticeReplySources: () => browserFor().noticeReplySources?.() ?? [],
    unreadConversationSources: () =>
      browserFor().unreadConversationSources?.() ?? [],
    answerWatchSources: () => browserFor().answerWatchSources?.() ?? [],
    openAnswerWatch: (params) => browserFor().openAnswerWatch(params),
    close: async () => browserSender?.close(),
  });
};
