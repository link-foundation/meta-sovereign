async (page) => (async (page, data) => {
  const errors = [];
  const followed = [];
  page.on('pageerror', (error) => errors.push(String(error)));
  page.on('request', (request) => {
    if (request.url().startsWith('https://example.test/')) {
      followed.push(request.url());
    }
  });
  await page.addInitScript((entries) => {
    for (const [key, value] of entries) {
      globalThis.localStorage.setItem(key, value);
    }
  }, data.storage);
  await page.setViewportSize({ width: 1180, height: 950 });
  await page.goto(data.base);
  const results = [];
  for (const [locale, label] of Object.entries(data.labels)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      locale
    );
    await page.goto(`${data.base}/?api-link-review=${locale}#/automation`);
    await page
      .locator(`[data-automation="${data.automation}"]`)
      .first()
      .click();
    const response = page.waitForResponse((value) =>
      value.url().endsWith('/api/automations/plan')
    );
    await page
      .locator(
        'form.automation-editor .automation-actions > button[type="button"]'
      )
      .first()
      .click();
    if ((await response).status() !== 200) {
      throw new Error('Preview failed');
    }
    const evidence = page
      .locator('.automation-plan [data-answer-evidence]')
      .first();
    const links = evidence.locator('[data-question-links]');
    await links.waitFor();
    if ((await links.locator('code').textContent()) !== data.target) {
      throw new Error('Destination changed');
    }
    if ((await links.locator('small').textContent()) !== label) {
      throw new Error(`Missing ${locale} label`);
    }
    if (await links.locator('a').count()) {
      throw new Error('Destination became an active link');
    }
    if (locale === 'en') {
      await page.setViewportSize({ width: 390, height: 844 });
      await evidence.scrollIntoViewIfNeeded();
      if (
        !(await page.evaluate(
          () => document.documentElement.scrollWidth <= globalThis.innerWidth
        ))
      ) {
        throw new Error('Phone overflow');
      }
      await page.screenshot({
        path: `${data.root}/docs/screenshots/issue-56-question-${data.kind}-links/mcp-phone.png`,
      });
      await page.setViewportSize({ width: 1180, height: 950 });
    }
    results.push({ locale, literalDestination: true, translatedLabel: true });
  }
  await page.reload();
  if (await page.locator('.automation-plan').count()) {
    throw new Error('Reload replayed the preview');
  }
  if (errors.length || followed.length) {
    throw new Error(JSON.stringify({ errors, followed }));
  }
  return {
    results,
    errors,
    followed,
    reloadReplayed: false,
    liveProvider: false,
  };
})(page, {"base":"http://127.0.0.1:34633","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","storage":[["metaSovereignTutorial","{\"off\":true,\"v\":5}"]],"kind":"email","automation":"automation:email-links","target":"https://example.test/assignment?revision=One#Review","labels":{"en":"Link destinations — review before replying:","ru":"Адреса ссылок — проверьте перед ответом:","hi":"लिंक के पते — उत्तर देने से पहले जाँचें:","zh":"链接目标 — 回复前请核对："}})