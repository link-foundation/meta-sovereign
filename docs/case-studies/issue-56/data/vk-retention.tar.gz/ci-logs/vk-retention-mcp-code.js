async (page) => (async (page, fixture, check) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      language
    );
    await page.goto(`${fixture.base}/?vkLocale=${language}#conn-vk/manual`);
    const panel = page.locator(`[data-${fixture.feature}]`);
    const ready = () =>
      page.waitForFunction((feature) => {
        const input = document.querySelector(
          `[data-${feature}] input[type=checkbox]`
        );
        return input && !input.disabled;
      }, fixture.feature);
    // A mounted heading and an enabled control distinguish loading from absence.
    await panel
      .getByRole('heading', { name: words.title, exact: true })
      .waitFor();
    await ready();
    for (const key of fixture.keys) {
      if (!(await panel.innerText()).includes(words[key])) {
        throw Error(`Missing ${language}.${key}`);
      }
    }
    const { focus, ...checked } = await check(page, {
      panel,
      words,
      ready,
      feature: fixture.feature,
      action: async (name) => {
        await panel.locator(`[data-action=${fixture.feature}-${name}]`).click();
        await ready();
      },
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await panel.locator(focus).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-${fixture.evidenceName}/mcp-${language}-phone.png`,
    });
    result.push({ language, translated: true, ...checked });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:36487","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","feature":"vk-retention","evidenceName":"vk-retention","keys":["hint","peers","threshold","scanLimit","run"],"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"VK history retention","hint":"Scheduling starts off. Clear only configured histories strictly above the threshold. Review the complete bounded history first. Provider deletion affects this account only; unsupported conversation deletion falls back to reviewed message IDs in batches of 100. Unknown outcomes never replay. Local messages become recoverable tombstones only after confirmed provider deletion; partial work requires manual review.","peers":"VK peer IDs, separated by commas (up to 100; negative IDs allowed)","threshold":"Clear when message count is greater than","scanLimit":"Maximum history messages to inspect (must exceed threshold)","run":"Confirm reviewed provider deletion and local retention"},"ru":{"title":"Очистка истории ВКонтакте","hint":"Расписание выключено. Очищаются только заданные беседы строго выше порога после полной ограниченной проверки. Удаление действует только для этого аккаунта. Если метод удаления беседы не поддерживается, используются проверенные ID сообщений пакетами по 100. Неизвестный результат не повторяется. После подтверждения провайдера локальные сообщения получают восстанавливаемые отметки удаления; частичная очистка требует ручной проверки.","peers":"ID бесед ВКонтакте через запятую (до 100, допустимы отрицательные)","threshold":"Очищать, когда число сообщений больше","scanLimit":"Максимум проверяемых сообщений (выше порога)","run":"Подтвердить удаление у провайдера и локальную отметку"},"hi":{"title":"VK इतिहास प्रतिधारण","hint":"शेड्यूल बंद है। केवल चुनी गई चैट सीमा से अधिक होने पर साफ़ होती हैं। पहले पूरा सीमित इतिहास जाँचें। प्रदाता पर केवल इस खाते के लिए हटाया जाता है; बातचीत हटाने की विधि असमर्थित होने पर समीक्षित संदेश ID के 100 वाले बैच उपयोग होते हैं। अज्ञात परिणाम नहीं दोहरते। प्रदाता पुष्टि के बाद स्थानीय संदेश पुनर्प्राप्त करने योग्य हटाने के चिह्न बनते हैं; आंशिक काम की मैन्युअल समीक्षा ज़रूरी है।","peers":"VK चैट ID, अल्पविराम से अलग (अधिकतम 100; ऋणात्मक ID मान्य)","threshold":"संदेश संख्या इससे अधिक हो तो साफ़ करें","scanLimit":"जाँचने के लिए अधिकतम इतिहास संदेश (सीमा से अधिक)","run":"समीक्षित प्रदाता हटाना और स्थानीय प्रतिधारण पुष्ट करें"},"zh":{"title":"VK 历史保留策略","hint":"自动计划默认关闭。仅清理明确配置且消息数严格超过阈值的对话，先审核有界的完整历史。服务端仅为当前账号删除；整段对话删除方法不受支持时，改用已审核消息 ID，每批 100 条。结果未知时绝不重试。服务端确认删除后，本地消息标为可恢复删除；部分完成须重新手动审核。","peers":"VK 对话 ID，逗号分隔（最多 100 个，可用负数）","threshold":"消息数超过此值时清理","scanLimit":"最多检查的历史消息数（须高于阈值）","run":"确认服务端删除和本地保留操作"}}}, (async (page, { panel, ready, action }) => {
  await panel.locator('[data-retention-field=peers]').fill('9');
  await panel.locator('[data-retention-field=threshold]').fill('1');
  await action('save');
  await action('plan');
  if (
    !(await panel.locator('[data-retention-reason=belowThreshold]').count())
  ) {
    if (
      !(await panel.locator('[data-retention-evidence]').innerText()).includes(
        '3'
      )
    ) {
      throw Error('Missing reviewed retention message counts');
    }
    await action('run');
  }
  await page.reload();
  await ready();
  await action('plan');
  if (
    (await panel.locator('[data-retention-reason=belowThreshold]').count()) !==
      1 ||
    (await panel.locator('[data-vk-retention-status=confirmed]').count()) !==
      1 ||
    !(await panel.locator('[data-retention-evidence]').innerText()).includes(
      '3'
    )
  ) {
    throw Error('Confirmed retention and provider receipt were not recovered');
  }
  if (await panel.locator('[data-action=vk-retention-enabled]').isChecked()) {
    throw Error('Retention scheduling unexpectedly enabled');
  }
  return {
    focus: '[data-vk-retention-plan]',
    reviewedRetention: true,
    confirmedRecovery: true,
    automaticOff: true,
  };
}))