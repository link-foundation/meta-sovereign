async (page) => (async (page, fixture, check) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      language
    );
    await page.goto(`${fixture.base}/?vkLocale=${language}#conn-vk/manual`);
    const panel = page.locator(`[data-${fixture.feature}]`);
    const ready = () =>
      page.waitForFunction((feature) => {
        const input = document.querySelector(
          `[data-${feature}] input[type=checkbox]`
        );
        return input && !input.disabled;
      }, fixture.feature);
    // A mounted heading and an enabled control distinguish loading from absence.
    await panel
      .getByRole('heading', { name: words.title, exact: true })
      .waitFor();
    await ready();
    for (const key of fixture.keys) {
      if (!(await panel.innerText()).includes(words[key])) {
        throw Error(`Missing ${language}.${key}`);
      }
    }
    const { focus, ...checked } = await check(page, {
      panel,
      words,
      ready,
      feature: fixture.feature,
      action: async (name) => {
        await panel.locator(`[data-action=${fixture.feature}-${name}]`).click();
        await ready();
      },
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await panel.locator(focus).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-${fixture.evidenceName}/mcp-${language}-phone.png`,
    });
    result.push({ language, translated: true, ...checked });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:44413","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","feature":"vk-wall","evidenceName":"vk-friend-invitations","keys":["hint","communities","attachments","replaceOwned","randomAttachment","run"],"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"VK community invitations","hint":"Scheduling and old-post replacement start off. Review each destination, exact text, native attachments and owned old posts. A positively acknowledged new post must be retained before any reviewed old post is deleted. Partial replacement requires a fresh manual review; unknown delivery is never replayed.","communities":"Community IDs, separated by commas (up to 100)","attachments":"Native photo/audio/video/doc IDs, separated by commas (up to 10)","replaceOwned":"Replace reviewed owned posts after the new post is acknowledged","randomAttachment":"Choose one configured media item at random for each reviewed post","run":"Confirm reviewed publication and deletions"},"ru":{"title":"Приглашения в сообщества ВКонтакте","hint":"Расписание и замена старых записей выключены. Проверьте адрес, точный текст, вложения и свои старые записи. Подтверждённая новая запись сохраняется до удаления старых. Частичная замена требует новой ручной проверки; неизвестная отправка не повторяется.","communities":"ID сообществ через запятую (до 100)","attachments":"ID фото, аудио, видео или документов через запятую (до 10)","replaceOwned":"Заменять проверенные свои записи после подтверждения новой","randomAttachment":"Случайно выбирать одно заданное медиа для каждой проверяемой записи","run":"Подтвердить проверенную публикацию и удаления"},"hi":{"title":"VK समुदाय आमंत्रण","hint":"शेड्यूल और पुरानी पोस्ट बदलना बंद हैं। हर गंतव्य, सटीक पाठ, मूल अटैचमेंट और अपनी पुरानी पोस्ट जाँचें। पुरानी पोस्ट हटाने से पहले नई पोस्ट की पुष्टि सहेजी जाती है। आंशिक बदलाव को नई मैन्युअल समीक्षा चाहिए; अज्ञात भेजना दोहराया नहीं जाता।","communities":"समुदाय ID, कॉमा से अलग (अधिकतम 100)","attachments":"मूल फोटो/ऑडियो/वीडियो/दस्तावेज़ ID, कॉमा से अलग (अधिकतम 10)","replaceOwned":"नई पोस्ट की पुष्टि के बाद समीक्षित अपनी पोस्ट बदलें","randomAttachment":"हर समीक्षित पोस्ट के लिए चुने मीडिया में से एक यादृच्छिक आइटम चुनें","run":"समीक्षित प्रकाशन और हटाने की पुष्टि करें"},"zh":{"title":"VK 社区邀请","hint":"自动计划和旧帖替换默认关闭。审核每个目标、原文、原生附件和自己的旧帖。必须先保存新帖的明确确认，才能删除已审核的旧帖。部分替换需要重新手动审核；结果未知时绝不重发。","communities":"社区 ID，以逗号分隔（最多 100 个）","attachments":"原生照片/音频/视频/文档 ID，以逗号分隔（最多 10 个）","replaceOwned":"新帖确认后替换已审核的自己的旧帖","randomAttachment":"为每条待审核帖子随机选择一个配置的媒体附件","run":"确认已审核的发布和删除"}}}, (async (page, { panel, ready }) => {
  for (const [key, value] of [
    ['communities', '42'],
    ['messages', 'Add me as a friend: owner invitation'],
    ['attachments', 'audio-1_23,audio-1_24'],
  ]) {
    await panel.locator(`[data-wall-field=${key}]`).fill(value);
  }
  await panel.locator('[data-wall-field=replaceOwned]').check();
  await panel.locator('[data-wall-field=randomAttachment]').check();
  for (const action of ['save', 'plan']) {
    await panel.locator(`[data-action=vk-wall-${action}]`).click();
    await ready();
  }
  const visible = await panel.locator('[data-wall-reason=visible]').count();
  if (!visible) {
    const review = await panel.locator('[data-vk-wall-plan]').innerText();
    if (
      (review.match(/audio-1_(23|24)/gu) ?? []).length !== 1 ||
      !review.includes('Add me as a friend: owner invitation')
    ) {
      throw Error('Missing native wall review');
    }
    await panel.locator('[data-action=vk-wall-run]').click();
    await ready();
    await panel.locator('[data-vk-wall-status=confirmed]').waitFor();
  }
  await page.reload();
  await ready();
  await panel.locator('[data-action=vk-wall-plan]').click();
  await ready();
  if ((await panel.locator('[data-wall-reason=visible]').count()) !== 1) {
    throw Error('Top-ten duplicate was not held after reload');
  }
  if (await panel.locator('[data-action=vk-wall-enabled]').isChecked()) {
    throw Error('Schedule unexpectedly enabled');
  }
  if (
    !(await panel.locator('[data-wall-field=randomAttachment]').isChecked())
  ) {
    throw Error('Saved media choice was lost after reload');
  }
  return {
    focus: '[data-vk-wall-plan]',
    nativeReview: true,
    postBeforeDelete: true,
    deduplication: true,
    automaticOff: true,
    retainedSingleMedia: true,
  };
}))