The documented `send` and `test` commands are not registered as commands in the CLI. The entry point takes the first positional argument as message text, so documented sends select `send` as the payload, and `test` reaches the publishing path. The documented comma-separated platform list is also rejected by the whole-string `choices` validation.

Inspected current commit [1b98a0a](https://github.com/konard/broadcast/blob/1b98a0a0eb02edbdf74f481db853f72a0fab6a8a/broadcast.mjs). This is a static source audit; I have not executed the reference CLI or posted to any provider.

Reproduction after installing the repository's normal dependencies, using only dry runs:

```sh
bun run broadcast.mjs send "Expected payload" --platforms x --dry-run
bun run broadcast.mjs test --platforms x --dry-run
bun run broadcast.mjs send "Expected payload" --platforms telegram,vk --dry-run
```

The first call selects the first positional argument (`send`) for `message`, instead of `Expected payload`. The second selects `test` as the message. Without `--dry-run`, that second command proceeds into `broadcast(message, platforms)` and can publish the literal word `test` with configured accounts. The declared `testBroadcasters()` function has no call site. The third call fails argument choices because `telegram,vk` is not one of the individual choices, before the code can split and validate its components.

Expected behavior: the documented send command forwards the complete message unchanged; the test command dispatches only the explicitly defined configuration/connectivity behavior; any documented list of valid platforms is accepted. Dry-run must never reach publishing.

Workaround: use a single positional message with no `send` prefix, select a single platform (or `all`), and verify the resolved text with `--dry-run` first. Do not use the documented `test` subcommand for connectivity testing until it has a real dispatch path. Also note that the provider-level Telegram/VK test helpers currently publish and delete a test message, so those should remain explicit user-controlled operations.

Suggested fix: register distinct yargs `send <message>` and `test` handlers, optionally keep an explicit default positional-message handler for compatibility, and validate comma-separated platform entries after splitting instead of restricting the entire option string to one enum value. Add CLI regression tests with mocked providers for exact payload preservation, zero writes on dry-run, correct test-handler dispatch, accepted platform combinations and rejected unknown platforms.

The [README usage and command reference](https://github.com/konard/broadcast/blob/1b98a0a0eb02edbdf74f481db853f72a0fab6a8a/README.md#usage) documents all three affected forms. Found during the complete broadcast reference audit in [meta-sovereign PR 57](https://github.com/link-foundation/meta-sovereign/pull/57).
