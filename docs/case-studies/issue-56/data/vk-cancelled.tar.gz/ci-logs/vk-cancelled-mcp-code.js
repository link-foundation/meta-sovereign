async (page) => (async (page, fixture, check) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      language
    );
    await page.goto(`${fixture.base}/?vkLocale=${language}#conn-vk/manual`);
    const panel = page.locator(`[data-${fixture.feature}]`);
    const ready = () =>
      page.waitForFunction((feature) => {
        const input = document.querySelector(
          `[data-${feature}] input[type=checkbox]`
        );
        return input && !input.disabled;
      }, fixture.feature);
    // A mounted heading and an enabled control distinguish loading from absence.
    await panel
      .getByRole('heading', { name: words.title, exact: true })
      .waitFor();
    await ready();
    for (const key of fixture.keys) {
      if (!(await panel.innerText()).includes(words[key])) {
        throw Error(`Missing ${language}.${key}`);
      }
    }
    const { focus, ...checked } = await check(page, {
      panel,
      words,
      ready,
      feature: fixture.feature,
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await panel.locator(focus).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-${fixture.evidenceName}/mcp-${language}-phone.png`,
    });
    result.push({ language, translated: true, ...checked });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:39485","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","feature":"vk-cancelled","evidenceName":"vk-cancelled","keys":["hint","blockUnanswered","blockUnwritable","plan","run"],"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"VK friendship follow-up","hint":"Outgoing requests cannot prove a former friendship. Review each candidate and the exact message. A greeting and question are sent together once per account/person. Automatic runs and both blocking choices start off. Priority accounts are always protected; incomplete history or uncertain delivery prevents action.","blockUnanswered":"Allow blocking after the unanswered interval","blockUnwritable":"Allow blocking when VK says writing is unavailable","plan":"Prepare review","run":"Confirm reviewed messages and blocks"},"ru":{"title":"Обсуждение дружбы ВКонтакте","hint":"Исходящая заявка не доказывает прошлую дружбу. Просмотрите каждого кандидата и точный текст. Приветствие и вопрос отправляются одним сообщением один раз для пары аккаунт/человек. Автозапуск и оба вида блокировки изначально выключены. Приоритетные аккаунты защищены; неполная история и неизвестная доставка запрещают действие.","blockUnanswered":"Разрешить блокировку после срока без ответа","blockUnwritable":"Разрешить блокировку, когда ВКонтакте запрещает писать","plan":"Подготовить просмотр","run":"Подтвердить просмотренные сообщения и блокировки"},"hi":{"title":"VK मित्रता के बारे में पूछें","hint":"भेजा गया अनुरोध पिछली मित्रता का प्रमाण नहीं है। हर व्यक्ति और पूरा संदेश जाँचें। अभिवादन और सवाल एक साथ प्रति खाता/व्यक्ति एक बार भेजे जाते हैं। स्वचालित चलना और दोनों ब्लॉक विकल्प शुरू में बंद हैं। प्राथमिक खाते सुरक्षित हैं; अधूरी हिस्ट्री या अज्ञात डिलीवरी पर कार्रवाई नहीं होती।","blockUnanswered":"प्रतीक्षा के बाद जवाब न मिलने पर ब्लॉक की अनुमति","blockUnwritable":"VK पर लिखना अनुपलब्ध होने पर ब्लॉक की अनुमति","plan":"समीक्षा तैयार करें","run":"समीक्षित संदेश और ब्लॉक की पुष्टि करें"},"zh":{"title":"VK 好友关系询问","hint":"已发出的请求无法证明曾经是好友。请审核每个人及完整消息。问候和问题合为一条消息，每个账户/个人仅发送一次。自动运行及两种屏蔽选项默认关闭。优先账户受到保护；历史不完整或发送结果未知时禁止操作。","blockUnanswered":"允许在等待期后无回复时屏蔽","blockUnwritable":"允许在 VK 无法发送消息时屏蔽","plan":"准备审核","run":"确认已审核的消息及屏蔽"}}}, (async (page, { panel, ready }) => {
  for (const [key, value] of [
    ['greeting', 'Hello, friend.'],
    ['question', 'Would you like to stay in touch?'],
    ['limit', '1'],
  ]) {
    await panel.locator(`[data-cancelled-field=${key}]`).fill(value);
  }
  for (const action of ['save', 'plan']) {
    await panel.locator(`[data-action=vk-cancelled-${action}]`).click();
    await ready();
  }
  const previouslyPrompted = await panel
    .locator('[data-cancelled-reason=alreadyPrompted]')
    .count();
  if (
    !previouslyPrompted &&
    (await panel.locator('[data-cancelled-message]').innerText()) !==
      'Hello, friend.\nWould you like to stay in touch?'
  ) {
    throw new Error('Reviewed message mismatch');
  }
  await panel.locator('[data-action=vk-cancelled-run]').click();
  await ready();
  await page.reload();
  await ready();
  await panel.locator('[data-action=vk-cancelled-plan]').click();
  await ready();
  if (
    (await panel.locator('[data-cancelled-reason=alreadyPrompted]').count()) !==
    1
  ) {
    throw new Error('Duplicate prompt not suppressed');
  }
  if (
    (await panel
      .locator('[data-cancelled-field=blockUnanswered]')
      .isChecked()) ||
    (await panel.locator('[data-cancelled-field=blockUnwritable]').isChecked())
  ) {
    throw new Error('Implicit blocking consent');
  }
  return {
    focus: '[data-vk-cancelled-plan]',
    honestEvidence: true,
    reviewed: true,
    noRepeat: true,
    blockingOff: true,
    savedText: true,
  };
}))