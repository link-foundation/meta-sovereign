async (page) => (async (page, fixture, check) => {
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.setDefaultTimeout(10000);
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const result = [];
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (value) => globalThis.localStorage.setItem('metaSovereignLocale', value),
      language
    );
    await page.goto(`${fixture.base}/?vkLocale=${language}#conn-vk/manual`);
    const panel = page.locator(`[data-${fixture.feature}]`);
    const ready = () =>
      page.waitForFunction((feature) => {
        const input = document.querySelector(
          `[data-${feature}] input[type=checkbox]`
        );
        return input && !input.disabled;
      }, fixture.feature);
    // A mounted heading and an enabled control distinguish loading from absence.
    await panel
      .getByRole('heading', { name: words.title, exact: true })
      .waitFor();
    await ready();
    for (const key of fixture.keys) {
      if (!(await panel.innerText()).includes(words[key])) {
        throw Error(`Missing ${language}.${key}`);
      }
    }
    const { focus, ...checked } = await check(page, {
      panel,
      words,
      ready,
      feature: fixture.feature,
    });
    await page.setViewportSize({ width: 390, height: 844 });
    await panel.locator(focus).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error(`Phone overflow: ${language}`);
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-${fixture.evidenceName}/mcp-${language}-phone.png`,
    });
    result.push({ language, translated: true, ...checked });
  }
  if (errors.length) {
    throw Error(JSON.stringify(errors));
  }
  return { result, errors, liveProvider: false };
})(page, {"base":"http://127.0.0.1:40335","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","feature":"vk-birthday","evidenceName":"vk-birthday","keys":["hint","timeZone","messages","stickers","attachments","run"],"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"title":"VK birthday greetings","hint":"Scheduling starts off. Choose an explicit IANA time zone and review today’s current friends. Skip private birthdays, unread chats and conversations active in the last 24 hours. Select a sticker, then text with optional native media, 15 seconds apart. The reviewed date and acknowledged steps are retained; unknown delivery is never replayed.","timeZone":"Birthday time zone (IANA, for example UTC or Europe/Moscow)","messages":"Birthday text variants (one per line, up to 20)","stickers":"VK sticker variants (comma-separated IDs, up to 20; optional)","attachments":"Native photo/audio/video/doc IDs (comma-separated, up to 10; optional)","run":"Confirm remaining reviewed steps"},"ru":{"title":"Поздравления с днём рождения ВКонтакте","hint":"Расписание выключено. Выберите часовой пояс IANA и проверьте текущих друзей с днём рождения сегодня. Скрытые даты, непрочитанные беседы и общение за последние 24 часа исключены. Сначала стикер, затем текст с необязательными медиа, с паузой 15 секунд. Дата и подтверждённые шаги сохраняются; неизвестная отправка не повторяется.","timeZone":"Часовой пояс дня рождения (IANA, например UTC или Europe/Moscow)","messages":"Варианты поздравления (по строке, до 20)","stickers":"Варианты стикеров ВКонтакте (ID через запятую, до 20; необязательно)","attachments":"ID фото/аудио/видео/документов (через запятую, до 10; необязательно)","run":"Подтвердить оставшиеся просмотренные шаги"},"hi":{"title":"VK जन्मदिन अभिवादन","hint":"शेड्यूल बंद है। IANA समय क्षेत्र चुनें और आज जन्मदिन वाले वर्तमान मित्रों की समीक्षा करें। निजी तिथि, अपठित चैट और पिछले 24 घंटे की बातचीत छोड़ी जाती है। पहले स्टीकर, फिर वैकल्पिक मूल मीडिया वाला टेक्स्ट, 15 सेकंड के अंतर पर जाता है। तिथि और पुष्ट चरण सहेजे जाते हैं; अज्ञात भेजना दोहराया नहीं जाता।","timeZone":"जन्मदिन समय क्षेत्र (IANA, जैसे UTC या Asia/Kolkata)","messages":"जन्मदिन टेक्स्ट विकल्प (हर पंक्ति पर एक, अधिकतम 20)","stickers":"VK स्टीकर विकल्प (अल्पविराम से अलग ID, अधिकतम 20; वैकल्पिक)","attachments":"मूल फ़ोटो/ऑडियो/वीडियो/दस्तावेज़ ID (अल्पविराम से अलग, अधिकतम 10; वैकल्पिक)","run":"शेष समीक्षित चरणों की पुष्टि करें"},"zh":{"title":"VK 生日问候","hint":"自动计划默认关闭。选择明确的 IANA 时区并审核今天过生日的当前好友。跳过隐藏生日、未读对话以及过去 24 小时内活跃的对话。先发贴纸，再发带可选原生媒体的文字，间隔 15 秒。保留审核日期和已确认步骤；结果未知时绝不重发。","timeZone":"生日時区（IANA，例如 UTC 或 Asia/Shanghai）","messages":"生日文字选项（每行一个，最多 20 个）","stickers":"VK 贴纸选项（逗号分隔 ID，最多 20 个；可选）","attachments":"原生照片/音频/视频/文档 ID（逗号分隔，最多 10 个；可选）","run":"确认剩余已审核步骤"}}}, (async (page, { panel, ready }) => {
  for (const [key, value] of [
    ['timeZone', 'UTC'],
    ['messages', 'Happy birthday!'],
    ['stickers', '60302'],
    ['attachments', 'video1_23'],
  ]) {
    await panel.locator(`[data-birthday-field=${key}]`).fill(value);
  }
  const action = async (name) => {
    await panel.locator(`[data-action=vk-birthday-${name}]`).click();
    await ready();
  };
  await action('save');
  await action('plan');
  if (!(await panel.locator('[data-birthday-reason=cooldown]').count())) {
    if (
      (await panel.locator('[data-personal-sequence] li').count()) !== 2 ||
      !(await panel.locator('[data-personal-sequence]').innerText()).includes(
        'video1_23'
      ) ||
      !(await panel.locator('[data-birthday-date]').innerText()).includes(
        '2026-11-15'
      )
    ) {
      throw Error('Missing reviewed birthday date and native message payload');
    }
    await action('run');
  }
  await page.reload();
  await ready();
  await action('plan');
  if ((await panel.locator('[data-birthday-reason=cooldown]').count()) !== 1) {
    throw Error('Birthday date deduplication was not retained');
  }
  if (
    (await panel
      .locator('[data-sequence-receipt]:not([data-sequence-receipt=""])')
      .count()) !== 2
  ) {
    throw Error('Completed birthday receipts are missing from date review');
  }
  if (await panel.locator('[data-action=vk-birthday-enabled]').isChecked()) {
    throw Error('Birthday scheduling unexpectedly enabled');
  }
  return {
    focus: '[data-vk-birthday-plan]',
    reviewedBirthday: true,
    dateDeduplication: true,
    automaticOff: true,
  };
}))