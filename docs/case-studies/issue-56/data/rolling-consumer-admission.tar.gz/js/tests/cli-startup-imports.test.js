import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { readFileSync } from 'node:fs';

test(
  'version aliases need no provider or ordinary command graph',
  {
    timeout: 10000,
    skip: Boolean(process.versions.bun || process.versions.deno),
  },
  () => {
    const probe = fileURLToPath(
      new URL(
        '../../experiments/issue-56/cli-version-imports.mjs',
        import.meta.url
      )
    );
    const result = JSON.parse(
      execFileSync(process.execPath, [probe], {
        encoding: 'utf8',
        timeout: 5000,
      })
    );
    const { version } = JSON.parse(
      readFileSync(new URL('../../package.json', import.meta.url), 'utf8')
    );
    assert.deepEqual(result.codes, [0, 0, 0]);
    assert.deepEqual(result.output, [version, version, version]);
    assert.deepEqual(
      result.modules.filter(
        (name) =>
          name.startsWith('sources/') ||
          name === 'server/index.js' ||
          name === 'cli/commands.js'
      ),
      [],
      'version imported unrelated command/provider code'
    );
  }
);

test(
  'serve admission leaves provider and ordinary command modules to their consumers',
  {
    timeout: 10000,
    // The load hook observes Node's actual module graph; other runtimes run
    // the shared CLI and real rolling-host behavioral checks instead.
    skip: Boolean(process.versions.bun || process.versions.deno),
  },
  () => {
    const probe = fileURLToPath(
      new URL(
        '../../experiments/issue-56/cli-serve-imports.mjs',
        import.meta.url
      )
    );
    const result = JSON.parse(
      execFileSync(process.execPath, [probe], {
        encoding: 'utf8',
        timeout: 5000,
      })
    );
    assert.equal(result.code, 1);
    assert.match(result.output.join('\n'), /recovery formats must be/u);
    const unrelated = result.modules.filter(
      (name) =>
        name.startsWith('sources/') ||
        name === 'server/index.js' ||
        name === 'cli/commands.js' ||
        name === 'cli/cv-commands.js' ||
        name === 'cli/forms-commands.js' ||
        name === 'server/runner-health.js' ||
        name === 'server/wire.js' ||
        name === 'transport/lino.js' ||
        name === 'storage/recovery-dump.js' ||
        name === 'storage/backup-archive.js' ||
        name === 'web/discover.js'
    );
    assert.deepEqual(
      unrelated,
      [],
      'serve imported command, health, error or archive consumers before use'
    );
  }
);
