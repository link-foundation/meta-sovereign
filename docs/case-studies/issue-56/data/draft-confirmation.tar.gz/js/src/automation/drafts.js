/**
 * Safe-mode drafts (see `./runner.js`), without timers or Node modules so
 * the browser can hold drafts while no server is up: load an automation
 * (a saved link or a preset), queue drafts, and settle them — send after
 * confirmation, switch "ты"/"вы", mark as sent by hand, or skip.
 */

import {
  AUTOMATION_PREFIX,
  DRAFT_PREFIX,
  automationKey,
  draftId,
  automationPresets,
  normalizeAutomation,
  redraftWithForm,
  runRecordId,
} from './automations.js';
import { validateAnswerDraft } from './question-store.js';
import { personalReplyKinds } from './contextual-replies.js';

// Bind the destination, rendered content and evidence the owner reviewed.
// Queue bookkeeping is excluded: it does not change the reviewed operation.
export const draftConfirmationKey = (draft) =>
  JSON.stringify([
    draft.id,
    draft.automation,
    draft.source,
    draft.chat,
    draft.contact ?? null,
    draft.form,
    draft.text,
    draft.answer ?? null,
    draft.sticker ?? null,
    ...personalReplyKinds.map((key) => draft[key] ?? null),
  ]);

const renderDraft = (automation, stored, { text, form } = {}) => {
  const draft =
    form && form !== stored.form
      ? redraftWithForm(automation, stored, form)
      : stored;
  return typeof text === 'string'
    ? { ...draft, text, ...(text.trim() ? { sticker: undefined } : {}) }
    : draft;
};

export class ConfirmationRequiredError extends Error {
  constructor(message) {
    super(message);
    this.name = 'ConfirmationRequiredError';
    this.code = 'confirm-required';
  }
}

export const runRecord = (automation, draft, { status, at, ...extra }) => ({
  id: runRecordId(automation, draft),
  tokens: ['automation-run', automationKey(automation), draft.source, status],
  automation: automation.id,
  source: draft.source,
  chat: String(draft.chat),
  contact: draft.contact ?? null,
  status,
  at,
  form: draft.form ?? null,
  text: draft.text ?? '',
  ...(draft.sticker ? { sticker: draft.sticker } : {}),
  ...Object.fromEntries(
    Object.entries(extra).filter(([, value]) => value !== undefined)
  ),
});

/** A saved automation or, before the user saved a copy, a preset. */
export const loadAutomation = async (store, automationOrId) => {
  if (typeof automationOrId !== 'string') {
    return normalizeAutomation(automationOrId);
  }
  const id = automationOrId.startsWith(AUTOMATION_PREFIX)
    ? automationOrId
    : `${AUTOMATION_PREFIX}${automationOrId}`;
  const link =
    (await store.get(id)) ?? automationPresets().find((a) => a.id === id);
  if (!link) {
    throw new Error(`no automation ${id}`);
  }
  return normalizeAutomation(link);
};

/** Saved automations first, then the presets not saved yet. */
export const listAutomations = async (store) => {
  const saved = (
    await store.query((l) => l?.id?.startsWith(AUTOMATION_PREFIX))
  ).map((l) => {
    try {
      return { ...normalizeAutomation(l), saved: true };
    } catch (error) {
      return { id: l.id, name: l.name ?? l.id, invalid: error.message };
    }
  });
  const ids = new Set(saved.map((a) => a.id));
  return [
    ...saved,
    ...automationPresets()
      .filter((a) => !ids.has(a.id))
      .map((a) => ({ ...a, saved: false })),
  ];
};

/** Write planned drafts; they are shown in their chats until settled. */
export const queueDrafts = async (store, automation, drafts, at) => {
  // A draft is settled against its automation later; keep an unsaved one.
  if (drafts.length > 0 && !(await store.get(automation.id))) {
    await store.put(automation);
  }
  const queued = [];
  for (const draft of drafts) {
    if (draft.answer?.model?.used) {
      const existing = await store.get(draft.id);
      if (existing?.status === 'pending') {
        queued.push(existing);
        continue;
      }
      const valid = await validateAnswerDraft(store, automation, draft, {
        reviewed: true,
        now: Date.parse(at),
      });
      if (!valid.ok) {
        throw Object.assign(new Error(valid.error), { code: valid.code });
      }
    }
    await store.put({
      ...draft,
      tokens: ['automation-draft', automationKey(automation), draft.source],
      status: 'pending',
      createdAt: at,
    });
    queued.push(draft);
  }
  return queued;
};

// Revealing an existing preview is a read, so it needs no archive planning.
export const existingTestResult = async (store, automation, options, at) => {
  if (automation.mode !== 'safe' || !options.test || !options.targets?.length) {
    return null;
  }
  const ids = new Set(
    options.targets.map((target) => draftId(automation, target))
  );
  const queued = [];
  for (const id of ids) {
    const draft = await store.get(id);
    if (draft?.status !== 'pending') {
      return null;
    }
    queued.push(draft);
  }
  return {
    automation: automation.id,
    name: automation.name,
    mode: automation.mode,
    generatedAt: at,
    total: queued.length,
    drafts: queued,
    excluded: [],
    queued,
    reused: true,
  };
};

// Re-testing a chat opens its pending draft rather than silently doing
// nothing or overwriting text the user already edited. Other exclusions stay.
export const pendingTestDrafts = async (store, automation, plan, options) => {
  if (!options.test || !Array.isArray(options.targets)) {
    return [];
  }
  const pending = new Set(
    plan.excluded
      .filter((item) => item.reason === 'draft-pending')
      .map((item) => item.key)
  );
  const found = [];
  for (const target of options.targets) {
    if (pending.has(`${target.source}:${target.chat}`)) {
      const draft = await store.get(draftId(automation, target));
      if (
        draft?.status === 'pending' &&
        !found.some((item) => item.id === draft.id)
      ) {
        found.push(draft);
      }
    }
  }
  return found;
};

/** What the user can do with a pending safe-mode draft. */
export const draftOperations = ({
  store,
  load,
  deliver,
  nowIso,
  afterSend = async () => {},
}) => {
  const pendingDraft = async (id) => {
    const draft = await store.get(id);
    if (!draft?.id?.startsWith(DRAFT_PREFIX)) {
      throw new Error(`no draft ${id}`);
    }
    return { draft, automation: await load(draft.automation) };
  };

  const settleDraft = async (id, status, extra = {}) => {
    const { draft, automation } = await pendingDraft(id);
    const record = runRecord(automation, draft, {
      status,
      at: nowIso(),
      ...extra,
    });
    await store.put(record);
    await store.delete(id);
    return { status, draft, record };
  };

  return {
    async previewDraft(id, options = {}) {
      const { draft, automation } = await pendingDraft(id);
      return globalThis.structuredClone(
        renderDraft(automation, draft, options)
      );
    },
    /** Pending drafts, optionally for one chat or one automation. */
    async drafts({ source, chat, automation } = {}) {
      const owner = automation
        ? `${AUTOMATION_PREFIX}${automationKey(automation)}`
        : null;
      return store.query(
        (l) =>
          l?.id?.startsWith(DRAFT_PREFIX) &&
          (!source || l.source === source) &&
          (chat === undefined || String(l.chat) === String(chat)) &&
          (!owner || l.automation === owner)
      );
    },
    /** Send one draft after the user confirmed it (optionally edited). */
    async sendDraft(id, { confirm = false, text, form, confirmedDraft } = {}) {
      if (!confirm) {
        throw new ConfirmationRequiredError(
          'safe mode sends one message per confirmation; pass confirm: true'
        );
      }
      const { draft: stored, automation } = await pendingDraft(id);
      const draft = renderDraft(automation, stored, { text, form });
      if (
        confirmedDraft &&
        draftConfirmationKey(draft) !== draftConfirmationKey(confirmedDraft)
      ) {
        return {
          status: 'failed',
          code: 'draft-changed',
          error: 'The draft changed. Review it again before sending',
          draft,
        };
      }
      const outcome = await deliver(automation, draft, { reviewed: true });
      if (outcome.status === 'sent') {
        await store.delete(id);
        await afterSend(automation, draft);
      }
      return outcome;
    },
    /** Re-render a pending draft in the other "ты"/"вы" form. */
    async setDraftForm(id, form) {
      const { draft, automation } = await pendingDraft(id);
      const next = redraftWithForm(automation, draft, form);
      await store.put(next);
      return next;
    },
    /** The user sent it in their own app. */
    markSent: (id) => settleDraft(id, 'sent', { manual: true }),
    skip: (id) => settleDraft(id, 'skipped'),
  };
};
