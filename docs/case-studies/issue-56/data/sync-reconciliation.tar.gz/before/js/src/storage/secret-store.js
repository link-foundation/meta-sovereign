/**
 * Encrypted-at-rest decorator for `secret:*` links (R-J9 / ROADMAP §8).
 *
 * `wrapSecretStore({ inner, passphrase })` returns a Universal Links
 * Access store that transparently encrypts/decrypts the payload of any
 * link whose `id` starts with `secret:`. Non-secret links pass through
 * untouched so contacts, messages, patterns etc. keep their normal
 * shape (the universal store invariant — the data store IS the API —
 * stays intact).
 *
 * Cipher: AES-256-GCM, scrypt(N=2^14)-derived key, random salt + IV per
 * write. The ciphertext envelope is the same JSON shape the encrypted
 * backup format already uses (see `encryptBackup`/`decryptBackup` in
 * `./backup.js`) so a single passphrase decrypts both surfaces.
 *
 * On disk the encrypted link looks like:
 *   { id: 'secret:telegram:bot-token',
 *     tokens: ['secret', 'telegram', 'bot-token'], // id parts only
 *     enc: '{"version":1,"cipher":"aes-256-gcm",...}' }
 *
 * `tokens` is regenerated from the id so it carries no plaintext, but
 * the binary store can still index/range-scan by id without knowing
 * the passphrase. The original `tokens`, `body`, `value`, etc. live
 * inside `enc` and are restored on read.
 *
 * If no passphrase is provided, `wrapSecretStore` returns the inner
 * store unchanged — encryption is opt-in via `MS_SECRET_PASSPHRASE`
 * (or the `passphrase` option on `startServer`).
 */

import { changedLink } from './mutation.js';
import { encryptBackup, decryptBackup } from './backup.js';

const SECRET_PREFIX = 'secret:';

const isSecret = (link) =>
  link && typeof link.id === 'string' && link.id.startsWith(SECRET_PREFIX);

const idTokens = (id) => id.split(':');

const sealLink = (link, passphrase) => {
  const { id, ...rest } = link;
  const enc = encryptBackup(JSON.stringify(rest), passphrase);
  return { id, tokens: idTokens(id), enc };
};

const openLink = (link, passphrase) => {
  if (!link || typeof link.enc !== 'string') {
    return link;
  }
  const rest = JSON.parse(decryptBackup(link.enc, passphrase));
  return { id: link.id, ...rest };
};

export const wrapSecretStore = ({ inner, passphrase }) => {
  if (!passphrase) {
    return inner;
  }
  return {
    // A backup streams the log as stored (secrets sealed) and a restore
    // puts them back unsealed-again-free (R-Z16).
    rawStore: inner,
    logFile: inner.logFile,
    flushLog: inner.flushLog,
    size: inner.size ? () => inner.size() : undefined,
    memoryStats: inner.memoryStats ? () => inner.memoryStats() : undefined,
    async put(link, options) {
      if (isSecret(link)) {
        const sealed = sealLink(link, passphrase);
        await inner.put(sealed, options);
        return link;
      }
      return inner.put(link, options);
    },
    async update(id, change, options) {
      const out = await inner.update(
        id,
        (before) => {
          const opened =
            before?.enc && id.startsWith(SECRET_PREFIX)
              ? openLink(before, passphrase)
              : before;
          const next = changedLink(id, change, opened);
          return isSecret(next) ? sealLink(next, passphrase) : next;
        },
        options
      );
      return isSecret(out) ? openLink(out, passphrase) : out;
    },
    async get(id) {
      const raw = await inner.get(id);
      if (!raw) {
        return raw;
      }
      if (id.startsWith(SECRET_PREFIX) && raw.enc) {
        return openLink(raw, passphrase);
      }
      return raw;
    },
    async delete(id, options) {
      return inner.delete(id, options);
    },
    async query(filter) {
      // Apply non-secret filters before cloning the archive. A typing or health
      // poll must not allocate a copy of every stored message.
      const all = await inner.query(
        filter ? (link) => isSecret(link) || filter(link) : undefined
      );
      const opened = all.map((l) =>
        l.id.startsWith(SECRET_PREFIX) && l.enc ? openLink(l, passphrase) : l
      );
      return filter ? opened.filter(filter) : opened;
    },
    async scan(filter, size, onBatch, project = (link) => ({ ...link })) {
      if (!inner.scan) {
        const all = await this.query(filter);
        for (let at = 0; at < all.length; at += size) {
          await onBatch(all.slice(at, at + size).map(project));
        }
        return all.length;
      }
      return inner.scan(
        (link) => isSecret(link) || !filter || filter(link),
        size,
        async (batch) => {
          const out = [];
          for (const item of batch) {
            const link =
              item.secret && item.value.enc
                ? openLink(item.value, passphrase)
                : item.value;
            if (!item.secret || !filter || filter(link)) {
              out.push(item.secret ? project(link) : link);
            }
          }
          if (out.length) {
            await onBatch(out);
          }
        },
        (link) => ({
          secret: isSecret(link),
          value: isSecret(link) ? link : project(link),
        })
      );
    },
    subscribe(handler) {
      return inner.subscribe((event) => {
        if (event.link && isSecret(event.link) && event.link.enc) {
          handler({ ...event, link: openLink(event.link, passphrase) });
          return;
        }
        handler(event);
      });
    },
  };
};

export const isSecretLinkId = (id) =>
  typeof id === 'string' && id.startsWith(SECRET_PREFIX);
