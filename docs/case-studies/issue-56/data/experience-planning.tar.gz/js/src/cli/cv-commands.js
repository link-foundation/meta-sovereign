/**
 * CV subcommands (issue #29, R-V17).
 *
 * The terminal gets the same surface as the HTTP API: the catalogue
 * and the dry-run plans answer without a browser, `cv-read`/`cv-sync`
 * drive one through the facade, and `cv-telemetry` replays what a run
 * recorded so a failed live run is debuggable after the fact.
 *
 * The command map is built by a factory so the CLI entry point injects
 * its own `openStore` (and the tests inject a fake commander) without
 * this module importing the entry point back.
 */

import { defaultStoreDir } from '../storage/app-directory.js';
import {
  compareAllCvs,
  cvPlatformCatalogue,
  diffAllCvs,
  formatExperienceComparison,
  dryRunPlan,
  getCvPlatform,
  listCvPlatforms,
  loadCvTelemetry,
  loadStoredCvs,
  readAllCvs,
  summarizeCvRuns,
  syncCvAcross,
} from '../cv/index.js';
import { confirmCli } from './confirm.js';
import { createLinkedinExperienceCommands } from './cv-linkedin-experience-command.js';
import { createExperienceCommands } from './cv-experience-commands.js';
import { createExperiencePlanCommands } from './cv-experience-plan-command.js';

export { CV_HELP } from './help.js';

/** `--platforms=a,b` (or repeated commas) — defaults to every platform. */
export const parsePlatforms = (value) => {
  const ids =
    typeof value === 'string' && value.trim()
      ? value
          .split(',')
          .map((id) => id.trim())
          .filter(Boolean)
      : listCvPlatforms();
  for (const id of ids) {
    // Throws listing the known ids, which the CLI prints as an error.
    getCvPlatform(id);
  }
  return ids;
};

/**
 * `--paths=basics.headline,skills` / `--groups=intro,skills` — the
 * user narrowing a write to part of the CV. Absent means "everything
 * the platform allows".
 * @returns {string[]|null}
 */
export const parseList = (value) => {
  if (typeof value !== 'string' || !value.trim()) {
    return null;
  }
  const items = value
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);
  return items.length > 0 ? items : null;
};

/**
 * Template variables for a plan: `--vars` takes a JSON object and
 * `--login` is the shorthand every platform's profile URL needs.
 */
export const parseVars = (args) => {
  const vars = args.vars ? JSON.parse(args.vars) : {};
  for (const key of ['login', 'resumeId', 'profileId']) {
    if (args[key]) {
      vars[key] = args[key];
    }
  }
  return vars;
};

const flagOff = (value) => value === false || value === 'false';
const runHeadless = (args) => {
  if (args.headed === true || args.headed === 'true') {
    return false;
  }
  if (args.headless === undefined) {
    return undefined;
  }
  if (![true, false, 'true', 'false'].includes(args.headless)) {
    throw new Error('--headless must be true or false');
  }
  return args.headless === true || args.headless === 'true';
};

/** Options every live command shares. */
const liveOptions = (args, store, extra) => ({
  store,
  vars: parseVars(args),
  headless: runHeadless(args),
  browserSlot: args['browser-slot'] ?? 'main',
  profileDir: args.profile ?? null,
  artifactDir: args.artifacts ?? null,
  save: !(args['no-save'] === true || flagOff(args.save)),
  recordTelemetry: !flagOff(args.telemetry),
  ...extra,
});

const asJson = (value) => JSON.stringify(value, null, 2);

const reportFailures = (failures, log) => {
  for (const failure of failures ?? []) {
    log(`! ${failure.platform}: ${failure.code} — ${failure.message}`);
  }
  return failures?.length ? 1 : 0;
};

const platformsCmd = async (args, log) => {
  const catalogue = cvPlatformCatalogue();
  if (args.json) {
    log(asJson(catalogue));
    return 0;
  }
  for (const platform of catalogue) {
    log(
      `${platform.id}\t${platform.label}\t${platform.markupAccess}\t` +
        `read ${platform.readPaths.length} paths, write ${platform.writePaths.length}\t` +
        `${platform.confidence.verified} verified / ` +
        `${platform.confidence.draft} draft steps`
    );
  }
  return 0;
};

const planCmd = async (args, log) => {
  const plan = dryRunPlan(getCvPlatform(args.platform ?? ''));
  if (args.json) {
    log(asJson(plan));
    return 0;
  }
  log(
    `${plan.platform}: ${plan.label} — ${plan.read.length} read steps, ` +
      `${plan.update.length} write groups, markup ${plan.markupAccess}`
  );
  for (const step of plan.read) {
    log(
      `  read   ${step.action}\t${step.target ?? ''}\t[${step.confidence}]${
        step.optional ? '\t(optional)' : ''
      }`
    );
  }
  for (const group of plan.update) {
    log(`  write  ${group.id}\t${group.paths.join(', ')}`);
  }
  for (const item of plan.evidence) {
    log(`  source ${item}`);
  }
  return 0;
};

const readCmd = async (args, log, openStore, injected) => {
  const store = await openStore(args.store ?? defaultStoreDir());
  const ids = parsePlatforms(args.platforms);
  const { entries, failures } = await readAllCvs(
    ids,
    liveOptions(args, store, injected)
  );
  if (args.json) {
    log(asJson({ entries, failures }));
    return failures.length ? 1 : 0;
  }
  for (const entry of entries) {
    log(
      `${entry.platform}\t${entry.fields} fields\t${entry.url ?? ''}${
        entry.warnings.length ? `\t(${entry.warnings.length} warnings)` : ''
      }`
    );
  }
  return reportFailures(failures, log);
};

const diffCmd = async (args, log, openStore) => {
  const store = await openStore(args.store ?? defaultStoreDir());
  const entries = await loadStoredCvs(store, parsePlatforms(args.platforms));
  const comparison = compareAllCvs(entries, { prefer: args.prefer ?? null });
  const diffs = diffAllCvs(entries, null);
  if (args.json) {
    log(asJson({ entries, comparison, diffs }));
    return 0;
  }
  if (entries.length === 0) {
    log('no stored CV snapshots — run cv-read first');
    return 1;
  }
  log(`platforms: ${entries.map((entry) => entry.platform).join(', ')}`);
  log(`agreed on ${comparison.agreed} of ${comparison.rows.length} fields`);
  if (comparison.experience) {
    log(formatExperienceComparison(comparison.experience));
  }
  for (const row of comparison.rows.filter(
    (item) => item.conflict || item.missing.length
  )) {
    const values = Object.entries(row.values)
      .map(([platform, value]) => `${platform}=${JSON.stringify(value)}`)
      .join(' ');
    log(
      `  ${row.conflict ? '≠' : '·'} ${row.path}\t${values}${
        row.missing.length ? `\tmissing: ${row.missing.join(',')}` : ''
      }`
    );
  }
  return 0;
};

// Show the dry run's plan, then write exactly it once the user agrees;
// null when they did not.
const applyConfirmed = async (preview, { args, log, ask, run }) => {
  for (const action of preview.actions) {
    log(`  ${action.platform}\t${action.paths.join(', ')}`);
  }
  const ok = await confirmCli(
    `Write these changes to ${preview.actions.length} platform(s)?`,
    { args, log, ask }
  );
  return ok
    ? run(false, { target: preview.target, actions: preview.actions })
    : null;
};

const syncCmd = async (args, log, openStore, injected) => {
  const store = await openStore(args.store ?? defaultStoreDir());
  const ids = parsePlatforms(args.platforms);
  const run = (dryRun, confirmed = null) =>
    syncCvAcross(ids, {
      ...liveOptions(args, store, injected),
      dryRun,
      confirmed,
      prefer: args.prefer ?? null,
      paths: parseList(args.paths),
      groups: parseList(args.groups),
    });
  const preview = await run(true);
  const apply = args.apply === true || args.apply === 'true';
  const result = apply
    ? await applyConfirmed(preview, { args, log, ask: injected?.ask, run })
    : preview;
  if (!result) {
    return 1;
  }
  if (args.json) {
    log(asJson(result));
    return result.failures.length ? 1 : 0;
  }
  log(result.dryRun ? 'dry run — nothing was written' : 'applying changes');
  for (const action of result.actions) {
    const narrowed = action.deselected
      ? `\t(${action.deselected} deselected)`
      : '';
    log(`  ${action.platform}\t${action.paths.join(', ')}${narrowed}`);
  }
  for (const applied of result.applied) {
    log(
      `  applied ${applied.platform}\t${(applied.applied ?? []).join(', ')}${
        (applied.warnings ?? []).length
          ? `\t(${applied.warnings.length} warnings)`
          : ''
      }`
    );
  }
  return reportFailures(result.failures, log);
};

const telemetryCmd = async (args, log, openStore) => {
  const store = await openStore(args.store ?? defaultStoreDir());
  const events = await loadCvTelemetry(store, {
    runId: args.run ?? null,
    platform: args.platform ?? null,
    type: args.type ?? null,
    limit: Number(args.limit ?? 500),
  });
  if (args.json) {
    log(asJson({ runs: summarizeCvRuns(events), events }));
    return 0;
  }
  for (const run of summarizeCvRuns(events)) {
    const counts = Object.entries(run.counts)
      .map(([type, n]) => `${type}=${n}`)
      .join(' ');
    log(`${run.runId}\t${run.platform}\t${run.mode}\t${counts}`);
    for (const problem of run.problems) {
      log(`  ! ${problem}`);
    }
  }
  return 0;
};

/**
 * An unknown platform or a missing browser is a user-facing message,
 * not a stack trace: report it on the CLI's log and exit non-zero.
 */
const guarded = (fn) => async (args, log) => {
  try {
    return await fn(args, log);
  } catch (error) {
    log(`error: ${error.message}`);
    if (error.code === 'browser-unavailable') {
      log(`install: npm i ${(error.missing ?? []).join(' ')}`);
    }
    return 1;
  }
};

/**
 * @param {object} deps
 * @param {Function} deps.openStore directory → store
 * @param {object} [deps.live] injected `commander`/`openSession` for tests
 */
export const createCvCommands = ({
  openStore,
  openReadOnly = openStore,
  live = {},
}) =>
  Object.fromEntries(
    Object.entries({
      ...createExperienceCommands(openStore),
      ...createExperiencePlanCommands(
        { openStore, openReadOnly },
        live.experiencePlanning
      ),
      ...createLinkedinExperienceCommands(
        { openStore, openReadOnly },
        live.experience
      ),
      'cv-platforms': platformsCmd,
      'cv-plan': planCmd,
      'cv-read': (args, log) => readCmd(args, log, openStore, live),
      'cv-diff': (args, log) => diffCmd(args, log, openStore),
      'cv-sync': (args, log) => syncCmd(args, log, openStore, live),
      'cv-telemetry': (args, log) => telemetryCmd(args, log, openStore),
    }).map(([name, fn]) => [name, guarded(fn)])
  );
