import { nativeApplicationForm } from '../../js/tests/helpers/application-native-request.mjs';
import { changeApplicationHoldFixture } from './application-hold-dom.mjs';
import { applicationLimitMs } from '../../js/src/jobs/application-limit-data.js';
import { mountApplicationLimitChallenge } from './application-limit-challenge-dom.mjs';
import { rejectNativeApplicationAtLimit } from './application-limit-rejection-dom.mjs';

const changeChallenge = async (page, url) => {
  if (url === '/limit-reject-next') {
    await page.evaluate(rejectNativeApplicationAtLimit);
  }
  if (url !== '/limit-challenge' && url !== '/limit-challenge-remount') {
    return;
  }
  await page.evaluate(mountApplicationLimitChallenge);
  if (url === '/limit-challenge-remount') {
    await page.locator('[data-qa-popup-error-code]').evaluate((node) => {
      node.hidden = true;
    });
  }
};

/** Isolated synthetic fixture controls; never application product routes. */
export const applicationLimitControl = (browser, clock) => async (req) => {
  if (
    ![
      '/limit-show',
      '/limit-dismiss',
      '/limit-expire',
      '/limit-values',
      '/limit-edit',
      '/limit-edit-later',
      '/limit-letter',
      '/limit-letter-later',
      '/limit-challenge',
      '/limit-challenge-remount',
      '/limit-reject-next',
    ].includes(req.url)
  ) {
    return null;
  }
  const page = nativeApplicationForm(browser);
  if (!page) {
    throw new Error('No owned synthetic form for daily limit');
  }
  if (req.method === 'POST') {
    await changeChallenge(page, req.url);
    if (req.url === '/limit-letter' || req.url === '/limit-letter-later') {
      const letter = page.locator(
        '[data-qa="vacancy-response-form-letter-input"]'
      );
      if (!(await letter.count())) {
        await page.locator('[data-qa="add-cover-letter"]').click();
      }
      await letter.fill(
        req.url === '/limit-letter'
          ? 'Actual owner letter before waiting.'
          : 'Later owner letter while waiting.'
      );
    }
    if (req.url === '/limit-edit' || req.url === '/limit-edit-later') {
      await page
        .locator('#experience')
        .fill(
          req.url === '/limit-edit'
            ? 'Original owner answer before waiting.'
            : 'Later native owner answer while waiting.'
        );
    }
    if (req.url === '/limit-show' || req.url === '/limit-dismiss') {
      await page.evaluate(
        changeApplicationHoldFixture,
        req.url === '/limit-show' ? 'daily-limit' : 'clear'
      );
    }
    if (req.url === '/limit-expire') {
      clock.value += applicationLimitMs;
    }
  }
  return page.evaluate(() => ({
    experience: document.querySelector('#experience')?.value,
    letter: document.querySelector(
      '[data-qa="vacancy-response-form-letter-input"]'
    )?.value,
    entries: globalThis.applicationEntries,
    sends: globalThis.applicationAttempts,
    challengeCloses: globalThis.limitCaptchaCloses ?? 0,
    challengeActions: globalThis.limitCaptchaActions ?? 0,
    challengeVisible: Boolean(document.querySelector('#limit-captcha')),
  }));
};
