async (page) => {
  const assert = { equal(a, b) { if (a !== b) throw new Error('Browser assertion failed'); } };
  const translate = (_locale, key) => ({"questions.sharedLoad":"Load profiles","questions.sharedSelect":"Linked profile","questions.shared.id":"Profile identifier","questions.salaryEnabled":"Use configured salary targets","questions.salaryApproved":"Approve complete salary answers for automatic sending","questions.salaryHours":"Work hours per month (empty disables hourly answers)","questions.salaryAdd":"Add salary currency","questions.salaryCode":"Currency code, e.g. USD","questions.salaryKeywords":"Currency words, comma-separated","questions.salary.net":"Monthly net amount","questions.salary.gross":"Monthly gross amount","questions.salaryDefault":"Default salary currency"})[key];
  const applicationAnswerSalary = {"enabled":true,"approved":true,"exchangeMode":"snapshot","defaultCurrency":"RUB","defaultBasis":"net","monthlyHours":160,"currencies":[{"code":"USD","keywords":["USD"],"net":6200,"gross":7400},{"code":"RUB","keywords":["RUB"],"net":450000,"gross":530000}]};
  const applicationPanelBrowser = (fixture) => {
  const { page } = fixture;
  page.setDefaultTimeout(10000);
  const panel = page.locator('[data-application-panel]');
  const action = (name) => panel.locator(`[data-application-action="${name}"]`);
  const confirm = () =>
    panel.locator('[data-application-option="confirm"]').check();
  return {
    page,
    panel,
    action,
    confirm,
    batch() {
      const batch = panel.locator('[data-application-batch]');
      return {
        batch,
        field: (name) =>
          batch.locator(`[data-application-batch-field="${name}"]`),
        button: (name) =>
          batch.locator(`[data-application-batch-action="${name}"]`),
        phase: (name) =>
          batch
            .locator(`[data-application-batch-phase="${name}"]`)
            .waitFor({ timeout: 60000 }),
      };
    },
    screenshot(directory, prefix) {
      return async (name) => {
        if (directory) {
          await mkdir(directory, { recursive: true });
          await panel.screenshot({
            path: join(directory, `${prefix}-${name}.png`),
          });
        }
      };
    },
    async locales(selector, verify = async () => {}) {
      for (const locale of ['ru', 'hi', 'zh', 'en']) {
        await page.evaluate(
          (value) =>
            globalThis.localStorage.setItem('metaSovereignLocale', value),
          locale
        );
        await page.reload();
        await panel.locator(selector).waitFor();
        assert.equal(
          /\bapplication\.[a-z]/iu.test(await panel.innerText()),
          false
        );
        await verify(locale);
      }
    },
    async phone() {
      await page.setViewportSize({ width: 390, height: 1440 });
      assert.equal(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= globalThis.innerWidth
        ),
        true
      );
    },
    async close(owned) {
      await action('close').click();
      await panel.locator('[data-application-state="closed"]').waitFor();
      assert(owned.isClosed());
      assert(fixture.records.every((record) => record.closed));
      assert.deepEqual(fixture.errors, []);
    },
    async confirmed(name) {
      await confirm();
      await action(name).click();
      // A batch can close this delivered browser and move to its next review.
      // Completion needs an accepted, idle receipt, not an active native page.
      await page.waitForFunction(
        () =>
          !document.querySelector('[data-application-option="confirm"]')
            .checked &&
          !document.querySelector('[data-application-action="recover"]')
            .disabled &&
          !document.querySelector('[data-application-unknown]')
      );
    },
    async select() {
      await page.goto(`${fixture.base}/#/cv`);
      const vacancies = page.locator('[data-vacancies]');
      await vacancies.locator('[data-vacancy-field="query"]').fill('Python');
      await vacancies.locator('[data-vacancy-action="search"]').click();
      await vacancies
        .locator('[data-vacancy-action="collect"]')
        .first()
        .click();
      await panel.locator('[data-application-missing]').waitFor();
      const languagePolicy = panel.locator(
        '[data-application-option="autoSelectResumeLanguage"]'
      );
      if (await languagePolicy.count()) {
        await languagePolicy.uncheck();
      }
      return vacancies;
    },
  };
};
  const configureApplicationAnswerContext = async (panel) => {
  const t = (key) => translate('en', key);
  const context = panel.locator('[data-application-answer-context]');
  const profile = context.locator('[data-shared-profile]');
  await profile.locator(':scope > summary').click();
  await profile
    .getByRole('button', { name: t('questions.sharedLoad'), exact: true })
    .click();
  await profile
    .getByLabel(t('questions.sharedSelect'), { exact: true })
    .selectOption('qa-profile:questionnaire');
  await profile
    .getByLabel(t('questions.shared.id'), { exact: true })
    .filter({ visible: true })
    .waitFor();
  await profile.locator(':scope > summary').click();
  const salary = context.locator('[data-answer-salary]');
  await salary.locator(':scope > summary').click();
  await salary
    .getByLabel(t('questions.salaryEnabled'), { exact: true })
    .check();
  await salary
    .getByLabel(t('questions.salaryApproved'), { exact: true })
    .check();
  await salary
    .getByLabel(t('questions.salaryHours'), { exact: true })
    .fill('160');
  for (const [
    index,
    currency,
  ] of applicationAnswerSalary.currencies.entries()) {
    if (index) {
      await salary
        .getByRole('button', { name: t('questions.salaryAdd'), exact: true })
        .click();
    }
    const row = salary.locator('[data-salary-currency]').nth(index);
    for (const [key, value] of Object.entries({
      Code: currency.code,
      Keywords: currency.keywords.join(', '),
    })) {
      await row
        .getByLabel(t(`questions.salary${key}`), { exact: true })
        .fill(value);
    }
    for (const key of ['net', 'gross']) {
      await row
        .getByLabel(t(`questions.salary.${key}`), { exact: true })
        .fill(String(currency[key]));
    }
  }
  await salary
    .getByLabel(t('questions.salaryDefault'), { exact: true })
    .selectOption('RUB');
  await salary.locator(':scope > summary').click();
};
  return (async (page, createControls) => {
  const assert = { equal(a, b) { if (a !== b) throw new Error('Browser assertion failed: '+JSON.stringify({actual:a,expected:b})); } };
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  const controls = createControls({ page, base: "http://127.0.0.1:40747" });
  const { panel, action } = controls;
  await controls.select();
  const before = await (await page.request.get("http://127.0.0.1:38423")).json();
  const check = panel.locator('[data-application-option="collectVacancies"]');
  assert.equal(await check.isChecked(), true);
  await check.uncheck();
  await action('start').click();
  await panel.locator('[data-application-state="ready"]').waitFor();
  await panel.locator('[data-application-collection="memory"]').waitFor();
  assert.equal((await panel.locator('[data-application-description]').innerText()).includes('Employer’s final paragraph stays intact.'), true);
  await panel.screenshot({ path: 'docs/screenshots/issue-56-application-collection/mcp-desktop.png' });
  await controls.locales('[data-application-collection="memory"]');
  await controls.phone();
  await panel.screenshot({ path: 'docs/screenshots/issue-56-application-collection/mcp-phone.png' });
  await action('close').click();
  await panel.locator('[data-application-state="closed"]').waitFor();
  await page.reload();
  await panel.waitFor();
  assert.equal(await panel.locator('[data-application-description]').count(), 0);
  const stats = await (await page.request.get("http://127.0.0.1:38423")).json();
  assert.equal(stats.collection, false);
  assert.equal(stats.journalVacancy, false);
  assert.equal(stats.cacheEntries, 1);
  assert.equal(stats.cacheFingerprint, before.cacheFingerprint);
  assert.equal(stats.closed, true);
  assert.equal(stats.clicks, 0);
  assert.equal(stats.errors.length, 0);
  assert.equal(errors.length, 0);
  return { collection: false, locales: 4, completeContext: true, offlineContext: null, desktopAndPhoneFit: true, pageErrors: errors, ...stats };
})(page, applicationPanelBrowser, configureApplicationAnswerContext);
}