/**
 * Q&A Database module using Links Notation parser
 * Manages reading and writing Q&A pairs from qa.lino file
 *
 * IMPORTANT: This module REQUIRES explicit file path configuration!
 * Use createQADatabase(filePath) to create an instance.
 *
 * ============================================================================
 * LINKS NOTATION FORMAT - Multiline Support
 * ============================================================================
 *
 * Links Notation NATIVELY supports multiline strings through indentation:
 *
 * Format:
 *   Question (no indentation)
 *     Answer line 1 (2 spaces)
 *     Answer line 2 (2 spaces)
 *     Answer line 3 (2 spaces)
 *
 * Key Features:
 * - Questions are NOT indented (0 spaces)
 * - Answers are indented with exactly 2 spaces
 * - Multiline answers: EVERY line must have 2-space indentation
 * - Newlines are preserved NATURALLY - DO NOT use \n escaping!
 * - Only quote characters (") need escaping if present in content
 *
 * Example:
 *   What is your experience?
 *     I have worked with:
 *     - JavaScript for 5 years
 *     - Python for 3 years
 *
 * This format preserves multiline content without any special escape sequences.
 * ============================================================================
 */
import { Parser } from 'links-notation';
import fs from 'fs/promises';
import path from 'path';
import { createMutex, withFileLock } from './helpers/mutex.mjs';
import { normalizeAnswerVariants, resolveAnswerConflict } from './answer-variants.mjs';
import { composeQuestionAnswer, expandQuestionAnswers, splitQuestions } from './multi-question.mjs';

/**
 * Creates a Q&A database instance with the specified file path
 * @param {string} filePath - REQUIRED: Path to the qa.lino file
 * @param {Object} [options]
 * @param {boolean} [options.resolveVariants=false] - Resolve final-period answer conflicts on save/load
 * @param {boolean} [options.decomposeQuestions=options.resolveVariants] - Retain aligned individual Q&A alongside full questionnaires
 * @param {'with'|'without'} [options.finalPeriod] - Override the user's ANSWER_FINAL_PERIOD setting
 * @returns {Object} Q&A database instance with methods
 * @throws {Error} If filePath is not provided
 */
export function createQADatabase(filePath, { resolveVariants = false, finalPeriod, decomposeQuestions = resolveVariants } = {}) {
  if (!filePath) {
    throw new Error(
      'CRITICAL: QA Database file path is REQUIRED!\n' +
      'Usage: createQADatabase("/path/to/qa.lino")\n' +
      'This prevents accidental usage without explicit path configuration.',
    );
  }

  const QA_FILE_PATH = filePath;
  // The parser also serves configuration files; only answer databases opt into resolution.
  const normalize = (answer, question) => resolveVariants ? normalizeAnswerVariants(answer, { finalPeriod, question }) : answer;

  const exclusive = createMutex();

  /**
   * Reads Q&A pairs from qa.lino file
   *
   * IMPORTANT: Links Notation multiline indented format:
   * - Each indented line creates a SEPARATE link with the same question
   * - Multiple short answers (< 150 chars, unquoted) are kept as array (checkbox options)
   * - Multiple long/quoted answers are combined with newlines (multiline text)
   * - Example file format:
   *     Question
   *       Answer line 1
   *       Answer line 2
   *   Becomes 3 separate links in parser, we combine into 1 Q&A pair
   *
   * @returns {Promise<Map<string, string|Array<string>>>} Map of questions to answers
   */
  async function readRawQADatabase() {
    try {
      // Ensure data directory exists
      await fs.mkdir(path.dirname(QA_FILE_PATH), { recursive: true });

      // Try to read the file
      const content = await fs.readFile(QA_FILE_PATH, 'utf8');

      // Parse using Links Notation
      const parser = new Parser();
      const links = parser.parse(content);

      // Extract Q&A pairs from parsed links
      // Note: Multiple indented answer lines create multiple links with same question
      // Strategy:
      // - If answers look like separate options (short, no internal newlines), keep as array
      // - Otherwise, treat as multiline text and concatenate with newlines
      const qaMap = new Map();
      const answersByQuestion = new Map(); // Temporary: collect all answers per question

      for (const link of links) {
        if (link._isFromPathCombination && link.values && link.values.length === 2) {
          const question = extractText(link.values[0]);
          const answer = extractText(link.values[1]);

          if (question && answer) {
            if (!answersByQuestion.has(question)) {
              answersByQuestion.set(question, []);
            }
            answersByQuestion.get(question).push(answer);
          }
        }
      }

      // Process collected answers
      for (const [question, answers] of answersByQuestion.entries()) {
        if (answers.length === 1) {
          // Single answer - store as-is
          qaMap.set(question, answers[0]);
        } else {
          // Multiple answers - check if they're checkbox options or multiline text
          // Heuristic: if all answers are short (< 150 chars) and have no quotes, likely checkboxes
          const allShort = answers.every(a => a.length < 150);
          const anyQuoted = answers.some(a =>
            (a.startsWith('"') && a.endsWith('"')) ||
            (a.startsWith("'") && a.endsWith("'")),
          );

          if (allShort && !anyQuoted) {
            // Likely checkbox options - store as array (join with special delimiter)
            qaMap.set(question, answers);
          } else {
            // Multiline text - concatenate with newlines
            qaMap.set(question, answers.join('\n'));
          }
        }
      }

      return qaMap;
    } catch (error) {
      if (error.code === 'ENOENT') {
        // File doesn't exist yet, return empty map
        return new Map();
      }

      console.error('Error reading Q&A database:', error);
      return new Map();
    }
  }

  // A bad style setting must propagate to the writer, never masquerade as an empty database.
  async function readQADatabase() {
    const raw = await readRawQADatabase();
    return new Map([...(decomposeQuestions ? expandQuestionAnswers(raw) : raw)].map(([question, answer]) => [question, normalize(answer, question)]));
  }

  /**
   * Escapes a link reference for safe use in Links Notation format
   *
   * IMPORTANT: Link references cannot contain certain characters unquoted:
   * - Newlines (\n) - must be quoted to preserve as single reference
   * - Quotes (" or ') - must be wrapped and escaped
   * - Colons (:) - delimiter for self-reference, must be quoted in content
   * - Parentheses (()) - borders of nested links, must be quoted in content
   *
   * Simple quoting rules:
   *   - Has " but not ' → wrap with '...'
   *   - Has ' but not " → wrap with "..."
   *   - Has both " and ' → wrap with "..." and use "" to escape "
   *   - Has colon/parens/newlines but no quotes → wrap with "..."
   *
   * Issue #78: Quote strings with special chars to preserve literal text
   * @param {string} str - String to format (preserves newlines as-is)
   * @returns {string} Escaped link reference (may be quoted if needed)
   */
  function escapeReference(str) {
    // Check for characters that need quoting
    const hasColon = str.includes(':');
    const hasDoubleQuotes = str.includes('"');
    const hasSingleQuotes = str.includes("'");
    const hasParens = str.includes('(') || str.includes(')');
    const hasNewline = str.includes('\n');
    // Unquoted, repeated or edge spaces are read back as one: «года.  Соотношение»
    const hasSpacing = /\s\s|^\s|\s$/.test(str);

    const needsQuoting = hasColon || hasDoubleQuotes || hasSingleQuotes || hasParens || hasNewline || hasSpacing;

    if (needsQuoting) {
      if (hasDoubleQuotes && !hasSingleQuotes) {
        // Has " but not ' → use single quotes
        return `'${str}'`;
      } else if (hasSingleQuotes && !hasDoubleQuotes) {
        // Has ' but not " → use double quotes
        return `"${str}"`;
      } else if (hasDoubleQuotes && hasSingleQuotes) {
        // Has both " and ' → choose the wrapper with fewer escapes needed
        const doubleQuoteCount = (str.match(/"/g) || []).length;
        const singleQuoteCount = (str.match(/'/g) || []).length;

        if (singleQuoteCount < doubleQuoteCount) {
          // Fewer single quotes → wrap with " and escape ' as ''
          const escaped = str.replace(/'/g, "''");
          return `"${escaped}"`;
        } else {
          // Fewer or equal double quotes → wrap with ' and escape " as ""
          const escaped = str.replace(/"/g, '""');
          return `'${escaped}'`;
        }
      } else {
        // Has colon, parentheses, or newlines but no quotes → use double quotes
        return `"${str}"`;
      }
    }

    // No special characters - no quoting needed
    return str;
  }

  /**
   * Writes Q&A pairs to qa.lino file
   *
   * IMPORTANT: Links Notation multiline format:
   * - Questions are not indented
   * - Answers are indented with 2 spaces
   * - If answer contains newlines, EVERY line must be indented with 2 spaces
   * - If answer is an array (checkboxes), each option on separate indented line
   * - This preserves multiline content naturally without \n escaping
   *
   * Optimization: Skips writing if content is unchanged (no IO)
   *
   * @param {Map<string, string|Array<string>>} qaMap - Map of questions to answers (string or array)
   */
  async function writeQADatabase(qaMap) {
    try {
      // Ensure data directory exists
      await fs.mkdir(path.dirname(QA_FILE_PATH), { recursive: true });

      // Format as indented Q&A pairs with proper multiline handling
      const lines = [];
      for (const [question, saved] of (decomposeQuestions ? expandQuestionAnswers(qaMap) : qaMap).entries()) {
        const answer = normalize(saved, question);
        // Question handling: escapeReference handles all cases including multiline
        const escapedQuestion = escapeReference(question);
        lines.push(escapedQuestion);

        // Answer handling:
        // - If answer is an array (checkbox options), write each on separate line
        // - If answer is quoted string, write as single quoted multiline
        // - Otherwise, split by newlines and indent each line with 2 spaces
        if (Array.isArray(answer)) {
          // Array of checkbox options - each on separate line
          for (const option of answer) {
            const escapedOption = escapeReference(option);
            lines.push(`  ${escapedOption}`);
          }
        } else {
          const escapedAnswer = escapeReference(answer);
          const isQuoted = escapedAnswer.startsWith('"') || escapedAnswer.startsWith("'");

          if (isQuoted) {
            // Quoted answer - write as-is with 2-space indent (quotes preserve newlines)
            lines.push(`  ${escapedAnswer}`);
          } else {
            // Unquoted answer - split by newlines and indent each line
            const answerLines = escapedAnswer.split('\n');
            for (const answerLine of answerLines) {
              lines.push(`  ${answerLine}`);
            }
          }
        }
      }

      const newContent = lines.join('\n') + '\n';

      // Check if content has changed - skip write if identical (optimization)
      let existingContent = '';
      try {
        existingContent = await fs.readFile(QA_FILE_PATH, 'utf8');
      } catch {
        // File doesn't exist yet, will be created
      }

      if (existingContent === newContent) {
        // No changes - skip write operation
        return;
      }

      // Write new content: a temporary file renamed over the old one, so a reader in another
      // process never sees a half-written file
      const temporary = `${QA_FILE_PATH}.${process.pid}.tmp`;
      await fs.writeFile(temporary, newContent, 'utf8');
      await fs.rename(temporary, QA_FILE_PATH);
    } catch (error) {
      console.error('Error writing Q&A database:', error);
      throw error;
    }
  }

  /**
   * Adds or updates a Q&A pair in the database
   * Uses file locking to prevent race conditions
   * @param {string} question - The question
   * @param {string} answer - The answer
   */
  function addOrUpdateQA(question, answer) {
    // One write at a time in this process, and across processes (the run, form watchers, chats)
    return exclusive(() => withFileLock(QA_FILE_PATH, async () => {
      const qaMap = await readQADatabase();
      qaMap.set(question, resolveVariants ? resolveAnswerConflict(qaMap.get(question), answer, { finalPeriod, question }) : answer);
      await writeQADatabase(qaMap);
    }));
  }

  /** Learn a new question without replacing an answer saved by the user or another process. */
  function addQAIfMissing(question, answer) {
    return exclusive(() => withFileLock(QA_FILE_PATH, async () => {
      const qaMap = await readQADatabase();
      if (qaMap.has(question)) return false;
      qaMap.set(question, answer);
      await writeQADatabase(qaMap);
      return true;
    }));
  }

  /** Persist components of existing questionnaires under the same cross-process lock. */
  function backfillQuestionAnswers() {
    return exclusive(() => withFileLock(QA_FILE_PATH, async () => {
      const raw = await readRawQADatabase();
      const expanded = decomposeQuestions ? expandQuestionAnswers(raw) : raw;
      await writeQADatabase(expanded);
      return { before: raw.size, after: expanded.size, added: expanded.size - raw.size };
    }));
  }

  /**
   * Gets the answer for a given question
   * @param {string} question - The question
   * @returns {Promise<string|null>} The answer, or null if not found
   */
  async function getAnswer(question) {
    const qaMap = await readQADatabase();
    return qaMap.get(question) || null;
  }

  /**
   * Unescapes a link reference from Links Notation format
   *
   * IMPORTANT: Links Notation naturally preserves newlines!
   * - Multiline content is already in the string as actual newlines
   * - Unescape doubled quotes: "" → " and '' → '
   * - DO NOT process \n sequences - they should not exist in properly formatted files
   *
   * @param {string} str - Link reference to unescape (already contains real newlines)
   * @returns {string} Unescaped link reference (only quotes unescaped)
   */
  function unescapeReference(str) {
    if (!str) return str;

    // Unescape doubled quotes (Links Notation escape sequences)
    let unescaped = str.replace(/""/g, '"');  // "" → "
    unescaped = unescaped.replace(/''/g, "'"); // '' → '

    return unescaped;
  }

  /**
   * Extracts text from a Link object
   *
   * IMPORTANT: Links Notation multiline support:
   * - Quoted multiline: "text\nline2" - parser preserves actual newlines in .id
   * - Indented multiline: Parser concatenates all indented lines into word tokens
   *   We join word tokens with spaces (parser handles line boundaries internally)
   *
   * @param {Object} link - The link to extract text from
   * @returns {string} The extracted text (with actual newlines if quoted, spaces if indented)
   */
  function extractText(link) {
    if (!link) return '';

    let text = '';

    if (link.id && (!link.values || link.values.length === 0)) {
      // Single value with .id (might contain actual newlines if quoted)
      text = link.id;
    } else if (!link.id && link.values && link.values.length > 0) {
      // Multiple word tokens - join with spaces
      // Note: For indented multiline, parser concatenates lines into words
      text = link.values.map(v => extractText(v)).join(' ');
    } else if (link.id) {
      text = link.id;
    }

    // Unescape the text before returning
    return unescapeReference(text);
  }

  // Return the public API
  return {
    readQADatabase,
    writeQADatabase,
    addOrUpdateQA,
    addQAIfMissing,
    backfillQuestionAnswers,
    getAnswer,
    filePath: QA_FILE_PATH,
  };
}

// Export utility functions that don't require file path
/**
 * Calculate Levenshtein distance between two strings
 * @param {string} a - First string
 * @param {string} b - Second string
 * @returns {number} Edit distance
 */
export function levenshteinDistance(a, b) {
  const matrix = [];

  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }

  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }

  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1,
        );
      }
    }
  }

  return matrix[b.length][a.length];
}

/**
 * Calculate similarity score between two strings (0-1)
 * @param {string} a - First string
 * @param {string} b - Second string
 * @returns {number} Similarity score
 */
export function stringSimilarity(a, b) {
  const maxLength = Math.max(a.length, b.length);
  if (maxLength === 0) return 1.0;

  const distance = levenshteinDistance(a, b);
  return 1 - distance / maxLength;
}

/** Prefix of a pattern key: in data/chat-templates.lino (learned) and data/qa.lino (question templates) */
export const PATTERN_PREFIX = 'pattern: ';
/** A gap of any words in a pattern */
export const PATTERN_GAP = '…';

/** @param {string} key @returns {boolean} */
export const isPattern = (key) => key.startsWith(PATTERN_PREFIX);

/** Words of a message for patterns: lowercase, without punctuation, ё as е */
export const patternWords = (text) => normalizeQuestion(String(text).replace(/[«»"()—–/]/g, ' ')).replace(/ё/g, 'е').split(' ').filter(Boolean);

/**
 * Whether a message is another wording of a pattern: its words in order, anything in the gaps,
 * any ending after a stem
 * @param {string} pattern - With or without the «pattern: » prefix
 * @param {string} text
 * @returns {boolean}
 */
export function matchesPattern(pattern, text) {
  const tokens = pattern.replace(PATTERN_PREFIX, '').split(' ').filter(Boolean);
  const escape = (word) => word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  let source = '(?:^| )';
  tokens.forEach((token, index) => {
    if (token === PATTERN_GAP) {
      source += '(?:\\S+ )*?';
      return;
    }
    source += token.endsWith('*') ? `${escape(token.slice(0, -1))}\\S*` : escape(token);
    if (index < tokens.length - 1) {
      source += ' ';
    }
  });
  return new RegExp(`${source}(?: |$)`, 'u').test(patternWords(text).join(' '));
}

/**
 * Normalize a question string for comparison
 * @param {string} question - Question to normalize
 * @returns {string} Normalized question
 */
export function normalizeQuestion(question) {
  return question
    .toLowerCase()
    .replace(/[.,!?;:]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .split(' ')
    .map(toFormalAddress)
    .join(' ');
}

// "Какие твои ожидания?" and "Какие ваши ожидания?" ask the same
const FORMAL_PRONOUNS = {
  ты: 'вы', тебя: 'вас', тебе: 'вам', тобой: 'вами', твой: 'ваш', твоя: 'ваша', твоё: 'ваше', твое: 'ваше',
  твои: 'ваши', твоего: 'вашего', твоей: 'вашей', твоих: 'ваших', твоим: 'вашим', твоими: 'вашими',
  твою: 'вашу', твоём: 'вашем', твоем: 'вашем', твоему: 'вашему',
};

/**
 * A lowercase word in the formal address: pronouns, and 2nd person singular verbs
 * ("планируешь" -> "планируете", "видишь" -> "видите"); short words such as "лишь" stay
 * @param {string} word
 * @returns {string}
 */
export function toFormalAddress(word) {
  if (FORMAL_PRONOUNS[word]) {
    return FORMAL_PRONOUNS[word];
  }
  return word.length > 5 ? word.replace(/([еи])шь$/u, '$1те') : word;
}

const STOPWORDS = new Set([
  'пожалуйста', 'свои', 'ваши', 'от', 'до', 'в', 'на', 'с', 'по',
  'о', 'об', 'и', 'а', 'но', 'или', 'то', 'как', 'что', 'это',
  'вы', 'ты', 'он', 'она', 'они', 'мы', 'я', 'к', 'для', 'при',
  'чуть', 'данный', 'момент',
]);

// Words every question uses; sharing only these says nothing about the subject
const GENERIC_QUESTION_WORDS = new Set([
  'подскажите', 'укажите', 'напишите', 'расскажите', 'опишите', 'поделитесь',
  'какой', 'какая', 'какое', 'какие', 'каком', 'какую', 'каких', 'какого', 'каким',
  'ваш', 'ваша', 'ваше', 'ваши', 'вашей', 'вашего', 'вам', 'вас', 'вами', 'твой', 'тебя', 'тебе',
  'есть', 'ли', 'был', 'была', 'было', 'были', 'у', 'работали', 'работал', 'работала', 'приходилось',
  'опыт', 'опыта', 'опытом', 'себя', 'рассматриваете', 'работы', 'работа', 'работе', 'работу', 'работать', 'предложения', 'сейчас',
  // «опыт разработки для систем реального времени» is not «опыт разработки на чистом Си»
  'разработки', 'разработка', 'разработке', 'разработку', 'разрабатывали', 'разрабатывать',
]);

/**
 * Extract key words (plus 5-char stems of long words) from a question
 * @param {string} question - Question string
 * @param {Object} [options]
 * @param {boolean} [options.caseSensitive=false] - Preserve case of keywords
 * @returns {Set<string>} Set of key words
 */
export function extractKeywords(question, { caseSensitive = false } = {}) {
  const cleaned = caseSensitive
    ? question.replace(/[.,!?;:]/g, '').replace(/\s+/g, ' ').trim()
    : normalizeQuestion(question);
  const keywords = cleaned
    .split(/\s+/)
    .filter(word => word.length > 2 && !STOPWORDS.has(word.toLowerCase()));
  const stems = keywords.filter(word => word.length > 6).map(word => word.substring(0, 5));
  return new Set([...keywords, ...stems]);
}

/**
 * Calculate keyword overlap (Jaccard) similarity
 * @param {string} a - First question
 * @param {string} b - Second question
 * @param {Object} [options] - Passed to extractKeywords
 * @returns {number} Similarity score (0-1)
 */
export function keywordSimilarity(a, b, options) {
  const keywordsA = extractKeywords(a, options);
  const keywordsB = extractKeywords(b, options);

  if (keywordsA.size === 0 && keywordsB.size === 0) return 1.0;
  if (keywordsA.size === 0 || keywordsB.size === 0) return 0.0;

  const intersection = [...keywordsA].filter(x => keywordsB.has(x));
  const union = new Set([...keywordsA, ...keywordsB]);

  return intersection.length / union.size;
}

// Cyrillic letters that look like Latin ones, as in "С#" typed with a Cyrillic С
const LATIN_LOOKALIKES = { а: 'a', в: 'b', е: 'e', к: 'k', м: 'm', н: 'h', о: 'o', р: 'p', с: 'c', т: 't', у: 'y', х: 'x' };

// Cyrillic abbreviations that name what is asked about as much as Latin names do: "оформление по
// ТК РФ" is not "оформление по ИП", "разработка ЭЦП" is not "разработка на Си". Others such as БД,
// ЗП or ЯП are just short words
const NAME_ABBREVIATIONS = new Set(['ИП', 'ТК', 'ГПХ', 'ООО', 'СЗ', 'ЭДО', 'ЭЦП', 'СКЗИ', 'КЭП', 'НЭП']);

/**
 * Names a question is about: words with Latin letters, # or + (C#, Go, MongoDB, AWS, Lead, net, $),
 * and Cyrillic abbreviations such as ИП, ТК or ЭЦП.
 * Two questions about different names need different answers, however similar the wording.
 * @param {string} question
 * @returns {string} Sorted, comma-joined names
 */
export function extractSubjectTerms(question) {
  return [...new Set(question.split(/[\s,.;:!?()«»"'/]+/)
    .filter((word) => /[a-z#+$]/i.test(word) || NAME_ABBREVIATIONS.has(word.toUpperCase()))
    .map((word) => word.toLowerCase().replace(/[а-яё]/g, (letter) => LATIN_LOOKALIKES[letter] ?? letter)))]
    .sort()
    .join(',');
}

// Keywords include 5-letter stems of long words, so stems of generic words are generic too
const isGenericWord = (word) => GENERIC_QUESTION_WORDS.has(word) ||
  (word.length === 5 && [...GENERIC_QUESTION_WORDS].some((generic) => generic.length > 6 && generic.startsWith(word)));
const subjectWords = (question) => [...extractKeywords(question)].filter((word) => !isGenericWord(word));

/**
 * Whether two questions share a keyword other than the generic question words
 * @returns {boolean}
 */
export function sharesSubjectWord(a, b) {
  const wordsB = new Set(subjectWords(b));
  return subjectWords(a).some((word) => wordsB.has(word));
}

/**
 * How much of each question's subject the other one covers (0-1), on word stems, so that
 * "Ваши зарплатные ожидания?" covers "...поделитесь вашими зарплатными ожиданиями" however long it is
 * @returns {number} The mean of both coverages
 */
export function subjectCoverage(a, b) {
  const isQualifier = (word) => QUALIFIER_TERMS.has(word) ||
    (word.length === 5 && [...QUALIFIER_TERMS].some((term) => term.length > 6 && term.startsWith(word)));
  const stems = (question) => new Set(subjectWords(question).filter((word) => !isQualifier(word))
    .map((word) => (word.length > 6 ? word.substring(0, 5) : word)));
  const stemsA = stems(a);
  const stemsB = stems(b);
  if (stemsA.size === 0 || stemsB.size === 0) {
    return 0;
  }
  const shared = [...stemsA].filter((stem) => stemsB.has(stem)).length;
  const coverageA = shared / stemsA.size;
  const coverageB = shared / stemsB.size;
  // Counts only when one question is (almost) all inside the other, by at least two words:
  // "проектирования решений" inside "лидерства, менторинга, проектирования архитектуры решений" is not
  if (shared < 2 || Math.max(coverageA, coverageB) < 0.8) {
    return 0;
  }
  return (coverageA + coverageB) / 2;
}

// Latin words that only qualify a question, not name its subject: "ожидания на fulltime" asks
// what "ожидания" asks
const QUALIFIER_TERMS = new Set([
  'fulltime', 'full-time', 'parttime', 'part-time', 'remote', 'hybrid', 'office', '@username', 'username', 'nickname',
]);

/**
 * Whether two questions are about different names ("опыт на C#" and "опыт на Go", "в $" and
 * "в рублях"), so the answer of one does not fit the other. Qualifiers such as fulltime are left out.
 * @returns {boolean}
 */
export function subjectTermsConflict(a, b) {
  const terms = (question) => extractSubjectTerms(question).split(',').filter((term) => term && !QUALIFIER_TERMS.has(term)).join(',');
  return terms(a) !== terms(b);
}

export const extractKeywordsCaseSensitive = (question) => extractKeywords(question, { caseSensitive: true });
export const keywordSimilarityCaseSensitive = (a, b) => keywordSimilarity(a, b, { caseSensitive: true });

/**
 * Find all matching questions from a database using fuzzy matching
 * @param {string} question - Question to match
 * @param {Map<string, string>} qaDatabase - Q&A database
 * @param {Object} options - Matching options
 * @param {number} options.threshold - Minimum similarity threshold (0-1), default 0.4
 * @param {boolean} options.caseSensitive - Whether to use case-sensitive matching, default false
 * @param {boolean} options.returnAll - Return all matches sorted by score (true) or just best match (false), default false
 * @returns {Array<{question: string, answer: string, score: number}>|{question: string, answer: string, score: number}|null}
 */
/** Words of a sentence in English, which a bare list of technologies («Python, FastAPI?») lacks */
const ENGLISH_WORDS = /(?<!\p{L})(?:the|a|an|you|your|are|do|does|did|have|has|what|how|which|where|when|why|is|can|could|would|will|please|describe|tell|with|for|of|to|in|and|any|ready|thank|thanks|we|our)(?!\p{L})/giu;

/**
 * Whether a text is in English: no Cyrillic, and English words, not only names of technologies
 * @param {string} text
 * @returns {boolean}
 */
export const isEnglish = (text) => !/[а-яё]/iu.test(String(text ?? '')) && (String(text ?? '').match(ENGLISH_WORDS) ?? []).length >= 2;

/**
 * Whether an answer speaks the language of its question: a question in English takes no answer in
 * Russian (placeholders aside); a question in Russian takes either («Docker, Kubernetes»)
 * @param {string} question
 * @param {string|string[]} answer
 * @returns {boolean}
 */
export const speaksLanguageOf = (question, answer) => !isEnglish(question) ||
  !/[а-яё]/iu.test([answer].flat().join('\n').replace(/\{\{\w+\}\}/g, ''));

export function findBestMatch(question, qaDatabase, options = {}) {
  // Handle backward compatibility: if options is a number, treat it as threshold
  const threshold = typeof options === 'number' ? options : (options.threshold ?? 0.4);
  const caseSensitive = typeof options === 'object' ? (options.caseSensitive ?? false) : false;
  const returnAll = typeof options === 'object' ? (options.returnAll ?? false) : false;

  // Normalization function that respects case sensitivity option
  const normalize = (str) => caseSensitive ? str : normalizeQuestion(str);

  // Check for exact match first
  if (qaDatabase.has(question)) {
    const result = { question, answer: qaDatabase.get(question), score: 1.0 };
    return returnAll ? [result] : result;
  }

  // A questionnaire must not receive just one of its answers or a salary/contact template.
  // Composition is a draft even if every component was saved word for word.
  const parts = splitQuestions(question);
  if (parts.length > 1 && threshold > 0) {
    const composed = composeQuestionAnswer(question, (part) => findBestMatch(part, qaDatabase, {
      threshold: Math.max(threshold, 0.7), caseSensitive,
    }));
    return returnAll ? (composed ? [composed] : []) : composed;
  }

  // A question template («pattern: gross») takes every wording of its question
  // The most specific one wins: «pattern: gross … usd» over «pattern: gross»
  const template = [...qaDatabase.entries()]
    .filter(([dbQuestion, answer]) => isPattern(dbQuestion) && matchesPattern(dbQuestion, question) &&
      (threshold === 0 || speaksLanguageOf(question, answer)))
    .sort(([a], [b]) => b.split(' ').length - a.split(' ').length)[0];
  const templateMatch = template ? { question: template[0], answer: template[1], score: 1.0 } : null;
  if (templateMatch && !returnAll) {
    return templateMatch;
  }

  const matches = [];

  for (const [dbQuestion, answer] of qaDatabase.entries()) {
    if (isPattern(dbQuestion)) {
      continue;
    }
    if (threshold > 0 && splitQuestions(dbQuestion).length > 1) continue;
    // "опыт на C#" must not take the answer of "опыт на Go" (threshold 0 still lists everything)
    if (threshold > 0 && subjectTermsConflict(question, dbQuestion)) {
      continue;
    }
    // A question in English is not answered in Russian
    if (threshold > 0 && !speaksLanguageOf(question, answer)) {
      continue;
    }

    const editSimilarity = stringSimilarity(
      normalize(question),
      normalize(dbQuestion),
    );

    // A long question around a short saved one shares few words overall, but all of its subject
    const kwSimilarity = Math.max(
      keywordSimilarity(question, dbQuestion, { caseSensitive }),
      subjectCoverage(question, dbQuestion),
    );
    // Similar wording alone ("на каком стеке" vs "в каком городе") is not a match
    if (threshold > 0 && !sharesSubjectWord(question, dbQuestion)) {
      continue;
    }

    const combinedScore = (editSimilarity * 0.4) + (kwSimilarity * 0.6);

    if (combinedScore >= threshold) {
      matches.push({ question: dbQuestion, answer, score: combinedScore });
    }
  }

  // Sort matches by score in descending order (highest score first)
  matches.sort((a, b) => b.score - a.score);

  if (returnAll) {
    return templateMatch ? [templateMatch, ...matches] : matches;
  } else {
    // Return best match (first in sorted array) or null if no matches
    return matches.length > 0 ? matches[0] : null;
  }
}
