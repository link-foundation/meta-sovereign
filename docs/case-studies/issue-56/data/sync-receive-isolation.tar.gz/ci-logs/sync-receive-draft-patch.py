"""Apply the bounded receive-isolation draft to the current published sources."""
from pathlib import Path

def edit(name, changes):
    path = Path(name)
    source = path.read_text()
    for before, after in changes:
        assert before in source, (name, before)
        source = source.replace(before, after)
    path.write_text(source)

edit('js/src/storage/universal.js', [
    ('export const createMemoryStore', "import { changedLink, mutationEvent } from './mutation.js';\n\nexport const createMemoryStore"),
    ('const put = (link) =>', 'const put = (link, options) =>'),
    ("emit({ type: 'put', link });", "emit(mutationEvent('put', link, options));"),
    ('async put(link) {\n      return put(link);', 'async put(link, options) {\n      return put(link, options);'),
    ('async putMany(links) {\n      return links.map(put);', 'async putMany(links, options) {\n      return links.map((link) => put(link, options));'),
    ('    // A projection reads', '    async update(id, change, options) {\n      const before = data.get(id);\n      return put(changedLink(id, change, before ? copy(before) : null), options);\n    },\n    // A projection reads'),
    ('async delete(id) {', 'async delete(id, options) {'),
    ("emit({ type: 'delete', link });", "emit(mutationEvent('delete', link, options));"),
])
edit('js/src/storage/browser-store.js', [
    ("import { getLocalStorage }", "import { changedLink, mutationEvent } from './mutation.js';\nimport { getLocalStorage }"),
    ('async put(link) {', 'async put(link, options) {'),
    ("emit({ type: 'put', link: cloneLink(link) });", "emit(mutationEvent('put', cloneLink(link), options));"),
    ('async putMany(links) {', 'async putMany(links, options) {'),
    ('await this.put(link);', 'await this.put(link, options);'),
    ('    async get(id, project = cloneLink)', '    async update(id, change, options) {\n      const before = data.get(id);\n      return this.put(changedLink(id, change, before ? cloneLink(before) : null), options);\n    },\n    async get(id, project = cloneLink)'),
    ('async delete(id) {', 'async delete(id, options) {'),
    ("emit({ type: 'delete', link: cloneLink(link) });", "emit(mutationEvent('delete', cloneLink(link), options));"),
])
for name, completion in [('lino-store', 'await append([lineOf(out)]);'), ('doublets-store', 'snapshots.later();')]:
    edit('js/src/storage/' + name + '.js', [
        ('async put(link) {', 'async put(link, options) {'),
        ('await mem.put(link)', 'await mem.put(link, options)'),
        ('async putMany(links) {', 'async putMany(links, options) {'),
        ('await mem.putMany(links);', 'await mem.putMany(links, options);'),
        ('    async delete(id) {', '    async update(id, change, options) {\n' + ('      guard();\n' if name == 'lino-store' else '') + '      const out = await mem.update(id, change, options);\n      ' + completion + '\n      return out;\n    },\n    async delete(id, options) {'),
        ('await mem.delete(id)', 'await mem.delete(id, options)'),
    ])
edit('js/src/storage/dual-store.js', [
    ('const putEach = async (store, links) =>', 'const putEach = async (store, links, options) =>'),
    ('await store.put(link);', 'await store.put(link, options);'),
    ('async put(link) {', 'async put(link, options) {'),
    ('await binary.put(link);', 'await binary.put(link, options);'),
    ('await text.put(link);', 'await text.put(link, options);'),
    ('async putMany(links) {', 'async putMany(links, options) {'),
    ('binary.putMany(links) : putEach(binary, links)', 'binary.putMany(links, options) : putEach(binary, links, options)'),
    ('text.putMany(links) : putEach(text, links)', 'text.putMany(links, options) : putEach(text, links, options)'),
    ('  async get(id, project)', '  async update(id, change, options) {\n    if (binary.mirrors === text) {\n      const out = await text.update(id, change, options);\n      await binary.put(out, options);\n      return out;\n    }\n    const out = await binary.update(id, change, options);\n    await text.put(out, options);\n    return out;\n  },\n  async get(id, project)'),
    ('async delete(id) {', 'async delete(id, options) {'),
    ('await binary.delete(id);', 'await binary.delete(id, options);'),
    ('await text.delete(id);', 'await text.delete(id, options);'),
    ('  put: text.put,', '  put: text.put,\n  update: text.update,'),
])
edit('js/src/storage/dual-handoff.js', [("        'putMany',", "        'putMany',\n        'update',")])
edit('js/src/storage/secret-store.js', [
    ("import { encryptBackup", "import { changedLink } from './mutation.js';\nimport { encryptBackup"),
    ('async put(link) {', 'async put(link, options) {'),
    ('await inner.put(sealed);', 'await inner.put(sealed, options);'),
    ('return inner.put(link);', 'return inner.put(link, options);'),
    ('    async get(id) {', '    async update(id, change, options) {\n      return inner.update(id, (before) => {\n        const opened = before?.enc && id.startsWith(SECRET_PREFIX)\n          ? openLink(before, passphrase) : before;\n        const next = changedLink(id, change, opened);\n        return isSecret(next) ? sealLink(next, passphrase) : next;\n      }, options);\n    },\n    async get(id) {'),
    ('async delete(id) {\n      return inner.delete(id);', 'async delete(id, options) {\n      return inner.delete(id, options);'),
])
edit('js/src/storage/message-versions.js', [
    ("import { isTombstone }", "import { changedLink } from './mutation.js';\nimport { isTombstone }"),
    ('return async (links, single = false) =>', 'return async (links, single = false, options) =>'),
    ('await inner.put(records[0]);', 'await inner.put(records[0], options);'),
    ('await inner.putMany(records);', 'await inner.putMany(records, options);'),
    ('await inner.put(record);', 'await inner.put(record, options);'),
    ('result.put = (link) =>', 'result.put = (link, options) =>'),
    ('(await prepare([link], true))[0]', '(await prepare([link], true, options))[0]'),
    (': inner.put(link);', ': inner.put(link, options);'),
    ('  result.putMany = (links) =>', '  result.update = (id, change, options) =>\n    String(id).startsWith(\'msg:\') || String(id).startsWith(VERSION_PREFIX)\n      ? enqueue(async () => {\n          const next = changedLink(id, change, await inner.get(id));\n          return (await prepare([next], true, options))[0];\n        })\n      : inner.update(id, change, options);\n  result.putMany = (links, options) =>'),
    ('enqueue(() => prepare(links))', 'enqueue(() => prepare(links, false, options))'),
    ('? inner.putMany(links)', '? inner.putMany(links, options)'),
    ('links.map((link) => inner.put(link))', 'links.map((link) => inner.put(link, options))'),
    ('result.delete = (id) =>', 'result.delete = (id, options) =>'),
    ('? inner.delete(id)', '? inner.delete(id, options)'),
    ('await inner.delete(record.id);', 'await inner.delete(record.id, options);'),
    ('await inner.delete(id);', 'await inner.delete(id, options);'),
])
