async (page) => {
 const process={env:{}};
 const globalThis={performance:{now:()=>Date.now()}};
 const mcpPause=(ms)=>page.waitForTimeout(ms);
 var chatScanContract = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <stdin>
  var stdin_exports = {};
  __export(stdin_exports, {
    HH_WEB_UI: () => HH_WEB_UI,
    scanBrowserChatList: () => scanBrowserChatList,
    scanUnreadBrowserConversations: () => scanUnreadBrowserConversations
  });

  // finite-mcp:node:timers/promises
  var setTimeout2 = (ms) => mcpPause(ms);

  // js/src/sources/browser-actions.js
  var TARGET_ATTRIBUTE = "data-ms-target";
  var TARGET = `[${TARGET_ATTRIBUTE}="1"]`;
  var extractChats = (spec) => {
    const container = () => {
      if (!spec.listToken) {
        return { root: document };
      }
      const owned2 = window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-chat-list.v1")];
      return owned2?.token === spec.listToken && owned2.root?.isConnected ? owned2 : null;
    };
    const squash = (value) => String(value ?? "").replace(/\s+/g, " ").trim();
    const text = (node, selector, attribute) => {
      const found = selector ? node.querySelector(selector) : null;
      if (!found) {
        return "";
      }
      return squash(
        attribute ? found.getAttribute(attribute) : found.textContent
      );
    };
    const pattern = spec.linkPattern ? new RegExp(spec.linkPattern) : null;
    const idPattern = spec.idPattern ? new RegExp(spec.idPattern) : null;
    const linkedIdOf = (node) => {
      const link = spec.link ? node.matches?.(spec.link) ? node : node.querySelector(spec.link) : null;
      const href = link?.getAttribute("href") ?? "";
      const match = pattern ? pattern.exec(href) : null;
      return match ? decodeURIComponent(match[1]) : null;
    };
    const idOf = (node) => {
      const own = spec.idAttribute ? node.getAttribute(spec.idAttribute) : null;
      if (!idPattern) {
        return own || linkedIdOf(node);
      }
      const id = own ? idPattern.exec(own)?.[1] : null;
      if (own && !id) {
        return null;
      }
      const linked = linkedIdOf(node);
      return id && linked && id !== linked ? null : id ?? linked;
    };
    const rowOf = (node) => {
      const title = text(node, spec.title, spec.titleAttribute);
      return {
        chat: idOf(node) ?? (!spec.requireId && title ? `title:${title}` : null),
        title: title || null,
        preview: text(node, spec.preview) || null,
        time: text(node, spec.time) || null,
        unread: unreadOf(node)
      };
    };
    const unreadOf = (node) => {
      if (!spec.unread) {
        return 0;
      }
      const count = Number.parseInt(text(node, spec.unread), 10);
      return Number.isFinite(count) ? Math.max(0, count) : node.querySelector(spec.unread) ? 1 : 0;
    };
    const seen = /* @__PURE__ */ new Set();
    const rows = [];
    const owned = container();
    for (const node of owned?.root.querySelectorAll(spec.item) ?? []) {
      if (rows.length >= spec.limit) {
        break;
      }
      if (owned.visible && !owned.visible(node)) {
        continue;
      }
      const row = rowOf(node);
      if (!row.chat || spec.uniqueIds && seen.has(row.chat)) {
        continue;
      }
      seen.add(row.chat);
      rows.push(row);
    }
    return rows;
  };

  // finite-mcp:node:crypto
  var next = 0;
  var randomUUID = () => "independent-mcp-scan-" + ++next;
  var randomBytes = () => {
    throw new Error("This inspection is read-only");
  };

  // js/src/sources/browser-inactive-view.js
  var browserInactiveView = ({ operation, token }) => {
    const key = /* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1");
    const current = (state2) => state2.interrupted || document.hasFocus() ? "owner-active" : "ready";
    if (operation === "open" && !window[key]) {
      if (document.hasFocus()) {
        return { state: "owner-active" };
      }
      const state2 = { token, interrupted: false };
      state2.interrupt = () => {
        state2.interrupted = true;
        state2.notify?.();
      };
      state2.events = [
        "pointerdown",
        "keydown",
        "wheel",
        "touchstart",
        "touchmove",
        "input"
      ];
      state2.mark = (event) => {
        if (!event.isTrusted && event === state2.ownedInput || state2.ownedFilterControl && event.type === "input" && event.target === state2.ownedFilterControl) {
          return;
        }
        if (event.isTrusted || event.type === "input") {
          state2.interrupt();
        }
      };
      state2.focus = () => {
        if (document.hasFocus()) {
          state2.interrupt();
        }
      };
      for (const type of state2.events) {
        document.addEventListener(type, state2.mark, {
          capture: true,
          passive: true
        });
      }
      window.addEventListener("focus", state2.focus, true);
      document.addEventListener("visibilitychange", state2.focus, true);
      window[key] = state2;
    }
    const state = window[key];
    if (!state || state.token !== token) {
      return { state: state ? "busy" : "unavailable" };
    }
    const status = current(state);
    if (operation === "release") {
      state.releaseRelay?.();
      for (const type of state.events) {
        document.removeEventListener(type, state.mark, true);
      }
      window.removeEventListener("focus", state.focus, true);
      document.removeEventListener("visibilitychange", state.focus, true);
      delete window[key];
    }
    return { state: status };
  };
  var linkBrowserInactiveOwner = async ({ token }) => {
    const state = window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")];
    if (!state || state.token !== token) {
      return false;
    }
    if (state.releaseRelay) {
      return state.relayReady;
    }
    const owner = window.top === window;
    const peers = /* @__PURE__ */ new Set();
    const type = "meta-sovereign.browser-inactive-owner.v1";
    const send = (peer, operation) => {
      try {
        peer.postMessage({ type, token, operation }, "*");
      } catch {
        state.interrupted = true;
      }
    };
    let complete;
    let timer;
    const ready2 = owner ? Promise.resolve(true) : new Promise((resolve) => {
      complete = resolve;
      timer = setTimeout(() => resolve(false), 1e3);
    });
    state.relayReady = ready2;
    const ownerStatus = () => state.interrupted || document.hasFocus() ? "owner-active" : "ready";
    const receive = (event) => {
      const data = event.data;
      if (data?.type !== type || data.token !== token || !event.source) {
        return;
      }
      if (owner && event.source !== window && data.operation === "observe") {
        if (peers.size >= 64 && !peers.has(event.source)) {
          return;
        }
        peers.add(event.source);
        send(event.source, ownerStatus());
      } else if (!owner && event.source === window.top) {
        if (data.operation === "owner-active") {
          state.interrupt();
          complete(false);
        } else if (data.operation === "ready") {
          complete(true);
        }
      }
    };
    state.notify = () => {
      for (const peer of peers) {
        send(peer, "owner-active");
      }
    };
    state.releaseRelay = () => {
      window.removeEventListener("message", receive, true);
      clearTimeout(timer);
      complete?.(false);
      peers.clear();
      delete state.notify;
    };
    window.addEventListener("message", receive, true);
    if (!owner) {
      send(window.top, "observe");
    }
    const linked = await ready2;
    clearTimeout(timer);
    return linked;
  };
  var failure = (state) => {
    if (process.env.MS_BROWSER_HISTORY_DEBUG === "1") {
      console.error("[browser-inactive-view]", { state });
    }
    return Object.assign(
      new Error("The inactive provider view is no longer owned."),
      {
        code: `browser-background-${state}`,
        historyReason: state === "owner-active" ? state : "document-changed",
        fallback: false
      }
    );
  };
  var prepareBrowserInactiveView = async (page) => {
    const context = page.context();
    if (context.browser()?.browserType().name() !== "chromium") {
      throw failure("focus-unavailable");
    }
    let session;
    try {
      session = await context.newCDPSession(page);
      await session.send("Emulation.setFocusEmulationEnabled", {
        enabled: false
      });
    } catch {
      throw failure("focus-unavailable");
    } finally {
      await session?.detach().catch(() => {
      });
    }
  };
  var withInactiveBrowserView = async (document2, read, { relayOwner = false } = {}) => {
    if (["evaluateOwner", "evaluate"].some(
      (method) => typeof document2?.[method] !== "function"
    )) {
      throw failure("unavailable");
    }
    const token = randomUUID();
    const control = async (operation) => {
      for (const method of ["evaluateOwner", "evaluate"]) {
        const result = await document2[method]({
          fn: browserInactiveView,
          args: [{ operation, token }]
        });
        if (result.state !== "ready") {
          throw failure(result.state);
        }
      }
    };
    try {
      await document2.prepareInactiveView?.();
      await control("open");
      if (relayOwner) {
        for (const method of ["evaluateOwner", "evaluate"]) {
          const result2 = await document2[method]({
            fn: linkBrowserInactiveOwner,
            args: [{ token }]
          });
          if (!result2) {
            throw failure("owner-unverified");
          }
        }
        await control("status");
      }
      const result = await read(() => control("status"), token);
      await control("status");
      return result;
    } finally {
      await Promise.allSettled(
        ["evaluate", "evaluateOwner"].map(
          (method) => document2[method]({
            fn: browserInactiveView,
            args: [{ operation: "release", token }]
          })
        )
      );
    }
  };

  // js/src/sources/browser-choice-document.js
  var failure2 = () => Object.assign(
    new Error("The visible provider chat document changed or is ambiguous"),
    {
      code: "answer-chat-unverified",
      fallback: false
    }
  );
  var browserDocumentIdentity = (selector) => {
    const key = /* @__PURE__ */ Symbol.for("meta-sovereign.browser-choice-document.v1");
    window[key] ??= crypto.randomUUID();
    return { key: window[key], rows: document.querySelectorAll(selector).length };
  };
  var browserFrameVisible = (node) => {
    if (!node.isConnected || !node.getClientRects().length) {
      return false;
    }
    for (let parent = node; parent; parent = parent.parentElement) {
      const style = getComputedStyle(parent);
      if (parent.hidden || parent.getAttribute("aria-hidden") === "true" || style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) {
        return false;
      }
    }
    return true;
  };
  var trusted = (address, origins2) => {
    const url = new URL(address);
    return origins2.includes(url.origin) && !url.username && !url.password;
  };
  var inChat = (frame, ui, target) => {
    const url = new URL(frame.url());
    return trusted(url.href, ui.location.origins) && new RegExp(ui.location.pathPattern).exec(url.pathname)?.[1] === String(target);
  };
  var visibleFrame = async (frame, main, ui) => {
    for (let current = frame; current && current !== main; current = current.parentFrame()) {
      if (!trusted(current.url(), ui.documents.ancestorOrigins)) {
        return false;
      }
      const element = await current.frameElement();
      try {
        if (!await element.evaluate(browserFrameVisible)) {
          return false;
        }
      } finally {
        await element.dispose();
      }
    }
    return true;
  };
  var inList = (frame, ui) => trusted(frame.url(), ui.location.origins) && new RegExp(ui.chatScan.pathPattern).test(new URL(frame.url()).pathname);
  var listIdentitySelector = (ui) => [ui.chats.item, ui.chatScan.unreadFilter?.fallback].filter(Boolean).join(", ");
  var chooseBrowserChatDocument = async (page, ui, target, list = false) => {
    if (!page || !trusted(page.url(), ui.documents.ownerOrigins)) {
      throw failure2();
    }
    const main = page.mainFrame();
    const ownerRoute = new RegExp(ui.location.pathPattern).exec(
      new URL(page.url()).pathname
    );
    if (list ? !new RegExp(ui.chatScan.pathPattern).test(new URL(page.url()).pathname) : ownerRoute && ownerRoute[1] !== String(target)) {
      throw failure2();
    }
    const frames = page.frames();
    if (frames.length > ui.documents.maxFrames) {
      throw failure2();
    }
    const candidates = [];
    const selector = list ? listIdentitySelector(ui) : ui.messages.item;
    for (const frame of frames) {
      const matching = list ? inList(frame, ui) : inChat(frame, ui, target);
      if (matching && await visibleFrame(frame, main, ui)) {
        const identity = await frame.evaluate(browserDocumentIdentity, selector);
        if (identity.rows) {
          candidates.push({ frame, identity, frameUrl: frame.url() });
        }
      }
    }
    if (candidates.length !== 1) {
      throw failure2();
    }
    const owner = await main.evaluate(browserDocumentIdentity, selector);
    return { ...candidates[0], owner: owner.key, url: page.url() };
  };
  var resolveBrowserDocument = async (commander, page, ui, target, list = false) => {
    if (!ui.documents) {
      return commander;
    }
    let selected;
    try {
      selected = await chooseBrowserChatDocument(page, ui, target, list);
    } catch {
      throw failure2();
    }
    const assertCurrent = async () => {
      try {
        const current = await chooseBrowserChatDocument(page, ui, target, list);
        if (current.frame !== selected.frame || current.frameUrl !== selected.frameUrl || current.identity.key !== selected.identity.key || current.owner !== selected.owner || current.url !== selected.url) {
          throw failure2();
        }
      } catch {
        throw failure2();
      }
    };
    const ownerFrame = page.mainFrame();
    return {
      async prepareInactiveView() {
        await assertCurrent();
        await prepareBrowserInactiveView(page);
        await assertCurrent();
      },
      async evaluateOwner({ fn, args = [] }) {
        if (args.length > 1) {
          throw failure2();
        }
        if (args[0]?.operation === "release") {
          return ownerFrame.evaluate(fn, args[0]);
        }
        await assertCurrent();
        const result = await ownerFrame.evaluate(fn, args[0]);
        await assertCurrent();
        return result;
      },
      async evaluate({ fn, args = [] }) {
        if (args.length > 1) {
          throw failure2();
        }
        if (args[0]?.operation === "release") {
          return selected.frame.evaluate(fn, args[0]);
        }
        await assertCurrent();
        const value = selected.frame === page.mainFrame() ? await commander.evaluate({ fn, args }) : await selected.frame.evaluate(fn, args[0]);
        await assertCurrent();
        return value;
      },
      async clickButton({ selector, inactiveToken }) {
        await assertCurrent();
        if (inactiveToken) {
          for (const frame of /* @__PURE__ */ new Set([ownerFrame, selected.frame])) {
            const { state } = await frame.evaluate(browserInactiveView, {
              operation: "status",
              token: inactiveToken
            });
            if (state !== "ready") {
              throw Object.assign(
                new Error("Inactive reply ownership changed."),
                {
                  code: `browser-background-${state}`,
                  fallback: false,
                  dispatched: false
                }
              );
            }
          }
        }
        if (selected.frame === page.mainFrame()) {
          await commander.clickButton({
            selector,
            scrollIntoView: !inactiveToken,
            ...inactiveToken ? { activation: "dom", scroll: "none" } : {},
            waitForNavigation: false,
            waitAfterClick: 0,
            verify: false
          });
        } else if (inactiveToken) {
          await selected.frame.locator(selector).evaluate((node) => node.click());
        } else {
          await selected.frame.locator(selector).click({ timeout: 5e3 });
        }
      }
    };
  };
  var resolveBrowserChoiceDocument = (commander, page, ui, target) => resolveBrowserDocument(commander, page, ui, target);
  var resolveBrowserChatListDocument = (commander, page, ui) => resolveBrowserDocument(commander, page, ui, null, true);

  // js/src/sources/browser-chat-list-state.js
  var scrollOwnerActive = (state) => state.interrupted || state.inactiveToken && (window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")]?.token !== state.inactiveToken || window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")].interrupted || document.hasFocus()) || (state.drafts ?? []).some(
    ([node, value]) => !node.isConnected || node.value !== value
  ) || state.composer && document.querySelectorAll(state.composer).length !== state.drafts.length;
  var restoreScroll = (state, { restore, history, item, idAttribute }) => {
    if (!restore || scrollOwnerActive(state) || !state.visible(state.root)) {
      return false;
    }
    const move = (top) => {
      const previous = state.root.scrollTop;
      state.root.scrollTop = top;
      state.pendingScroll ||= previous !== state.root.scrollTop;
    };
    if (!history) {
      move(state.original);
      return true;
    }
    const anchor = [...state.root.querySelectorAll(item)].find(
      (node) => node.getAttribute(idAttribute) === state.anchor?.id
    );
    if (anchor) {
      move(
        state.root.scrollTop + anchor.getBoundingClientRect().top - state.root.getBoundingClientRect().top - state.anchor.offset
      );
      state.restoring = true;
      return true;
    }
    if (!state.restoring) {
      move(
        state.original + (state.reversed || state.tailOnly ? 0 : state.root.scrollHeight - state.originalHeight)
      );
      state.restoring = true;
    }
    return false;
  };
  var historyAnchor = (root, cells, idAttribute) => {
    const bounds = root.getBoundingClientRect();
    const anchor = cells.find((node) => {
      const rect = node.getBoundingClientRect();
      return rect.bottom > bounds.top && rect.top < bounds.bottom;
    });
    return anchor && {
      id: anchor.getAttribute(idAttribute),
      offset: anchor.getBoundingClientRect().top - bounds.top
    };
  };
  var browserChatScrollRoot = (cell) => {
    let root = cell?.parentElement;
    while (root && !/^(?:auto|scroll)$/.test(getComputedStyle(root).overflowY)) {
      root = root.parentElement;
    }
    return root ?? document.scrollingElement;
  };
  var openScroll = ({
    token,
    item,
    composer,
    idAttribute,
    scope,
    inactiveToken,
    allowOwnedInput,
    tailOnly
  }, visible) => {
    const history = scope === "history";
    const cell = [...document.querySelectorAll(item)].find(visible);
    const root = browserChatScrollRoot(cell);
    if (!root || !cell) {
      return { refused: "unavailable" };
    }
    const cells = history ? [...document.querySelectorAll(item)].filter(visible) : [];
    if (history && (cells.length > 500 || cells.some((node) => !root.contains(node)))) {
      return { refused: "unavailable" };
    }
    const state = {
      token,
      inactiveToken,
      root,
      visible,
      original: root.scrollTop,
      originalHeight: root.scrollHeight,
      anchor: history ? historyAnchor(root, cells, idAttribute) : void 0,
      reversed: getComputedStyle(root).flexDirection === "column-reverse",
      composer,
      tailOnly,
      interrupted: false,
      drafts: composer ? [...document.querySelectorAll(composer)].map((node) => [
        node,
        node.value
      ]) : []
    };
    state.events = [
      "pointerdown",
      "keydown",
      "wheel",
      "touchstart",
      "touchmove",
      "input"
    ];
    state.mark = (event) => {
      const inactive = window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")];
      if (allowOwnedInput === true && inactive && inactive.token === inactiveToken && event === inactive.ownedInput && !event.isTrusted) {
        return;
      }
      if (event.isTrusted || history) {
        state.interrupted = true;
      }
    };
    for (const type of state.events) {
      document.addEventListener(type, state.mark, {
        capture: true,
        passive: true
      });
    }
    state.scroll = (event) => {
      if (event.target === root || root === document.scrollingElement && event.target === document) {
        state.pendingScroll = false;
      }
    };
    document.addEventListener("scroll", state.scroll, {
      capture: true,
      passive: true
    });
    const previous = root.scrollTop;
    root.scrollTop = history && !state.reversed ? root.scrollHeight : 0;
    state.pendingScroll = previous !== root.scrollTop;
    return state;
  };
  var browserScrollState = (input, visible, openScroll2, restoreScroll2, scrollOwnerActive2) => {
    const {
      operation,
      token,
      item,
      top,
      restore,
      scope = "list",
      idAttribute
    } = input;
    const history = scope === "history";
    const key = /* @__PURE__ */ Symbol.for(
      history ? "meta-sovereign.browser-conversation-history.v1" : "meta-sovereign.browser-chat-list.v1"
    );
    const release2 = (state2) => {
      document.removeEventListener("scroll", state2.scroll, true);
      for (const type of state2.events) {
        document.removeEventListener(type, state2.mark, true);
      }
      const restored = restoreScroll2(state2, {
        restore,
        history,
        item,
        idAttribute
      });
      delete window[key];
      return { state: "released", restored };
    };
    const read = (state2) => {
      if (scrollOwnerActive2(state2)) {
        return { state: "owner-active" };
      }
      if (!visible(state2.root)) {
        return { state: "changed" };
      }
      if (operation === "move") {
        const previous = state2.root.scrollTop;
        state2.root.scrollTop = top;
        state2.pendingScroll = previous !== state2.root.scrollTop;
      }
      const { scrollTop, scrollHeight, clientHeight } = state2.root;
      if (clientHeight <= 0 || !Number.isFinite(scrollHeight)) {
        return { state: "unavailable" };
      }
      return {
        state: "ready",
        top: scrollTop,
        height: scrollHeight,
        view: clientHeight,
        bottom: scrollTop + clientHeight >= scrollHeight - 2,
        scrollPending: Boolean(state2.pendingScroll),
        loading: Boolean(
          state2.pendingScroll || state2.root.querySelector('[aria-busy="true"], [role="progressbar"]')
        ),
        ...input.debug ? {
          original: state2.original,
          anchor: state2.anchor,
          rendered: [...state2.root.querySelectorAll(item)].map(
            (node) => node.getAttribute(idAttribute)
          )
        } : {},
        ...history ? {
          reversed: state2.reversed,
          oldest: state2.reversed ? scrollTop <= -(scrollHeight - clientHeight) + 2 : scrollTop <= 2
        } : {}
      };
    };
    if (operation === "open") {
      if (window[key]) {
        return { state: "busy" };
      }
      if (scrollOwnerActive2({ inactiveToken: input.inactiveToken })) {
        return { state: "owner-active" };
      }
      const state2 = openScroll2(input, visible);
      if (state2.refused) {
        return { state: state2.refused };
      }
      window[key] = state2;
    }
    const state = window[key];
    if (!state || state.token !== token) {
      return { state: "unavailable" };
    }
    if (operation === "restore") {
      restoreScroll2(state, { restore, history, item, idAttribute });
    }
    return operation === "release" ? release2(state) : read(state);
  };
  var browserChatListState = new Function(`return (input) => {
  const visible = (${browserFrameVisible.toString()});
  const scrollOwnerActive = (${scrollOwnerActive.toString()});
  const restoreScroll = (${restoreScroll.toString()});
  const historyAnchor = (${historyAnchor.toString()});
  const browserChatScrollRoot = (${browserChatScrollRoot.toString()});
  const openScroll = (${openScroll.toString()});
  return (${browserScrollState.toString()})(input, visible, openScroll, restoreScroll, scrollOwnerActive);
}`)();

  // js/src/sources/browser-scan-control.js
  var createBrowserScanControl = (document2, spec) => {
    const token = randomUUID();
    return {
      token,
      control: (operation, extra = {}) => document2.evaluate({
        fn: browserChatListState,
        args: [{ ...spec, operation, token, ...extra }]
      })
    };
  };

  // js/src/sources/browser-native-input.js
  var writeBrowserNativeInput = (node, value, inactive) => {
    const prototype = node instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    if (!setter || !("value" in node)) {
      return false;
    }
    const event = new Event("input", { bubbles: true });
    if (inactive) {
      inactive.ownedInput = event;
    }
    try {
      setter.call(node, value);
      node.dispatchEvent(event);
      node.dispatchEvent(new Event("change", { bubbles: true }));
      return String(node.value) === value;
    } finally {
      if (inactive?.ownedInput === event) {
        delete inactive.ownedInput;
      }
    }
  };

  // js/src/sources/browser-choice-visibility.js
  var watchChoiceView = (attempt, stop2 = false) => {
    if (!stop2) {
      attempt.viewChanged = (event) => {
        if (event.type !== "pointerdown" || event.target !== attempt.node && !attempt.node.contains(event.target)) {
          attempt.preserveView = true;
        }
      };
    }
    for (const type of [
      "wheel",
      "touchmove",
      "keydown",
      "input",
      "pointerdown"
    ]) {
      document[stop2 ? "removeEventListener" : "addEventListener"](
        type,
        attempt.viewChanged,
        true
      );
    }
  };
  var revealChoiceReply = (spec, attempt, current, message) => {
    if (attempt.preserveView) {
      return "owner-activity";
    }
    const composer = current.composer;
    if (composer && String(composer.value ?? composer.textContent ?? "")) {
      return "owner-draft";
    }
    const pattern = new RegExp(spec.messages.idPattern);
    const nodes = [...document.querySelectorAll(spec.messages.item)].filter(
      (node) => pattern.exec(node.getAttribute(spec.messages.idAttribute) ?? "")?.[1] === message.id
    );
    if (nodes.length !== 1) {
      return "unavailable";
    }
    try {
      nodes[0].scrollIntoView({
        block: "nearest",
        inline: "nearest",
        behavior: "instant"
      });
      return "revealed";
    } catch {
      return "unavailable";
    }
  };

  // js/src/sources/browser-pending-turn.js
  var browserPendingTurn = (rows) => {
    const validText = (value, limit, empty = false) => typeof value === "string" && value.length <= limit && (empty || Boolean(value.trim()));
    const end = rows.findLastIndex((row) => row.outgoing || row.service);
    const last = rows[end];
    const messages = rows.slice(end + 1).map(({ id, body }) => ({ id, body }));
    const boundary = last ? {
      kind: last.service ? "service" : "outgoing",
      id: last.id,
      body: last.body
    } : { kind: "rendered-start" };
    if (messages.length > 20 || messages.reduce((size, row) => size + String(row.body ?? "").length, 0) > 24e3) {
      return { code: "answer-history-limited" };
    }
    const relevant = last ? [last, ...messages] : messages;
    if (relevant.some(
      (row) => !validText(row.id, 480) || !validText(row.body, 6e3, row === last)
    ) || new Set(relevant.map((row) => row.id)).size !== relevant.length) {
      return { code: "answer-history-unverified" };
    }
    return { boundary, messages };
  };
  var checkedBrowserPendingTurn = (turn, question) => {
    if (turn === void 0) {
      return void 0;
    }
    const boundary = turn?.boundary;
    if (!Array.isArray(turn?.messages) || turn.messages.length > 20 || !["rendered-start", "outgoing", "service"].includes(boundary?.kind)) {
      return null;
    }
    const rows = turn.messages.map((row) => ({ id: row?.id, body: row?.body }));
    if (boundary.kind !== "rendered-start") {
      rows.unshift({
        id: boundary.id,
        body: boundary.body,
        outgoing: boundary.kind === "outgoing",
        service: boundary.kind === "service"
      });
    }
    const value = browserPendingTurn(rows);
    const latest = rows.at(-1);
    return !value.code && latest?.id === question.id && latest.body === question.body && Boolean(latest.outgoing) === question.outgoing && !latest.service ? value : null;
  };

  // js/src/sources/browser-reply-guard.js
  var browserReplyAdmission = (state, reservation) => {
    if (state.attempts.has(reservation)) {
      return "send-in-doubt";
    }
    if (state.attempts.size >= 32) {
      const completed = [...state.attempts].find(
        ([_key, attempt]) => attempt.confirmed
      );
      if (!completed) {
        return "answer-choice-capacity";
      }
      state.attempts.delete(completed[0]);
    }
    return null;
  };
  var armBrowserReply = (input, context, current, node, valid) => {
    const { state, identity, snapshot } = context;
    const reservation = identity(current);
    const code = browserReplyAdmission(state, reservation);
    if (code) {
      return { code };
    }
    const attempt = {
      node,
      token: input.token,
      reservation,
      before: current.messages.map((row) => row.id),
      allowed: false,
      clicked: false
    };
    const selector = `[data-meta-answer-choice="${input.token}"]`;
    attempt.guard = (event) => {
      const tagged = event.target.closest?.(selector);
      if (!tagged && event.target !== attempt.node && !attempt.node.contains(event.target)) {
        return;
      }
      if (tagged !== attempt.node || !valid(snapshot(), attempt) || attempt.clicked) {
        event.preventDefault();
        event.stopImmediatePropagation();
        attempt.blocked = true;
        return;
      }
      attempt.allowed = true;
      attempt.clicked ||= event.type === "click";
    };
    node.setAttribute("data-meta-answer-choice", input.token);
    watchChoiceView(attempt);
    for (const type of ["pointerdown", "mousedown", "click"]) {
      document.addEventListener(type, attempt.guard, true);
    }
    state.attempts.set(reservation, attempt);
    return { armed: true, selector };
  };

  // js/src/sources/browser-text-controller.js
  var textReplyOpen = (spec) => {
    const nodes = [
      ...document.querySelectorAll('p,span,div,[role="status"],[role="alert"]')
    ];
    if (nodes.length > 5e3) {
      return false;
    }
    const pattern = new RegExp(spec.textReply.closedText, "iu");
    return !nodes.some(
      (node) => !node.children.length && browserFrameVisible(node) && pattern.test(node.textContent)
    );
  };
  var textReplyButtons = (spec) => [...document.querySelectorAll(spec.textReply.send)].filter(
    (node) => browserFrameVisible(node) && !node.matches(':disabled,[disabled],[aria-disabled="true"]') && !node.closest('[inert],[aria-disabled="true"]')
  );
  var armTextReply = (input, context) => {
    const {
      snapshot,
      same,
      state,
      identity,
      own,
      valueOf,
      write,
      writable,
      clearOwned
    } = context;
    const current = snapshot();
    if (!same(current) || current.strictOptions || !writable(current.composer) || !textReplyOpen(input.spec)) {
      return { code: "answer-text-changed" };
    }
    if (valueOf(current.composer)) {
      return { code: "answer-draft-preserved" };
    }
    const code = browserReplyAdmission(state, identity(current));
    if (code) {
      return { code };
    }
    const composer = current.composer;
    if (!write(composer, input.text)) {
      return { code: "answer-prefill-unverified" };
    }
    const owner = own(current, input.text);
    const valid = (fresh2, attempt2) => same(fresh2) && !fresh2.strictOptions && textReplyOpen(input.spec) && fresh2.composer === composer && writable(composer) && state.owners.get(composer) === owner && valueOf(composer) === input.text && !attempt2.preserveView && textReplyButtons(input.spec).length === 1 && textReplyButtons(input.spec)[0] === attempt2.node;
    const buttons = textReplyButtons(input.spec);
    const fresh = snapshot();
    if (buttons.length !== 1 || !valid(fresh, { node: buttons[0] })) {
      clearOwned(current);
      return { code: "answer-text-changed" };
    }
    const armed = armBrowserReply(input, context, fresh, buttons[0], valid);
    const attempt = state.attempts.get(identity(current));
    if (armed.armed) {
      attempt.clearDraft = () => {
        if (!attempt.allowed && state.owners.get(composer) === owner) {
          clearOwned(current);
        }
      };
    } else {
      clearOwned(current);
    }
    return armed;
  };

  // js/src/sources/browser-notice-context.js
  var noticeVacancyUrl = (link) => {
    let url;
    try {
      url = new URL(link.href);
      if (!["https://hh.ru", "https://www.hh.ru"].includes(url.origin) || url.username || url.password || !/^\/vacancy\/\d{1,30}\/?$/u.test(url.pathname)) {
        return null;
      }
    } catch {
      return null;
    }
    return `${url.origin}${url.pathname}`;
  };
  var browserNoticeContext = (spec) => {
    const selectors = spec.noticeContext;
    if (!selectors) {
      return null;
    }
    const one = (selector) => {
      const nodes = [...document.querySelectorAll(selector)].filter(
        browserFrameVisible
      );
      return nodes.length === 1 ? nodes[0] : null;
    };
    const company = one(selectors.company)?.textContent?.trim();
    const vacancy = one(selectors.vacancy)?.textContent?.trim();
    const link = one(selectors.link);
    if (!company || company.length > 600 || !vacancy || vacancy.length > 600 || !link) {
      return null;
    }
    const vacancyUrl = noticeVacancyUrl(link);
    if (!vacancyUrl) {
      return null;
    }
    const composer = one(spec.composer);
    return {
      noticeContext: {
        company,
        vacancy,
        vacancyUrl,
        canReply: Boolean(
          composer && !composer.matches(
            ':disabled,[disabled],[readonly],[aria-disabled="true"],[aria-readonly="true"]'
          ) && !composer.closest('[inert],[aria-disabled="true"]') && textReplyOpen(spec)
        )
      }
    };
  };

  // js/src/sources/browser-choice-reader.js
  var browserChoiceSuggestions = (spec, group, all, visible, text) => {
    if (!spec.choices.genericGroup || !group.matches(spec.choices.genericGroup) || group.closest(spec.messages.item)) {
      return false;
    }
    const offered = all.filter((node) => group.contains(node) && visible(node));
    const pattern = new RegExp(spec.choices.genericPattern, "iu");
    return offered.length > 0 && offered.some((node) => pattern.test(text(node)));
  };
  var browserChoiceHistory = (spec, visible, text, historyOnly = false) => {
    const unavailable = (code) => ({ code });
    const validLocation = (url2, match2) => spec.location.origins.includes(url2.origin) && Boolean(match2?.[1]);
    const validRows = (rows2) => !rows2.some((row) => !row.id || row.body.length > 6e3) && new Set(rows2.map((row) => row.id)).size === rows2.length;
    const bodyOf = (node) => String(node.querySelector(spec.messages.body)?.innerText ?? "").trim();
    const url = new URL(location.href);
    const match = new RegExp(spec.location.pathPattern).exec(url.pathname);
    if (!validLocation(url, match)) {
      return unavailable("answer-chat-unverified");
    }
    const chat = match[1];
    const candidates = [...document.querySelectorAll(spec.messages.item)];
    if (candidates.length > 500) {
      return unavailable("answer-history-limited");
    }
    const idPattern = new RegExp(spec.messages.idPattern);
    const serviceTitle = spec.messages.serviceTitlePattern ? new RegExp(spec.messages.serviceTitlePattern, "iu") : null;
    const rows = candidates.filter(visible).map((node) => ({
      node,
      id: idPattern.exec(node.getAttribute(spec.messages.idAttribute) ?? "")?.[1],
      body: bodyOf(node),
      outgoing: node.matches(spec.messages.outgoing) || Boolean(node.querySelector(spec.messages.outgoing)),
      ...serviceTitle?.test(text(node.querySelector(spec.messages.serviceTitle))) ? { service: true } : {}
    }));
    if (!validRows(rows)) {
      return unavailable("answer-history-unverified");
    }
    const messages = rows.map(({ node, ...row }) => ({
      ...row,
      timestamp: spec.messages.timestampAttribute ? node.getAttribute(spec.messages.timestampAttribute) : null
    }));
    const latest = rows.at(-1);
    const pendingTurn = historyOnly ? void 0 : browserPendingTurn(messages);
    if (pendingTurn?.code) {
      return pendingTurn;
    }
    return {
      chat,
      latest,
      messages,
      pendingTurn,
      questionAvailable: Boolean(latest?.body) && !latest.service
    };
  };
  var readBrowserChoices = (spec, internal = false, historyOnly = false) => {
    const text = (node) => String(node?.textContent ?? "").replace(/\s+/gu, " ").trim();
    const visible = (node) => {
      if (!node?.isConnected || !node.getClientRects().length) {
        return false;
      }
      for (let parent = node; parent; parent = parent.parentElement) {
        const style = getComputedStyle(parent);
        if (parent.hidden || parent.getAttribute("aria-hidden") === "true" || style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) {
          return false;
        }
      }
      return true;
    };
    const unavailable = (code) => ({ code });
    const validControls = (controls2) => controls2.length <= 100 && !controls2.some((node) => !text(node) || text(node).length > 6e3);
    const history = browserChoiceHistory(spec, visible, text, historyOnly);
    if (history.code) {
      return history;
    }
    const { chat, latest, messages, pendingTurn, questionAvailable } = history;
    if (!questionAvailable) {
      return historyOnly ? { chat, messages } : unavailable("answer-question-unavailable");
    }
    const all = [...document.querySelectorAll(spec.choices.button)];
    if (all.length > 1e3) {
      return unavailable("answer-options-limited");
    }
    const groups = [...document.querySelectorAll(spec.choices.group)].filter(
      (group) => visible(group) && !browserChoiceSuggestions(spec, group, all, visible, text)
    );
    const attached = groups.filter((group) => {
      const dialog = group.closest('[role="dialog"]');
      if (dialog && !dialog.contains(latest.node)) {
        return false;
      }
      const parent = group.closest(spec.messages.item);
      if (parent) {
        return parent === latest.node;
      }
      const bound = group.getAttribute(
        spec.choices.questionAttribute ?? "data-question-id"
      );
      return bound ? bound === latest.id : Boolean(latest.node.compareDocumentPosition(group) & 4);
    }).filter(
      (group, _index, selected) => !selected.some((other) => other !== group && group.contains(other))
    );
    if (groups.length > 100 || attached.length > 1) {
      return unavailable("answer-options-ambiguous");
    }
    const shown = all.filter(visible);
    const yes = /^(?:yes|да|हाँ|是)[.!]?$/iu;
    const no = /^(?:no|нет|नहीं|否)[.!]?$/iu;
    const unscoped = shown.filter((node) => {
      const owner = node.closest(spec.messages.item);
      const dialog = node.closest('[role="dialog"]');
      return (!owner || owner === latest.node) && (!dialog || dialog.contains(latest.node)) && !groups.some((group) => group.contains(node)) && (yes.test(text(node)) || no.test(text(node)));
    });
    const pair = unscoped.length === 2 && unscoped.some((node) => yes.test(text(node))) && unscoped.some((node) => no.test(text(node)));
    const controls = shown.filter(
      (node) => attached.some((group) => group.contains(node)) || spec.choices.attachedButtons && latest.node.contains(node) || pair && unscoped.includes(node)
    );
    if (!validControls(controls)) {
      return unavailable("answer-options-unverified");
    }
    const enabled = controls.filter(
      (node) => !node.matches(':disabled,[disabled],[aria-disabled="true"]') && !node.closest('[inert],[aria-disabled="true"]')
    );
    const strictOptions = [attached.length, pair, controls.length].some(Boolean);
    const answerOptions = enabled.map(text);
    if (historyOnly) {
      return {
        chat,
        messages: messages.map(
          (row) => row.id === latest.id ? { ...row, strictOptions, answerOptions } : row
        )
      };
    }
    const composers = [...document.querySelectorAll(spec.composer)].filter(
      visible
    );
    if (composers.length > 1) {
      return unavailable("answer-composer-ambiguous");
    }
    const result = {
      chat,
      question: { id: latest.id, body: latest.body, outgoing: latest.outgoing },
      strictOptions,
      answerOptions,
      optionsShown: controls.map(text),
      messages,
      pendingTurn,
      ...browserNoticeContext(spec)
    };
    return internal ? { ...result, controls: enabled, composer: composers[0] } : result;
  };

  // js/src/sources/browser-choice-controller.js
  var createChoiceContext = (input, read) => {
    const { spec, expected } = input;
    const key = /* @__PURE__ */ Symbol.for("meta-sovereign.browser-answer-choice.v1");
    const state = window[key] ??= {
      owners: /* @__PURE__ */ new WeakMap(),
      observed: /* @__PURE__ */ new WeakSet(),
      attempts: /* @__PURE__ */ new Map()
    };
    const snapshot = (historyOnly = false) => read(spec, true, historyOnly);
    const inactiveKey = /* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1");
    const inactive = input.inactiveToken && window[inactiveKey];
    const inactiveReady2 = () => !input.inactiveToken || inactive && window[inactiveKey] === inactive && inactive.token === input.inactiveToken && !inactive.interrupted && !document.hasFocus();
    const identity = (value) => JSON.stringify([value.chat, value.question?.id, value.question?.body]);
    const ownershipIdentity = (value) => JSON.stringify([identity(value), value.pendingTurn]);
    const samePending = (value) => expected.pendingTurn ? JSON.stringify(value.pendingTurn) === JSON.stringify(expected.pendingTurn) : expected.pendingMessages ? JSON.stringify(value.pendingTurn?.messages) === JSON.stringify(expected.pendingMessages) : value.pendingTurn?.messages.length === 1;
    const same = (value) => inactiveReady2() && !value.code && !value.question.outgoing && identity(value) === identity(expected) && samePending(value) && (!expected.noticeContext || JSON.stringify(value.noticeContext) === JSON.stringify(expected.noticeContext)) && JSON.stringify(value.answerOptions) === JSON.stringify(expected.answerOptions);
    const valueOf = (node) => node ? String("value" in node ? node.value : node.textContent ?? "") : "";
    const writable = (node) => Boolean(node) && !node.matches(
      ':disabled,[disabled],[readonly],[inert],[aria-disabled="true"],[aria-readonly="true"]'
    ) && !node.closest('[inert],[aria-disabled="true"]');
    const write = (node, value) => {
      if (!writable(node) || !inactiveReady2()) {
        return false;
      }
      state.writing = true;
      try {
        return writeBrowserNativeInput(node, value, inactive);
      } finally {
        state.writing = false;
      }
    };
    const clearOwned = (current) => {
      const node = current.composer;
      const owner = node && state.owners.get(node);
      if (owner && owner.identity === ownershipIdentity(current) && valueOf(node) === owner.text) {
        const attempt = state.attempts.get(identity(current));
        if (attempt?.allowed && !attempt.confirmed) {
          return false;
        }
        state.owners.delete(node);
        return write(node, "");
      }
      return !valueOf(node);
    };
    const own = (current, text) => {
      const node = current.composer;
      const owner = { identity: ownershipIdentity(current), text };
      state.owners.set(node, owner);
      if (!state.observed.has(node)) {
        state.observed.add(node);
        node.addEventListener("input", () => {
          if (!state.writing) {
            state.owners.delete(node);
          }
        });
      }
      return owner;
    };
    const clean = (attempt) => {
      attempt.clearDraft?.();
      watchChoiceView(attempt, true);
      attempt.node.removeAttribute("data-meta-answer-choice");
      for (const node of document.querySelectorAll("[data-meta-answer-choice]")) {
        if (node.getAttribute("data-meta-answer-choice") === attempt.token) {
          node.removeAttribute("data-meta-answer-choice");
        }
      }
      for (const type of ["pointerdown", "mousedown", "click"]) {
        document.removeEventListener(type, attempt.guard, true);
      }
    };
    return {
      state,
      snapshot,
      identity,
      ownershipIdentity,
      same,
      valueOf,
      writable,
      own,
      write,
      clearOwned,
      clean
    };
  };
  var readChoiceHistory = (_input, { snapshot }) => snapshot(true);
  var readChoicePublic = (input, context) => {
    const { snapshot, clearOwned, valueOf } = context;
    const current = snapshot();
    if (current.code) {
      return current;
    }
    if (!input.preserveDraft && current.optionsShown.length) {
      clearOwned(current);
    }
    const { controls: _controls, composer, ...result } = current;
    return { ...result, hasDraft: Boolean(valueOf(composer)) };
  };
  var prefillChoiceDraft = (input, context) => {
    const { snapshot, same, valueOf, write, own } = context;
    const current = snapshot();
    if (!same(current) || current.strictOptions || !current.composer || valueOf(current.composer)) {
      return { code: "answer-draft-preserved" };
    }
    const node = current.composer;
    if (!write(node, input.text)) {
      return { code: "answer-prefill-unverified" };
    }
    own(current, input.text);
    return same(snapshot()) ? { prefilled: true } : { code: "answer-prefill-unverified" };
  };
  var armChoiceClick = (input, context) => {
    const { option } = input;
    const { snapshot, same, clearOwned, valueOf } = context;
    const current = snapshot();
    const candidates = current.controls?.filter(
      (node) => String(node.textContent).replace(/\s+/gu, " ").trim() === option
    ) ?? [];
    if (!same(current) || !current.strictOptions || candidates.length !== 1) {
      return { code: "answer-choice-changed" };
    }
    if (!clearOwned(current)) {
      return { code: "answer-draft-preserved" };
    }
    return armBrowserReply(
      input,
      context,
      current,
      candidates[0],
      (fresh, attempt) => same(fresh) && fresh.controls.includes(attempt.node) && !valueOf(fresh.composer)
    );
  };
  var matchingChoiceReplies = (input, current, attempt) => {
    const { expected, option } = input;
    const questionIndex = current.messages?.findIndex((row) => row.id === expected.question.id) ?? -1;
    const matchesReply = (row) => row.outgoing && !row.service && !attempt.before.includes(row.id) && row.body === (option ?? input.text);
    return !current.code && current.chat === expected.chat && questionIndex >= 0 ? current.messages.slice(questionIndex + 1).filter(matchesReply) : [];
  };
  var readChoiceReceipt = (input, context) => {
    const { state, snapshot, clean } = context;
    const attempt = [...state.attempts.values()].find(
      (entry) => entry.token === input.token
    );
    if (!attempt) {
      return { code: "send-unknown" };
    }
    const current = snapshot();
    const matches = matchingChoiceReplies(input, current, attempt);
    const confirmed = (input.text === void 0 ? attempt.allowed : attempt.clicked) && matches.length === 1;
    if (confirmed || input.finish) {
      clean(attempt);
    }
    if (confirmed) {
      if (!attempt.confirmed) {
        attempt.reveal = revealChoiceReply(
          input.spec,
          attempt,
          current,
          matches[0]
        );
      }
      attempt.confirmed = true;
      return { sent: true, messageId: matches[0].id, reveal: attempt.reveal };
    }
    if (input.finish && !attempt.allowed && attempt.blocked) {
      state.attempts.delete(attempt.reservation);
      return {
        code: input.text === void 0 ? "answer-choice-changed" : "answer-text-changed",
        dispatched: false
      };
    }
    return { code: "send-unknown", blocked: Boolean(attempt.blocked) };
  };
  var releaseChoiceClick = ({ token }, { state, clean }) => {
    const attempt = [...state.attempts.values()].find(
      (entry) => entry.token === token
    );
    if (attempt) {
      clean(attempt);
    }
    return { released: true };
  };

  // js/src/crm/question-recognition.js
  var W = "[\\p{L}\\p{M}\\p{N}_]";
  var start = (source2) => new RegExp(`^(?:${source2})(?!${W})`, "iu");
  var QUESTION_START = start(
    "\u043A\u0430\u043A|\u0447\u0442\u043E|\u0447\u0435\u043C|\u0433\u0434\u0435|\u043A\u0443\u0434\u0430|\u043E\u0442\u043A\u0443\u0434\u0430|\u043A\u043E\u0433\u0434\u0430|\u043F\u043E\u0447\u0435\u043C\u0443|\u0437\u0430\u0447\u0435\u043C|\u043A\u0442\u043E|\u043A\u0435\u043C|\u043A\u0430\u043A\u043E\u0439|\u043A\u0430\u043A\u0430\u044F|\u043A\u0430\u043A\u043E\u0435|\u043A\u0430\u043A\u0438\u0435|\u0441\u043A\u043E\u043B\u044C\u043A\u043E|\u043C\u043E\u0436\u043D\u043E|\u043D\u0435\u043B\u044C\u0437\u044F \u043B\u0438|\u043D\u0435 \u043F\u043E\u0434\u0441\u043A\u0430\u0436\u0435\u0442\u0435|\u043F\u043E\u0434\u0441\u043A\u0430\u0436\u0438|\u043F\u043E\u0434\u0441\u043A\u0430\u0436\u0438\u0442\u0435|\u0435\u0441\u0442\u044C \u043B\u0438|\u0431\u044B\u043B \u043B\u0438|\u0431\u044B\u043B\u0430 \u043B\u0438|\u0431\u044B\u043B\u0438 \u043B\u0438|how|what|where|when|why|who|which|do you|did you|are you|can you|could you|would you|is there|have you"
  );
  var REQUEST = start(
    "please\\s+(?:tell|share|describe|provide|send)|tell\\s+(?:me|us)|describe\\s+your|share\\s+your|\u0440\u0430\u0441\u0441\u043A\u0430\u0436\u0438\u0442\u0435|\u0440\u0430\u0441\u0441\u043A\u0430\u0436\u0438|\u0443\u043A\u0430\u0436\u0438\u0442\u0435|\u0443\u043A\u0430\u0436\u0438|\u043D\u0430\u043F\u0438\u0448\u0438\u0442\u0435|\u043D\u0430\u043F\u0438\u0448\u0438|\u043F\u0440\u0438\u0448\u043B\u0438\u0442\u0435|\u043F\u0440\u0438\u0448\u043B\u0438|\u0443\u0442\u043E\u0447\u043D\u0438\u0442\u0435|\u0443\u0442\u043E\u0447\u043D\u0438|\u0441\u043E\u043E\u0431\u0449\u0438\u0442\u0435|\u0441\u043E\u043E\u0431\u0449\u0438|\u043E\u043F\u0438\u0448\u0438\u0442\u0435|\u043E\u043F\u0438\u0448\u0438|\u043F\u043E\u0434\u0435\u043B\u0438\u0442\u0435\u0441\u044C|\u043F\u043E\u0434\u0435\u043B\u0438\u0441\u044C|\u043F\u0440\u0438\u0432\u0435\u0434\u0438(?:\u0442\u0435)?\\s+\u043F\u0440\u0438\u043C\u0435\u0440"
  );
  var HINDI_WORD = "\u0915\u094D\u092F\u093E|\u0915\u0939\u093E\u0901|\u0915\u0939\u093E\u0902|\u0915\u092C|\u0915\u094D\u092F\u094B\u0902|\u0915\u0948\u0938\u0947|\u0915\u094C\u0928|\u0915\u093F\u0938(?:\u0915\u093E|\u0915\u0940|\u0915\u0947|\u0947)?|\u0915\u093F\u0924\u0928(?:\u093E|\u0940|\u0947)";
  var HINDI_START = start(HINDI_WORD);
  var HINDI_SUBJECT = new RegExp(
    `^(?:\u0906\u092A|\u0924\u0941\u092E|\u0906\u092A\u0915\u093E|\u0906\u092A\u0915\u0940|\u0906\u092A\u0915\u0947|\u0924\u0941\u092E\u094D\u0939\u093E\u0930\u093E|\u0924\u0941\u092E\u094D\u0939\u093E\u0930\u0940|\u0924\u0941\u092E\u094D\u0939\u093E\u0930\u0947)(?!${W})[^\u0964.!?\\r\\n]{0,100}?(?<!${W})(?:${HINDI_WORD})(?!${W})`,
    "u"
  );
  var HINDI_REQUEST = new RegExp(
    `^(?:\u0915\u0943\u092A\u092F\u093E(?!${W})[^\u0964.!?\\r\\n]{0,160}?(?<!${W}))?(?:\u092C\u0924\u093E\u0907\u090F|\u092C\u0924\u093E\u090F\u0902|\u092C\u0924\u093E\u092F\u0947\u0902|\u092C\u0924\u093E\u0913|\u0938\u093E\u091D\u093E \u0915\u0930\u0947\u0902|\u092D\u0947\u091C\u0947\u0902|\u092A\u094D\u0930\u0926\u093E\u0928 \u0915\u0930\u0947\u0902|\u0909\u0932\u094D\u0932\u0947\u0916 \u0915\u0930\u0947\u0902|\u0932\u093F\u0916\u0947\u0902)(?!${W})`,
    "u"
  );

  // js/src/automation/question-subjects.js
  var names = [
    ["go", ["go", "golang"]],
    ["csharp", ["c#", "\u0441#", "csharp", "c-sharp"]],
    ["cpp", ["c++", "\u0441++", "cpp"]],
    ["c", ["c", "\u0441\u0438"]],
    ["javascript", ["javascript", "js", "\u0434\u0436\u0430\u0432\u0430\u0441\u043A\u0440\u0438\u043F\u0442"]],
    ["typescript", ["typescript", "ts"]],
    ["java", ["java", "\u0434\u0436\u0430\u0432\u0430"]],
    ["python", ["python", "\u043F\u0438\u0442\u043E\u043D"]],
    ["rust", ["rust"]],
    ["ruby", ["ruby"]],
    ["php", ["php"]],
    ["swift", ["swift"]],
    ["kotlin", ["kotlin"]],
    ["scala", ["scala"]],
    ["docker", ["docker", "\u0434\u043E\u043A\u0435\u0440"]],
    ["kubernetes", ["kubernetes", "k8s"]],
    ["mongodb", ["mongodb", "mongo"]],
    ["postgresql", ["postgresql", "postgres"]],
    ["mysql", ["mysql"]],
    ["redis", ["redis"]],
    ["aws", ["aws"]],
    ["azure", ["azure"]],
    ["gcp", ["gcp"]],
    ["react", ["react", "reactjs"]],
    ["angular", ["angular"]],
    ["vue", ["vue", "vuejs"]],
    ["git", ["git", "\u0433\u0438\u0442"]],
    ["github", ["github"]],
    ["linkedin", ["linkedin"]],
    ["telegram", ["telegram", "\u0442\u0435\u043B\u0435\u0433\u0440\u0430\u043C"]],
    ["lead", ["lead", "\u0442\u0438\u043C\u043B\u0438\u0434", "\u0442\u0435\u0445\u043B\u0438\u0434"]],
    ["junior", ["junior"]],
    ["senior", ["senior"]],
    ["usd", ["usd", "\u0434\u043E\u043B\u043B\u0430\u0440", "\u0434\u043E\u043B\u043B\u0430\u0440\u043E\u0432", "dollar", "dollars"]],
    [
      "rub",
      [
        "rub",
        "rur",
        "\u0440\u0443\u0431",
        "\u0440\u0443\u0431\u043B\u0435\u0439",
        "\u0440\u0443\u0431\u043B\u044F\u0445",
        "\u0440\u0443\u0431\u043B\u0438",
        "\u0440\u0443\u0431\u043B\u044C",
        "rubles",
        "roubles"
      ]
    ],
    ["eur", ["eur", "euro", "euros", "\u0435\u0432\u0440\u043E"]],
    ["gbp", ["gbp"]],
    ["inr", ["inr"]],
    ["cny", ["cny", "rmb"]],
    ["vnd", ["vnd"]],
    ["jpy", ["jpy"]],
    ["employment:ip", ["\u0438\u043F"]],
    ["employment:gph", ["\u0433\u043F\u0445"]],
    ["employment:self", ["\u0441\u0430\u043C\u043E\u0437\u0430\u043D\u044F\u0442\u044B\u0439", "\u0441\u0430\u043C\u043E\u0437\u0430\u043D\u044F\u0442\u044B\u043C\u0438", "\u0441\u0430\u043C\u043E\u0437\u0430\u043D\u044F\u0442\u043E\u0441\u0442\u044C"]]
  ];
  var aliases = new Map(
    names.flatMap(([key, values]) => values.map((name) => [name, key]))
  );

  // js/src/automation/question-options.js
  var explicitChoice = /\b(?:choose|select|pick)\s+(?:one|an?\s+option|from)\b|выбер(?:и|ите)\s+(?:один|одну|вариант|из)|(?:एक|कोई)\s+विकल्प\s+चुन|请(?:选择|选取)(?:一个|一项)|选择一个/iu;
  var answerChoiceState = (question, input = {}) => {
    const options = input.options === void 0 ? [] : input.options;
    if (!Array.isArray(options) || options.length > 100 || options.some(
      (option) => typeof option !== "string" || !option.trim() || option.length > 6e3
    ) || input.strictOptions !== void 0 && typeof input.strictOptions !== "boolean") {
      throw new Error(
        "Answer choices require bounded text and a boolean strictOptions"
      );
    }
    return {
      options,
      strictOptions: input.strictOptions === true || options.length > 0 || input.questionMode !== "field" && explicitChoice.test(question)
    };
  };

  // js/src/automation/question-turns.js
  var ACK_WORDS = new Set(
    "\u043E\u043A \u043E\u043A\u0435\u0439 \u0445\u043E\u0440\u043E\u0448\u043E \u043F\u043E\u043D\u044F\u043B \u043F\u043E\u043D\u044F\u043B\u0430 \u0441\u043F\u0430\u0441\u0438\u0431\u043E \u0431\u043B\u0430\u0433\u043E\u0434\u0430\u0440\u044E \u043F\u0440\u0438\u043D\u044F\u0442\u043E \u043E\u0442\u043B\u0438\u0447\u043D\u043E \u044F\u0441\u043D\u043E \u0437\u0430 \u0432\u0430\u0448 \u0432\u0430\u0448\u0438 \u043E\u0442\u0432\u0435\u0442 \u043E\u0442\u0432\u0435\u0442\u044B \u043E\u0442\u043A\u043B\u0438\u043A \u043F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0441\u0442\u0438 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044E \u0443\u0447\u0442\u0443 \u043E\u043F\u044B\u0442 hello hi thanks thank you for the your answer answers details information understood noted okay ok got it \u0928\u092E\u0938\u094D\u0924\u0947 \u0927\u0928\u094D\u092F\u0935\u093E\u0926 \u8C22\u8C22 \u597D\u7684".split(
      " "
    )
  );
  var CONSENT_WORDS = new Set(
    "yes no yeah yep sure okay ok yes of course let s lets continue please thanks thank you maybe perhaps da \u0434\u0430 \u043D\u0435\u0442 \u043A\u043E\u043D\u0435\u0447\u043D\u043E \u0430\u0433\u0430 \u0443\u0433\u0443 \u0445\u043E\u0440\u043E\u0448\u043E \u043E\u043A \u0434\u0430\u0432\u0430\u0439\u0442\u0435 \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u043C \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0430\u0442\u044C \u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0441\u043F\u0430\u0441\u0438\u0431\u043E \u0431\u043B\u0430\u0433\u043E\u0434\u0430\u0440\u044E \u043D\u0435 \u0443\u0432\u0435\u0440\u0435\u043D \u0443\u0432\u0435\u0440\u0435\u043D\u0430 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E \u0939\u093E\u0901 \u0939\u093E\u0902 \u091C\u0940 \u0928\u0939\u0940\u0902 \u0920\u0940\u0915 \u091C\u093E\u0930\u0940 \u0930\u0916\u0947\u0902 \u0927\u0928\u094D\u092F\u0935\u093E\u0926 \u662F \u597D\u7684 \u7EE7\u7EED \u662F\u7684 \u4E0D \u8C22\u8C22".split(
      " "
    )
  );

  // js/src/sources/browser-text-reply.js
  var failure3 = (code) => Object.assign(
    new Error("The frozen provider text reply could not be verified."),
    { code, fallback: false }
  );
  var checkedTextSnapshot = (target, expected) => {
    const question = expected?.question;
    const pendingTurn = question && checkedBrowserPendingTurn(expected.pendingTurn, question);
    if (expected?.chat !== String(target) || expected.strictOptions !== false || !Array.isArray(expected.answerOptions) || expected.answerOptions.length || !question || question.outgoing !== false || !pendingTurn || answerChoiceState(question.body, { options: [] }).strictOptions) {
      throw failure3("bad-draft");
    }
    return {
      chat: String(target),
      strictOptions: false,
      question: { id: question.id, body: question.body, outgoing: false },
      pendingTurn,
      answerOptions: [],
      ...expected.noticeContext ? { noticeContext: expected.noticeContext } : {}
    };
  };
  var checkedTextReply = (ui, target, expected, text) => {
    if (!ui.documents || !ui.textReply?.send || !ui.textReply.closedText) {
      throw failure3("answer-text-unavailable");
    }
    if (typeof text !== "string" || !text.trim() || text.length > 12e3) {
      throw failure3("bad-draft");
    }
    return checkedTextSnapshot(target, expected);
  };
  var sendBrowserTextReply = async (commander, ui, target, expected, text, options = {}) => {
    const frozen = checkedTextReply(ui, target, expected, text);
    const result = await dispatchBrowserReply(
      commander,
      { spec: browserChoiceSpec(ui), expected: frozen, text },
      {
        receiptMs: options.receiptMs ?? 1e4,
        pollMs: options.pollMs ?? 100,
        inactiveToken: options.inactiveToken,
        verifyCurrent: options.verifyCurrent
      }
    );
    return {
      via: "browser",
      source: ui.id,
      chat: String(target),
      messageId: result.messageId,
      text
    };
  };

  // js/src/sources/browser-scan-options.js
  var bounded = (value, fallback, minimum, maximum) => {
    const result = value ?? fallback;
    if (!Number.isInteger(result) || result < minimum || result > maximum) {
      throw Object.assign(new Error("Invalid bounded browser scan setting"), {
        code: "bad-chat-scan",
        fallback: false
      });
    }
    return result;
  };
  var normalizeChatScanOptions = (options = {}) => {
    if (options.unreadOnly !== void 0 && typeof options.unreadOnly !== "boolean") {
      throw Object.assign(new Error("Unread-only selection must be a boolean"), {
        code: "bad-chat-scan",
        fallback: false
      });
    }
    return {
      limit: bounded(options.limit, 500, 1, 5e3),
      maxPasses: bounded(options.maxPasses, 100, 1, 500),
      budgetMs: bounded(options.budgetMs, 3e4, 100, 12e4),
      waitMs: bounded(options.waitMs, 150, 10, 1e3),
      endWaitMs: bounded(options.endWaitMs, 2e3, 100, 1e4)
    };
  };

  // js/src/sources/browser-choices.js
  var methods = {
    read: readChoicePublic,
    history: readChoiceHistory,
    prefill: prefillChoiceDraft,
    arm: armChoiceClick,
    armText: armTextReply,
    receipt: readChoiceReceipt,
    release: releaseChoiceClick
  };
  var source = `(input) => {
  const writeBrowserNativeInput = (${writeBrowserNativeInput.toString()});
  const watchChoiceView = (${watchChoiceView.toString()});
  const revealChoiceReply = (${revealChoiceReply.toString()});
  const browserFrameVisible = (${browserFrameVisible.toString()});
  const browserReplyAdmission = (${browserReplyAdmission.toString()});
  const matchingChoiceReplies = (${matchingChoiceReplies.toString()});
  const armBrowserReply = (${armBrowserReply.toString()});
  const textReplyButtons = (${textReplyButtons.toString()});
  const textReplyOpen = (${textReplyOpen.toString()});
  const noticeVacancyUrl = (${noticeVacancyUrl.toString()});
  const browserNoticeContext = (${browserNoticeContext.toString()});
  const browserPendingTurn = (${browserPendingTurn.toString()});
  const browserChoiceSuggestions = (${browserChoiceSuggestions.toString()});
  const browserChoiceHistory = (${browserChoiceHistory.toString()});
  const context = (${createChoiceContext.toString()})(input, ${readBrowserChoices.toString()});
  const methods = {${Object.entries(methods).map(([name, method]) => `${name}: ${method.toString()}`).join(",")}};
  return methods[input.operation](input, context);
}`;
  var browserChoicePage = new Function(`return (${source})`)();
  var failure4 = (code) => Object.assign(
    new Error(
      {
        "answer-draft-preserved": "The provider composer contains an owner draft; review it before selecting an answer",
        "send-unknown": "The option may have been selected; inspect the provider chat before trying again",
        "send-in-doubt": "This question already has a selection attempt; inspect the provider chat before trying again"
      }[code] ?? "The current provider question or answer controls could not be verified"
    ),
    {
      code,
      fallback: false,
      ...["send-unknown", "send-in-doubt"].includes(code) ? { ambiguous: true, outcome: "unknown" } : {}
    }
  );
  var browserChoiceSpec = (ui) => {
    if (!ui.choices || !ui.location || !ui.messages.idPattern || !ui.messages.outgoing) {
      throw failure4("answer-choice-required");
    }
    return {
      choices: ui.choices,
      location: ui.location,
      messages: ui.messages,
      composer: ui.composer,
      ...ui.textReply ? { textReply: ui.textReply } : {},
      ...ui.noticeContext ? { noticeContext: ui.noticeContext } : {}
    };
  };
  var evaluate = (commander, input) => commander.evaluate({ fn: browserChoicePage, args: [input] });
  var readBrowserHistory = async (commander, ui, target) => {
    const value = await evaluate(commander, {
      spec: browserChoiceSpec(ui),
      operation: "history"
    });
    if (value.code || value.chat !== String(target)) {
      throw failure4(value.code ?? "answer-chat-unverified");
    }
    return value.messages;
  };
  var readBrowserAnswerChoices = async (commander, ui, target, options = {}) => {
    const value = await evaluate(commander, {
      spec: browserChoiceSpec(ui),
      operation: "read",
      preserveDraft: options.preserveDraft === true
    });
    if (value.code || value.chat !== String(target)) {
      throw failure4(value.code ?? "answer-chat-unverified");
    }
    const choices = answerChoiceState(value.question.body, {
      options: value.answerOptions,
      strictOptions: value.strictOptions
    });
    return { ...value, ...choices, answerOptions: choices.options };
  };
  var validWait = (receiptMs, pollMs) => Number.isSafeInteger(receiptMs) && receiptMs >= 0 && receiptMs <= 3e4 && Number.isSafeInteger(pollMs) && pollMs >= 1 && pollMs <= 1e3;
  var issueBrowserReply = async (commander, selector, inactiveToken) => {
    try {
      await commander.clickButton({
        selector,
        scrollIntoView: !inactiveToken,
        ...inactiveToken ? { inactiveToken, activation: "dom", scroll: "none" } : {},
        waitForNavigation: false,
        waitAfterClick: 0,
        verify: false
      });
    } catch (error) {
      if (inactiveToken && error?.dispatched === false) {
        throw error;
      }
    }
  };
  var dispatchBrowserReply = async (commander, request, { receiptMs, pollMs, inactiveToken, verifyCurrent }) => {
    if (!validWait(receiptMs, pollMs)) {
      throw failure4("bad-draft");
    }
    const input = {
      ...request,
      ...inactiveToken ? { inactiveToken } : {},
      token: randomBytes(16).toString("hex")
    };
    try {
      await verifyCurrent?.();
      const armed = await evaluate(commander, {
        ...input,
        operation: input.text === void 0 ? "arm" : "armText"
      });
      if (!armed.armed) {
        throw failure4(armed.code);
      }
      await verifyCurrent?.();
      await issueBrowserReply(commander, armed.selector, inactiveToken);
      const deadline = Date.now() + receiptMs;
      for (; ; ) {
        let result;
        const finish = Date.now() >= deadline;
        try {
          result = await evaluate(commander, {
            ...input,
            operation: "receipt",
            finish
          });
        } catch {
          throw failure4("send-unknown");
        }
        if (result.sent) {
          return result;
        }
        if (finish) {
          throw failure4(result.code);
        }
        await setTimeout2(pollMs);
      }
    } finally {
      try {
        await evaluate(commander, { ...input, operation: "release" });
      } catch {
      }
    }
  };

  // js/src/sources/browser-conversation-history.js
  var stopped = (historyReason) => {
    throw Object.assign(new Error("Conversation history traversal stopped"), {
      historyReason
    });
  };
  var mergeConversationWindow = (known, incoming) => {
    if (!known.length) {
      return incoming.slice();
    }
    const positions = new Map(known.map((row, index) => [row.id, index]));
    const shared = incoming.findIndex((row) => positions.has(row.id));
    if (shared < 0) {
      stopped("history-gap");
    }
    const offset = positions.get(incoming[shared].id);
    if (shared > 0 && offset !== 0) {
      stopped("history-gap");
    }
    for (let index = shared; index < incoming.length; index++) {
      if (JSON.stringify(incoming[index]) !== JSON.stringify(known[offset + index - shared])) {
        stopped("conversation-changed");
      }
    }
    return [...incoming.slice(0, shared), ...known];
  };
  var releaseBrowserConversation = async (control, pause, waitMs, verifyCurrent) => {
    let restored = false;
    let restore;
    try {
      await verifyCurrent?.();
      restore = (await control("status")).state === "ready";
      if (restore) {
        await control("restore", { restore: true });
        for (let remaining = 2e3; ; remaining -= waitMs) {
          await pause(waitMs);
          await verifyCurrent?.();
          const state = await control("status");
          restore = state.state === "ready" && !state.scrollPending;
          if (state.state !== "ready" || !state.scrollPending || remaining <= 0) {
            break;
          }
        }
      }
    } catch {
      restore = false;
    }
    try {
      restored = Boolean((await control("release", { restore })).restored);
    } catch {
    }
    return restored;
  };
  var conversationTracker = (settings, ui, now) => {
    let rows = [];
    let passes = 0;
    let previous;
    let stableSince;
    return {
      get passes() {
        return passes;
      },
      loading() {
        passes++;
      },
      accept(found, state) {
        const merged = mergeConversationWindow(rows, found);
        if (merged.length > settings.limit || merged.reduce((sum, row) => sum + row.body.length, 0) > 1e6) {
          stopped("history-limit");
        }
        rows = merged;
        passes++;
        if (state.oldest && !state.loading && rows[0]?.service && ui.historyScan?.startAtService) {
          return "provider-start";
        }
        const signature = JSON.stringify([state.top, state.height, found]);
        if (state.oldest && !state.loading && signature === previous) {
          stableSince ??= now();
          if (now() - stableSince >= settings.endWaitMs) {
            return "rendered-start";
          }
        } else {
          stableSince = void 0;
        }
        previous = signature;
        return null;
      },
      result(reason, restored) {
        return {
          rows,
          coverage: {
            complete: reason === "provider-start",
            scope: "conversation",
            reason,
            passes
          },
          restored
        };
      }
    };
  };
  var scanBrowserConversation = async (document2, ui, target, options = {}, { now = () => globalThis.performance.now(), pause = setTimeout2, readNewest } = {}) => {
    const settings = normalizeChatScanOptions(options);
    const { control } = createBrowserScanControl(document2, {
      item: ui.messages.item,
      idAttribute: ui.messages.idAttribute,
      composer: ui.composer,
      scope: "history",
      inactiveToken: options.inactiveToken
    });
    const started = now();
    const observed = conversationTracker(settings, ui, now);
    let reason = "pass-limit";
    let restored;
    let newestRead = false;
    const check = async (operation = "status", extra) => {
      if (options.signal?.aborted) {
        stopped("cancelled");
      }
      if (now() - started >= settings.budgetMs) {
        stopped("time-limit");
      }
      await options.verifyCurrent?.();
      const state = await control(operation, extra);
      if (state.state !== "ready") {
        stopped(state.state);
      }
      return state;
    };
    try {
      await check("open");
      while (observed.passes < settings.maxPasses) {
        await pause(settings.waitMs);
        if ((await check()).loading) {
          observed.loading();
          continue;
        }
        const found = (await readBrowserHistory(document2, ui, target)).map(
          ({ strictOptions: _strict, answerOptions: _options, ...row }) => row
        );
        const state = await check();
        if (!newestRead) {
          await readNewest?.();
          newestRead = true;
          await check();
        }
        const completed = observed.accept(found, state);
        if (completed) {
          reason = completed;
          break;
        }
        await check("move", {
          top: state.top - Math.max(1, Math.floor(state.view * 0.7))
        });
      }
    } catch (error) {
      reason = error.historyReason ?? (error.code === "answer-chat-unverified" ? "document-changed" : "read-failed");
    } finally {
      restored = await releaseBrowserConversation(
        control,
        pause,
        settings.waitMs,
        options.verifyRestore ?? options.verifyCurrent
      );
    }
    const result = observed.result(reason, restored);
    if (process.env.MS_BROWSER_HISTORY_DEBUG === "1") {
      console.error("[browser-conversation-history]", {
        ...result.coverage,
        rows: result.rows.length,
        restored
      });
    }
    return result;
  };

  // js/src/sources/browser-chat-filter.js
  var chatFilterControl = (spec) => {
    const primary = [...document.querySelectorAll(spec.control)];
    const candidates = primary.length ? primary : [...document.querySelectorAll(spec.fallback)];
    return candidates.length === 1 ? candidates[0] : null;
  };
  var chatFilterStatus = (state, control, visible) => {
    const inactive = state.inactiveToken && window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")];
    if (state.interrupted || state.inactiveToken && (inactive?.token !== state.inactiveToken || inactive.interrupted || document.hasFocus())) {
      return "owner-active";
    }
    if (control !== state.control || !control?.isConnected || control.disabled || !state.root.isConnected || !visible(state.root)) {
      return "changed";
    }
    return control.checked === state.expected ? "ready" : "filter-changed";
  };
  var activateChatFilter = (state, want) => {
    state.expected = want;
    if (state.control.checked !== want) {
      const inactive = state.inactiveToken && window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")];
      state.activating = true;
      if (inactive && inactive.token === state.inactiveToken) {
        inactive.ownedFilterControl = state.control;
      }
      try {
        state.control.click();
      } finally {
        state.activating = false;
        if (inactive?.ownedFilterControl === state.control) {
          delete inactive.ownedFilterControl;
        }
      }
    }
  };
  var openChatFilter = (input, control, visible, scrollRoot) => {
    const cell = [...document.querySelectorAll(input.item)].find(visible);
    const root = cell && scrollRoot(cell);
    if (!control || control.disabled || !root || !visible(root)) {
      return null;
    }
    const state = {
      token: input.token,
      control,
      root,
      original: control.checked,
      expected: control.checked,
      top: root.scrollTop,
      inactiveToken: input.inactiveToken,
      interrupted: false
    };
    state.events = [
      "pointerdown",
      "keydown",
      "wheel",
      "touchstart",
      "touchmove",
      "input",
      "change"
    ];
    state.mark = (event) => {
      if (state.activating && event.target === control && ["input", "change"].includes(event.type)) {
        return;
      }
      if (event.isTrusted || ["input", "change"].includes(event.type)) {
        state.interrupted = true;
      }
    };
    for (const type of state.events) {
      document.addEventListener(type, state.mark, {
        capture: true,
        passive: true
      });
    }
    return state;
  };
  var releaseChatFilter = (state, result, restore) => {
    result.restored = Boolean(
      restore && result.state === "ready" && state.control.checked === state.original
    );
    if (result.restored) {
      state.root.scrollTop = state.top;
    }
    result.scrollRestored = result.restored && state.root.scrollTop === state.top;
    for (const type of state.events) {
      document.removeEventListener(type, state.mark, true);
    }
  };
  var filterState = (input, visible, scrollRoot) => {
    const key = /* @__PURE__ */ Symbol.for("meta-sovereign.browser-chat-filter.v1");
    const { operation, token, spec, unreadOnly, restore } = input;
    const control = chatFilterControl(spec);
    if (operation === "open" && !window[key]) {
      window[key] = openChatFilter(input, control, visible, scrollRoot);
    }
    const state = window[key];
    if (!state || state.token !== token) {
      return { state: state ? "busy" : "unavailable" };
    }
    let status = chatFilterStatus(state, control, visible);
    if (status === "ready" && operation === "set") {
      activateChatFilter(state, unreadOnly);
      status = chatFilterStatus(state, control, visible);
    }
    if (status === "ready" && operation === "restore" && restore) {
      activateChatFilter(state, state.original);
      status = chatFilterStatus(state, control, visible);
    }
    const result = {
      state: status,
      before: state.original,
      observed: control?.checked
    };
    if (operation === "release") {
      releaseChatFilter(state, result, restore);
      delete window[key];
    }
    return result;
  };
  var browserChatFilterState = new Function(`return (input) => {
  const visible = (${browserFrameVisible.toString()});
  const scrollRoot = (${browserChatScrollRoot.toString()});
  const chatFilterControl = (${chatFilterControl.toString()});
  const chatFilterStatus = (${chatFilterStatus.toString()});
  const activateChatFilter = (${activateChatFilter.toString()});
  const openChatFilter = (${openChatFilter.toString()});
  const releaseChatFilter = (${releaseChatFilter.toString()});
  return (${filterState.toString()})(input, visible, scrollRoot);
}`)();
  var failure5 = (state) => Object.assign(new Error("The provider chat filter could not be verified"), {
    code: `browser-chat-filter-${state}`,
    scanReason: state,
    fallback: false
  });
  var restoreChatFilter = async (control, options, pause) => {
    let restore;
    try {
      await options.verifyCurrent?.();
      restore = (await control("status")).state === "ready";
      if (restore) {
        await control("restore", { restore });
        await pause(options.waitMs);
        await options.verifyCurrent?.();
      }
    } catch {
      restore = false;
    }
    try {
      return await control("release", { restore });
    } catch {
      return null;
    }
  };
  var withBrowserChatFilter = async (document2, ui, options, read, pause = setTimeout2) => {
    const token = randomUUID();
    const control = (operation, extra = {}) => document2.evaluate({
      fn: browserChatFilterState,
      args: [
        {
          token,
          operation,
          spec: ui.chatScan.unreadFilter,
          item: ui.chats.item,
          unreadOnly: options.unreadOnly,
          inactiveToken: options.inactiveToken,
          ...extra
        }
      ]
    });
    const ready2 = async (operation) => {
      const result2 = await control(operation);
      if (result2.state !== "ready") {
        throw failure5(result2.state);
      }
      return result2;
    };
    let result;
    let receipt;
    let selected;
    try {
      await ready2("open");
      if (options.signal?.aborted) {
        throw failure5("cancelled");
      }
      await options.verifyCurrent?.();
      selected = await ready2("set");
      await pause(options.waitMs);
      await ready2("status");
      result = await read(() => ready2("status"));
    } finally {
      receipt = await restoreChatFilter(control, options, pause);
    }
    const filter = {
      requested: options.unreadOnly,
      before: selected.before,
      observed: selected.observed,
      restored: receipt?.restored === true,
      scrollRestored: receipt?.scrollRestored === true
    };
    if (process.env.MS_BROWSER_CHAT_SCAN_DEBUG === "1") {
      console.error("[browser-chat-filter]", filter);
    }
    return {
      ...result,
      filter,
      restored: Boolean(
        result.restored && filter.restored && filter.scrollRestored
      )
    };
  };

  // js/src/sources/browser-chat-reply-view.js
  var browserChatReplyNode = (ui, reply) => {
    const pattern = new RegExp(ui.messages.idPattern);
    const nodes = [...document.querySelectorAll(ui.messages.item)].filter(
      (node2) => pattern.exec(node2.getAttribute(ui.messages.idAttribute) ?? "")?.[1] === reply.messageId
    );
    const node = nodes.length === 1 ? nodes[0] : null;
    return node && browserFrameVisible(node) && (node.matches(ui.messages.outgoing) || node.querySelector(ui.messages.outgoing)) && node.querySelector(ui.messages.body)?.innerText.trim() === reply.text ? node : null;
  };
  var browserChatReplyVisible = (node, root) => {
    if (!node || !root?.contains(node)) {
      return false;
    }
    const bubble = node.getBoundingClientRect();
    const pane = root.getBoundingClientRect();
    return bubble.width > 0 && bubble.height > 0 && bubble.bottom > Math.max(0, pane.top) && bubble.top < Math.min(window.innerHeight, pane.bottom) && bubble.right > Math.max(0, pane.left) && bubble.left < Math.min(window.innerWidth, pane.right);
  };
  var replyViewOwned = (state, inactive, token, inactiveToken) => state && state.token === token && state.url === window.location.href && inactive?.token === inactiveToken && !inactive.interrupted && !document.hasFocus();
  var emptyReplyComposer = (state, ui) => {
    const fields = [...document.querySelectorAll(ui.composer)].filter(
      browserFrameVisible
    );
    if (state.draft?.value !== "" || fields.length !== 1 || fields[0].value !== "" || fields[0].disabled || fields[0].readOnly) {
      return null;
    }
    return fields[0];
  };
  var replyView = ({ operation, token, inactiveToken, ui, reply }) => {
    const state = window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-chat-view.v1")];
    const inactive = window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")];
    if (!replyViewOwned(state, inactive, token, inactiveToken)) {
      return { state: "owner-active" };
    }
    const composer = emptyReplyComposer(state, ui);
    if (!composer) {
      return { state: "owner-draft" };
    }
    if (operation === "prepare") {
      return { state: "ready" };
    }
    if (operation === "discard") {
      delete state.reply;
      return { state: "ready" };
    }
    const node = browserChatReplyNode(ui, reply);
    if (!node) {
      return { state: "waiting" };
    }
    if (operation === "reveal") {
      revealChoiceReply(ui, {}, { composer }, { id: reply.messageId });
    }
    if (!browserChatReplyVisible(node, browserChatScrollRoot(node))) {
      return { state: "waiting" };
    }
    if (operation === "commit") {
      state.reply = reply;
    }
    return { state: "revealed" };
  };
  var browserChatReplyView = new Function(`return (input) => {
  const browserFrameVisible = (${browserFrameVisible.toString()});
  const browserChatScrollRoot = (${browserChatScrollRoot.toString()});
  const revealChoiceReply = (${revealChoiceReply.toString()});
  const browserChatReplyNode = (${browserChatReplyNode.toString()});
  const browserChatReplyVisible = (${browserChatReplyVisible.toString()});
  const replyViewOwned = (${replyViewOwned.toString()});
  const emptyReplyComposer = (${emptyReplyComposer.toString()});
  return (${replyView.toString()})(input);
}`)();
  var revealBrowserChatReply = async ({ document: document2, ui, reply, token, verify, view, waitMs = 50 }, pause = setTimeout2) => {
    const initial = await view("prepare", reply);
    if (initial.state !== "ready") {
      return initial.state;
    }
    const { control } = createBrowserScanControl(document2, {
      item: ui.messages.item,
      idAttribute: ui.messages.idAttribute,
      composer: ui.composer,
      scope: "history",
      inactiveToken: token,
      tailOnly: true
    });
    let released = false;
    try {
      await verify();
      if ((await control("open")).state !== "ready") {
        return "unavailable";
      }
      const interval = Math.max(50, Math.min(200, waitMs));
      for (let remaining = 2e3; remaining > 0; remaining -= interval) {
        await pause(interval);
        await verify();
        const status = await control("status");
        if (status.state !== "ready") {
          return "owner-active";
        }
        if (status.loading || status.scrollPending) {
          continue;
        }
        const result = await view("reveal", reply);
        if (result.state === "revealed") {
          await pause(interval);
          await verify();
          const settled = await control("status");
          if (settled.state !== "ready") {
            return "owner-active";
          }
          if (settled.scrollPending || (await view("commit", reply)).state !== "revealed") {
            continue;
          }
          await control("release", { restore: false });
          released = true;
          return "revealed";
        }
        if (result.state !== "waiting") {
          return result.state;
        }
      }
      return "unavailable";
    } finally {
      if (!released) {
        await view("discard", reply).catch(() => {
        });
        await releaseBrowserConversation(control, pause, waitMs, verify);
      }
    }
  };

  // js/src/sources/browser-chat-view-state.js
  var viewElements = (ui) => {
    const first = (selector) => [...document.querySelectorAll(selector)].find(browserFrameVisible);
    const fields = [...document.querySelectorAll(ui.composer)].filter(
      browserFrameVisible
    );
    const control = chatFilterControl(ui.chatScan.unreadFilter);
    return {
      field: fields.length === 1 ? fields[0] : null,
      fields: fields.length,
      control,
      list: first(ui.chats.item) ? browserChatScrollRoot(first(ui.chats.item)) : null,
      messages: first(ui.messages.item) ? browserChatScrollRoot(first(ui.messages.item)) : null
    };
  };
  var captureView = (ui, token) => {
    const nodes = viewElements(ui);
    const field = nodes.field;
    if (nodes.fields > 1 || !nodes.control || (field?.value.length ?? 0) > 1e5) {
      return null;
    }
    return {
      token,
      url: window.location.href,
      unreadOnly: nodes.control.checked,
      listTop: nodes.list?.scrollTop ?? null,
      messageTop: nodes.messages?.scrollTop ?? null,
      draft: field ? {
        value: field.value,
        start: field.selectionStart,
        end: field.selectionEnd,
        direction: field.selectionDirection,
        top: field.scrollTop
      } : null
    };
  };
  var selectionRestored = (draft, field) => !draft || Boolean(
    field && field.selectionStart === draft.start && field.selectionEnd === draft.end && field.selectionDirection === draft.direction && field.scrollTop === draft.top
  );
  var restoredView = (state, nodes, ui) => ({
    filter: nodes.control?.checked === state.unreadOnly,
    list: state.listTop === null || nodes.list?.scrollTop === state.listTop,
    messages: state.reply ? browserChatReplyVisible(
      browserChatReplyNode(ui, state.reply),
      nodes.messages
    ) : state.messageTop === null || nodes.messages?.scrollTop === state.messageTop,
    draft: !state.draft || nodes.field?.value === state.draft.value,
    selection: selectionRestored(state.draft, nodes.field)
  });
  var draftMayRestore = (draft, field) => !draft || field && (field.value === "" || field.value === draft.value);
  var restoreDraft = (draft, field, inactive) => {
    if (!draft) {
      return true;
    }
    if (field.value !== draft.value && (field.disabled || field.readOnly || !writeBrowserNativeInput(field, draft.value, inactive))) {
      return false;
    }
    field.setSelectionRange(draft.start, draft.end, draft.direction);
    field.scrollTop = draft.top;
    return true;
  };
  var restoreView = (state, nodes, inactive, input) => {
    if (!draftMayRestore(state.draft, nodes.field)) {
      return "draft-changed";
    }
    if (input.operation === "restore-filter") {
      if (!nodes.control || nodes.control.disabled) {
        return "filter-unavailable";
      }
      activateChatFilter(
        { control: nodes.control, inactiveToken: input.inactiveToken },
        state.unreadOnly
      );
    } else if (input.operation === "restore-position") {
      if (!restoreDraft(state.draft, nodes.field, inactive)) {
        return "draft-unavailable";
      }
      if (nodes.list) {
        nodes.list.scrollTop = state.listTop;
      }
      if (nodes.messages && state.messageTop !== null) {
        nodes.messages.scrollTop = state.messageTop;
      }
    }
    return "ready";
  };
  var visitView = (input) => {
    const { ui, operation } = input;
    const root = viewElements(ui).list;
    const candidates = [...document.querySelectorAll(ui.chats.item)].filter(
      (node) => root?.contains(node) && browserFrameVisible(node) && new RegExp(ui.chats.idPattern).exec(
        node.getAttribute(ui.chats.idAttribute) ?? ""
      )?.[1] === input.chat
    );
    if (operation === "locate") {
      return { state: "ready", found: candidates.length === 1 };
    }
    if (candidates.length !== 1) {
      return { state: "chat-unavailable" };
    }
    candidates[0].click();
    return { state: "activated" };
  };
  var inactiveReady = (inactive, token) => inactive?.token === token && !inactive.interrupted && !document.hasFocus();
  var viewState = (input) => {
    const key = /* @__PURE__ */ Symbol.for("meta-sovereign.browser-chat-view.v1");
    const { operation, token, inactiveToken, ui } = input;
    if (operation === "release") {
      if (window[key]?.token === token) {
        delete window[key];
      }
      return { state: "released" };
    }
    const inactive = window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")];
    if (!inactiveReady(inactive, inactiveToken)) {
      return { state: "owner-active" };
    }
    if (operation === "open" && !window[key]) {
      window[key] = captureView(ui, token);
    }
    const state = window[key];
    if (!state || state.token !== token) {
      return { state: state ? "busy" : "unavailable" };
    }
    if (operation === "visit" || operation === "locate") {
      return visitView(input);
    }
    if (!operation.startsWith("restore") && operation !== "receipt") {
      return { state: "ready" };
    }
    if (window.location.href !== state.url) {
      return { state: "route-changed" };
    }
    const nodes = viewElements(ui);
    const status = restoreView(state, nodes, inactive, input);
    return { state: status, fields: restoredView(state, nodes, ui) };
  };
  var browserChatViewState = new Function(`return (input) => {
  const browserFrameVisible = (${browserFrameVisible.toString()});
  const browserChatScrollRoot = (${browserChatScrollRoot.toString()});
  const browserChatReplyNode = (${browserChatReplyNode.toString()});
  const browserChatReplyVisible = (${browserChatReplyVisible.toString()});
  const chatFilterControl = (${chatFilterControl.toString()});
  const activateChatFilter = (${activateChatFilter.toString()});
  const writeBrowserNativeInput = (${writeBrowserNativeInput.toString()});
  const viewElements = (${viewElements.toString()});
  const captureView = (${captureView.toString()});
  const selectionRestored = (${selectionRestored.toString()});
  const restoredView = (${restoredView.toString()});
  const draftMayRestore = (${draftMayRestore.toString()});
  const restoreDraft = (${restoreDraft.toString()});
  const restoreView = (${restoreView.toString()});
  const visitView = (${visitView.toString()});
  const inactiveReady = (${inactiveReady.toString()});
  return (${viewState.toString()})(input);
}`)();

  // js/src/automation/question-browser-state.js
  var boundedBrowserText = (value, max) => typeof value === "string" && Boolean(value.trim()) && value.length <= max;
  var browserChoiceReceipt = (result, draft) => {
    if (result?.via !== "browser" || result.source !== draft.source || result.chat !== String(draft.chat) || result.option !== draft.text || typeof result.messageId !== "string" || !result.messageId.trim() || result.messageId.length > 480) {
      return null;
    }
    return {
      via: "browser",
      source: result.source,
      chat: result.chat,
      option: result.option,
      messageId: result.messageId
    };
  };
  var browserTextReceipt = (result, draft) => {
    if (!boundedBrowserText(draft.text, 12e3)) {
      return null;
    }
    const receipt = browserChoiceReceipt(
      { ...result, option: result?.text },
      draft
    );
    if (!receipt) {
      return null;
    }
    const { option, ...identity } = receipt;
    return { ...identity, text: option };
  };

  // js/src/sources/browser-chat-history-tail.js
  var tails = /* @__PURE__ */ new WeakMap();
  var failure6 = (reason) => Object.assign(
    new Error("The browser history ownership could not be verified"),
    {
      code: `browser-chat-view-${reason}`,
      scanReason: reason,
      historyReason: reason,
      fallback: false
    }
  );
  var sameIds = (left, right) => left.length === right.length && left.every((id, index) => id === right[index]);
  var sameBindings = (left, right) => left.length === right.length && left.every(
    (item, index) => ["frame", "key", "url", "length"].every(
      (field) => item[field] === right[index][field]
    )
  );
  var browserHistoryTailWitness = ({ operation, token }) => {
    const key = /* @__PURE__ */ Symbol.for("meta-sovereign.browser-history-tail.v1");
    if (operation === "open" && !window[key] && !document.hasFocus()) {
      const state2 = { token, interrupted: false };
      state2.mark = (event) => {
        const inactive = window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")];
        const owned = event === inactive?.ownedInput || inactive?.ownedFilterControl && event.type === "input" && event.target === inactive?.ownedFilterControl;
        if (!owned && (event.isTrusted || event.type === "input")) {
          state2.interrupted = true;
        }
      };
      state2.focus = () => {
        if (document.hasFocus()) {
          state2.interrupted = true;
        }
      };
      state2.events = [
        "pointerdown",
        "keydown",
        "wheel",
        "touchstart",
        "touchmove",
        "input"
      ];
      for (const type of state2.events) {
        document.addEventListener(type, state2.mark, {
          capture: true,
          passive: true
        });
      }
      window.addEventListener("focus", state2.focus, true);
      document.addEventListener("visibilitychange", state2.focus, true);
      window[key] = state2;
    }
    const state = window[key];
    if (!state || state.token !== token) {
      return false;
    }
    if (operation === "release") {
      for (const type of state.events) {
        document.removeEventListener(type, state.mark, true);
      }
      window.removeEventListener("focus", state.focus, true);
      document.removeEventListener("visibilitychange", state.focus, true);
      delete window[key];
    }
    return !state.interrupted && !document.hasFocus();
  };
  var witness = async (record, operation) => {
    const results = await Promise.allSettled(
      record.bindings.map(
        async ({ frame }) => frame.evaluate(browserHistoryTailWitness, {
          operation,
          token: record.token
        })
      )
    );
    const failed = results.find((result) => result.status === "rejected");
    if (failed) {
      throw failed.reason;
    }
    return results.map((result) => result.value);
  };
  var forget = async (page, record) => {
    if (tails.get(page) === record) {
      tails.delete(page);
    }
    for (const event of ["framenavigated", "framedetached", "close"]) {
      page.off(event, record.invalidate);
    }
    await witness(record, "release").catch(() => {
    });
  };
  var verifyBrowserHistoryTransition = (before, after, restoring = false) => {
    const prefix = before.ids.slice(0, before.index + 1);
    const samePrefix = sameIds(prefix, after.ids.slice(0, prefix.length));
    if (restoring) {
      return samePrefix && after.index === before.index;
    }
    return samePrefix && (after.index === before.index && sameIds(before.ids, after.ids) || after.index === before.index + 1 && after.ids.length === after.index + 1 && !before.ids.includes(after.ids[after.index]));
  };
  var claimBrowserHistoryTail = async (page, bindings, position) => {
    const prior = tails.get(page);
    let reusable = false;
    if (prior) {
      reusable = sameBindings(prior.bindings, bindings) && prior.position.index === position.index && sameIds(prior.position.ids, position.ids) && (await witness(prior, "status").catch(() => [false])).every(Boolean);
      await forget(page, prior);
    }
    if (position.index !== position.ids.length - 1 && !reusable) {
      throw failure6("history-forward");
    }
    if (position.index >= 48) {
      throw failure6("history-capacity");
    }
    const record = {
      token: randomUUID(),
      bindings: bindings.map((item) => ({ ...item }))
    };
    record.invalidate = () => {
      forget(page, record).catch(() => {
      });
    };
    try {
      if (!(await witness(record, "open")).every(Boolean)) {
        throw failure6("owner-active");
      }
    } catch (error) {
      await forget(page, record);
      throw error;
    }
    let retained = false;
    return {
      reused: reusable,
      async retain(next2) {
        if (next2.index === next2.ids.length - 1 || !(await witness(record, "status")).every(Boolean) || !verifyBrowserHistoryTransition(position, next2, true)) {
          return;
        }
        record.position = next2;
        record.bindings = bindings.map((item) => ({ ...item }));
        for (const event of ["framenavigated", "framedetached", "close"]) {
          page.on(event, record.invalidate);
        }
        tails.set(page, record);
        retained = true;
      },
      async release() {
        if (!retained) {
          await forget(page, record);
        }
      }
    };
  };

  // js/src/sources/browser-chat-navigation.js
  var failure7 = (reason) => Object.assign(new Error("The inactive chat view could not be preserved"), {
    code: `browser-chat-view-${reason}`,
    scanReason: reason,
    historyReason: reason,
    fallback: false
  });
  var chatAt = (address, ui) => {
    const url = new URL(address);
    return ui.location.origins.includes(url.origin) && !url.username && !url.password ? new RegExp(ui.location.pathPattern).exec(url.pathname)?.[1] : void 0;
  };
  var historyBack = ({ token, count }) => {
    const state = window[/* @__PURE__ */ Symbol.for("meta-sovereign.browser-inactive-view.v1")];
    if (state?.token !== token || state.interrupted || document.hasFocus()) {
      return false;
    }
    window.history.go(-count);
    return true;
  };
  var bindingOf = async (frame) => ({
    frame,
    key: (await frame.evaluate(browserDocumentIdentity, "body")).key,
    url: frame.url(),
    length: await frame.evaluate(() => window.history.length)
  });
  var sameDocument = (current, original) => current.frame === original.frame && current.identity.key === original.identity.key && current.owner === original.owner;
  var documentFor = (commander, page, ui, target) => target ? resolveBrowserChoiceDocument(commander, page, ui, target) : resolveBrowserChatListDocument(commander, page, ui);
  var ChatNavigation = class {
    constructor({
      commander,
      page,
      ui,
      signal,
      waitMs = 50,
      navigationMs = 5e3
    }) {
      Object.assign(this, { commander, page, ui, signal, waitMs, navigationMs });
      this.spec = {
        composer: ui.composer,
        chats: ui.chats,
        messages: ui.messages,
        chatScan: ui.chatScan
      };
      this.token = randomUUID();
      this.changed = false;
      this.restoration = { restored: false, reason: "unavailable" };
      this.adapter = Object.fromEntries(
        ["evaluate", "evaluateOwner", "prepareInactiveView", "clickButton"].map(
          (method) => [method, (input) => this.call(method, input)]
        )
      );
      this.navigated = (frame) => {
        const binding = this.bindings.find((item) => item.frame === frame);
        if (!binding || !this.allowed(binding)) {
          this.changed = true;
        }
      };
      this.invalidate = () => {
        this.changed = true;
      };
    }
    trace(phase, reason) {
      if (process.env.MS_BROWSER_CHAT_VIEW_DEBUG === "1") {
        console.error("[browser-chat-view]", { phase, reason });
      }
    }
    async selectOriginal() {
      const target = chatAt(this.page.url(), this.ui);
      if (target) {
        return {
          target,
          selected: await chooseBrowserChatDocument(this.page, this.ui, target)
        };
      }
      const candidates = [];
      const targets = new Set(
        this.page.frames().map((frame) => chatAt(frame.url(), this.ui)).filter(Boolean)
      );
      for (const candidate of [null, ...targets]) {
        try {
          candidates.push({
            target: candidate,
            selected: await chooseBrowserChatDocument(
              this.page,
              this.ui,
              candidate,
              !candidate
            )
          });
        } catch {
        }
      }
      if (candidates.length !== 1) {
        throw failure7("document-unverified");
      }
      return candidates[0];
    }
    async open() {
      const original = await this.selectOriginal();
      this.originalTarget = original.target;
      this.original = original.selected;
      this.bindings = await Promise.all(
        [.../* @__PURE__ */ new Set([this.page.mainFrame(), this.original.frame])].map(bindingOf)
      );
      this.initial = this.bindings.map((binding) => ({ ...binding }));
      this.currentDocument = await documentFor(
        this.commander,
        this.page,
        this.ui,
        this.originalTarget
      );
    }
    allowed(binding) {
      return binding.frame.url() === binding.url || this.pending?.chat && chatAt(binding.frame.url(), this.ui) === this.pending.chat || this.pending?.restore && binding.frame.url() === this.initial.find((item) => item.frame === binding.frame).url;
    }
    async historyPosition() {
      const history = await this.historySession.send("Page.getNavigationHistory");
      return {
        index: history.currentIndex,
        ids: history.entries.map((entry) => entry.id)
      };
    }
    async admitHistory() {
      this.historySession = await this.page.context().newCDPSession(this.page);
      this.position = await this.historyPosition();
      this.historyTail = await claimBrowserHistoryTail(
        this.page,
        this.bindings,
        this.position
      );
      this.initialPosition = this.position;
    }
    async verify() {
      if (this.changed || this.page.isClosed() || this.page.mainFrame() !== this.bindings[0].frame) {
        throw failure7("document-changed");
      }
      if (this.historySession && !this.pending && JSON.stringify(await this.historyPosition()) !== JSON.stringify(this.position)) {
        throw failure7("history-changed");
      }
      for (const binding of this.bindings) {
        if (!this.allowed(binding) || (await binding.frame.evaluate(browserDocumentIdentity, "body")).key !== binding.key) {
          throw failure7("document-changed");
        }
        if (this.inactiveToken) {
          const result = await binding.frame.evaluate(browserInactiveView, {
            token: this.inactiveToken,
            operation: "status"
          });
          if (result.state !== "ready") {
            throw failure7(result.state);
          }
        }
        if (!this.pending && await binding.frame.evaluate(() => window.history.length) !== binding.length) {
          throw failure7("history-changed");
        }
      }
    }
    async update() {
      const position = await this.historyPosition();
      if (!verifyBrowserHistoryTransition(
        this.pending?.restore ? this.initialPosition : this.position,
        position,
        Boolean(this.pending?.restore)
      )) {
        throw failure7("history-changed");
      }
      this.position = position;
      for (const binding of this.bindings) {
        const length = await binding.frame.evaluate(() => window.history.length);
        if (length !== position.ids.length) {
          throw failure7("history-changed");
        }
        binding.url = binding.frame.url();
        binding.length = length;
      }
    }
    async call(method, input) {
      if (input?.args?.[0]?.operation !== "release") {
        await this.verify();
      }
      return this.currentDocument[method](input);
    }
    async view(operation, extra = {}) {
      const result = await this.adapter.evaluate({
        fn: browserChatViewState,
        args: [
          {
            operation,
            token: this.token,
            inactiveToken: this.inactiveToken,
            ui: this.spec,
            ...extra
          }
        ]
      });
      if (result.state !== "ready" && operation !== "release") {
        throw failure7(result.state);
      }
      return result;
    }
    async wait(read) {
      const deadline = globalThis.performance.now() + this.navigationMs;
      do {
        await this.verify();
        const result = await read();
        if (result) {
          return result;
        }
        await setTimeout2(this.waitMs);
      } while (globalThis.performance.now() < deadline);
      throw failure7("navigation-timeout");
    }
    async reveal(chat) {
      const { control } = createBrowserScanControl(this.adapter, {
        item: this.ui.chats.item,
        inactiveToken: this.inactiveToken
      });
      try {
        if ((await control("open")).state !== "ready") {
          throw failure7("list-unavailable");
        }
        await this.wait(async () => {
          if (this.signal?.aborted) {
            throw failure7("cancelled");
          }
          if ((await this.view("locate", { chat })).found) {
            return true;
          }
          const current = await control("status");
          if (current.state !== "ready") {
            throw failure7(current.state);
          }
          if (current.loading) {
            return false;
          }
          if (current.bottom) {
            const settled = await this.view("locate", { chat });
            this.trace("reveal-end", settled.found ? "found" : "chat-unavailable");
            if (settled.found) {
              return true;
            }
            throw failure7("chat-unavailable");
          }
          const moved = await control("move", {
            top: current.top + Math.max(1, Math.floor(current.view * 0.7))
          });
          if (moved.state !== "ready") {
            throw failure7(moved.state);
          }
          return false;
        });
      } finally {
        await control("release", { restore: false }).catch(() => {
        });
      }
    }
    async visit(chat, read) {
      await this.verify();
      if (this.signal?.aborted) {
        throw failure7("cancelled");
      }
      const target = String(this.ui.target({ chat }));
      if (chatAt(this.original.frame.url(), this.ui) !== target) {
        if (this.position.index >= 48) {
          throw failure7("history-capacity");
        }
        await this.reveal(target);
        if (this.signal?.aborted) {
          throw failure7("cancelled");
        }
        this.pending = { chat: target };
        const activated = await this.original.frame.evaluate(
          browserChatViewState,
          {
            operation: "visit",
            token: this.token,
            inactiveToken: this.inactiveToken,
            ui: this.spec,
            chat: target
          }
        );
        if (activated.state !== "activated") {
          this.pending = null;
          throw failure7(activated.state);
        }
        const selected = await this.wait(async () => {
          try {
            return await chooseBrowserChatDocument(this.page, this.ui, target);
          } catch {
            return null;
          }
        });
        if (!sameDocument(selected, this.original)) {
          throw failure7("document-changed");
        }
        await this.update();
        this.currentDocument = await documentFor(
          this.commander,
          this.page,
          this.ui,
          target
        );
        this.pending = null;
        await this.verify();
      }
      if (this.signal?.aborted) {
        throw failure7("cancelled");
      }
      this.trace("visit", "ready");
      return read(this.adapter, target, () => this.verify(), this.inactiveToken);
    }
    async restoreRoutes() {
      this.pending = { restore: true };
      for (const binding of this.bindings) {
        const saved = this.initial.find((item) => item.frame === binding.frame);
        if (binding.frame.url() !== saved.url) {
          const count = this.position.index - this.initialPosition.index;
          if (count <= 0 || !await binding.frame.evaluate(historyBack, {
            token: this.inactiveToken,
            count
          })) {
            throw failure7("history-unavailable");
          }
          await this.wait(() => binding.frame.url() === saved.url);
        }
      }
      await this.update();
      this.currentDocument = await documentFor(
        this.commander,
        this.page,
        this.ui,
        this.originalTarget
      );
      this.pending = null;
    }
    async restore() {
      let replyView2;
      try {
        await this.verify();
        await this.restoreRoutes();
        await this.view("restore-filter");
        await setTimeout2(this.waitMs);
        await this.view("restore-position");
        await setTimeout2(this.waitMs);
        if (this.reply && !this.signal?.aborted) {
          const state = await revealBrowserChatReply({
            document: this.adapter,
            ui: this.ui,
            reply: this.reply,
            token: this.inactiveToken,
            verify: () => this.verify(),
            waitMs: this.waitMs,
            view: (operation, reply) => this.original.frame.evaluate(browserChatReplyView, {
              operation,
              reply,
              token: this.token,
              inactiveToken: this.inactiveToken,
              ui: this.spec
            })
          });
          replyView2 = {
            state,
            chat: this.reply.chat,
            messageId: this.reply.messageId
          };
          this.trace("reply-view", state);
        }
        const receipt = await this.view("receipt");
        receipt.fields.historyPosition = this.position.index === this.initialPosition.index;
        const history = {
          positionRestored: receipt.fields.historyPosition,
          lengthBefore: this.initialPosition.ids.length,
          lengthAfter: this.position.ids.length,
          reusedOwnedForward: this.historyTail.reused
        };
        return {
          history,
          restored: Object.values(receipt.fields).every(Boolean),
          fields: receipt.fields,
          reason: "checked",
          ...replyView2 ? { replyView: replyView2 } : {}
        };
      } catch (error) {
        return {
          restored: false,
          reason: error.scanReason ?? "document-changed",
          ...this.reply ? {
            replyView: {
              state: "unavailable",
              chat: this.reply.chat,
              messageId: this.reply.messageId
            }
          } : {}
        };
      }
    }
    async run(work) {
      await this.open();
      this.page.on("framenavigated", this.navigated);
      this.page.on("framedetached", this.invalidate);
      this.page.on("close", this.invalidate);
      try {
        return await withInactiveBrowserView(
          this.adapter,
          async (inactive, token) => {
            this.inactiveToken = token;
            await this.admitHistory();
            await this.view("open");
            let result;
            try {
              result = await work({
                document: this.adapter,
                visit: (chat, read) => this.visit(chat, read),
                verifyCurrent: inactive,
                inactiveToken: token,
                retainReply: (receipt) => {
                  const reply = browserTextReceipt(receipt, {
                    source: this.ui.id,
                    chat: this.originalTarget,
                    text: receipt?.text
                  });
                  if (reply) {
                    this.reply = reply;
                  }
                }
              });
            } finally {
              this.restoration = await this.restore();
              this.trace("restore", this.restoration.reason);
              await this.original.frame.evaluate(browserChatViewState, {
                operation: "release",
                token: this.token
              }).catch(() => {
              });
            }
            return { ...result, restoration: this.restoration };
          },
          { relayOwner: true }
        );
      } catch (error) {
        this.trace("failed", error.scanReason ?? error.code);
        throw Object.assign(error, { restoration: this.restoration });
      } finally {
        this.page.off("framenavigated", this.navigated);
        this.page.off("framedetached", this.invalidate);
        this.page.off("close", this.invalidate);
        try {
          if (this.restoration.restored) {
            await this.historyTail?.retain(this.position);
          }
        } catch {
        } finally {
          await this.historyTail?.release();
          await this.historySession?.detach().catch(() => {
          });
        }
      }
    }
  };
  var withBrowserChatNavigation = (options, work) => new ChatNavigation(options).run(work);

  // js/src/sources/browser-conversation-tail.js
  var failure8 = (reason) => Object.assign(new Error("The borrowed unread conversation is unavailable."), {
    code: `browser-unread-${reason}`,
    fallback: false
  });
  var stableQuestion = async ({ read, checked, control, settings, pause }) => {
    let previous;
    for (let pass = 0; pass < settings.maxPasses; pass++) {
      await pause(settings.waitMs);
      await checked();
      const state = await control("status");
      if (state.state !== "ready") {
        throw failure8(state.state);
      }
      if (state.loading) {
        continue;
      }
      const snapshot = await read();
      await checked();
      const signature = JSON.stringify(snapshot);
      if (signature === previous) {
        return snapshot;
      }
      previous = signature;
    }
    throw failure8("tail-unstable");
  };
  var withBrowserConversationTail = async ({ document: document2, ui, chat, settings, signal, token, verify, retainReply }, work, { pause = setTimeout2, now = () => globalThis.performance.now() } = {}) => {
    const { control: scrollControl } = createBrowserScanControl(document2, {
      item: ui.messages.item,
      idAttribute: ui.messages.idAttribute,
      composer: ui.composer,
      scope: "history",
      inactiveToken: token,
      allowOwnedInput: true,
      tailOnly: true,
      debug: process.env.MS_BROWSER_HISTORY_DEBUG === "1"
    });
    const control = async (operation, extra) => {
      const result = await scrollControl(operation, extra);
      if (process.env.MS_BROWSER_HISTORY_DEBUG === "1") {
        console.error("[browser-conversation-tail]", { operation, result });
      }
      return result;
    };
    const deadline = now() + settings.budgetMs;
    let closed = false;
    const pending = /* @__PURE__ */ new Set();
    let queued = Promise.resolve();
    let value;
    let restored;
    const read = () => readBrowserAnswerChoices(document2, ui, chat, { preserveDraft: true });
    const checked = async () => {
      if (closed || signal?.aborted || now() >= deadline) {
        throw failure8(closed ? "visit-closed" : "cancelled");
      }
      await verify();
      if (closed || signal?.aborted || now() >= deadline) {
        throw failure8(closed ? "visit-closed" : "cancelled");
      }
    };
    const run = (action) => {
      const result = queued.then(async () => {
        await checked();
        return action();
      });
      queued = result.catch(() => {
      });
      pending.add(result);
      result.then(
        () => pending.delete(result),
        () => pending.delete(result)
      );
      return result;
    };
    try {
      await checked();
      if ((await control("open")).state !== "ready") {
        throw failure8("tail-unavailable");
      }
      const snapshot = await stableQuestion({
        read,
        checked,
        control,
        settings,
        pause
      });
      value = await work({
        snapshot,
        readInactiveQuestion: () => run(read),
        replyTextInactive: (expected, text, verifyCurrent) => run(async () => {
          const receipt = await sendBrowserTextReply(
            document2,
            ui,
            chat,
            expected,
            text,
            {
              receiptMs: settings.receiptMs,
              pollMs: settings.pollMs,
              inactiveToken: token,
              verifyCurrent: async () => {
                await checked();
                await verifyCurrent?.();
              }
            }
          );
          try {
            await retainReply?.(receipt);
          } catch {
          }
          return receipt;
        })
      });
    } finally {
      closed = true;
      await Promise.allSettled([...pending]);
      restored = await releaseBrowserConversation(
        control,
        pause,
        settings.waitMs,
        verify
      );
    }
    return { value, restored };
  };

  // js/src/sources/browser-unread-conversations.js
  var normalizeUnreadScanOptions = (options = {}) => {
    const settings = normalizeChatScanOptions(options);
    const maxChats = options.maxChats ?? 20;
    if (!Number.isInteger(maxChats) || maxChats < 1 || maxChats > 100 || options.unreadOnly === false || options.onConversation !== void 0 && typeof options.onConversation !== "function") {
      throw Object.assign(new Error("An unread scan requires one to 100 chats"), {
        code: "bad-chat-scan",
        fallback: false
      });
    }
    return { ...settings, maxChats };
  };
  var passStopReason = (signal, deadline, limitReached = false) => {
    if (signal?.aborted) {
      return "cancelled";
    }
    if (globalThis.performance.now() >= deadline) {
      return "time-limit";
    }
    return limitReached ? "chat-limit" : null;
  };
  var scanUnreadBrowserConversations = ({
    commander,
    page,
    ui,
    scanList,
    ...options
  }) => {
    const settings = normalizeUnreadScanOptions(options);
    const deadline = globalThis.performance.now() + settings.budgetMs;
    return withBrowserChatNavigation(
      { commander, page, ui, signal: options.signal, waitMs: settings.waitMs },
      async ({ document: document2, visit, verifyCurrent, inactiveToken, retainReply }) => {
        const list = await scanList(document2, ui, {
          ...options,
          ...settings,
          unreadOnly: true,
          verifyCurrent,
          inactiveToken
        });
        if (process.env.MS_BROWSER_CHAT_VIEW_DEBUG === "1") {
          console.error("[browser-unread-list]", {
            elapsedMs: settings.budgetMs - (deadline - globalThis.performance.now()),
            coverage: list.coverage
          });
        }
        const conversations = [];
        let reason = list.coverage.endObserved ? "observed-list" : list.coverage.reason;
        for (const row of list.rows) {
          const stop2 = passStopReason(
            options.signal,
            deadline,
            conversations.length >= settings.maxChats
          );
          if (stop2) {
            reason = stop2;
            break;
          }
          await verifyCurrent();
          const observation = await visit(
            row.chat,
            async (chatDocument, chat, verify, token) => {
              const remaining = Math.floor(
                deadline - globalThis.performance.now()
              );
              if (remaining < 100) {
                return null;
              }
              let question = null;
              const history = await scanBrowserConversation(
                chatDocument,
                ui,
                chat,
                {
                  ...settings,
                  signal: options.signal,
                  budgetMs: remaining,
                  inactiveToken: token,
                  verifyCurrent: verify,
                  verifyRestore: verify
                },
                {
                  readNewest: async () => {
                    await verify();
                    question = await readBrowserAnswerChoices(
                      chatDocument,
                      ui,
                      chat,
                      {
                        preserveDraft: true
                      }
                    );
                    await verify();
                  }
                }
              );
              await verify();
              const observation2 = {
                ...row,
                history,
                question: options.signal?.aborted ? null : question
              };
              if (options.onConversation && !options.signal?.aborted) {
                const processed = await withBrowserConversationTail(
                  {
                    document: chatDocument,
                    ui,
                    chat,
                    settings: {
                      ...settings,
                      budgetMs: Math.max(
                        0,
                        deadline - globalThis.performance.now()
                      )
                    },
                    signal: options.signal,
                    token,
                    verify,
                    retainReply
                  },
                  (handle) => options.onConversation(observation2, handle)
                );
                observation2.processing = processed;
              }
              return observation2;
            }
          );
          if (!observation) {
            reason = "time-limit";
            break;
          }
          conversations.push(observation);
          if (observation.processing?.restored === false) {
            reason = "visit-restoration-failed";
            break;
          }
          const stopped2 = passStopReason(options.signal, deadline);
          if (stopped2) {
            reason = stopped2;
            break;
          }
        }
        return {
          list,
          conversations,
          coverage: {
            complete: false,
            scope: "unread-conversations",
            reason,
            observed: list.rows.length,
            visited: conversations.length
          }
        };
      }
    );
  };

  // js/src/sources/browser-chat-scan.js
  var failure9 = (message, code) => Object.assign(new Error(message), { code, fallback: false });
  var stop = (scanReason) => {
    throw Object.assign(new Error("Browser chat scan stopped"), { scanReason });
  };
  var ready = async (control, operation, extra) => {
    const state = await control(operation, extra);
    if (state.state !== "ready") {
      stop(state.state);
    }
    return state;
  };
  var release = async (control) => {
    let restore = false;
    try {
      restore = (await control("status")).state === "ready";
    } catch {
    }
    try {
      return Boolean((await control("release", { restore })).restored);
    } catch {
      return false;
    }
  };
  var tracker = (settings, now) => {
    const rows = /* @__PURE__ */ new Map();
    let previous;
    let stableSince;
    let passes = 0;
    return {
      get passes() {
        return passes;
      },
      accept(found, current) {
        for (const row of found) {
          if (!rows.has(row.chat) && rows.size === settings.limit) {
            break;
          }
          rows.set(row.chat, row);
        }
        passes++;
        if (rows.size >= settings.limit) {
          return "row-limit";
        }
        const signature = JSON.stringify([current, found]);
        if (current.bottom && !current.loading && signature === previous) {
          stableSince ??= now();
          if (now() - stableSince >= settings.endWaitMs) {
            return "rendered-end";
          }
        } else {
          stableSince = void 0;
        }
        previous = signature;
        return null;
      },
      result(reason, restored) {
        return {
          rows: [...rows.values()],
          restored,
          coverage: {
            complete: false,
            scope: "rendered-list",
            endObserved: reason === "rendered-end",
            reason,
            passes
          }
        };
      }
    };
  };
  var traverseBrowserChatList = async (document2, ui, options = {}, { now = () => globalThis.performance.now(), pause = setTimeout2 } = {}) => {
    const settings = normalizeChatScanOptions(options);
    const { token, control: scrollControl } = createBrowserScanControl(document2, {
      item: ui.chats.item,
      inactiveToken: options.inactiveToken
    });
    const control = async (operation, extra) => {
      if (operation !== "release") {
        await options.verifyCurrent?.();
      }
      return scrollControl(operation, extra);
    };
    const started = now();
    const observed = tracker(settings, now);
    let reason = "pass-limit";
    let restored;
    const remaining = () => {
      if (options.signal?.aborted) {
        stop("cancelled");
      }
      const ms = settings.budgetMs - (now() - started);
      if (ms <= 0) {
        stop("time-limit");
      }
      return ms;
    };
    try {
      remaining();
      await ready(control, "open");
      while (observed.passes < settings.maxPasses) {
        await pause(Math.min(settings.waitMs, remaining()));
        remaining();
        await ready(control, "status");
        const found = await document2.evaluate({
          fn: extractChats,
          args: [
            {
              ...ui.chats,
              limit: settings.limit,
              listToken: token
            }
          ]
        });
        const current = await ready(control, "status");
        if (options.unreadOnly === true && found.some((row) => row.unread <= 0)) {
          stop("filter-unconfirmed");
        }
        const completed = observed.accept(found, current);
        if (completed) {
          reason = completed;
          break;
        }
        remaining();
        const top = current.top + Math.max(1, Math.floor(current.view * 0.7));
        await ready(control, "move", { top });
      }
    } catch (error) {
      reason = error?.scanReason ?? (error?.code === "answer-chat-unverified" ? "document-changed" : "read-failed");
    } finally {
      restored = await release(control);
    }
    const result = observed.result(reason, restored);
    if (process.env.MS_BROWSER_CHAT_SCAN_DEBUG === "1") {
      console.error("[browser-chat-scan]", {
        passes: observed.passes,
        rows: result.rows.length,
        reason,
        restored
      });
    }
    return result;
  };
  var scanBrowserChatList = async (document2, ui, options = {}, dependencies = {}) => {
    const settings = normalizeChatScanOptions(options);
    if (options.unreadOnly === void 0) {
      return traverseBrowserChatList(document2, ui, options, dependencies);
    }
    if (!ui.chatScan?.unreadFilter) {
      throw failure9(
        "Explicit unread filtering is unavailable for this provider",
        "unsupported-action"
      );
    }
    return withBrowserChatFilter(
      document2,
      ui,
      { ...options, waitMs: settings.waitMs },
      (verify) => traverseBrowserChatList(
        document2,
        ui,
        {
          ...options,
          verifyCurrent: async () => {
            await options.verifyCurrent?.();
            await verify();
          }
        },
        dependencies
      ),
      dependencies.pause
    );
  };

  // js/src/sources/hh-web-ui.js
  var origins = ["https://hh.ru", "https://www.hh.ru", "https://chatik.hh.ru"];
  var invalid = () => Object.assign(
    new Error("HH requires an explicit numeric web-chat reference"),
    {
      code: "unsupported-target",
      fallback: false
    }
  );
  var hhWebChatId = (value) => {
    const text = String(value ?? "").trim();
    if (/^\d{1,30}$/u.test(text)) {
      return text;
    }
    try {
      const url = new URL(text);
      const match = /^\/chat\/(\d{1,30})\/?$/u.exec(url.pathname);
      if (origins.includes(url.origin) && !url.username && !url.password && match) {
        return match[1];
      }
    } catch {
    }
    throw invalid();
  };
  var hhWebChatUrl = (target, { browserUrl } = {}) => {
    const chat = hhWebChatId(target);
    if (!browserUrl) {
      return `https://hh.ru/chat/${chat}`;
    }
    try {
      const url = new URL(browserUrl);
      if (origins.slice(0, 2).includes(url.origin) && !url.username && !url.password) {
        const route = /^\/chat\/(\d+)\/?$/u.exec(url.pathname);
        if (!route || route[1] === chat) {
          return url.href;
        }
      }
    } catch {
    }
    throw invalid();
  };
  var HH_WEB_UI = {
    id: "hh",
    name: "HeadHunter",
    loginUrl: "https://hh.ru/account/login",
    listUrl: "https://hh.ru/chat",
    chatUrl: hhWebChatUrl,
    target: ({ chat, to }) => hhWebChatId(chat ?? to),
    loggedIn: '[data-qa^="chatik-chat-message-"], textarea[data-qa="text-input"], iframe[src^="https://chatik.hh.ru/"], [data-qa="mainmenu_applicantProfile"]',
    loggedOut: '[data-qa="account-login-submit"], form[action*="account/login"]',
    composer: 'textarea[data-qa="text-input"]',
    location: { origins, pathPattern: "^/chat/(\\d{1,30})/?$" },
    documents: { ownerOrigins: origins, ancestorOrigins: origins, maxFrames: 32 },
    chatScan: {
      pathPattern: "^/chat/?$",
      unreadFilter: {
        control: 'label:has(input[data-qa="chatik-checkbox-only-unread"]) input[type="checkbox"]:not([data-qa])',
        fallback: 'input[data-qa="chatik-checkbox-only-unread"]'
      }
    },
    historyScan: { startAtService: true },
    chatNavigation: { sameDocument: true },
    noticeContext: {
      company: '[data-qa="participant-info-title"]',
      vacancy: '[data-qa="chatik-header-sub-header"]',
      link: '[data-qa="chatik-header-sub-header"] a[href*="/vacancy/"]'
    },
    textReply: {
      send: 'button[data-qa*="send"]',
      closedText: "\u0440\u0430\u0431\u043E\u0442\u043E\u0434\u0430\u0442\u0435\u043B\u044C \u043E\u0442\u043A\u043B\u044E\u0447\u0438\u043B \u043F\u0435\u0440\u0435\u043F\u0438\u0441\u043A\u0443|\u043F\u0435\u0440\u0435\u043F\u0438\u0441\u043A\u0430 \u0431\u0443\u0434\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u0430 \u043F\u043E\u0441\u043B\u0435 \u043F\u0440\u0438\u0433\u043B\u0430\u0448\u0435\u043D\u0438\u044F|(?:chat|conversation) (?:is |has been )?closed|(?:messaging|correspondence) (?:is |has been )?disabled"
    },
    choices: {
      group: '[class*="buttons-wrapper"], [class*="reply-options"], [data-qa*="answer-options"], [data-qa*="question-options"]',
      attachedButtons: true,
      genericGroup: '[class*="buttons-wrapper"]:not([class*="reply-options"]):not([data-qa*="answer-options"]):not([data-qa*="question-options"])',
      genericPattern: "^(?:\u0437\u0434\u0440\u0430\u0432\u0441\u0442\u0432\u0443\u0439\u0442\u0435|\u043A\u0430\u043A\u0430\u044F \u0441\u0445\u0435\u043C\u0430 \u043E\u043F\u043B\u0430\u0442\u044B|\u0433\u0434\u0435 \u043D\u0430\u0445\u043E\u0434\u0438\u0442\u0441\u044F \u043C\u0435\u0441\u0442\u043E \u0440\u0430\u0431\u043E\u0442\u044B|\u043C\u043E\u0436\u043D\u043E \u0431\u0435\u0437 \u043E\u043F\u044B\u0442\u0430|\u043A\u0430\u043A\u043E\u0439 \u0433\u0440\u0430\u0444\u0438\u043A \u0440\u0430\u0431\u043E\u0442\u044B|\u043C\u043E\u0433\u0443 \u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u0432 \u0433\u0438\u0431\u043A\u043E\u043C \u0433\u0440\u0430\u0444\u0438\u043A\u0435|\u0443 \u043C\u0435\u043D\u044F \u0435\u0441\u0442\u044C \u043F\u0440\u043E\u0444\u0438\u043B\u044C\u043D\u044B\u0439 \u043E\u043F\u044B\u0442|hello|\u0928\u092E\u0938\u094D\u0924\u0947|\u4F60\u597D)[.!?]*$",
      button: 'button, [role="button"], [role="option"]'
    },
    messages: {
      item: '[data-qa^="chatik-chat-message-"]',
      idAttribute: "data-qa",
      idPattern: "^chatik-chat-message-(\\d+)$",
      body: '[data-qa="chat-bubble-text"]',
      outgoing: '[data-qa="status-icon-delivered"], [data-qa="status-icon-read"], [data-qa="status-icon-sent"]',
      timestampAttribute: "data-time",
      serviceTitle: '[data-qa="chat-bubble-title"], [data-qa="chat-bubble-author-name"]',
      serviceTitlePattern: "^(?:\u043E\u0442\u043A\u043B\u0438\u043A \u043D\u0430 \u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044E|vacancy application|(?:application for|response to) (?:the|a) vacancy|bewerbung)$"
    },
    chats: {
      item: '[data-qa^="chatik-open-chat-"], a[href^="/chat/"]',
      idAttribute: "data-qa",
      idPattern: "^chatik-open-chat-(\\d{1,30})$",
      requireId: true,
      uniqueIds: true,
      link: 'a[href^="/chat/"]',
      linkPattern: "^/chat/(\\d{1,30})(?:[/?#]|$)",
      title: '[data-qa="chat-cell-title"], [data-qa="chat-title"]',
      preview: '[class*="last-message-color_"], [data-qa="chat-last-message"]',
      unread: '[data-qa="chat-unread-count"], [data-qa*="badge"], [data-qa*="counter"]'
    },
    actions: {}
  };
  return __toCommonJS(stdin_exports);
})();

 const releaseRevealMcp = (async (page, input, value, touched) => {
  if (touched || input?.operation !== 'locate' || input.chat !== '9' || value.found !== false) {
    return touched;
  }
  await page.evaluate(() => {
    const list = document.querySelector('#list');
    list.scrollTop = list.scrollHeight;
    list.dispatchEvent(new Event('scroll'));
  });
  return true;
});
 const verifyRepeatedMcp = (async ({
  commander,
  page,
  other,
  snapshot,
  original,
  result,
  check,
}) => {
  const second = await chatScanContract.scanUnreadBrowserConversations({
    commander,
    page,
    ui: chatScanContract.HH_WEB_UI,
    scanList: chatScanContract.scanBrowserChatList,
    waitMs: 150,
    endWaitMs: 100,
    budgetMs: 30000,
    maxChats: 1,
  });
  check(
    second.conversations[0]?.chat === '9',
    'Read the next unread conversation'
  );
  check(
    second.restoration.restored &&
      second.restoration.history.reusedOwnedForward,
    'Reuse only witnessed automation entries'
  );
  check(
    second.restoration.history.lengthAfter ===
      result.restoration.history.lengthAfter,
    'Repeated pass does not keep growing history'
  );
  check(
    JSON.stringify(await snapshot()) === JSON.stringify(original),
    'Second exact original view'
  );
  await page.bringToFront();
  await other.bringToFront();
  let refusal;
  try {
    await chatScanContract.scanUnreadBrowserConversations({
      commander,
      page,
      ui: chatScanContract.HH_WEB_UI,
      scanList: chatScanContract.scanBrowserChatList,
      waitMs: 150,
      endWaitMs: 100,
      budgetMs: 30000,
    });
  } catch (error) {
    refusal = error.code;
  }
  check(
    refusal === 'browser-chat-view-history-forward',
    'Returning owner permanently revokes reuse'
  );
  check(
    JSON.stringify(await snapshot()) === JSON.stringify(original),
    'Refusal preserves the current view'
  );
  return second.restoration;
});
 return (async (page) => (async (page, { html, screenshot, repeat, reveal }) => {
  const check = (condition, message) => {
    if (!condition) {
      throw new Error(message);
    }
  };
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.setViewportSize({ width: 1024, height: 900 });
  await page.route('https://hh.ru/**', (route) =>
    route.fulfill({ contentType: 'text/html', body: html })
  );
  const results = [];
  for (const ownerReturns of [false, true]) {
    await page.goto(`https://hh.ru/chat/7?mcp-owner=${ownerReturns}#reading`);
    const snapshot = () =>
      page.evaluate(() => {
        const field = document.querySelector('textarea');
        return {
          url: window.location.href,
          draft: field.value,
          selection: [
            field.selectionStart,
            field.selectionEnd,
            field.selectionDirection,
          ],
          draftTop: field.scrollTop,
          listTop: document.querySelector('#list').scrollTop,
          messageTop: document.querySelector('#history').scrollTop,
          filter: document.querySelector('#outer-filter').checked,
          sends: window.fixture.sends,
          live: Boolean(
            window[Symbol.for('meta-sovereign.browser-chat-view.v1')] ||
            window[Symbol.for('meta-sovereign.browser-inactive-view.v1')]
          ),
        };
      });
    const original = await snapshot();
    const other = await page.context().newPage();
    let released = false;
    let touched = false,
      result;
    try {
      await other.bringToFront();
      const commander = {
        evaluate: async ({ fn, args = [] }) => {
          const value = await page.evaluate(fn, args[0]);
          if (reveal) {
            released = await releaseRevealMcp(page, args[0], value, released);
          }
          if (ownerReturns && !touched && args[0]?.operation === 'history') {
            touched = true;
            await page.bringToFront();
            await page.locator('textarea').fill('Owner returned draft');
          }
          return value;
        },
      };
      try {
        result = await chatScanContract.scanUnreadBrowserConversations({
          commander,
          page,
          ui: chatScanContract.HH_WEB_UI,
          scanList: chatScanContract.scanBrowserChatList,
          waitMs: 150,
          endWaitMs: 100,
          budgetMs: 30000,
          maxChats: reveal ? 2 : 1,
        });
        check(!ownerReturns, 'Owner return must interrupt');
        check(
          result.conversations.length === (reveal ? 2 : 1) &&
            result.conversations[0].chat === '8',
          'Expected unread chats'
        );
        check(!reveal || (released && result.conversations[1].chat === '9'), 'Settled virtual render is readable');
        check(
          result.conversations[0].history.coverage.complete,
          'Full fixture conversation'
        );
        check(
          result.restoration.restored && !result.coverage.complete,
          'Restore with partial provider coverage'
        );
        check(
          JSON.stringify(await snapshot()) === JSON.stringify(original),
          'Exact original view'
        );
      } catch (error) {
        if (!ownerReturns) {
          throw error;
        }
        check(
          error.restoration?.restored === false,
          'No restore after owner return'
        );
        const current = await snapshot();
        check(
          current.url === 'https://hh.ru/chat/8' &&
            current.draft === 'Owner returned draft' &&
            current.sends === 0 &&
            !current.live,
          'Preserve owner view'
        );
        result = { interrupted: true, restoration: error.restoration };
      }
      const repeated =
        repeat && !ownerReturns
          ? await verifyRepeatedMcp({
              commander,
              page,
              other,
              snapshot,
              original,
              result,
              check,
            })
          : undefined;
      const receipt = {
        ownerReturns,
        revealReleased: released,
        coverage: result.coverage,
        restoration: result.restoration,
        ...(repeated ? { repeated } : {}),
        state: await snapshot(),
      };
      results.push(receipt);
      await page.locator('#result').evaluate((node, value) => {
        node.textContent = JSON.stringify(value, null, 2);
      }, receipt);
      await page.screenshot({
        path: `${screenshot}-${ownerReturns ? 'owner' : 'restored'}.png`,
        fullPage: true,
      });
    } finally {
      await other.close();
    }
  }
  check(errors.length === 0, 'No browser errors');
  return {
    cases: results.length,
    results,
    pageErrors: errors,
    liveProvider: false,
  };
})(page, {"html":"\u003c!doctype html\u003e\u003chtml lang=\"en\"\u003e\n\u003cmeta charset=\"utf-8\"\u003e\u003ctitle\u003eOwned unread conversations · isolated fixture\u003c/title\u003e\u003cstyle\u003e\nbody{font:16px system-ui;margin:24px;color:#172333;background:#eef2f7}main{display:flex;gap:20px}#list{width:250px;height:200px;overflow-y:auto;background:white}#list article{box-sizing:border-box;height:100px;padding:14px;border-bottom:1px solid #ccc;cursor:pointer}#history{height:220px;width:620px;overflow-y:auto;overflow-anchor:none;background:white}#messages{height:800px;position:relative;flex-shrink:0}#history article{box-sizing:border-box;position:absolute;height:100px;padding:12px}textarea{display:block;width:610px;height:65px;margin:12px 0}pre{white-space:pre-wrap;max-width:940px}\n\u003c/style\u003e\u003cnav data-qa=\"mainmenu_applicantProfile\"\u003eSynthetic applicant profile\u003c/nav\u003e\u003ch1\u003eOwned unread conversation pass\u003c/h1\u003e\n\u003cp\u003eOffline fixture. Reading a conversation clears its unread counter; sending is never requested.\u003c/p\u003e\n\u003clabel\u003e\u003cinput id=\"outer-filter\" type=\"checkbox\"\u003e\u003clabel\u003e\u003cinput type=\"checkbox\" checked data-qa=\"chatik-checkbox-only-unread\"\u003eUnread conversations only\u003c/label\u003e\u003c/label\u003e\n\u003cmain\u003e\u003cdiv id=\"list\"\u003e\u003c/div\u003e\u003csection\u003e\u003ch2 id=\"chat-title\"\u003e\u003c/h2\u003e\u003cspan data-qa=\"participant-info-title\"\u003eExample employer\u003c/span\u003e\u003cdiv data-qa=\"chatik-header-sub-header\"\u003e\u003ca href=\"https://hh.ru/vacancy/123\"\u003eExample vacancy\u003c/a\u003e\u003c/div\u003e\u003cdiv id=\"history\"\u003e\u003cdiv id=\"messages\"\u003e\u003c/div\u003e\u003c/div\u003e\u003cdiv id=\"composer\"\u003e\u003c/div\u003e\u003cbutton data-qa=\"send\"\u003eSend\u003c/button\u003e\u003c/section\u003e\u003c/main\u003e\u003cpre id=\"result\"\u003eThe owner's draft, selection and scroll must survive the pass.\u003c/pre\u003e\n\u003cscript\u003e\nconst list=document.querySelector('#list'),filter=document.querySelector('#outer-filter'),pane=document.querySelector('#history'),messages=document.querySelector('#messages');\nconst ownerDraft=false?'':Array.from({length:8},(_,i)=\u003e'Owner unfinished line '+i).join('\\n');\nconst fixture=window.fixture={sends:0,visits:[],drafts:{'7':ownerDraft,'8':'','9':''},unread:{'7':0,'8':1,'9':1},chat:'7'};\nfunction renderList(){const ids=(true?['8','1','2','7','3','9']:['8','9','7']).filter(id=\u003e!filter.checked||fixture.unread[id]\u003e0);const first=true?Math.floor(list.scrollTop/100):0;list.innerHTML='\u003cdiv style=\"position:relative;height:'+(ids.length*100)+'px\"\u003e'+ids.slice(first,true?first+3:ids.length).map((id,i)=\u003e'\u003carticle style=\"'+(true?'position:absolute;width:100%;top:'+((first+i)*100)+'px':'')+'\" data-qa=\"chatik-open-chat-'+id+'\"\u003e\u003cb data-qa=\"chat-cell-title\"\u003eEmployer '+id+'\u003c/b\u003e\u003cdiv data-qa=\"chat-last-message\"\u003eA pending question\u003c/div\u003e\u003cspan data-qa=\"chat-cell-counter\"\u003e'+fixture.unread[id]+'\u003c/span\u003e\u003c/article\u003e').join('')+'\u003c/div\u003e';for(const row of list.querySelectorAll('article'))row.onclick=()=\u003eopenChat(row.dataset.qa.replace('chatik-open-chat-',''));}\nconst messageOffset=()=\u003efalse?pane.scrollHeight-pane.clientHeight+pane.scrollTop:pane.scrollTop;\nfunction renderMessages(){const first=Math.floor(messageOffset()/100);messages.innerHTML=Array.from({length:Math.min(4,8-first)},(_,i)=\u003e{const n=first+i;return '\u003carticle style=\"top:'+(n*100)+'px\" data-qa=\"chatik-chat-message-'+(Number(fixture.chat)*100+n)+'\"\u003e'+(n===0?'\u003cb data-qa=\"chat-bubble-title\"\u003eVacancy application\u003c/b\u003e':'')+'\u003cp data-qa=\"chat-bubble-text\"\u003e'+(n===7?(null?.[fixture.chat]??'What time can you start?'):'Conversation record '+n)+'\u003c/p\u003e'+(false&&n\u003e0&&n\u003c7?'\u003cspan data-qa=\"status-icon-delivered\"\u003e\u003c/span\u003e':'')+'\u003c/article\u003e';}).join('');}\nfunction renderChat(){fixture.chat=location.pathname.match(/chat\\/(\\d+)/)?.[1]||'7';document.querySelector('#chat-title').textContent='Employer '+fixture.chat;document.querySelector('#composer').innerHTML='\u003ctextarea data-qa=\"text-input\"\u003e\u003c/textarea\u003e';const field=document.querySelector('textarea');field.value=fixture.drafts[fixture.chat]||'';field.oninput=()=\u003e{fixture.drafts[fixture.chat]=field.value;};pane.scrollTop=300;renderMessages();renderList();}\nfunction openChat(id){const field=document.querySelector('textarea');if(!(false&&fixture.chat==='7'))fixture.drafts[fixture.chat]=field.value;else fixture.drafts['7']='';fixture.visits.push(id);fixture.unread[id]=0;const url='/chat/'+id;if(false){location.href=url;return;}window.history[false?'replaceState':'pushState']({chat:id},'',url);renderChat();}\nwindow.addEventListener('popstate',()=\u003e{if(false)fixture.drafts['7']='Owner draft changed elsewhere';renderChat();});pane.addEventListener('scroll',()=\u003erenderMessages());if(true)list.addEventListener('scroll',renderList);filter.addEventListener('change',()=\u003e{list.scrollTop=0;renderList();});\nfixture.replies={};\nif(false){\n const previous=renderMessages;\n renderMessages=()=\u003e{\n  previous();\n  const reply=fixture.replies[fixture.chat];\n  messages.style.height=reply?'900px':'800px';\n  if(reply&&messageOffset()\u003e=500){\n   const row=document.createElement('article');row.dataset.qa='chatik-chat-message-'+(Number(fixture.chat)*100+8);row.style.top='800px';\n   const body=document.createElement('p');body.dataset.qa='chat-bubble-text';body.textContent=reply;row.append(body);\n   const status=document.createElement('span');status.dataset.qa='status-icon-delivered';row.append(status);messages.append(row);\n  }\n };\n}\ndocument.querySelector('button').onclick=()=\u003e{\n fixture.sends++;\n if(!false)return;\n const field=document.querySelector('textarea');fixture.replies[fixture.chat]=field.value;fixture.drafts[fixture.chat]='';field.value='';renderMessages();\n};\nrenderChat();list.scrollTop=100;const field=document.querySelector('textarea');field.setSelectionRange(6,16,'backward');field.scrollTop=24;\n\u003c/script\u003e\u003c/html\u003e","repeat":false,"reveal":true,"screenshot":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459/docs/screenshots/issue-56-unread-reveal/mcp"}))(page);
}