async (page) => (async (page, fixture) => {
  const exceptions = [];
  page.on('pageerror', (error) => exceptions.push(error.message));
  await page.addInitScript(
    ([key, value]) => globalThis.localStorage.setItem(key, value),
    fixture.tutorial
  );
  await page.goto(fixture.base);
  const verifyIntroductions = async (form, replies, words) => {
    if (fixture.alternatives) {
      for (const [index, address] of ['informal', 'formal'].entries()) {
        const name =
          address === 'informal' ? 'alternativeInformal' : 'alternativeFormal';
        if (
          (await form.locator(`[name="${name}"]`).inputValue()) !==
          fixture.alternatives[address].join('\n\n')
        ) {
          throw Error('Lost introduction catalog');
        }
        if (!fixture.alternatives[address].includes(replies[index])) {
          throw Error('Reply absent from introduction catalog');
        }
      }
      if (
        !(
          await form.locator('[data-acquaintance-catalog]').innerText()
        ).includes(words.catalogHint)
      ) {
        throw Error(`Untranslated introduction catalog`);
      }
    } else if (
      JSON.stringify(replies) !==
      JSON.stringify([fixture.informal, fixture.formal])
    ) {
      throw Error(`Unexpected private replies: ${replies}`);
    }
  };
  const capturePhone = async (form, action) => {
    await page.setViewportSize({ width: 390, height: 844 });
    await (
      fixture.kind === 'engagement'
        ? page.locator('.automation-plan [data-ordered-reply]').first()
        : fixture.alternatives
          ? form.locator('[data-acquaintance-catalog]')
          : action
    ).scrollIntoViewIfNeeded();
    if (
      !(await page.evaluate(
        () => document.documentElement.scrollWidth <= globalThis.innerWidth
      ))
    ) {
      throw Error('Personal reply phone overflow');
    }
    await page.screenshot({
      path: `${fixture.root}/docs/screenshots/issue-56-vk-${fixture.kind}/mcp-phone.png`,
    });
    await page.setViewportSize({ width: 1180, height: 950 });
  };
  const result = [];
  let firstReplies;
  for (const [language, words] of Object.entries(fixture.words)) {
    await page.evaluate(
      (language) =>
        globalThis.localStorage.setItem('metaSovereignLocale', language),
      language
    );
    await page.goto(`${fixture.base}/?${fixture.kind}=${language}#/automation`);
    await page
      .locator(`[data-automation="automation:${fixture.kind}"]`)
      .click();
    const form = page.locator('.automation-editor');
    const action = form.locator('[name="actionKind"]');
    if ((await form.locator('[name="cooldownDays"]').inputValue()) !== '1') {
      throw Error('Lost daily cooldown');
    }
    if ((await action.locator('option:checked').innerText()) !== words.kind) {
      throw Error(`Untranslated ${language} action`);
    }
    if (
      (await form.locator('[name="incomingRecognizer"]').inputValue()) !==
      fixture.kind
    ) {
      throw Error('Lost personal reply recognizer');
    }
    if (language === 'en') {
      await form.locator('[name="informal"]').fill(fixture.informal);
      await form.locator('[name="formal"]').fill(fixture.formal);
      if (fixture.alternatives) {
        await form
          .locator('[name="alternativeInformal"]')
          .fill(fixture.alternatives.informal.join('\n\n'));
        await form
          .locator('[name="alternativeFormal"]')
          .fill(fixture.alternatives.formal.join('\n\n'));
      }
      const put = page.waitForResponse(
        (r) =>
          r.url().endsWith('/api/automations') && r.request().method() === 'PUT'
      );
      await form.getByRole('button', { name: words.save, exact: true }).click();
      if ((await put).status() !== 200) {
        throw Error('Personal reply save failed');
      }
      await page.reload();
      await page
        .locator(`[data-automation="automation:${fixture.kind}"]`)
        .click();
    }
    if (
      (await form.locator('[name="formal"]').inputValue()) !== fixture.formal ||
      (await form.locator('[name="informal"]').inputValue()) !==
        fixture.informal
    ) {
      throw Error('Personal reply variants changed');
    }
    const request = page.waitForResponse((r) =>
      r.url().endsWith('/api/automations/plan')
    );
    await form
      .getByRole('button', { name: words.preview, exact: true })
      .click();
    if ((await request).status() !== 200) {
      throw Error('Personal reply preview failed');
    }
    const replies = await page
      .locator('.automation-plan blockquote')
      .allTextContents();
    await verifyIntroductions(form, replies, words);
    if (fixture.kind === 'engagement') {
      const reviews = page.locator('.automation-plan [data-ordered-reply]');
      if ((await reviews.count()) !== 2) {
        throw Error('Missing ordered personal reply reviews');
      }
      for (const review of await reviews.all()) {
        if (
          (await review.locator('[data-ordered-step]').count()) !== 2 ||
          !(await review.innerText()).includes(words.orderedHint) ||
          !(
            await review.locator('[data-ordered-step="1"]').innerText()
          ).includes('59431')
        ) {
          throw Error('Missing translated sticker-first ordered review');
        }
      }
    }
    if (
      firstReplies &&
      JSON.stringify(firstReplies) !== JSON.stringify(replies)
    ) {
      throw Error('Reply choice changed on repeated review');
    }
    firstReplies = replies;
    if (language === 'en') {
      await capturePhone(form, action);
    }
    result.push({
      language,
      translated: true,
      retainedVariants: true,
      privateReplies: 2,
      stableAlternatives: Boolean(fixture.alternatives),
      ...(fixture.kind === 'engagement' ? { orderedSteps: 2 } : {}),
    });
  }
  if (exceptions.length) {
    throw Error(JSON.stringify(exceptions));
  }
  return { result, exceptions, liveProvider: false };
})(page, {"kind":"engagement","base":"http://127.0.0.1:36175","root":"/tmp/gh-issue-solver-resume-01a1bfa4-bdec-7780-9e26-c4c5ae2e7a00-1794478565459","informal":"Informal engagement \u003cMCP\u003e & 👋","formal":"Formal engagement \u003cMCP\u003e & 👋","alternatives":{"informal":["Informal catalog \u003cone\u003e & 👋","Informal catalog \u003ctwo\u003e & 👋"],"formal":["Formal catalog \u003cone\u003e & 👋","Formal catalog \u003ctwo\u003e & 👋"]},"tutorial":["metaSovereignTutorial","{\"off\":true,\"v\":5}"],"words":{"en":{"kind":"Introduce yourself after a negative acquaintance answer","save":"Save","preview":"Preview","catalogHint":"Separate alternatives with a blank line; up to 32 per form, 4096 characters each. A reply is selected consistently for each incoming message. Leave a list empty to use the ordinary text variant below.","orderedHint":"Send the sticker first, then the introduction. Each step has its own receipt. An uncertain step needs manual outbox review; a definite failure can resume after another review."},"ru":{"kind":"Представиться после отрицательного ответа о знакомстве","save":"Сохранить","preview":"Предпросмотр","catalogHint":"Разделяйте варианты пустой строкой: до 32 на форму, до 4096 символов каждый. Для каждого входящего сообщения выбор сохраняется. Пустой список использует обычный текст ниже.","orderedHint":"Сначала отправляется стикер, затем представление. Для каждого шага сохраняется отдельное подтверждение. При неизвестном результате проверьте исходящие вручную; явный отказ можно повторить после нового просмотра."},"hi":{"kind":"परिचय से इनकार के बाद अपना परिचय दें","save":"सहेजें","preview":"पूर्वावलोकन","catalogHint":"विकल्पों को खाली पंक्ति से अलग करें: हर संबोधन के लिए अधिकतम 32, प्रत्येक 4096 अक्षर तक। हर आने वाले संदेश के लिए चयन स्थिर रहता है। खाली सूची नीचे का सामान्य पाठ चुनती है।","orderedHint":"पहले स्टिकर, फिर परिचय भेजें। हर चरण की अलग रसीद है। अनिश्चित चरण के लिए आउटबॉक्स में स्वयं जाँचें; निश्चित विफलता की नई समीक्षा के बाद आगे बढ़ सकते हैं।"},"zh":{"kind":"在对方否认曾交谈后自我介绍","save":"保存","preview":"预览","catalogHint":"用空行分隔备选回复；每种称呼最多 32 条，每条不超过 4096 字符。每条收到的消息保持相同选择。列表留空时使用下方的普通文本。","orderedHint":"先发送贴纸，再发送介绍。每一步单独保留回执。结果不明时请手动检查发件箱；明确失败后可重新审阅并继续。"}}})