// Observed message content is append-only, independently of the service's
// retention. Save both sides before replacing a message; never scan the archive
// on a write or create versions for read receipts, counters or tombstones.
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import { changedLink, replicatedMutation } from './mutation.js';
import { syncRecords } from './sync-deletions.js';
import { isTombstone } from './soft-delete.js';
import { SYNC_STAMP } from '../sync/register.js';
import {
  VERSION_PREFIX,
  importMessageVersions,
  messageVersionPrefix,
} from './message-version-id.js';

export { VERSION_PREFIX } from './message-version-id.js';
export const isMessageVersion = (link) => link?.kind === 'message-version';
const isMessage = (link) => String(link?.id ?? '').startsWith('msg:');
const wrapped = new WeakMap();
const volatile = new Set([
  'fileReference',
  'accessHash',
  'dcId',
  'views',
  'forwards',
  'reactions',
  'results',
]);
const stable = (value) => {
  if (Array.isArray(value)) {
    return value.map(stable);
  }
  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.keys(value)
        .sort()
        .filter((key) => !volatile.has(key))
        .map((key) => [key, stable(value[key])])
    );
  }
  return typeof value === 'bigint' ? String(value) : value;
};
const content = (link) =>
  JSON.stringify(
    stable({
      body: link.body ?? link.raw?.message ?? '',
      subject: link.subject ?? '',
      entities: link.raw?.entities ?? link.entities ?? [],
      media: link.raw?.media ?? link.media ?? link.attachments ?? null,
      buttons: link.raw?.replyMarkup ?? link.replyMarkup ?? null,
    })
  );
const hash = (value) => createHash('sha256').update(value).digest('hex');
const editedAt = (link) => {
  const value =
    typeof link.edited === 'string' ? link.edited : link.raw?.editDate;
  if (!value) {
    return null;
  }
  const number = Number(value);
  const ms = Number.isFinite(number)
    ? number * (number < 1e12 ? 1000 : 1)
    : Date.parse(value);
  return Number.isFinite(ms) ? new Date(ms).toISOString() : null;
};
const snapshot = (link) => {
  const {
    versionHead: _head,
    versionCount: _count,
    versionPartial: _partial,
    ...rest
  } = link;
  return globalThis.structuredClone(rest);
};
const version = (link, parent, at) => {
  const id = `${messageVersionPrefix(link.id)}${hash(JSON.stringify([content(link), editedAt(link), parent]))}`;
  return {
    id,
    tokens: ['message-version'],
    kind: 'message-version',
    messageId: link.id,
    ...(link.source !== undefined ? { source: link.source } : {}),
    ...(link.chat !== undefined ? { chat: link.chat } : {}),
    capturedAt: at,
    editedAt: editedAt(link),
    previous: parent ?? null,
    snapshot: snapshot(link),
  };
};
const changeKind = (before, link) => {
  if (!before) {
    return null;
  }
  if (content(before) !== content(link)) {
    return 'edit';
  }
  return isTombstone(link) && !isTombstone(before) ? 'delete' : null;
};

const writeVersionBatch = async (inner, records, options, single = false) => {
  if (!records.length) {
    return [];
  }
  if (single && records.length === 1) {
    return [await inner.put(records[0], options)];
  }
  if (inner.putMany) {
    return inner.putMany(records, options);
  }
  const output = [];
  for (const record of records) {
    output.push(await inner.put(record, options));
  }
  return output;
};

const importRecordedHistory = async (inner, link, earlierTexts, history) => {
  // A newer observation or an explicit local hard delete takes precedence.
  if (
    (await inner.get(link.id)) ||
    (await inner[syncRecords]?.has?.(link.id))
  ) {
    return null;
  }
  if (!earlierTexts.length) {
    return link;
  }
  const texts = [...earlierTexts, link.body];
  let head = null;
  for (const body of texts) {
    const record = version({ ...link, body }, head, null);
    if (!(await inner.get(record.id))) {
      history.push(record);
    }
    head = record.id;
  }
  return {
    ...link,
    versionHead: head,
    versionCount: texts.length,
    versionPartial: true,
  };
};

const versionWriter = (inner, { now, preserve, indexVersions }) => {
  const guard = async (link) => {
    if (!String(link?.id).startsWith(VERSION_PREFIX)) {
      return;
    }
    const before = await inner.get(link.id);
    const immutable = (record) => {
      const {
        assets: _assets,
        vc: _clock,
        [SYNC_STAMP]: _stamp,
        ...rest
      } = record;
      return rest;
    };
    if (before && !isDeepStrictEqual(immutable(before), immutable(link))) {
      throw Object.assign(new Error('saved message versions are immutable'), {
        code: 'VERSION_IMMUTABLE',
      });
    }
  };
  const changed = async (
    before,
    link,
    { pending, history, after },
    deleted = false
  ) => {
    const at = now();
    const old = version(before, null, at);
    const parent = before.versionHead ?? old.id;
    const partial = before.versionHead
      ? Boolean(before.versionPartial)
      : Boolean(before.edited || before.raw?.editDate);
    const current = version(link, parent, at);
    const previous = pending.get(parent) ?? (await inner.get(parent)) ?? old;
    const finish = await preserve(previous, {
      before,
      next: link,
      cached: !pending.has(link.id),
    });
    if (typeof finish === 'function') {
      after.push(finish);
    }
    history.push(previous);
    pending.set(previous.id, previous);
    if (deleted) {
      return {
        ...link,
        versionHead: parent,
        versionCount: before.versionCount ?? 1,
        versionPartial: partial,
      };
    }
    if (!pending.has(current.id) && !(await inner.get(current.id))) {
      history.push(current);
      pending.set(current.id, current);
    }
    return {
      ...link,
      versionHead: current.id,
      versionCount: (before.versionCount ?? 1) + 1,
      versionPartial: partial,
    };
  };
  const currentMessage = async (link, state) => {
    const before = state.pending.get(link.id) ?? (await inner.get(link.id));
    const kind = changeKind(before, link);
    if (kind) {
      return changed(before, link, state, kind === 'delete');
    }
    return before?.versionHead
      ? {
          ...link,
          versionHead: before.versionHead,
          versionCount: before.versionCount,
          versionPartial: Boolean(before.versionPartial),
        }
      : link;
  };
  return async (links, single = false, options, recording) => {
    const pending = new Map();
    const writes = [];
    const history = [];
    const after = [];
    for (const link of links) {
      if (
        !isMessage(link) ||
        (inner[syncRecords] && options?.[replicatedMutation])
      ) {
        if (!isMessage(link)) {
          await guard(link);
        }
        writes.push(link);
        continue;
      }
      if (recording?.has(link.id)) {
        if (!pending.has(link.id)) {
          const next = await importRecordedHistory(
            inner,
            link,
            recording.get(link.id),
            history
          );
          if (next) {
            pending.set(link.id, next);
            writes.push(next);
          }
        }
        continue;
      }
      const next = await currentMessage(link, { pending, history, after });
      pending.set(link.id, next);
      writes.push(next);
    }
    await writeVersionBatch(inner, history, options);
    indexVersions(history);
    for (const finish of after) {
      await finish();
    }
    const output = await writeVersionBatch(inner, writes, options, single);
    indexVersions(writes);
    return output;
  };
};

/** Wrap any store; the returned store retains lifecycle/handoff methods. */
export const withMessageVersions = (
  inner,
  {
    now = () => new Date().toISOString(),
    preserve = async () => {},
    purgeMedia = async () => {},
  } = {}
) => {
  if (wrapped.has(inner)) {
    return wrapped.get(inner);
  }
  let tail = Promise.resolve();
  let versionIds = null;
  const indexVersions = (records) => {
    if (!versionIds) {
      return;
    }
    for (const record of records.filter(isMessageVersion)) {
      const ids = versionIds.get(record.messageId) ?? new Set();
      ids.add(record.id);
      versionIds.set(record.messageId, ids);
    }
  };
  const versionsFor = async (id) => {
    if (!versionIds) {
      versionIds = new Map();
      if (inner.scan) {
        await inner.scan(isMessageVersion, 500, indexVersions);
      } else {
        indexVersions(await inner.query(isMessageVersion));
      }
    }
    return (
      await Promise.all(
        [...(versionIds.get(id) ?? [])].map((key) => inner.get(key))
      )
    ).filter(Boolean);
  };
  const enqueue = (run) => {
    const result = tail.then(run);
    tail = result.catch(() => {});
    return result;
  };
  const prepare = versionWriter(inner, { now, preserve, indexVersions });
  const result = Object.defineProperties(
    {},
    Object.getOwnPropertyDescriptors(inner)
  );
  // Causal production peers replicate the origin's immutable revision records
  // separately. Generating new revisions from a delayed losing message could
  // retain text that its causal hard-delete has already erased.
  const originHistory = (options) =>
    inner[syncRecords] && options?.[replicatedMutation];
  result[importMessageVersions] = (links, recording, options) =>
    enqueue(() => prepare(links, false, options, recording));
  result.put = (link, options) =>
    originHistory(options) && isMessage(link)
      ? enqueue(() => inner.put(link, options))
      : isMessage(link) || String(link?.id).startsWith(VERSION_PREFIX)
        ? enqueue(async () => (await prepare([link], true, options))[0])
        : inner.put(link, options);
  result.update = (id, change, options) =>
    originHistory(options) && String(id).startsWith('msg:')
      ? enqueue(() => inner.update(id, change, options))
      : String(id).startsWith('msg:') || String(id).startsWith(VERSION_PREFIX)
        ? enqueue(async () => {
            const next = changedLink(id, change, await inner.get(id));
            return (await prepare([next], true, options))[0];
          })
        : inner.update(id, change, options);
  result.putMany = (links, options) =>
    links.some(
      (link) => isMessage(link) || String(link?.id).startsWith(VERSION_PREFIX)
    )
      ? enqueue(() => prepare(links, false, options))
      : inner.putMany
        ? inner.putMany(links, options)
        : Promise.all(links.map((link) => inner.put(link, options)));
  result.delete = (id, options) =>
    !String(id).startsWith('msg:')
      ? inner.delete(id, options)
      : enqueue(async () => {
          // Validate and merge an incoming deletion before erasing revisions.
          // A delayed deletion can lose to an explicit recreation; malformed
          // metadata must not erase any current message history either.
          let removed;
          if (originHistory(options)) {
            removed = await inner.delete(id, options);
            if (await inner.get(id)) {
              return removed;
            }
          }
          // Hard deletion is already an explicitly confirmed local operation. Its
          // saved text must be erased too, rather than left as hidden revision links.
          const records = await versionsFor(id);
          for (const record of records) {
            await inner.delete(record.id, options);
          }
          removed ??= await inner.delete(id, options);
          versionIds.delete(id);
          await purgeMedia(records, inner);
          return removed;
        });
  for (const name of [
    'flush',
    'flushLog',
    'prepareHandoff',
    'releaseForHandoff',
    'close',
  ]) {
    if (typeof inner[name] === 'function') {
      result[name] = async (...args) => {
        await tail;
        return inner[name](...args);
      };
    }
  }
  wrapped.set(inner, result);
  wrapped.set(result, result);
  return result;
};

/** Read the immutable chain by ID, without querying unrelated messages. */
export const messageVersions = async (
  store,
  id,
  { before, limit = 50 } = {}
) => {
  const message = await store.get(id);
  const versions = [];
  const seen = new Set();
  let cursor = before ?? message?.versionHead;
  while (cursor && !seen.has(cursor) && versions.length < limit) {
    seen.add(cursor);
    const record = await store.get(cursor);
    if (!isMessageVersion(record) || record.messageId !== id) {
      break;
    }
    versions.push(record);
    cursor = record.previous;
  }
  if (!versions.length && message && !before) {
    versions.push({
      messageId: id,
      capturedAt: null,
      editedAt: editedAt(message),
      snapshot: snapshot(message),
    });
  }
  return {
    message,
    versions,
    next: cursor && !seen.has(cursor) ? cursor : null,
  };
};
